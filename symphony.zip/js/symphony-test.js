/*
 *	QUnit is a prerequisite for the 'runQUnitTests/equal/notEqual/OK' methods.
 *		This file complies with QUnit 2.x standards (QUnit.start()** and QUnit.stop() replaced with assert.async()).
 *		Please include QUnit in your app before using this method.
 *		This file does not use QUnit.start() or modify the QUnit.config.autostart option, this is up to the consumer.
 *		Controlling when QUnit starts is up to any consumer of this file. Please create the following divs:
 *  		<div id='qunit'></div>
 *  		<div id='qunit-fixture'></div>
 *  These divs have to be available before QUnit is started (eg, if these divs are in a workspace that is not visible
 *  	yet, then set 'QUnit.config.autostart = false' and then programmatically call QUnit.start())
 *
 *  **Even though the QUnit stop and start methods are deprecated for asynchronous asserts,
 *  	in QUnit 2.x, QUnit.start() is still used for starting QUnit when 'QUnit.config.autostart = false'.
 */

$.Class('infa.tests.TestUtils',
{
	_instance: undefined,

	instance: function(){
		if (!infa.tests.TestUtils._instance) {
			infa.tests.TestUtils._instance = new infa.tests.TestUtils();
		}
		return infa.tests.TestUtils._instance;
	}
},
{
	runQUnitTests: function(groupId) {
		var self = this;
		var reader = infa.extensibility.ExtensionReader.instance();
		reader.read('com.informatica.tools.w3.tests.testProvider').done(
			function(extensions) {
				self._runAllTests(extensions, groupId).always(function(){
					$(document).trigger('SymphonyQUnitTestsRunCompleted');
				});
			}
		);
	},

	/**
	 * Runs all test suites in serial order waits till previous test suites is completed using jQuery Deferred & then.
	 */
	_runAllTests: function(extensions, groupId) {
		var self = this;
		var $deferred = $.Deferred(function(DFD){
			if (extensions.length>1) {
				var defs = [$.Deferred()];
				for (var n=1; n<extensions.length-1; n++){
					(function(n){
						defs.push($.Deferred());
						defs[n-1].then(function(){
							self._runTest(extensions[n], defs[n], groupId);
						});
					})(n);
				};

				defs[(extensions.length-2)].then(function(){
					self._runTest(extensions[extensions.length -1 ], DFD, groupId);
				});

				self._runTest(extensions[0], defs[0], groupId);

			} else if (extensions.length>0) {
				self._runTest(extensions[0], DFD, groupId);
			} else {
				DFD.resolve();
			};
		});

		return $deferred.promise();
	},

	_runTest: function(extension, $def, groupId) {
		var self = this;
		if(extension.$groupId === groupId){
			var extnSplit = extension.$jsCallback.split('.'),
				extnName = extnSplit.length > 1 ? extnSplit[1] : extnSplit[0],
				jsCallback =  $.toFunction(extension.$jsCallback);

			if(jsCallback) {
				var jsCallbackInst = new jsCallback(),
					testDivId = $.htmlId(extnName);

				//QUnit automatically cleans up the qunit-fixture div
				QUnit.test(extnName, function(assert) {
					self.assert = assert;
					var done = assert.async();
					$.when(jsCallbackInst.initialize('qunit-fixture')).always(function(){
						done();
						$def.resolve();
					});
				});
			} else {
				infa.utils.Utils.instance().logError('jsClass ' + extension.$jsCallback + ' not found');
				$def.resolve();
			}
		} else {
			$def.resolve();
		}
	},

	runAllTestMethods: function(testObj, methods) {
		var self = this;
		var $deferred = $.Deferred(function(DFD){
			if (methods.length>1) {
				var defs = [$.Deferred()];
				for (var n=1; n<methods.length-1; n++){
					(function(n){
						defs.push($.Deferred());
						defs[n-1].then(function(){
							self._runTestMethod(testObj, methods[n], defs[n]);
						});
					})(n);
				};

				defs[(methods.length-2)].then(function(){
					self._runTestMethod(testObj, methods[methods.length -1 ], DFD);
				});

				self._runTestMethod(testObj, methods[0], defs[0]);

			} else if (methods.length>0) {
				self._runTestMethod(testObj, methods[0], DFD);
			} else {
				DFD.resolve();
			};
		});

		return $deferred.promise();
	},

	_runTestMethod: function(testObj, method, $def) {
		if(method in testObj) {
			$.when(testObj[method].call(testObj)).always(function(){
				$def.resolve();
			});
		} else {
			this.ok(undefined, 'Method not found - ' + method);
			$def.resolve();
		}
	},

	waitForMilliSeconds: function(n) {
		var dfd = $.Deferred();
		setTimeout(function(){dfd.resolve();},n);

		return dfd.promise();
	},

	equal: function(actual, expected, message, assert) {
		this.assert.equal(actual, expected, message);
	},

	notEqual: function(actual, expected, message, assert) {
		this.assert.notEqual(actual, expected, message);
	},

	ok: function(result, message, assert) {
		this.assert.ok(result, message);
	}
});