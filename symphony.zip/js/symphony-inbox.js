$.infaNamespace('infaw.humantask');
(function( $ ){
infaw.humantask.I18nResources = {
  TASK_NAME : 'Task name',
  DESCRIPTION : 'Description',
  OWNER : 'Owner',
  STATUS : 'Status',
  SAVE : 'Save',
  DUE_DATE : 'Due Date',
  USER_CONCAT : 'User',
  GROUP_CONCAT : 'Group',
  CREATED_STATUS : 'Created',
  ASSIGNED_STATUS : 'Assigned',
  COMPLETED_STATUS : 'Completed',
  OWNER_INVALID : 'Owner is invalid'
  
}}(jQuery));

$.Class('infaw.humantask.TaskUtils',
// static methods 
{  
	_instance : undefined,
  
	instance : function(){
		if (!infaw.humantask.TaskUtils._instance) {
			infaw.humantask.TaskUtils._instance = new infaw.humantask.TaskUtils();
		}
		return infaw.humantask.TaskUtils._instance;
	}        
},
// prototype methods
{
	init: function() {
		this._taskType2MixinMap = {};
	},
	/**
	 * This function accepts a taskType and returns the associated mixin name
	 */
	
	getMixinName: function(taskType){
		var self = this;
		return this.initialize().then(function(){
			return self._taskType2MixinMap[taskType];			
		});		
	},
	
	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();		
			this.$intializedDef = $.when(reader.read('com.informatica.imf.mixin'))
					.then(function(mixinInfoExtns) {
						self._mixinInfoExtns = mixinInfoExtns; 
						self._processExtns();
					});
		}
		return this.$intializedDef.promise();		
	},
	
	_processExtns: function() {
		var self = this;
		
		$.each(this._mixinInfoExtns, function(index, extension){
			var taskType,
			condition = extension.$condition,
			name = extension.$name;
			if(name && condition && condition.match("^taskType=")){
				taskType =  condition.substring(9);
				self._taskType2MixinMap[taskType] = name;
			}
		});
	},
	
	// label to display in the UI
	getStatusLabel: function(statusEnum) {
		
		var $i18nAlias = infaw.humantask.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		
		switch (statusEnum) {
		case "INFA_CREATED": 
			return $textUtils.getText($i18nAlias.CREATED_STATUS);
		case "INFA_ASSIGNED":
			return $textUtils.getText($i18nAlias.ASSIGNED_STATUS);
		case "INFA_COMPLETED":
			return $textUtils.getText($i18nAlias.COMPLETED_STATUS);
		}
	},
	
	getStatusEnum: function(serviceStatus) {
		
		var $i18nAlias = infaw.humantask.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();
		
		switch (serviceStatus) {
			case "Created": 
			case "Submitted":	
			case "Opened":
				return "CREATED";
			
			case "Assigned":
				return "ASSIGNED";
			
			case "Completed":
			case "Resolved":
			case "Closed":
				return "COMPLETED";								
		}
	},
	
	isTask: function(metaClassId) {
		return infa.imf.IClassInfo.instance().isSelfOrSuperClass(metaClassId, 'com.informatica.metadata.common.humantask.AbstractHumanTask')
	}
}
);
(function ($) {
	
	//static variables
	var widgetName = 'infaUserGroupPickerInput';
	var inputStub = '<input class="infaField"></input>';
	
	$.widget('infa.infaUserGroupPicker', { 
		
		_inputControl: null,
		
		_autoComWidget: null,
		
		options: {
			type : '',
			selection: 'user' //the values could be user/group/both
		},		
	
		_create: function() {
			if(this.options.type === ''){
				return;
			}
			var inputId = $.htmlId(widgetName);
			this._inputControl = $(inputStub).appendTo(this.element);
			this._inputControl.attr('id', inputId);
			if(this.options.selection === 'both'){
				this._inputControl.infaAutoComplete({categorized: true});
			}else{
				this._inputControl.infaAutoComplete();
			}
			this._autoComWidget = $.getWidget(this._inputControl,'infaAutoComplete');
			this._autoComWidget.setDataSource($.url('/web.humantask/infaUserProvider?' + infa.utils.Utils.instance().getTokenParam() + '&picker='+ this.options.selection+'&type='+this.options.type));
		},
		
		getValue: function(){
			return this._inputControl.val();
		},
		
		setValue: function(value){
			this._inputControl.val(value);
			return this;
		},			
		
		setValidLook: function(){
			this._inputControl.removeClass('infaFieldInvalid')
			.removeAttr('aria-invalid');
			return this;
		},
		setInvalidLook: function(){
			this._inputControl.addClass('infaFieldInvalid')
			.attr('aria-invalid', 'true');
			return this;
		},
	    isValidLook: function(){
			return !this._inputControl.hasClass('infaFieldInvalid'); 
	    },
		
	    focus: function(){
	    	this._inputControl.focus();
	    	return this;
	    },
	    
		destroy: function(){
			this._autoComWidget.destroy();
			this.element.empty();
			$.Widget.prototype.destroy.call( this );
		}
		
		
	});
	
}(jQuery));
/**
 * Task Provider Manager
 * @author Madhu 
 */

$.Class("infaw.humantask.TaskProviderManager", 
{
	_instance : undefined,

	instance : function(){
		var taskProviderManager = infaw.humantask.TaskProviderManager;
		if (taskProviderManager._instance === undefined) {
			taskProviderManager._instance = new infaw.humantask.TaskProviderManager();
		}
		return taskProviderManager._instance;
	}
},
{	 
	_extns: [],

	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();		
			this.$intializedDef = reader.read("com.informatica.tools.model.humantask.TaskProvider").then(	
					function(extensions) {	
						self._extns = extensions;
						return;
					}
			);
		}
		return this.$intializedDef.promise();		
	},
	

	getTaskType2MetaClassMap: function() {
		var self = this,
			taskType2MetaClassMap ={};
		return this.initialize().then(function(){
			$.each(self._extns, function(index, extn){
				var supportedTaskTypes = extn.supportedTaskType;
				if(supportedTaskTypes) {
					if(!$.isArray(supportedTaskTypes)) {
						supportedTaskTypes = [supportedTaskTypes];
					}
					
					$.each(supportedTaskTypes, function(index, supportedTaskType) {
						taskType2MetaClassMap[supportedTaskType.$taskType] = supportedTaskType.$$metaClass;
					});
				}
			});
			
			return taskType2MetaClassMap;
		});
		
		return taskType2MetaClassMap;
	}
});
$.infaNamespace('infaw.inbox');
(function( $ ){
infaw.inbox.I18nResources = {
  TASK_GRID_EMPTY_RECORDS_MESSAGE : 'No tasks to view',
  REASSIGN_TASK : 'Reassign Task',
  ASSIGN : 'Assign',
  CANCEL : 'Cancel',
  COMMENTS : 'Comments',
  TYPE_TO_FILTER : 'Type to filter',
  DISPLAY_NAME : 'Display Name',
  USER_NAME : 'User Name',
  REFRESH_BUTTON_LABEL : 'Refresh',
  TASK_GRID_ITEMS_LABEL : 'Tasks',
  TASK_GRID_OF_LABEL : 'of',
  TASK_GRID_SELECTED_LABEL : 'Selected',
  TASK_GRID_FILTER_LABEL : 'Filter',
  INFA_UNCLAIMED : 'Unclaimed',
  INFA_ASSIGNED : 'Assigned',
  INFA_STARTED : 'Started',
  INFA_SUSPENDED : 'Suspended',
  INFA_CREATED : 'Created',
  INFA_COMPLETED : 'Completed',
  INFA_CLAIMED : 'Claimed',
  INFA_SUBMITTED : 'Submitted',
  INFA_OPENED : 'Open',
  INFA_CLOSED : 'Closed',
  INFA_FAILED : 'Failed',
  INFA_ERROR : 'Error',
  INFA_EXITED : 'Exited',
  INFA_OBSOLETE : 'Obsolete'
  
}}(jQuery));

/**
 * @author akukreja 
 * Task Inbox portlet callback
 * 
 */

infaw.portlet.AbstractPortlet.extend('infaw.TaskInbox', 
{
	_counter: 0
},
{
	init: function(blockElementId, instanceId, customPropMap) {
		this._super(blockElementId, instanceId, customPropMap);
		var $portlet = this.getPortletElem(),
			self = this;
		
		$portlet.css('overflow', 'hidden');
		var taskGridOptMgr = infaw.inbox.TaskGridOptionsManager.instance();
		this._hiddenColumns = undefined;
		this._workspaceInst = infaw.portlet.PortletUtils.instance().getWorkspace($portlet);		
		this.taskObjectMgr = infaw.inbox.TaskObjectManager.instance();
		this.taskGridOptMgr = infaw.inbox.TaskGridOptionsManager.instance();
		this.userID = $.cookie('userID');
		this._storage = 'tasks';
		this._resultSetName = "taskinbox" + infaw.workspace.WorkspaceManager.instance().getTabCounter() + '_' + (infaw.TaskInbox._counter++);
		this.i18nAlias = infaw.inbox.I18nResources;
		this.textUtils = infa.i18n.TextUtils.instance();
		 
		$.when(this.taskObjectMgr.initialize(),this.taskGridOptMgr.initialize()).then(function(){
			self._hiddenColumns = taskGridOptMgr.getHiddenColumns();
			self.createInboxGrid();
			self.registerEvent();				
		});
	},
	
	createInboxGrid: function() {
		var self = this;
		this.$extnTaskGrid = $('<div id="' + $.htmlId('in') + '"></div>').appendTo(this.getPortletElem());
		this.taskInboxRowModel = new infaw.inbox.TaskGridRowModel(this._getWorkspaceInst(), this._resultSetName);		
		
		this.$extnTaskGrid = this.$extnTaskGrid.extensibleGrid({
			hiddenDefaultColumns: this._hiddenColumns,
			autowidth: true,
			rowModel: this.taskInboxRowModel,
			widgetId: 'inbox.extensibleTaskGrid',
			useMenu: true,
			menuId: 'inbox.taskGrid',
			actionsMenuColumn: true,
			delaySelectionEvent: false,
			dataBinding: true,
			lazy: true,
			pagination: true,
			rowNum: 60,  			
			infiniteScroll: true,
			altRows: false,
			sortname: 'dueDate',
			filterToolbar: true,
			filterToolbarOptions: {
				autosearch: true,
				searchOnEnter: false,
				hideCount: 0,
			},			
			detailView: this.taskGridOptMgr.showExpandableColumn(),
			detailViewOptions	: {
				hideEmptyValueProperty: true
			},
			subGridOptions: {
				expandAllButton: true
			},
			checkboxes: true,
			emptyrecordsMsg: this.textUtils.getText(this.i18nAlias.TASK_GRID_EMPTY_RECORDS_MESSAGE),
			recordCount: {
				show	: true,
				itemsLabel: this.textUtils.getText(this.i18nAlias.TASK_GRID_ITEMS_LABEL),
				ofLabel		: this.textUtils.getText(this.i18nAlias.TASK_GRID_OF_LABEL),
				selectedLabel: this.textUtils.getText(this.i18nAlias.TASK_GRID_SELECTED_LABEL)
			},			
			border: false
		});
		
		this.extnTaskGrid = $.getWidget(this.$extnTaskGrid, 'infaGrid');
		
		var taskType = (this._customPropMap && this._customPropMap.taskType) ? this._customPropMap.taskType : undefined;
		
		this.taskInboxRowModel.setTaskView(taskType);
		
		this._curTaskView = taskType;
	
		return $.when(this.extnTaskGrid.processExtensions(),
				this._setSupportedTaskType2MetaClassMap()).then(function(){
			self.resizeGridDimension();
			self.taskInboxRowModel.setColumnNames(self.extnTaskGrid.getColumnNames());
			self.extnTaskGrid.loadData();
			self.refreshMenu();
		});	
		
	},
		
	getGrid: function() {
		return this.extnTaskGrid;
	},
	
	getSelection: function() {
	},
	
	registerEvent: function() {
		var self = this;
		var eventMgr = this._getEventManager();
		if (eventMgr) {
			eventMgr.registerEvents({				
				'onSave': function(event, taskObject){
					// refresh the grid on save
					if(taskObject && $(taskObject).data('new')) {
						//New task object added
						self.taskInboxRowModel.tasks= undefined;
						self.extnTaskGrid.empty();
						self.extnTaskGrid.loadData();
					} else {
						//Edit task object
						self.extnTaskGrid.deselectRow();
						self.refreshMenu();
					}

				},
				'onDelete': function(){
					// support multiple object delete
					if (arguments){
						var deletedObjects = $.makeArray(arguments).splice(1);  // first argument is the event
						return self._removeObjectsFromGrid(deletedObjects);
					}
				}
			});						
		}
		
		this.getPortletElem().on('onResize', function() {
			self.resizeGridDimension();
		});

		this.$extnTaskGrid.on({
			'onSelectRow' :  $.proxy(function(evt, row, value) {
				var selectedObj= self.extnTaskGrid.getRowDataObject(row);
				if (eventMgr) {	
					eventMgr.sendEvent('onSelectChange', [selectedObj]);					
				}
				// need to tell row model to remember the selection events
				self.taskInboxRowModel.updateSelectedRows(selectedObj, value);
			}, this),
			'onSortCol' : function(event) {
				eventMgr.sendEvent('clearSelection');
			},
			'onHrefClick' : function(e, row) {
				var clickedObj = self.extnTaskGrid.getRowDataObject(row);	
				self.taskObjectMgr.executeTaskAction([clickedObj.taskType], [clickedObj]);				
			}, 
			'onSelectAll' : function (evt, value, allRowIds) {
				for (var i = 0; i < allRowIds.length; i++){
					var selectedObj = self.extnTaskGrid.getRowDataObject({id:allRowIds[i]});
					self.taskInboxRowModel.updateSelectedRows(selectedObj, value);
				}
				if (eventMgr) {	
					eventMgr.sendEvent('onSelectChange');					
				}
			},
			
			'onDataProviderLoad': function(event, startIndex, endIndex){
				
			    var firstRowIndex = startIndex + 1;			    
				var rowCount = self.extnTaskGrid.rowCount();					
				var lastRowIndex = Math.min(rowCount, endIndex);
		
				for(var i=firstRowIndex; i<=lastRowIndex; i++){				
					var row = self.extnTaskGrid.getRowByIndex(i);						
					var rowObj = self.extnTaskGrid.getRowDataObject(row);						
					var userId = rowObj.owner;				

					var $deferred = infa.users.UserInfoManager.instance().getUserInfo(userId, -1);
					$.when($deferred).then(function(userInfo){			
						infaw.shell.common.Utils.addUserTooltip($(self.extnTaskGrid.getCellByIndex(i, 'owner')), userInfo);	
					});	

				}
							

			},
			
			
			
			'onDetailViewRendered': function(event, subgridId, subGridColumnInfo, rowDataObj, rowValue) {
				
				var userId = rowDataObj.owner;	
				var $deferred = infa.users.UserInfoManager.instance().getUserInfo(userId, -1);
				var that = this;
				$.when($deferred).then(function(userInfo){			
				    infaw.shell.common.Utils.addUserTooltip(self.extnTaskGrid.getDetailViewValueCell(subgridId, "owner", subGridColumnInfo, rowValue), userInfo);		
			   });	
				
					
			}
		});
			
	},
	
	resizeGridDimension: function() {
		var grid = $.getWidget(this.$extnTaskGrid, 'infaGrid');
		var $portlet = this.getPortletElem();
		var portletWidth = $portlet.width();
		if(portletWidth > 0) {
			grid.setWidth(portletWidth);	
		}
		
		var portletHeight = $portlet.height();
		if(portletHeight > 0) {
			grid.setHeight(portletHeight - 50 - 42);		
		}
	},
	
	_getWorkspaceInst: function() {
		return infaw.portlet.PortletUtils.instance().getWorkspace(this.getPortletElem());
	},
	
	_computeAssignee : function(taskType){
		var $deferred = $.Deferred(),
		self = this;
		switch(taskType) {
		case 'taskAdministration' :
			this.taskInboxRowModel.setAssignee(undefined);
			$deferred.resolve();
			break;				
		case 'myTasks' :
			this.taskInboxRowModel.setAssignee(this.userID);
			$deferred.resolve();
			break;
		case 'taskAssignedToMyGroup' :
			var url = $.url('/web.humantask/infaUserProvider?' + infa.utils.Utils.instance().getTokenParam() + '&picker=userGroups&term='+this.userID);
			$.getJSON(url, function(groups){
				self.taskInboxRowModel.setAssignee(groups);
				$deferred.resolve();
			});			
			break;
		default:
			$deferred.resolve();
		}
		return $deferred.promise();
	},
	
	_setSupportedTaskType2MetaClassMap: function(){
		var self = this;
		return infaw.humantask.TaskProviderManager.instance()
				.getTaskType2MetaClassMap().then(function(taskType2MetaClassMap){
					self.taskInboxRowModel.setTaskType2MetaClassMap(taskType2MetaClassMap);
		})
	},
	
	onConfigChange: function(config) {
		this.taskInboxRowModel.clearSelectedRows(); // clear the selected rows from the row model
		this.taskInboxRowModel.setTaskView(config.taskType);
		this._curTaskView = config.taskType;
		this.extnTaskGrid.empty();
		this.extnTaskGrid.loadData();
		this.refreshMenu();
	},
	
	refreshTasks: function() {
		this.taskInboxRowModel.clearSelectedRows(); // clear the selected rows from the row model
		this.extnTaskGrid.empty();
		this.extnTaskGrid.loadData();
		this.refreshMenu();
	},
	
	_removeObjectsFromGrid: function(objects){
		if (!objects){
			return;
		}
		
		var self = this, i, indicies = [], $deferred = $.Deferred();
		
		indicies = $.map(objects, function(object){
			if(!object.$$OID || !object.$$class) {
				return;
			} else {
				return self._workspaceInst.getIterativeResultIndex({
					storage: self._storage,
					resultSetName: self._resultSetName,
					objId: object.$$OID,
					metaClassId: object.$$class
				});
			}
		});
		
		$.when.apply($, indicies).then(function(){
			var resolvedIndexObjects = $.makeArray(arguments), resolvedRows = [], resolvedIndicies = [];
			$.each(resolvedIndexObjects, function(ind, resp){
				// if resolving more than one index, resp will be wrapped
				var index = resp ? resp[0] ? resp[0].index : resp.index : -1;
				if(index !== undefined && index != -1) {
//					window.console.log("index of object " + index);
					resolvedRows.push(self.extnTaskGrid.getRowByIndex(index + 1));
					resolvedIndicies.push(index);
				} 
			});

			var i, deletedRowObj;

			self.extnTaskGrid.removeRow(resolvedRows);

			self._workspaceInst.removeIterativeResultItem({
				storage: self._storage,
				resultSetName: self._resultSetName,
				index: resolvedIndicies
			}).done(function(){
				$deferred.resolve();
			});
		});
		return $deferred.promise();
	},
	
	getHelpId: function(){
		var taskType = this.getPortletCustomProperty('taskType');
		if(taskType === 'taskAdministration'){
			return "infaw.inbox.taskAdministration.helpId";
		}
		return "infaw.inbox.myTasks.helpId";
	},
	
	getActiveTaskView : function() {
		return this._curTaskView;
	}
 
			
});
/**
 * Task Grid Row Model
 * @author Madhu 
 * 
 */
$.Class("infaw.inbox.TaskGridRowModel", {
	init: function(workspaceInst, _resultSetName) {
		this._workspaceIsnt = workspaceInst;
		this._storage = 'tasks';
		this._resultSetName = _resultSetName;
		this._owner = undefined;	
		this._selectionEvaluators = [
							         {property: '$id', alias:'$$OID'}, 
							         {property: '$metaClass', alias:'$$class'}
								];
		this._checkedObjs = {};
	},
	
	setColumnNames: function(columnNames) {
		var self = this;
		$.each(columnNames, function(index, columnName){
			self._selectionEvaluators.push({
				property: columnName
			});
		});
		
		this._columnNames = columnNames;
		
	},
	
	setTaskView : function(taskView) {
		this._taskView = taskView;
	},
	
	setTaskType2MetaClassMap: function(taskType2MetaClassMap) {		
		this._taskType2MetaClassMap = taskType2MetaClassMap;
		this._setTaskTypes();
	},
	
	_setTaskTypes: function(taskTypes) {		
		var self = this;
		this._taskTypes = [];
		$.each(this._taskType2MetaClassMap, function(key, element) {
		    self._taskTypes.push(key);
		});
		
		this._taskTypes = $.unique(this._taskTypes);
	},

	_getAllMetaClasses: function(){
		var allMetaClasses = [];
		$.each(this._taskType2MetaClassMap, function(key, element) {
		    allMetaClasses.push(element);
		});
		return $.unique(allMetaClasses);
	},
	
	getRowCount: function(options) {
		if(this._itertativeResultCreated && options && options.startIndex !== 0) {
			return this._rowCount;
		}
		
		if($.isEmptyObject(this._taskType2MetaClassMap)) {
			//No Task Provider Contributed
			this._rowCount = 0;
			return this._rowCount;
		}
		
		var self = this,
			filterCondition,
			$$classes = (options.taskType && options.taskType !== 'all') ? [this._taskType2MetaClassMap[options.taskType]] : this._getAllMetaClasses(),
			clauses = [{
				select: this._selectionEvaluators,
				$$classes: $$classes,
				sortBy: options.sortBy,
				backScroll: true
			}];
					
		if(this._taskView && this._taskView === 'taskAdministration') {
			clauses[0].where = '$$taskAdministration = true ';	
		}

		var $deferred = $.Deferred(),
			ownerFilter = false;
		$.each(this._columnNames, function(index, columnName) {
			var filterValue = options[columnName];
			if (filterValue && columnName === 'owner') {
				ownerFilter = true;
				// Translate the human name entered by the user to userIds (as the server can only
				// handle filter criteria based on userIds not human name). There can be multiple
				// userIds with the same human name. If no user info provider is registered, that
				// means the filter value entered by the user is already the userId.
				$.when(infa.users.UserInfoManager.instance().getUserIds(filterValue, -1)).then(function(userIds) {
					if (userIds === 'infa.users.NO_PROVIDER_REGISTERED') {
						$deferred.resolve([filterValue]);
					} else {
						$deferred.resolve(userIds);
					}
				}).fail(function(resp) {
					infaw.shell.common.Utils.showErrorFromResponse(resp);
					$deferred.reject();
				});
			}
		});
		if (!ownerFilter) {
			$deferred.resolve();
		}
		
		return $deferred.then(
			function(userIds) {
				if (userIds && !userIds.length) {
					// No such user exists. No result should be shown.
					self._rowCount = 0;
					return self._rowCount;
				}
				
				$.each(self._columnNames, function(index, columnName){
					var filterValue = options[columnName];
					if(filterValue && columnName !== 'type') {
						if (columnName === 'owner') {
							var userCondition = '{';
							for (var i = 0; i < userIds.length; i++) {
								var userId = userIds[i];
								userCondition += columnName + ' = "' + userId + '" ';
								if (i < userIds.length - 1) {
									userCondition += ' | ';
								}
							}
							userCondition += '}';
							if (filterCondition) {
								filterCondition += ' & ' + userCondition;
							} else {
								filterCondition = userCondition;
							}
						} else {
							if(columnName === 'dueDate' || columnName === 'createdDate') {
								var locale = infa.utils.Utils.instance().getLocale();
								locale = locale.replace(/_/g,"-");
								if(!$.datepicker.regional[locale]){
									locale = infa.utils.Utils.instance().getFallbackLocale(locale);
									if(!locale || !$.datepicker.regional[locale]){
										locale = "";					
									}
								}								
								
								var localeDateFormat = $.datepicker.regional[locale].dateFormat;
								var date = $.datepicker.parseDate(localeDateFormat, filterValue);
								filterValue = date.getTime();
							}
											
							if(filterCondition) {
								filterCondition += '& ' + columnName + ' = "' + filterValue + '" ';
							} else {
								filterCondition = columnName + ' = "' + filterValue + '" ';
							}
						}
					}
				});
		
				var taskTypes = self._taskTypes;
				
				if(options.taskType){
					taskTypes = [options.taskType];
				}
				
				if(taskTypes && taskTypes.length>0){
					var endBraces = false;
					if(filterCondition){
						filterCondition += '& {';
						endBraces = true;
					} else {
						 filterCondition = '';
					}
					
					$.each(taskTypes,function(index, taskType){
						if(index>0){
							filterCondition += '| '
						}
						filterCondition += 'taskType = "'+taskType+'" ';
					});
					
					if(endBraces){
						filterCondition += "}";
					}
					
				}
				
				if(filterCondition) {
					if(clauses[0].where) {
						clauses[0].where +=  '& ' + filterCondition; 
					} else {
						clauses[0].where = filterCondition;
					}			
				}
				
				if (filterCondition && options.startIndex == 0){
					// this means the filter is being used, clear the 'checkedObjs' list
					self.clearSelectedRows();
				}
					
				self._gridOptions = options;
		
				return $.when(
					self._workspaceIsnt.createIterativeResult({
						storage: self._storage,
						resultSetName: self._resultSetName,
						type: 'query',
						data: {
							type: 'simple',					
							clauses: clauses
						}			
					})
				).then(
					function() {
						self._itertativeResultCreated = true;
						return self._workspaceIsnt.getIterativeResultCount({
							storage: self._storage,
							resultSetName: self._resultSetName
						}).then(
								function(data){
									if(data) {
										self._rowCount = data.count;
										return data.count;						
									} else {
										self._rowCount = 0;
										return 0;	
									}
								},
								function(resp) {
									self._rowCount = 0;
									infaw.shell.common.Utils.showErrorFromResponse(resp);
									return 0;							
								}
						);			
					},
					function(resp) {
						self._rowCount = 0;
						infaw.shell.common.Utils.showErrorFromResponse(resp);
						return 0;
					}
				);
			},
			function() {
				// Unexpected error occurs while getting userIds. Stop retrieving any tasks.
				self._rowCount = 0;
				return self._rowCount;
			}
		);
	},
	
	getRootObjects : function(options) {
		if(this._rowCount === 0) {
			return [];
		}	
		var self = this;
		return this._workspaceIsnt.getLwObjectsFromIterativeResults({ //getLwObjectsFromIterativeResults({ //TODO: Replace once REST is ready
			storage: this._storage,
			resultSetName: this._resultSetName,
			startIndex: options.startIndex,
			endIndex: options.endIndex,
			idForm: 1			
		}).then(
			function(lwObjects){
				if(lwObjects.length > 0) {
					lwObjects.pop(); //Remove the last element of data as it contains additional information about meta class ID & name
					
					if (lwObjects.length) {
						if (lwObjects[0].owner) {
							// If owner is going to be shown, display the human name instead of the 
							// userId. Get all the human names in one shot here, so that 
							// TaskGridColumnModel does not have to get the human names from the
							// server one by one.
							var userIds = [],
								userIdMap = {};
							for (var i = 0; i < lwObjects.length; i++) {
								var lwObject = lwObjects[i];
								if (!userIdMap[lwObject.owner]) {
									// ensure that the same userId is only added once
									userIdMap[lwObject.owner] = true;
									userIds.push(lwObject.owner);
								}
							}
							
							return infa.users.UserInfoManager.instance().getUserInfos(userIds, -1).then(function(userInfos) {
								return lwObjects;
							});
						}
					}
				}
				return lwObjects;
			},
			function(resp) {
				infaw.shell.common.Utils.showErrorFromResponse(resp);
			}
		);
    },
    
    getSubGridColumnInfo: function(rowObject) {
		var extnGridMgr = infaw.infaGrid.ExtensibleGridManager.instance(),
			taskObjMgr = infaw.inbox.TaskObjectManager.instance();
		return taskObjMgr.getTaskObjectDescriptor(rowObject.taskType).then(function(taskObjExtn){						
			if(taskObjExtn && taskObjExtn.taskObjectGridDescriptor) {
				return $.when(extnGridMgr.getColumnInfo(taskObjExtn.taskObjectGridDescriptor.$extensibleGridId),
						extnGridMgr.getColumnInfo('inbox.defaultSubGridID')).then(function(columnInfo, defaultColumnInfo) {
					var mergedColumnInfo = $.merge(defaultColumnInfo, columnInfo);
					
					mergedColumnInfo.sort(function(col1, col2) {
						var pos1 = col1.$position;
						var pos2 = col2.$position;
						if (pos1 == pos2) {
							return 0;
						}
						if (!pos1) {
							return 1;
						}
						if (!pos2) {
							return -1;
						}
						return pos1 - pos2;
					});
					
					return mergedColumnInfo;
				});				
			} else {
				return $.when(extnGridMgr.getColumnInfo('inbox.defaultSubGridID')).then(function(defaultColumnInfo) {
					return defaultColumnInfo;
				});				
			}
		});
	}, 
	
	updateSelectedRows : function (dataObject, selected) {
		var id = this._getDataObjectID(dataObject);
		if (id){
			if (selected) {
				// add to selected rows list
				this._checkedObjs[id] = dataObject;
			} else {
				// remove from selected rows list
				this._checkedObjs[id] = null;
			}
		}
	},

	clearSelectedRows : function () {
		this._checkedObjs = {};
	},
	
	_getDataObjectID : function (dataObject) {
		if(dataObject){
			return dataObject.$$OID ? dataObject.$$OID : dataObject.$$IID;
		}
	}, 
	
	isRowChecked : function (rowDataObject) {
		return this._checkedObjs[this._getDataObjectID(rowDataObject)];
	}
	
});
$.Class('infaw.inbox.OpenCommandHandler', 
{
	init: function() {
		this.taskObjectMgr = infaw.inbox.TaskObjectManager.instance();
	},
	
	isEnabled: function(commandId, $eMenu) {
		var menuInstance = $.getWidget($eMenu, 'infaMenu'),
			selectedObj;
		// if the command is called from the task administrator/my tasks level, apply to all that are selected in the grid
		if (menuInstance.options.widgetId === 'inbox.taskGrid'){
			selectedObj = [menuInstance.getContextObject()];
		}
		// if the command is called from the grid level, apply to the individual task
		else if (menuInstance.options.widgetId === 'inbox.task'){
			selectedObj = this._getGridSelectedObjs($eMenu);
		}
		if (selectedObj){
			if (selectedObj.length == 0 || !selectedObj[0]){
				// nothing valid is selected
				return false;
			}
			if (commandId ==='inbox.open') {
				// make sure at least one selected obj is task
				var obj;
				for (var i = 0; i < selectedObj.length; i++){
					obj = selectedObj[i];
					if (infaw.humantask.TaskUtils.instance().isTask(obj.$$class)){
						return true;
					}
				}
				return false;
			}
		}
		
		return false;
	},
	
	execute: function(commandId, $eMenu){
		var menuInstance = $.getWidget($eMenu, 'infaMenu'),
			selectedObj, taskTypeArr = [];
		// if the command is called from the task administrator/my tasks level, apply to all that are selected in the grid
		if (menuInstance.options.widgetId === 'inbox.taskGrid'){
			selectedObj = [menuInstance.getContextObject()];
			if($.isArray(selectedObj[0])){
				var selectedObjs = selectedObj[0];
				for (var i = 0; i < selectedObjs.length; i++){
					taskTypeArr.push(selectedObjs[i].taskType);
				}
				selectedObj = selectedObj[0];
			} else {
				taskTypeArr.push(selectedObj[0].taskType);
			}
		}
		// if the command is called from the grid level, apply to the individual task
		else if (menuInstance.options.widgetId === 'inbox.task'){
			selectedObj = this._getGridSelectedObjs($eMenu);
			for (var i = 0; i < selectedObj.length; i++){
				taskTypeArr.push(selectedObj[i].taskType);
			}
		}
		if (commandId === 'inbox.open') {
			// pass all selected objects, execution can only execute a limited number if desired
			this.taskObjectMgr.executeTaskAction(taskTypeArr, selectedObj);	
		} 
	},
	
	_getGridSelectedObjs: function($eMenu) {
		var instance = infaw.portlet.PortletUtils.instance().getPortletInstance($eMenu);
		if (instance) {
			var grid = instance.getGrid(),
				rowObjects = [];
			if(grid) {
				var rows = grid.getSelectedRow(), num;
				// place a max of 10 objects to open
				for (var i = 0; i < rows.length; i++){
					rowObjects.push(grid.getRowDataObject(rows[i]));		
				}
				return rowObjects;
			}
		}
		return undefined;
	},

});
$.Class('infaw.inbox.MenuCommandHandler', 
{
	init: function() {
		this.taskObjectMgr = infaw.inbox.TaskObjectManager.instance();
	},
	
	isEnabled: function(commandId, $eMenu) {
		var selectedObjs = this._getSelectedObjects($eMenu), i;
		if (commandId == 'inbox.task.reassign' || commandId == 'inbox.task.release'){
			if (selectedObjs) {
				// if one of them is NOT a task, disable 
				// TODO check permissions?
				$.each(selectedObjs, function(index, value){
					if (!infaw.humantask.TaskUtils.instance().isTask(value.$$class)){
						return false;
					}
				});
				// they are all tasks
				return true;
			}
		}
		return false;
	},

	execute: function(commandId, $eMenu){
		var selectedObjs = this._getSelectedObjects($eMenu),
			that = this, 
			$i18nAlias = infaw.inbox.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		
		if (commandId == 'inbox.task.reassign' || commandId == 'inbox.task.release'){
			// fetch all objects! 
			this._getFetchedObjects(selectedObjs, $eMenu).done(function(){
				var fetchedObjects = $.makeArray(arguments);
				if (commandId == 'inbox.task.release'){
					$.each(fetchedObjects, function(object, index){
						that._updateOwner(object, null); // individually update owner
					});
					that._saveObject(fetchedObjects); // do a bulk save on all objects
				}
				// for 9.6, assume that all tasks are of the same service type and potential owner list is uniform across each task
				$.when(that._getServiceType(fetchedObjects[0])).done(function (data1){ // just get the service type for the first
					if (commandId == 'inbox.task.reassign'){
						that.$reassignDialog = $('<div></div>').infaDialog({
							title: $textUtils.getText($i18nAlias.REASSIGN_TASK) + ': ' + 
								(selectedObjs.length == 1 ? selectedObjs[0].name : selectedObjs.length + ' tasks'), // If one task, put name, if multiple, include count
							modal: true,
							resizeable: false,
							draggable: false,
							width: 350,
							buttons: [
							          {
							        	  text: $textUtils.getText($i18nAlias.ASSIGN), 
							        	  click: function(evt){
							        		  var selectedRow = that.userGrid.getSelectedRow()[0], 
							        		  commentsText = $.getWidget(that.$commentsBox, 'infaTextbox').getValue(), // TODO wait on Madhu's changes
							        		  newOwner;
							        		  if (selectedRow){
							        			  newOwner = that.userGrid.getRowValue(selectedRow).value; // get the 'user'
							        			  if (newOwner){
							        				  $.each(fetchedObjects, function(object, index){
							        					  that._updateOwner(object, newOwner); // individually update owner
							        				  });
							        				  // bulk save the update!
							        				  that._saveObject(fetchedObjects);
							        			  }
							        		  }
							        		  $.getWidget(that.$reassignDialog, 'infaDialog').destroy();  
							        	  }
							          }, // end assign button
							          {
							        	  text: $textUtils.getText($i18nAlias.CANCEL), 
							        	  click: function(evt){
							        		  $.getWidget(that.$reassignDialog, 'infaDialog').destroy();
							        	  }
							          }
							          ]
						}); // end infaDialog creation
						// set the content
						var $content = $('<div id="filterTextDiv" style="margin-bottom: 10px"></div>'+
								'<div id="userGridDiv" style="margin-bottom: 10px"></div>'+
								'<div id="commentsLabel" style="margin-bottom: 6px">'+ $textUtils.getText($i18nAlias.COMMENTS) + '</div>'+
								'<div id="commentsBoxDiv"></div>'), 
							$filterTextDiv = $($content[0]),
							$userGridDiv = $($content[1]),
							$commentsDiv = $($content[3]);

						var currentOwner, i;
						if (selectedObjs.length > 1) {
							// multi select, if all current owners are the same, can eliminate him/her from list
							var cachedOwner = selectedObjs[0].owner, oneOwner = true;
							for (i = 0; i < selectedObjs.length ; i++){
								if (cachedOwner !== selectedObjs[i].owner){
									oneOwner = false;
									break;
								}
							}
							if (oneOwner){
								currentOwner = cachedOwner;
							}
						} else {
							// single select, remove current owner from the list of owners to assign to
							currentOwner = selectedObjs[0].owner;
						}
						
						$filterTextDiv.infaTextbox({
							placeHolder: $textUtils.getText($i18nAlias.TYPE_TO_FILTER) + '...'
						}).bind('onChange', function(event){
							var filterBox = $.getWidget($(event.target), 'infaTextbox'), text = filterBox.getValue().trim();  // typed in filter text
							that.userGrid.empty(); // clear current grid, so it can be re-populated
							that._getUsers(text, that.serviceType, currentOwner).done(function(users){
								if (users.length > 0){
									that.userGrid.addRow(users);
									that.userGrid.selectRow(that.userGrid.getRowByIndex(1), true);
								}
							});
						});
						var $userGrid = $userGridDiv.infaGrid({
							columnInfo: [
							             {name: 'label', label: $textUtils.getText($i18nAlias.DISPLAY_NAME), sortable: true},
							             {name: 'value', label: $textUtils.getText($i18nAlias.USER_NAME), sortable: true}
							             ],
							             autoWidth: true,
							             height: 100,
							             sortname: 'label'
						});

						$userGrid.on('onSelectRow', function(evt, row, value){
							if (value == ""){
								// selected an empty row, disable 'Assign' button
								var buttons = $.getWidget(that.$reassignDialog, 'infaButton');
							}
						})
						
						that.userGrid = $.getWidget($userGrid, 'infaGrid');

						that._getUsers('', that.serviceType, currentOwner).done(function(users) { // default get all users
							// populate users into grid
							that.userGrid.addRow(users);
							// default select first row:
							that.userGrid.selectRow(that.userGrid.getRowByIndex(1), true);
							// add comments section
							that.$commentsBox = $commentsDiv.infaTextbox({
								height: 50,
								lines: 5
							});

							var reassignDialog = $.getWidget(that.$reassignDialog, 'infaDialog');

							reassignDialog.setContent($content);
							reassignDialog.open();

						}).fail(function(){
							if (window.console){
								window.console.log('failed to fetch users');
							}
						}); // end getusers
					}
				}).fail(function(){
					if (window.console){
						window.console.log('failed to get metaclass or service type');
					}
				}); // end metaclass, servicetype
			}).fail(function(){
				if (window.console){
					window.console.log('failed to fetch object');
				}
			}); // end fetchedobject
		} 
	},

	_updateOwner : function (object, newOwner) {
		var userChar, userCharIndex, i, userCharId;
		for(i=0; i < object.customCharacteristics.length; i++){
			if(object.customCharacteristics[i].$$class == this.userCharMetaClassId){
				userChar = object.customCharacteristics[i];
				userCharIndex = i;
				break;
			}
		}
		if(userChar == null){
			//create the user characteristic (should never enter here)
			userCharId = undefined;
			userChar = {$$class: this.userCharMetaClassId, userId: ''};
			object.customCharacteristics.push(userChar);
		}
		userChar.userId = newOwner;
		object.owner = newOwner;
	},
	
	_getSelectedObjects: function($eMenu) {
		var instance = infaw.portlet.PortletUtils.instance().getPortletInstance($eMenu);
		if (instance) {
			var grid = instance.getGrid();
			if(grid) {
				var rowArray = grid.getSelectedRow();
				rowArray = $.map(rowArray, function(row, index){
					return grid.getRowDataObject(row)
				});
				return rowArray;			
			}
		}
		return undefined;
	},
	
	_getFetchedObjects : function(lwObjects, $eMenu) {
		var workspace = infaw.portlet.PortletUtils.instance().getWorkspace($eMenu);
		if (workspace){
			lwObjects = $.map(lwObjects, function(obj, index){
				return workspace.getObject({
					objId: obj.$$OID, 
					metaClassId: obj.$$class, 
					storage: 'tasks', 
					idForm: 1, 
					dependencies: true, 
					cached: false
				});
			});
			return $.when.apply($, lwObjects);
		} 
	},
	
	_getUsers: function(filterText, serviceType, userToIgnore){
		var $deferred = $.Deferred();
		// TODO block UI? might take time
		$.getJSON($.url('/web.humantask/infaUserProvider?' + infa.utils.Utils.instance().getTokenParam()), 
				{
					picker: 'user',
					type: serviceType,
					term: filterText
				}
		).done(function(data){
			// remove the unwanted user first
			if (userToIgnore){
				data = $.map(data, function(user){
					if (user.value != userToIgnore){
						return user;
					}
				});
			}
			data.sort(function(user1, user2){
				return (user1.label < user2.label) ? -1 : 1; // sort by display name
			});
			$deferred.resolve(data);
		}).fail(function(){
			$deferred.reject();
		});
		return $deferred.promise();
	},
	
	_saveObject : function (object) {
		infa.model.ObjectSaver.instance().blockObjectSave(object, 'tasks').pipe(
				function(){			
					var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
					if (workspace) {
						var eventMgr = workspace.getEventManager();
						if (eventMgr) {
							eventMgr.sendEvent('onSave', [object]); 
						}
					}
				},
				function(resp) {				
					infaw.shell.common.Utils.showErrorFromResponse(resp);
				}
		);
	},
	
	_getServiceType : function (object) {
		var that = this, metaClassName = 'com.informatica.metadata.common.humantask.HumanTask', status;
		for(var i=0; i < object.customCharacteristics.length; i++){
			if(object.customCharacteristics[i].$$class == this.statCharMetaClassId){
				status = object.customCharacteristics[i].serviceStatus;
				break;
			}
		}
		return $.getJSON($.url('/web.humantask/humanTaskStatus?' + infa.utils.Utils.instance().getTokenParam()), 
				{
					metaClass: metaClassName,
					status: status
				}, function (data) {
					that.serviceType = data[0].serviceType;
				}
		)
	}, 
});
/**
 * Task Object Extension Manager
 * @author Madhu, Danish 
 */

$.Class("infaw.inbox.TaskObjectManager", 
{
	_instance : undefined,

	instance : function(){
		var taskObjectManager = infaw.inbox.TaskObjectManager;
		if (taskObjectManager._instance === undefined) {
			taskObjectManager._instance = new infaw.inbox.TaskObjectManager();
		}
		return taskObjectManager._instance;
	}
},
{	 
	_metaClassToExtn: {},
	_taskTypeToLogicalName: {},
	_displayStatuses:{},

	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance(),
				clsInfoInst = infa.imf.IClassInfo.instance();		
			this.$intializedDef = $.when(reader.read("com.informatica.tools.web.inbox.taskObject"), 
					clsInfoInst.init(),
					this._populateStatuses()
					).then(	
				function(args) {
					var extensions = args[0];
					if(extensions && extensions.length) {
						$.each(extensions, function(index, taskActionExtn){
							self._metaClassToExtn[taskActionExtn.$taskType] = taskActionExtn;						
							//var taskClsInfo = clsInfoInst.iClassById(taskActionExtn.$$metaClass, true);
							self._taskTypeToLogicalName[taskActionExtn.$taskType] = taskActionExtn.$label;
						});						
					}
					return;
				}
			);
		}
		return this.$intializedDef.promise();		
	},
	
	getTaskObjectDescriptor: function(taskType) {
		var self = this;	
		return this.initialize().then(function(){
			return self._metaClassToExtn[taskType];
		});		
	},
	
	getTaskTypeToLogicalNameMap: function(immediate) {
		if(immediate) {
			return this._taskTypeToLogicalName;	
		} else {
			var self = this;	
			return this.initialize().then(function(){
				return self._taskTypeToLogicalName;	
			});				
		}
	},
	
	_populateStatuses: function(){
		var $deferred = $.Deferred();
		var that = this;
		
		var $i18nAlias = infaw.inbox.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();
		// TODO block UI? might take time
		$.getJSON($.url('/web.humantask/humanTaskStatus?' + infa.utils.Utils.instance().getTokenParam())).done(function(data){
			if(data && data.taskStatuses){
				var taskStatuses = data.taskStatuses;
				$.each(taskStatuses, function(index, taskStatus){
					that._displayStatuses[taskStatus] = $textUtils.getText($i18nAlias[taskStatus]);
				});
				that._displayStatuses = infa.utils.Utils.instance().sortObj(that._displayStatuses, 'value', true);
			}
			$deferred.resolve();
		}).fail(function(){
			$deferred.reject();
		});
		return $deferred.promise();
	},

	getDisplayStatuses: function(){
		return this._displayStatuses;
	},	
	
	getTaskTypeToLogicalName: function(taskType, immediate) {
		if(immediate) {
			return this._taskTypeToLogicalName[taskType];	
		} else {
			var self = this;	
			return this.initialize().then(function(){				
				return self._taskTypeToLogicalName[taskType];	
			});				
		}
	},
	
	executeTaskAction: function(taskTypeArr, lwObject) { /* arrays, assume same length and indexes match*/
		var self = this,
			blockRequireResource = infa.extensibility.ResourceInclude.blockRequireResource, 
			taskExtnToLwObj = {};
		
		return this.initialize().then(function(){
			var lwObjList, taskType, taskActionExtn, taskExtnIdToExtn = {};
			for (var i = 0; i < taskTypeArr.length; i++){
				// make a map of task action extensions to the list of lwObjects that can be opened by that extension
				taskType = taskTypeArr[i];
				taskActionExtn = self._metaClassToExtn[taskType];
				if(taskActionExtn) {
					lwObjList = taskExtnToLwObj[taskActionExtn.$id];
					if (!lwObjList){
						lwObjList = [];
						taskExtnToLwObj[taskActionExtn.$id] = lwObjList;
						taskExtnIdToExtn[taskActionExtn.$id] = taskActionExtn;
					}
					lwObjList.push(lwObject[i]);
				}
			}
			// go through the map of extensions and open the objects
			for (var taskActionExtnId in taskExtnToLwObj){
				lwObjList = taskExtnToLwObj[taskActionExtnId];
				taskActionExtn = taskExtnIdToExtn[taskActionExtnId];
				if(taskActionExtn.$actionJSClassInst) {
					taskActionExtn.$actionJSClassInst.execute(lwObjList);
				} else {
					blockRequireResource(taskActionExtn).done(function(){
						var cls = $.toFunction(taskActionExtn.$actionJSClass);
						if(cls) {
							taskActionExtn.$actionJSClassInst = new cls();
							taskActionExtn.$actionJSClassInst.execute(lwObjList);
						}
					});		
				}
			}
		});
	}
	
});
/** 
 * Task Description Column Model
 * 
 */

$.Class("infaw.inbox.TaskGridColumnModel", 
{
	instance : function(){
		return new infaw.inbox.TaskGridColumnModel();
	} 
},
{
	init: function() {
		this._imageManager = infaw.shell.common.ImageManager.instance(),
		this._taskUtils = infaw.humantask.TaskUtils.instance(),
		this._$i18nAlias = infaw.inbox.I18nResources,
		this._$textUtils = infa.i18n.TextUtils.instance();

	},
	
	getData : function(rowObj, columnName, columnIndex, view) {
		switch(columnName) {
		case 'description' :
			var description = this._getDescription(rowObj);
			if(typeof description === 'string')
				return $.infa.Formats.escapeComprehensive(description);
			return description;
		case 'status':
			var displayStatus = this._$textUtils.getText(this._$i18nAlias[rowObj[columnName]]);
			return displayStatus;			
		case 'createdDate':
		case 'dueDate':
			if(rowObj[columnName]) {
				var milliseconds = rowObj[columnName],
					myDate = new Date(parseInt(milliseconds, 10)),
					locale = infa.utils.Utils.instance().getLocale(),
					dateFormatString = infa.utils.Utils.instance().getLocaleDateString(locale),
					dateString = infa.utils.Utils.instance().dateFormat(myDate,dateFormatString);
				return dateString;				
			}
			return '';
		case 'taskType':
			var taskObjMgr = infaw.inbox.TaskObjectManager.instance(),
			taskTypeToLogicalName = taskObjMgr.getTaskTypeToLogicalName(rowObj.taskType, true);
			return taskTypeToLogicalName;
		case 'owner':
			var userId = rowObj.owner;
			return infaw.shell.common.Utils.getUserName(userId, -1);  
		default		:	
			if(typeof rowObj[columnName] === 'string')
				return $.infa.Formats.escapeComprehensive(rowObj[columnName]);
			return rowObj[columnName];
		}
	},
	
	getIcon: function(rowObj, columnName){
		var self = this;
		if(columnName === 'name') {
			return $.when(this._taskUtils.getMixinName(rowObj.taskType)).then(function(mixin){
				return self._imageManager.getObjectImage(rowObj.$$class, [mixin]);	
			});
		}
		return undefined;
	},
	
	getIconColor: function(rowObj, columnName) {
		var self = this;
		if(columnName === 'name') {
			return $.when(this._taskUtils.getMixinName(rowObj.taskType)).then(function(mixin){
				return self._imageManager.getObjectImageColor(rowObj.$$class, [mixin], 'activeOOFColor');
			});
		}		
		return undefined;		
	},

	getFilterOptions: function(columnName) {
		switch(columnName) {
		case 'status' :
			var taskObjMgr = infaw.inbox.TaskObjectManager.instance(),
				statuses = taskObjMgr.getDisplayStatuses(),
				statusFilterOptions = {
					value	: statuses,
					dataInit: function(elem) {
						$(elem).prepend("<option value='' selected='selected'></option>");
					}
				}
			return statusFilterOptions;			
		case 'taskType' :
			var taskObjMgr = infaw.inbox.TaskObjectManager.instance(),
				metaClassToLogicalNameMap = taskObjMgr.getTaskTypeToLogicalNameMap(true),
				typeFilterOptions = {
					value	: metaClassToLogicalNameMap,
					dataInit: function(elem) {
						$(elem).prepend("<option value='' selected='selected'></option>");
					}
				}
			return typeFilterOptions;			
		case 'dueDate' :
		case 'createdDate':			
			var dueDateFilterOptions = {
				dataInit: function(elem) {
					var $elem = $(elem);						
					$elem.infaDatePicker({
						readonly: false
					}).on('onChange', function(event){
						var $grid = $(this).closest(':infaGrid'),
							grid = $.getWidget($grid, 'infaGrid')
						grid.triggerToolbar();	
						
					});
				}
			}
			return dueDateFilterOptions;
		}
	},
	
	_getDescription: function(lwObject) {
		if(lwObject.description) {
			return lwObject.description;
		}
		
		var self = this,
			workspaceInst = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		return workspaceInst.getObject({
			objId: lwObject.$$OID, 
			metaClassId: lwObject.$$class, 
			storage: 'tasks', 
			idForm: 1			
		}).then(
			function(object) {								
				return object.description;				
			},
			function(resp) {				
				infaw.shell.common.Utils.showErrorFromResponse(resp);
			}
		);	
	},
	
	
});
/**
 * Refresh Action Handler
 * 
 * @author Madhu
 */

$.Class("infaw.inbox.RefreshActionHandler", {
	
	initAction: function(blockElementId, actionId) {
		var $refreshElem = $('#' + blockElementId),
			taskInboxPortletInst = infaw.portlet.PortletUtils.instance().getPortletInstance($refreshElem),
			i18nAlias = infaw.inbox.I18nResources,
			textUtils = infa.i18n.TextUtils.instance();
		
		$refreshElem.infaButton({
			shape: 'iconic', 
			icon: $.url('/web.portlet/images/refresh.svg'), 
			height: 16,
			width: 16,
			tooltip: textUtils.getText(i18nAlias.REFRESH_BUTTON_LABEL)
		}).on('onSelect', function(){
			if(taskInboxPortletInst) {
				taskInboxPortletInst.refreshTasks();
			}
		});
		
	}
	
}); 
/** 
 * Task Detail View Date Column Model
 * 
 */

$.Class("infaw.inbox.DateColumnModel", 
{
	instance : function(){
		return new infaw.inbox.DateColumnModel();
	} 
},
{	
	getData : function(rowObj, columnName) {
		switch(columnName) {	
		case 'createdDate':
		case 'dueDate':
			if(rowObj[columnName]) {
				var milliseconds = rowObj[columnName],
					myDate = new Date(parseInt(milliseconds, 10));
			
				myDate.setMilliseconds(myDate.getMilliseconds() + infaw.page.PageManager.instance().getServerTimeDifference(myDate));
				var locale = infa.utils.Utils.instance().getLocale();
				var dateFormatString = infa.utils.Utils.instance().getLocaleDateString(locale)+" hh:MM:ss TT";
				var dateString = infa.utils.Utils.instance().dateFormat(myDate,dateFormatString);				
				return dateString;			
			}
		default:
			return '';
		}
		
	}	
});
/**
 * Task Grid Options Extension Manager
 * @author Danish 
 */

$.Class("infaw.inbox.TaskGridOptionsManager", 
{
	_instance : undefined,

	instance : function(){
		var taskGridOptManager = infaw.inbox.TaskGridOptionsManager;
		if (taskGridOptManager._instance === undefined) {
			taskGridOptManager._instance = new infaw.inbox.TaskGridOptionsManager();
		}
		return taskGridOptManager._instance;
	}
},
{	 
	_customConfigMap: {},
	
	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();
			this.$intializedDef = $.when(reader.read("com.informatica.tools.web.inbox.taskGridOptions")).then(	
					function(extensions) {	
						$.each(extensions, function(index, extension){
							if (extension.$configElem === 'configCustomizer') {
								self._customConfigMap[extension.$property] = extension.$value;
							}
						});
					}
			);
		}
		return this.$intializedDef.promise();		
	},
	
	showExpandableColumn: function() {
		if(this._customConfigMap['showExpandableColumn']!==undefined) {
			return this._customConfigMap['showExpandableColumn']=='false'?false:true;
		}
		return true;
	},
	
	getHiddenColumns: function(){
		if(this._customConfigMap['hiddenColumns']!==undefined) {
			return this._customConfigMap['hiddenColumns'].replace(/ /g,"").split(',');
		}
		return undefined;
	}
});