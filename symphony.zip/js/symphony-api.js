/**
 * @author mma
 * @class infaw.SymphonyCore
 * Symphony entry point to config header and workspace
 * It calls IndexHeader to initialize header and WorkspaceManager/WorkspaceStrategy to initialize workspace
 */
$.Class("infaw.SymphonyCore", {
    _instance : undefined,

    /** @constant */
    _workspaceContextId: "infaPage.indexPage.workspaceContextID",

    instance : function(){
        if (infaw.SymphonyCore._instance === undefined) {
            infaw.SymphonyCore._instance = new infaw.SymphonyCore();
        }
        return infaw.SymphonyCore._instance;
    }

},{

    ready: function() {
        this.$body = $('body');
    },

    /**
     *
     * @param {object} options header options
     * @param {string} options.label app title
     * @param {object} [options.search] search config. Pass jsClass to handle onSearch/onAutoComplete
     * @param {object} [options.setting] setting config. Pass jsClass to handle getItems
     *      jsClass.getItems function that is provided is expected to return a promise which will be resolved with a list of items to add to the dropdown.
     * @param {object} [options.user] user config. Pass jsClass to handle getItems
     * @param {object} [options.help] help config. Pass jsClass to handle getItems
     * @param {object} [options.switcher] product switching config. Pass jsClass to handle getItems
     */
    configHeader: function(options){
        var headerID = $.htmlId('ipg');
        this.$header = $('<header id="' + headerID + '"> </header>');

        this.$body.append(this.$header);


        var headerViewClass = new infaw.indexPage.IndexHeader();

        headerViewClass.initialize(this.$header[0].id, options);


    },

    /**
     * @param {object} options
     * @param {Array} options.workspaces array of workspaces config object
     * @see infaw.SymphonyCore.addWorkspace
     */
    configWorkspace: function(options){
    	var self = this,
            wsExts = [];
    	/*do not expose for now
    	if (options.initWSId) {
    		wsExts.push({
    			configElem: 'initialState',
    			contextId: infaw.SymphonyCore._workspaceContextId,
    			activeWorkspaceId: options.initWSId
    		});
    	}*/
    	options.workspaces.forEach(function(wsConfig){
    		wsConfig = $.extend(wsConfig, {configElem: "workspaceProvider",
                contextId: infaw.SymphonyCore._workspaceContextId,
                isConfigurable: "false",
                package: []});
            wsExts.push(wsConfig);
        });
    	infa.extensibility.ExtensionReader.instance().addFromJs('com.informatica.tools.web.shell.extensibleWorkspaces', wsExts);
        infaw.SymphonyCore.instance()._initWorkspace();
        $(window).on('resize', function() {
            self._refresh();
		});
    },

    /**
     * @param {object} options workspace options
     * @param {String} options.jsClass javaStript class that renders the workspace
     * @param {String} options.label workspace title
     * @param {String} options.multiTabs "true"|"false"
     * @param {String} options.workspaceId workspace id,
     * @param {String} options.permanent "true"|"false"
     */
    addWorkspace: function(options) {
    	$.extend(options, {configElem: "workspaceProvider",
            contextId: infaw.SymphonyCore._workspaceContextId,
            isConfigurable: "false",
            package: []});
        options = infa.extensibility.ExtensionReader.instance().addPrefix(options);
        var wsManager = infaw.workspace.WorkspaceManager.instance();
        wsManager._registerWorkspace(options);
        wsManager._addWorkspace(options);
    },

    _initWorkspace : function() {
        this.$workspaceSection = $('<section id="' + $.htmlId('ipg') + '" role="workspaces"></section>');

        this.$workspaceSection.appendTo(this.$body);

        this.$globalHolder = $('<div></div>').appendTo(this.$workspaceSection)
            .infaFloatPanelComposite({
                panelOptions: {
                    //title:$textUtils.getText($i18nAlias.GLOBAL_PANEL),
                    attachment:'bottom', // possible values: top, bottom, left, right
                    height:'380px',
                    global:true
                }
            });
        var workspaceComposite = $.getWidget(this.$globalHolder, 'infaFloatPanelComposite'),
            $workspaceDiv = workspaceComposite.getMainElement(),
            self = this;


        this.$globalPanel = workspaceComposite.getFloatPanel()
            .on('dock manualresize', function(){
                self._refresh();
            });
        this.globalPanelWidget = $.getWidget(this.$globalPanel, 'infaFloatPanel');

        this._refresh();
        
        infaw.workspace.WorkspaceStrategy.instance().initialize($workspaceDiv);
        var wsManager = infaw.workspace.WorkspaceManager.instance();
        var $deferred = wsManager.initialize(infaw.SymphonyCore._workspaceContextId,
                $workspaceDiv,
                this.pageURL);
    },

    _refresh:function(){

        if(this.$globalHolder) {
            var wHeight = $(window).height(),
                headerHeight=0,
                footerHeight=0;

            // assumes minimum heights for header=37px and footer=24px
            if(this.$header){
                headerHeight=this.$header.height();
                if(headerHeight<37) {
                    headerHeight=50;
                }
            }
            if(this.$footer){
                footerHeight=this.$footer.height();
                if(footerHeight<24){
                    footerHeight=24;
                }
            }
            wHeight=Math.round(wHeight - headerHeight - footerHeight);

            this.$globalHolder.height(wHeight);
            this.$globalPanel.infaFloatPanel('refresh');
        }
        $(window).trigger('pageresize');


    },

    /**
     * @param {Array} options Array of portlet config options
     * Each portlet must have three different configElem(portletProvider|portletConfigDescriptor|portletDescriptor)
     * @exmaple
     * [{	configElem: "portletProvider",
	 *		workspaceId: "SonataDatasetsWS",
	 *		portletInstance: {
	 *			label: 'Properties',
	 *			configElem: "portletInstance",
	 *			configId: "leftConfig",
	 *			instanceId: "leftInstance",
	 *			position: "1"
	 *		}
	 *	}, {
	 *	    configElem: "portletConfigDescriptor",
	 *		closable: "false",
	 *		configId: "leftConfig",
	 *		portletDescriptorId: "LeftPortlet",
	 *	},{
	 *	    configElem: "portletDescriptor",
	 *		collapsible: "true",
	 *		columnSpan: "1",
	 *		defaultPortletConfigId: "leftConfig",
	 *		hasDropdown: "false",
	 *		height: "840",
	 *		jsClass: "LeftPortlet",
	 *		minWidth: "300",
	 *		package: [],
	 *		portletId: "LeftPortlet"
	 *	}
     */
    configPortlet: function(options){
        infa.extensibility.ExtensionReader.instance().addFromJs("com.informatica.tools.web.shell.portletContainer", options);
    },

    /**
     * Open the passed object in specified workspace
     * @param {String} workspaceId
     * @param objectInfo information about the object to open
     */
    openObject: function(workspaceId, objectInfo) {
        // TODO use objectType to find workspace support it
        var workspaceMgr = infaw.workspace.WorkspaceManager.instance();

        workspaceMgr.selectWorkspace(workspaceId).then(function (wsInst) {
            if (wsInst.openObject) {
                wsInst.openObject(objectInfo);
            }
        });
    },

    /**
     * Symphony wrapper to select a workspace
     * @param {String} workspaceId
     * @return {defer} deferred object
     */
    selectWorkspace: function(workspaceId) {
        var workspaceMgr = infaw.workspace.WorkspaceManager.instance();

        return workspaceMgr.selectWorkspace(workspaceId);
    },

    /**
     * Symphony wrapper to remove a workspace
     * @param {String} workspaceId
     */
    removeWorkspace: function(workspaceId) {
        var workspaceMgr = infaw.workspace.WorkspaceManager.instance();

        workspaceMgr.removeWorkspace(workspaceId);
    },

    /**
     * Symphony wrapper to get active workspaceId
     * @return {String} workspaceId
     */
    getActiveWorkspaceId: function() {
        var workspaceMgr = infaw.workspace.WorkspaceManager.instance();

        return workspaceMgr.getActiveWorkspaceId();
    },

    /**
     * Symphony wrapper to get active workspaceId
     * @return {infaw.workspace.AbstractWorkspace} workspace
     */
    getActiveWorkspace: function() {
        var workspaceMgr = infaw.workspace.WorkspaceManager.instance();

        return workspaceMgr.getActiveWorkspace();
    },

    /**
     *
     * @param {object} log object
     * @param {String} log.message
     * @param {String} log.level
     */
    log: function(log){
        if (log && log.message)
            console.log(log.message);
    }
});


/**
 * @author mma
 * @class infaw.SymphonyExtension
 * Symphony class to enable extensions - include this javascript to the build to enable extensions
 */

$.Class("infaw.SymphonyExtension", {
    _instance : undefined,

    instance : function(){
        if (infaw.SymphonyExtension._instance === undefined) {
            infaw.SymphonyExtension._instance = new infaw.SymphonyExtension();
        }
        return infaw.SymphonyExtension._instance;
    }
},{

   init: function() {

   },

    /**
     * config jsCallback, The jsCallback function that is provided is expected to return a promise when it is resolved return an array of extensions.
     * @param jsCallback
     */
    configExtension: function(jsCallback) {
        infa.extensibility.ExtensionReader.instance()._jsCallback = jsCallback;
    }

});