/**
 * @author clam
 * 
 * Query for the access state (e.g. readOnly, visible) of a UI component.
 */
$.Class('infaw.access.AccessManager',
// static methods 
{  
	_instance : undefined,
  
	instance : function(){
		if (!infaw.access.AccessManager._instance) {
			infaw.access.AccessManager._instance = new infaw.access.AccessManager();
		}
		return infaw.access.AccessManager._instance;
	}        
},
// prototype methods
{
	_typeToVerifiers: undefined,
	_allVerifiers: undefined,
	_actionIdVerifiers: undefined, 
	
	/**
	 * @param id the id of the UI component
	 * @param type the type of the UI component
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the UI component is read only. A 
	 * message field is also present to provide more detail about why the component is read only.
	 */
	isReadOnly: function(id, type, elemID) {
		var $deferred = $.Deferred();
		/*var self = this;
		self._getVerifierClasses(type).done(function(resultVerifiers) {
			var result = false;
			if (resultVerifiers.typeVerifiers) {
				var verifiers = resultVerifiers.typeVerifiers[type];
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isReadOnly && verifierClass.isReadOnly(id, type)) {
		        			result = true;
		        			break;
		        		}
					}
				}
			}
			if (!result) {
				var verifiers = resultVerifiers.allVerifiers;
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isReadOnly && verifierClass.isReadOnly(id, type)) {
		        			result = true;
		        			break;
		        		}
					}
				}
			}
			
			if (!result) {
				$.blockGetJSON('/web.access/access/' + id + '@' + type + '?' + infa.utils.Utils.instance().getTokenParam() + '&state=readOnly', null, null, elemID).done(function(objects) {
					if (objects.length == 1) {
						$deferred.resolve(objects[0].state.readOnly);
					} else {
						$deferred.reject();
					}
		  		}).fail(function(resp){
		  			infaw.shell.common.Utils.showErrorFromResponse(resp);
					$deferred.reject(resp);
		  		});
			} else {
				$deferred.resolve({value: true});
			}
		});*/
		$deferred.resolve({value: true});
		return $deferred.promise();
	},
	
	/**
	 * @param id the id of the UI component
	 * @param type the type of the UI component
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the UI component is visible. A 
	 * message field is also present to provide more detail about why the component is not visible.
	 */
	isVisible: function(id, type, elemID) {
		var $deferred = $.Deferred();
		/*var self = this;
		self._getVerifierClasses(type).done(function(resultVerifiers) {
			var result = true;
			if (resultVerifiers.typeVerifiers) {
				var verifiers = resultVerifiers.typeVerifiers[type];
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isVisible && !verifierClass.isVisible(id, type)) {
		        			result = false;
		        			break;
		        		}
					}
				}
			}
			if (result) {
				var verifiers = resultVerifiers.allVerifiers;
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isVisible && !verifierClass.isVisible(id, type)) {
		        			result = false;
		        			break;
		        		}
					}
				}
			}
			
			if (result) {
				$.blockGetJSON('/web.access/access/' + id + '@' + type + '?' + infa.utils.Utils.instance().getTokenParam() + '&state=visible', null, null, elemID).done(function(objects) {
					if (objects.length == 1) {
						$deferred.resolve(objects[0].state.visible);
					} else {
						$deferred.reject();
					}
		  		}).fail(function(resp){
		  			infaw.shell.common.Utils.showErrorFromResponse(resp);
					$deferred.reject(resp);
		  		});
			} else {
				$deferred.resolve({value: true});
			}
		});*/
        $deferred.resolve({value: true});
		return $deferred.promise();
	},
	
	/**
	 * @param id the id of the UI component
	 * @param type the type of the UI component
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the content of the UI component is visible.
	 * A message field is also present to provide more detail about why the content is not visible.
	 */
	isContentVisible: function(id, type, elemID) {
		var $deferred = $.Deferred();
		/*var self = this;
		self._getVerifierClasses(type).done(function(resultVerifiers) {
			var result = true;
			if (resultVerifiers.typeVerifiers) {
				var verifiers = resultVerifiers.typeVerifiers[type];
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isContentVisible && !verifierClass.isContentVisible(id, type)) {
		        			result = false;
		        			break;
		        		}
					}
				}
			}
			if (result) {
				var verifiers = resultVerifiers.allVerifiers;
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isContentVisible && !verifierClass.isContentVisible(id, type)) {
		        			result = false;
		        			break;
		        		}
					}
				}
			}
			
			if (result) {
				$.blockGetJSON('/web.access/access/' + id + '@' + type + '?'  + infa.utils.Utils.instance().getTokenParam() + '&state=contentVisible', null, null, elemID).done(function(objects) {
					if (objects.length == 1) {
						$deferred.resolve(objects[0].state.contentVisible);
					} else {
						$deferred.reject();
					}
		  		}).fail(function(resp){
		  			infaw.shell.common.Utils.showErrorFromResponse(resp);
					$deferred.reject(resp);
		  		});
			} else {
				$deferred.resolve({value: true});
			}
		});*/
        $deferred.resolve({value: true});
		return $deferred.promise();
	},
	
	/**
	 * @param id the actionId
	 * @param type the type of the component
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the content of the UI component is allowed.
	 * A message field is also present to provide more detail about why the content is not allowed.
	 */
	isAllowed: function(id, type, elemID) {
		var $deferred = $.Deferred();
		/*var self = this;
		self._getVerifierClasses(type).done(function(resultVerifiers) {
			var result = true;
			if (resultVerifiers.typeVerifiers) {
				var verifiers = resultVerifiers.typeVerifiers[type];
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isAllowed && !verifierClass.isAllowed(id, type)) {
		        			result = false;
		        			break;
		        		}
					}
				}
			}
			if (result) {
				var verifiers = resultVerifiers.allVerifiers;
				if (verifiers) {
					for (var i = 0; i < verifiers.length; i++) {
						var verifier = verifiers[i];
						var verifierClass = verifier.verifier;
						if (!verifierClass) {
							var cls = $.toFunction(verifier.extension.$verifierJsClass);
							verifierClass = new cls();
							verifier.verifier = verifierClass;
						}
		        		if (verifierClass.isAllowed && !verifierClass.isAllowed(id, type)) {
		        			result = false;
		        			break;
		        		}
					}
				}
			}
			
			if (result) {
				$.blockGetJSON('/web.access/access/' + id + '@' + type + '?' + infa.utils.Utils.instance().getTokenParam() + '&state=allowed', null, null, elemID).done(function(objects) {
					if (objects.length == 1) {
						$deferred.resolve(objects[0].state.allowed);
					} else {
						$deferred.reject();
					}
		  		}).fail(function(resp){
		  			infaw.shell.common.Utils.showErrorFromResponse(resp);
					$deferred.reject(resp);
		  		});
			} else {
				$deferred.resolve({value: true});
			}
		});*/
        $deferred.resolve({value: true});
		return $deferred.promise();
	},
	
	/**
	 * Based on the state(s) specified, return the value of the state(s) for each of the given
	 * components.  If a component is not visible, its content is not visible. If the content is not 
	 * visible, and the readOnly state is also requested, the readOnly state will not be returned as 
	 * it is not applicable. If a component is not visible, and the allowed state is also requested, the allowed state 
	 * will not be returned.
	 * 
	 * @param {Array.<{id, type}>} components an array of components, each having id and type. In the case of allowed,
	 * the id is an actionId.
	 * @param {Object.<{visible, contentVisible, readOnly, allowed}>} states: object with properties that 
	 * map to booleans of whether or not the state is requested. If the state is not present, assumes false.  
	 * @param elemID the element to block
	 * @param data the data to pass into verifier callbacks
	 * @return a deferred object which represents an array of component states,. Each state object 
	 * has the properties id, type, readOnly or visible based on the corresponding values specified 
	 * or requested in the parameter. 
	 */
	getState: function(components, queryStates, elemID, data) {
//		$.blockElem(elemID);
		var $deferred = $.Deferred(), 
			self = this, 
			typeMap = {},
			visible = queryStates.visible,
			readOnly = queryStates.readOnly,
			contentVisible = queryStates.contentVisible,
			allowed = queryStates.allowed,
			types = [],
			ids = [],
			args = data;
		
		for (var i = 0; i < components.length; i++) {
			if(!typeMap[components[i].type]) {
				types.push(components[i].type);
			}
			
			typeMap[components[i].type] = true;
			ids.push(components[i].id);
		}
		
		self._getVerifierClasses(types, ids).done(function(resultVerifiers) {
			var jsResult = [];
			for (var i = 0; i < components.length; i++) {
				var id = components[i].id,
				 	type = components[i].type,
				 	result = {id: id, type: type, state: {}},
				 	done = false,
					readOnlyRes = readOnly ? false : undefined,
					visibleRes = visible ? true : undefined,
					contentVisibleRes = contentVisible ? true : undefined,
					allowedRes = allowed ? true: undefined;

				jsResult.push(result);
				if(resultVerifiers.idVerifiers) {
					var verifiers = resultVerifiers.idVerifiers[id];
					
					if (verifiers) {
						for (var j = 0; j < verifiers.length; j++) {
							var verifier = verifiers[j];
							var verifierClass = verifier.verifier;
							if (!verifierClass) {
								var cls = $.toFunction(verifier.extension.$verifierJsClass);
								verifierClass = new cls();
								verifier.verifier = verifierClass;
							}
			        		if (readOnly && !readOnlyRes && verifierClass.isReadOnly && verifierClass.isReadOnly(id, type, args)) {
			        			readOnlyRes = true;
			        		}
			        		if (visible && visibleRes && verifierClass.isVisible && !verifierClass.isVisible(id, type, args)) {
			        			visibleRes = false;
			        		}
			        		if (contentVisible && contentVisibleRes && verifierClass.isContentVisible && !verifierClass.isContentVisible(id, type, args)) {
			        			contentVisibleRes = false;
			        		}
			        		if (allowed && allowedRes && verifierClass.isAllowed && !verifierClass.isAllowed(id, type, args)) {
			        			allowedRes = false;
			        		}
			        		
			        		done = (!readOnly || readOnlyRes === true) &&
				        		   (!visible || visibleRes === false) &&
				        		   (!contentVisible || contentVisibleRes === false) &&
				        		   (!allowed || allowedRes == false);
			        		if (done) {
			        			break;
			        		}
						}
					}
				}
				
				if (!done && resultVerifiers.typeVerifiers) {
					var verifiers = resultVerifiers.typeVerifiers[type];
					if (verifiers) {
						for (var j = 0; j < verifiers.length; j++) {
							var verifier = verifiers[j];
							var verifierClass = verifier.verifier;
							if (!verifierClass) {
								var cls = $.toFunction(verifier.extension.$verifierJsClass);
								verifierClass = new cls();
								verifier.verifier = verifierClass;
							}
			        		if (readOnly && !readOnlyRes && verifierClass.isReadOnly && verifierClass.isReadOnly(id, type, data)) {
			        			readOnlyRes = true;
			        		}
			        		if (visible && visibleRes && verifierClass.isVisible && !verifierClass.isVisible(id, type, data)) {
			        			visibleRes = false;
			        		}
			        		if (contentVisible && contentVisibleRes && verifierClass.isContentVisible && !verifierClass.isContentVisible(id, type, data)) {
			        			contentVisibleRes = false;
			        		}
			        		if (allowed && allowedRes && verifierClass.isAllowed && !verifierClass.isAllowed(id, type, data)) {
			        			allowedRes = false;
			        		}
			        		
			        		done = (!readOnly || readOnlyRes === true) &&
				        		   (!visible || visibleRes === false) &&
				        		   (!contentVisible || contentVisibleRes === false) &&
				        		   (!allowed || allowedRes == false);
			        		if (done) {
			        			break;
			        		}
						}
					}
				}
				
				if (!done) {
					var verifiers = resultVerifiers.allVerifiers;
					if (verifiers) {
						for (var j = 0; j < verifiers.length; j++) {
							var verifier = verifiers[j],
								verifierClass = verifier.verifier;
							if (!verifierClass) {
								var cls = $.toFunction(verifier.extension.$verifierJsClass);
								verifierClass = new cls();
								verifier.verifier = verifierClass;
							}
			        		if (readOnly && !readOnlyRes && verifierClass.isReadOnly && verifierClass.isReadOnly(id, type)) {
			        			readOnlyRes = true;
			        		}
			        		if (visible && visibleRes && verifierClass.isVisible && !verifierClass.isVisible(id, type)) {
			        			visibleRes = false;
			        		}
			        		if (contentVisible && contentVisibleRes && verifierClass.isContentVisible && !verifierClass.isContentVisible(id, type)) {
			        			contentVisibleRes = false;
			        		}
			        		if (allowed && allowedRes && verifierClass.isAllowed && !verifierClass.isAllowed(id, type)) {
			        			allowedRes = false;
			        		}
			        		
			        		done = (!readOnly || readOnlyRes === true) &&
				        		   (!visible || !visibleRes === false) &&
				        		   (!contentVisible || !contentVisibleRes === false) &&
				        		   (!allowed || !allowedRes == false);

			        		if (done) {
			        			break;
			        		}
						}
					}
				}
				
				if (readOnly) {
					result.state.readOnly = readOnlyRes;
				}
				if (visible) {
					result.state.visible = visibleRes;
				}
				if (contentVisible) {
					result.state.contentVisible = contentVisibleRes;
				}
				if (allowed) {
					result.state.allowed = allowedRes;
				}

				//TODO????
				result.state.visible = {value: true};
				result.state.readOnly = {value: false};
				result.state.contentVisible = {value: true};
			}
			
			var bulk = true;
			
			var urlPath;
			if (bulk) {
				urlPath = '';
			} else {
				urlPath = self._getString(components[0].id, components[0].type);
				for (var i = 1; i < components.length; i++) {
					urlPath = urlPath + ',' + self._getString(components[i].id, components[i].type);
				}
			}
			
			urlPath = urlPath + '?' + infa.utils.Utils.instance().getTokenParam() + '&state='
			var states = [];
			if (visible) {
				states.push('visible');
			}
			if (contentVisible) {
				states.push('contentVisible');
			}
			if (readOnly) {
				states.push('readOnly');
			}
			if (allowed) {
				states.push('allowed');
			}
			urlPath = urlPath + states[0];
			for (var i = 1; i < states.length; i++) {
				urlPath = urlPath + ',' + states[i];
			}
			
			/*var data;
			if (bulk) {
				var compArray = [];
				for (var i = 0; i < components.length; i++) {
					compArray.push(self._getString(components[i].id, components[i].type));
				}
				data = $.toJSON(compArray);
			}
			
			var func = bulk ? $.blockPostJSON : $.blockGetJSON;
			func('/web.access/access/' + urlPath, data, null, elemID).done(function(objects) {
				for (var i = 0; i < jsResult.length; i++) {
	  				var jsRes = jsResult[i];
	  				if (jsRes.state.readOnly === false) {
	  					jsRes.state.readOnly = objects[i].state.readOnly;
	  				}
	  				if (jsRes.state.visible === true) {
	  					jsRes.state.visible = objects[i].state.visible;
	  				}
	  				if (jsRes.state.contentVisible === true) {
	  					jsRes.state.contentVisible = objects[i].state.contentVisible;
	  				}
	  				if (jsRes.state.allowed === true){
	  					jsRes.state.allowed = objects[i].state.allowed;
	  				}
	  			}
				$deferred.resolve(jsResult);
	  		}).fail(function(resp) {
	  			infaw.shell.common.Utils.showErrorFromResponse(resp);
	  			$deferred.reject(resp);
	  		});*/

            $deferred.resolve(jsResult);
			
//			$.ajax({
//				type : bulk ? 'POST' : 'GET',
//				url: $.url('/web.access/access/' + urlPath), 
//				data: data,
//	  			contentType: 'application/json',
//		  		datatype: "text"})
//		  		.always(function() {console.log("always");$.unblockElem(elemID);})
////		  		.done(function() {$.unblockElem(elemID);})
//		  		.done(function(objects) {
////		  			$.unblockElem(elemID);
//		  			console.log("done");
//		  			for (var i = 0; i < jsResult.length; i++) {
//		  				var jsRes = jsResult[i];
//		  				if (jsRes.state.readOnly === false) {
//		  					jsRes.state.readOnly = objects[i].state.readOnly;
//		  				}
//		  				if (jsRes.state.visible === true) {
//		  					jsRes.state.visible = objects[i].state.visible;
//		  				}
//		  				if (jsRes.state.contentVisible === true) {
//		  					jsRes.state.contentVisible = objects[i].state.contentVisible;
//		  				}
//		  			}
//		  			$deferred.resolve(jsResult);
//		  		});
		});
		return $deferred.promise();
	},
	
	_getString: function(id, type) {
		return id + '@' + type;
	},
	
	_readJsAccessExt: function() {
		var $deferred = $.Deferred();
		var self = this;
		if (!self._allVerifiers) {
			self._typeToVerifiers = {};
			self._actionIdVerifiers = {};
			self._allVerifiers = [];
			var reader = infa.extensibility.ExtensionReader.instance();
	    	reader.read("com.informatica.tools.web.shell.access").done(
	    		/**
	    		 * @param {Array.<{$configElem, $verifierJsClass, type: {$name}}>} extensions
	    		 */
				function(extensions) {
					$.each(extensions, function(index, extension) {
						if (extension.$configElem === 'jsAccess') {
							var type = extension.type;
							if (type) {
								if ($.isArray(type)) {
									for(var i = 0; i < type.length; i++) {
										var currType = type[i];
										if (!self._typeToVerifiers[currType.$name]) {
											self._typeToVerifiers[currType.$name] = [];
										}
										self._typeToVerifiers[currType.$name].push({extension: extension});
									}
								} else {
									if (!self._typeToVerifiers[type.$name]) {
										self._typeToVerifiers[type.$name] = [];
									}
									self._typeToVerifiers[type.$name].push({extension: extension});
								}
							} else if(extension.action) {
								if ($.isArray(extension.action)) {
									for(var i = 0; i < extension.action.length; i++) {
										var action = extension.action[i];
										if (!self._actionIdVerifiers[action.$id]) {
											self._actionIdVerifiers[action.$id] = [];
										}
										self._actionIdVerifiers[action.$id].push({extension: extension});
									}
								} else {
									if (!self._actionIdVerifiers[extension.action.$id]) {
										self._actionIdVerifiers[extension.action.$id] = [];
									}
									self._actionIdVerifiers[extension.action.$id].push({extension: extension});
								}
							} else {
								self._allVerifiers.push({extension: extension});
							}
						}
					});
					$deferred.resolve();
				}
			);
		} else {
			$deferred.resolve();
		}
		return $deferred.promise();
	},
	
	_getVerifierClasses: function(type, ids) {
		var $deferred = $.Deferred();
		var self = this;
		self._readJsAccessExt().done(function() {
			var returnedVerifiers = {};
			var resourceDeferredArr = [];
			var types;
			if ($.isArray(type)) {
				types = type;
			} else {
				types = [];
				types.push(type);
			}
			
			if(ids) {
				for (var i = 0; i < ids.length; i++) {
					var currId = ids[i];
					var verifiers = self._actionIdVerifiers[currId];
					if (verifiers) {
						if(!returnedVerifiers.idVerifiers) {
							returnedVerifiers.idVerifiers = {};
						}
						for (var j = 0; j < verifiers.length; j++) {
							var idVerifiers = returnedVerifiers.idVerifiers[currId];
							if (!idVerifiers) {
								idVerifiers = [];
								returnedVerifiers.idVerifiers[currId] = idVerifiers;
							}
							idVerifiers.push(verifiers[j]);
							resourceDeferredArr.push(infa.extensibility.ResourceInclude.blockRequireResource(verifiers[j].extension));
						}
					}
				}
			}
			
			for (var i = 0; i < types.length; i++) {
				var currType = types[i];
				var verifiers = self._typeToVerifiers[currType];
				if (verifiers) {
					if(!returnedVerifiers.typeVerifiers) {
						returnedVerifiers.typeVerifiers = {};
					}
					for (var j = 0; j < verifiers.length; j++) {
						var typeVerifiers = returnedVerifiers.typeVerifiers[currType];
						if (!typeVerifiers) {
							typeVerifiers = [];
							returnedVerifiers.typeVerifiers[currType] = typeVerifiers;
						}
						typeVerifiers.push(verifiers[j]);
						resourceDeferredArr.push(infa.extensibility.ResourceInclude.blockRequireResource(verifiers[j].extension));
					}
				}
				
				returnedVerifiers.allVerifiers = [];
				for (var j = 0; j < self._allVerifiers.length; j++) {
					returnedVerifiers.allVerifiers.push(self._allVerifiers[j]);
					resourceDeferredArr.push(infa.extensibility.ResourceInclude.blockRequireResource(self._allVerifiers[j].extension));
				}
			}
			$.when.apply($, resourceDeferredArr).done(function () {
				$deferred.resolve(returnedVerifiers);
			});
		});
		return $deferred.promise();
	}
	
}
);

$.infaNamespace('infaw.help');
(function( $ ){
infaw.help.I18nResources = {
  ERROR : 'Error',
  HELP_NOT_AVAILABLE : 'Help is not available.'
  
}}(jQuery));

$.Class('infa.help.HelpUtils',
// static methods 
{  
	_instance : undefined,
  
	instance : function(){
		if (!infa.help.HelpUtils._instance) {
			infa.help.HelpUtils._instance = new infa.help.HelpUtils();
		}
		return infa.help.HelpUtils._instance;
	}

},
// prototype methods
{
    launchHelp : function(widgetHelpTopicId) {
    	if(widgetHelpTopicId === null){
    		var $i18nAlias = infaw.help.I18nResources,
				$textUtils = infa.i18n.TextUtils.instance();
    		this.showError($textUtils.getText($i18nAlias.HELP_NOT_AVAILABLE));
    		return;
    	}
    	var that = this;
    	$.when(
    			$.blockGetJSON('/web.help/help?' + infa.utils.Utils.instance().getTokenParam() + '&widgetHelpId=' + widgetHelpTopicId, null, null)
		).pipe(
			function(data) {
				if(data){
					var windowFeature = "menubar=no,location=no,resizable=yes,scrollbars=yes,status=no";
					window.open(data.url, "HelpDocuments", windowFeature);
				}
			},
			function(resp) {
				that.showErrorFromResponse(resp);
			}
		);		
    },

	showError: function(message) {
		var $dialog = $('<div></div>').infaDialog({
			buttons: {
				OK: function(e) {
					var dialog = $.getWidget($(this), 'infaDialog');
					dialog.destroy();
				}
			}
		});
		var dialog = $.getWidget($dialog, 'infaDialog');
		
		var $i18nAlias = infaw.help.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		
		dialog.setTitle($textUtils.getText($i18nAlias.ERROR));
		dialog.setContent(message);
		dialog.open(true);
	},
	
	showErrorFromResponse: function(resp) {		
		var msg = this.getErrorMessageFromResponse(resp);
		this.showError(msg);
	},
	
	getErrorMessageFromResponse: function(resp) {
		var msg;
		try {
			var obj = JSON.parse(resp.responseText);
			msg = obj.description;
		} catch (e) {
			msg = resp.statusText || resp;
		}
		return msg;
	}	
}
);
$.infaNamespace('infaw.pageHeader');
(function( $ ){
infaw.pageHeader.I18nResources = {
  PREFERENCES : 'Preferences',
  SETTINGS : 'Settings',
  LOG_OUT : 'Log Out'
  
}}(jQuery));

/**
 * @author Olivier 
 * Infa PageHeader
 * 
 */

(function ($) {
	
$.widget('infa.infaPageHeader', { 

    options: { 
        logo: $.url('/images/pageHeader/infa-logo.png'),
        logo2: null,
        search: false,
        config: true,       
        menu: false,
        addPanel: false,
        links: null, // links:[{label:'infa',url:'http://informatica.com'},{label:'google',url:'http://google.com',target:'g'}],
        username: null,
        html: null
    },
	
    _create: function() {  
    	if(this.options.html){    		
    		// content
    		this.element.html(this.options.html);
			// events
			this._setEvents();
    	}else{  	
    		var that=this;
    		$.blockRequireTemplate({"/tmpl/pageHeader/infaPageHeader.htm": "infaPageHeaderTmpl"}).done(function(){
				var e=that.element,
					opts=that.options,
					icons=$.url('/images/pageHeader/dropdown.png');
				// html content				
				e.html($.tmpl("infaPageHeaderTmpl", {SettingImageURL: $.url('/images/pageHeader/settings.png')}).get(0))
					// links
					.find("[data-id='Links']").html(that._getLinksHTML());
				// logo
				e.find("[data-id='Logo']").html(that._getLogosHTML());
				
				
				//Login Items
				if(that.options.username) {
					var $loginItems = that.$loginItems = e.find("[data-id='LoginItems']").infaDropdown({	
						transparent: true,
						buttonIcon: icons,
						buttonLabel: that.options.username,					
						maxWidth:'120px'
					});
					
					var loginItemsButton = that.loginItemsMenu = $.getWidget($.getWidget($loginItems, 'infaDropdown').getButton(), 'infaButton');
					loginItemsButton.setIconAlignment('right');
					
					var loginItemsMenu = that.loginItemsMenu = $.getWidget($.getWidget($loginItems, 'infaDropdown').getMenu(), 'infaMenu');
					
					var $i18nAlias = infaw.pageHeader.I18nResources,
						$textUtils = infa.i18n.TextUtils.instance();
					
					loginItemsMenu.add(-1, 'last', 'push', $textUtils.getText($i18nAlias.PREFERENCES));
					loginItemsMenu.add(-1, 'last', 'push', $textUtils.getText($i18nAlias.SETTINGS));
					loginItemsMenu.add(-1, 'last', 'separator');
					loginItemsMenu.add(-1, 'last', 'push', $textUtils.getText($i18nAlias.LOG_OUT));
				}
				
				if(opts.search){
					e.find("[data-id='Search']").infaSearchBox({
						autoResize: true,
						clearAfterSubmit: true,
						useShortCut: true // ctrl-shift-s will show it
					});
				}
				
				
//				//user name
//				that.setUsername(that.options.username);
//				// search
//				if(opts.search){
//					e.find("[data-id='Search']").infaSearchBox({
//						autoResize: true,
//						clearAfterSubmit: true,
//						useShortCut: true // ctrl-shift-s will show it
//					});
//				}
//				// config
//				if(!opts.config){
//					e.find("[data-id='Config']").remove();
//				}
//				/*
//				var $configMenu=e.find("[data-id='Config']").infaDropdown({
//			    		buttonIcon: '/web.pageheader/images/settings.png'
//			    	});
//				this._configMenu=$.getWidget($.getWidget($configMenu, 'infaDropdown').getMenu(), 'infaMenu');
//				this._configMenu.add(-1, 'last', 'push', 'Config 1');
//				this._configMenu.add(-1, 'last', 'push', 'Config 2'); */
//				// menu
//				if(opts.menu){
//					var $menu = $('.topMenu').infaMenu();
//					if($.browser.msie){
//						$menu.css('top','1px');
//					}
//					var menu = $.getWidget($menu, 'infaMenu');
//					var mFile = menu.add(-1, 'last', 'menu', 'File');
//					menu.add(mFile, 'last', 'push', 'File 1');
//					menu.add(mFile, 'last', 'push', 'File 2');
//					menu.add(mFile, 'last', 'push', 'File 3');
//					var mEdit = menu.add(-1, 'last', 'push', 'Edit');
//					menu.add(mEdit, 'last', 'push', 'Edit 1');
//					menu.add(mEdit, 'last', 'push', 'Edit 2');
//					var mView = menu.add(-1, 'last', 'menu', 'View');
//					menu.add(mView, 'last', 'push', 'View 1');
//				}

				
				// events
				that._setEvents();
				that.element.trigger('loaded');
			});
    	}
    },
 
    _setEvents: function(){
    	var e=this.element,
    		that = this;
    	// logout event
		/*e.find("[data-id='User'] a").on('click', function(evt){
			evt.preventDefault();
			e.trigger('onLogout');
		});*/		
		
    	if(that.options.username) {
    		this.$loginItems.on('onSelect', function(evt){
    			var menuItem = that.loginItemsMenu.getLabel(evt.target); 
    			if(menuItem === 'Log Out') {
    				e.trigger('onLogout');
    			}
    		});    		
    	}
    },
    
    getLogo: function(index){
    	if(index==2){
    		return this.options.logo2;
    	}else{
    		return this.options.logo;
    	}
    },
    setLogos: function( logo1, logo2){
    	this.options.logo=logo1; 
    	this.options.logo2=logo2;
    	this.element.find("[data-id='Logo']").html(this._getLogosHTML()); 
    	return this;
    },
    _getLogosHTML: function(){
    	var h=[];
		h.push('<img src="',this.options.logo,'"/>');
		if(this.options.logo2){
			h.push('<img src="',this.options.logo2,'"/>');
	    }    	
    	return h.join(''); 
    },    
    
    getUsername: function(){
		return this.options.username; 
    },
    setUsername: function( value){
    	this.options.username=value;
    	var e=this.element.find("[data-id='User']");
    	var eName=e.find('span');
    	var eLogout=e.find('a');
    	if(typeof(value) == 'undefined' || value==null || value==''){
    		eName.empty();
    		eLogout.hide();
    	}else{
    		eName.html(value);
    		eLogout.show();
    	}
    	return this;
    },    
    
    showLogout: function() {  	
    	this.element.find("[data-id='User']").find('a').show();
    	return this;
    },
    hideLogout: function() {  	
    	this.element.find("[data-id='User']").find('a').hide();
    	return this;
    },
    showConfig: function() {  	
    	this.element.find("[data-id='Config']").show();
    	return this;
    },
    hideConfig: function() {  	
    	this.element.find("[data-id='Config']").hide();
    	return this;
    },
//    getConfigMenuWidget: function() {
//    	return this._configMenu;
//    },
    
    getLinks: function(){
		return this.options.links; 
    },
    setLinks: function( links){
    	this.options.links=links;
    	this.element.find("[data-id='Links']").html(this._getLinksHTML()); 
    	return this;
    },
    _getLinksHTML: function(){
    	var h=[];
    	var links=this.options.links;
    	if(links){
	    	for(var i=0,iMax=links.length;i<iMax;i++){
	    		var link=links[i];
	    		h.push('<a href="', link.url);
	    		if(link.target){
	    			h.push('" target="', link.target)
	    		}
	    		h.push('">', link.label, '</a>');
	    		if(i<iMax-1){
	    			h.push('|');
	    		}
	    	}
    	}
    	return h.join('');
    },
	
	destroy: function(){
		this.element
			.removeClass('infaPageHeader')
			//.unbind()
			.empty();
		$.Widget.prototype.destroy.call( this );		
	}
	
});

}(jQuery));


/**
 * @author Madhu 
 * PageHeader Manager
 */

$.Class("infaw.pageHeader.PageHeaderManager", 
{
	_instance : undefined,

	instance : function(){
		if (infaw.pageHeader.PageHeaderManager._instance == undefined)
			infaw.pageHeader.PageHeaderManager._instance = new infaw.pageHeader.PageHeaderManager();         
		return infaw.pageHeader.PageHeaderManager._instance;
	}  
},
{
	load : function(headerId, $header) {	
		var $loadDeferred = $.Deferred();
		this.headerId = headerId;
		this.$header = $header;
		
		var $deferred = this.readPageHeaderExtension();
		
		var that = this;
		$deferred.done(function(object) {
			infa.extensibility.ResourceInclude.blockRequireResource(that.pageHeaderExtension, $header.get(0).id).done(function(data){
				$.when(that.initializePageHeader()).then(function(){
					$loadDeferred.resolve();	
				});						
			});
		});
		
		
		$deferred.fail(function(object) {
			that.$body.append(object);
			$loadDeferred.resolve();
		});
		
		return $loadDeferred.promise();
	},	
	
	readPageHeaderExtension : function() {
		var $deferred = $.Deferred();				
		var that = this;
		var reader = infa.extensibility.ExtensionReader.instance();
		reader.read("com.informatica.tools.web.shell.extensiblePageHeader").done(				
			function(extensions) {			
				
				for(var index in extensions) {
					var extension = extensions[index];
					if(extension.$id === that.headerId) {
						that.pageHeaderExtension = extension;
						$deferred.resolve();
						return;
					}
				}
				
				$deferred.reject('No extension found for given headerId');
					
			}
		);	
		
		return $deferred.promise();		
	},	
	
	initializePageHeader: function() {	
		if(!this.pageHeaderExtension.$jsClass)
			return;	
		
		var headerViewClass = $.toFunction(this.pageHeaderExtension.$jsClass);
		
		if(headerViewClass) {
			var headerViewHandler = new headerViewClass();
			return headerViewHandler.initialize(this.$header[0].id);
		}			
	}	
	 	
});
$.infaNamespace('infaw.shell.common');
(function( $ ){
infaw.shell.common.I18nResources = {
  ERROR : 'Error',
  USERNAME : 'Username',
  PASSWORD : 'Password',
  LOGIN : 'Log In',
  PAGE_TITLE : 'Symphony Showcase',
  NEXT_LABEL : 'Next',
  BACK_LABEL : 'Back',
  CANCEL_LABEL : 'Cancel',
  SAVE_LABEL : 'Save',
  YES_LABEL : 'Yes',
  NO_LABEL : 'No',
  SAVE_AND_CONTINUE_LABEL : 'Save and Continue',
  SAVE_AND_FINISH_LABEL : 'Save and Finish ',
  OK : 'OK',
  LEAVE_PAGE_LABEL : 'Leave this Page',
  STAY_PAGE_LABEL : 'Stay on this Page',
  CONFIRM_NAVIGATION : 'Confirm',
  UNSAVED_CHANGES_WARNING_MSG : '&lt;br&gt; You have unsaved changes.&lt;br&gt;&lt;br&gt; Are you sure you want to continue?',
  UNSAVED_CHANGES_MSG : '&lt;br&gt; Do you want to save changes made to ',
  USER_DELETED : 'User does not exist in the current domain'
  
}}(jQuery));

/**
 * @author clam
 */
$.Class('infaw.shell.common.Utils',
	// static methods 
	{
		showMsg: function(message, title) {
			var $dialog = $('<div></div>').infaDialog({
				buttons: {
					OK: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
					}
				},
				width:400
			});
			var dialog = $.getWidget($dialog, 'infaDialog');
			
			dialog.setTitle(title);
			dialog.setContent(message);
			dialog.open(true);
		},
		/**
		 * Argument title is optional. By default, messages are not html-escaped.
		 */
		showError: function(message, title, isEscapeMessage) {
			var $i18nAlias = infaw.shell.common.I18nResources;
			var $textUtils = infa.i18n.TextUtils.instance();
			var $dialog = $('<div></div>').infaDialog({
				buttonLabels: {
					OK:$textUtils.getText($i18nAlias.OK)
				},
				buttons: {
					OK: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
					}
				},
				width:400
			});
			var dialog = $.getWidget($dialog, 'infaDialog');
			
			dialog.setTitle(title || $textUtils.getText($i18nAlias.ERROR));
			dialog.setContent(message, isEscapeMessage);
			dialog.open(true);
		},
		
		showErrorFromResponse: function(resp, isEscapeMessage) {	
			var msg = this.getErrorMessageFromResponse(resp);
			infaw.shell.common.Utils.showError(msg, null, isEscapeMessage);
		},
		
		logErrorFromResponse: function(resp) {
			infa.utils.Utils.instance().logErrorFromResponse(resp);
		},
		
		getErrorMessageFromResponse: function(resp) {
			return infa.utils.Utils.instance().getErrorMessageFromResponse(resp);
		},
		
		/**
		 * Returns the ObjectEditorAssociation instance for the given child DOM element.
		 */
		getObjectEditorAssociationInstance: function($elem) { 
			var $portletContainer = $elem.closest(':portletContainer'),
				portletContainer = $.getWidget($portletContainer, 'portletContainer');
			
			if(portletContainer && portletContainer.options.data && portletContainer.options.data.length 
					&& portletContainer.options.data[0].key === 'objectEditorAssociation') {
				return portletContainer.options.data[0].value;	
			}
			
			return undefined;
		},
		
		
		/**
		 * Get user full name given user id
		 * 
		 * @param {string} userId - user id
		 * @param elemID the element to block
		 * @returns {string} user full name
		 */
		getUserName: function(userId, elemID, immediate) {
			if (immediate) {
				var userInfo = infa.users.UserInfoManager.instance().getUserInfo(userId, elemID, immediate);
				return this._getUserName(userInfo);
			}
			
			var self = this;
			return infa.users.UserInfoManager.instance().getUserInfo(userId, elemID, immediate).then(function(userInfo) {
				return self._getUserName(userInfo);
			});
		},
		
		_getUserName: function(userInfo) {
			if(userInfo.fullName){
				if(infa.users.UserInfoManager.instance().isFullNameDuplicated(userInfo.fullName))
					return  $.infa.Formats.escapeComprehensive(userInfo.fullName) + ' [' + userInfo.id + ']';
				else
					return $.infa.Formats.escapeComprehensive(userInfo.fullName);
			} else{
				return $.infa.Formats.escapeComprehensive(userInfo.id);
			}
		},
		
		/**
		 * Add a tooltip to show detailed user information
		 * 
		 * @param {jQuery object} $elem - the jQuery object to which the tooltip will be attached
		 * @param {object} userInfo - an object with properties id, fullname and email
		 */	
		addUserTooltip: function($elem,  userInfo) {
			//if user id is empty
			if(!userInfo.id)
				return;
			
			// if user is deleted
			if(userInfo.isDeleted){
				$elem.infaTooltip({type: 'bubble', hideDelay: 100, closable: false});
				var mytooltip = $elem.data('infaTooltip');
				mytooltip.setTitle(userInfo.id);
				
				var $i18nAlias = infaw.shell.common.I18nResources;
				var $textUtils = infa.i18n.TextUtils.instance();				
				mytooltip.setContent($textUtils.getText($i18nAlias.USER_DELETED));
				mytooltip.setOrientation('bottomcenter');
				return;
			}
				
			// if neither fullname and email exists	
			if(!userInfo.fullName && !userInfo.email)
				return;
			var name = userInfo.fullName ? userInfo.fullName : userInfo.id;
			var fullName = $.infa.Formats.escapeComprehensive(name);				
			var email = userInfo.email ? userInfo.email : '';				
			var userId = userInfo.id;

			$elem.infaTooltip({type: 'bubble', hideDelay: 100, closable: false});
			var mytooltip = $elem.data('infaTooltip');
			mytooltip.setTitle(fullName);
			
			if(email){
				mytooltip.setContent(userId + '<br>' +				
					'<a href=\"mailto:' + email + '\">' + email + '</a>' + 
					'<a href=\"mailto:' + email + '\"><img class=\"emailIcon\" src=\"' + $.url('/images/shell.common/email.svg') + '\"/></a>');
			}else{
				mytooltip.setContent(userId);
			}
			mytooltip.setOrientation('bottomcenter');
		
		},
		
		isCurrentUser: function(user){
			if(!user)
				return false;
			
			var currentUser = $.cookie('userID');						
			var namespace = $.cookie('namespace');						
			if(namespace){
				var index = user.indexOf('@'+ namespace);
				if( index!== -1 && (index  + namespace.length + 1)  === user.length){
					//if user ends with @namespacce
					user = user.substr(0, index);
				}
			}
			return currentUser === user;				
		}
		
		
	},
	
	// prototype methods
	{
	}
);
/**
 * @author Madhu
 * 
 * Image Manager 
 */

$.Class('infaw.shell.common.ImageManager', {
	_instance : undefined,
	  
	instance : function(){
		if (!infaw.shell.common.ImageManager._instance) {
			infaw.shell.common.ImageManager._instance = new infaw.shell.common.ImageManager();
		}
		return infaw.shell.common.ImageManager._instance;
	}
},
{
	init: function() {
		this._namespaceIDMap = {};
		this._imageInfoIDMap = {};
		this._objectImageInfoIDMap = {};
		this._object2ImageMap = {};		
	},

	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();		
			this.$intializedDef = $.when(reader.read('com.informatica.tools.web.shell.imageInfo'),
					reader.read('com.informatica.tools.web.shell.objectImageInfo'))
					.pipe(function(imgInfoExtns, objImgInfoExtns) {
						self._imgInfoExtns = imgInfoExtns[0];
						self._objImgInfoExtns = objImgInfoExtns[0];
						self._processExtns();
					});
		}
		return this.$intializedDef.promise();		
	},
	
	_processExtns: function() {
		var self = this;
		$.each(this._imgInfoExtns, function(index, extension){
			if(extension.$configElem === 'namespace') {
				self._namespaceIDMap[extension.$id] = extension;
			} else if(extension.$configElem === 'imageInfo') {
				self._imageInfoIDMap[extension.$id] = extension;
			}
		});
		
		$.each(this._objImgInfoExtns, function(index, extension){
			self._objectImageInfoIDMap[extension.$id] = extension;
			if(extension.images) {
				var imageInfo = self._imageInfoIDMap[extension.images.$imageId];
				if(imageInfo) {
					self._object2ImageMap[extension.$$metaClass + (extension.$mixin || '')] = imageInfo;					
				}
			}
		});
	},
	
	getObjectImage: function(metaClassId, $mixins, immediate) {
		var $mixin = '',
			self = this;
		
		if($mixins && $mixins.length)  {
			$mixin = $mixins[0];			
			if($.isNumeric($mixin)) {
				var clsInfoInst = infa.imf.IClassInfo.instance(),
					clsInfo = clsInfoInst.iClassById($mixin, true);	
				$mixin = clsInfo.name;
			}
		}		
		
		if(metaClassId && !$.isNumeric(metaClassId)) {
			var clsInfoInst = infa.imf.IClassInfo.instance(),
				clsInfo = clsInfoInst.iClassByName(metaClassId, true);	
			
			if(clsInfo) {
				metaClassId = clsInfo.id;
			}			
		}
		
		
		if(immediate) {
			var imageInfo = self._object2ImageMap[metaClassId + $mixin];
			if(imageInfo && imageInfo.$image) {
				return $.url(imageInfo.$image);
			} else {
				return undefined;
			}			
		} else {
			return this.initialize().pipe(function(){
				var imageInfo = self._object2ImageMap[metaClassId + $mixin];
				if(imageInfo && imageInfo.$image) {
					return $.url(imageInfo.$image);
				} else {
					return undefined;
				}
			});			
		}
	},
	
	getObjectImageColor: function(metaClassId, $mixins, state, immediate) {
		var $mixin = '',
			self = this;
		
		if($mixins && $mixins.length)  {
			$mixin = $mixins[0];			
			if($.isNumeric($mixin)) {
				var clsInfoInst = infa.imf.IClassInfo.instance(),
					clsInfo = clsInfoInst.iClassById($mixin, true);	
				$mixin = clsInfo.name;
			}
		}		
		
		if(metaClassId && !$.isNumeric(metaClassId)) {
			var clsInfoInst = infa.imf.IClassInfo.instance(),
				clsInfo = clsInfoInst.iClassByName(metaClassId, true);	
			
			if(clsInfo) {
				metaClassId = clsInfo.id;
			}			
		}
		
		
		if(immediate) {
			return this._getObjectImageColor(metaClassId, $mixin, state);		
		} else {
			return this.initialize().pipe(function(){
				return self._getObjectImageColor(metaClassId, $mixin, state);
			});			
		}		
	},
	
	
	_getObjectImageColor: function(metaClassId, $mixin, state) {
		var imageInfo = this._object2ImageMap[metaClassId + $mixin];		
		if(imageInfo && state) {
			return imageInfo['$' + state];
		} else if (imageInfo) {
			return imageInfo.$activeOOFColor;
		}		
		return undefined;
	}
	
});
/**
 * @author Madhu
 * iframe helper methods
 */
$.Class('infaw.shell.common.IframeHelper', {
	
	/**
	 * To replicate the keyboard/mouse event in iframe to main window.
	 * 
	 * Usage eg:
	 *		$(document).on('mousemove keydown DOMMouseScroll mousewheel mousedown touchstart touchmove', function(event){
	 *			$.iframeCall(window.parent, '*', 'infaw.common.IframeHelper.onEventInIframe', event.type);
	 *		});
	 */
	onEventInIframe : function(eventType){
		if(eventType) {
			$(document).trigger(eventType);
		}
	},
	
	postMessage: function(data, iframeIDs) {
		
		if (!iframeIDs) {
			
			var iframeIDs = [];
			var iframes = $("iframe");
			for (var i = 0; i < iframes.length; i++) {
				var iframe = iframes[i];
				if (iframe.id) {
					iframeIDs.push(iframe.id);
				}
			}
		} else if (!Array.isArray(iframeIDs)) {
			iframeIDs = [iframeIDs];
		}
		
		for (var i = 0; i < iframeIDs.length; i++) {
			var iframe = document.getElementById(iframeIDs[i]).contentWindow;
			if (!window.document.location.origin) {
	  			window.document.location.origin = window.document.location.protocol + "//" + window.document.location.host;
			}  
			iframe.postMessage(data, window.document.location.origin);
		}
	},
	
	addPostMessageEventCallback: function(callbackFunction) {
		
		var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
		var eventFunction = window[eventMethod];
		var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";

		// Listen to message from child window
		eventFunction(messageEvent, function(event) {
		    callbackFunction(event);
		}, false);
	}
},{});
/**
 * Object Editor Association Manager
 * 
 * @author Madhu 
 */

$.Class('infaw.shell.common.ObjectEditorAssociationManager', {
	_instance : undefined,
	  
	instance : function(){
		if (!infaw.shell.common.ObjectEditorAssociationManager._instance) {
			infaw.shell.common.ObjectEditorAssociationManager._instance = new infaw.shell.common.ObjectEditorAssociationManager();
		}
		return infaw.shell.common.ObjectEditorAssociationManager._instance;
	}
},
{
	init: function() {
		this._objeditorAssocExtns =[];
		this._object2EditorAssoc = {};
		this._editorToActionContrb = {};
		this._idToActionHandler = {};
		this._idToEditorAssoc = {};
	},

	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();		
			this.$intializedDef = reader.read('com.informatica.tools.web.shell.ObjectEditorAssociation')
					.pipe(function(extns) {
						self._objeditorAssocExtns = extns;
						self._processExtns();
					});
		}
		return this.$intializedDef.promise();		
	},
	
	_processExtns: function() {
		var self = this;
		$.each(this._objeditorAssocExtns, function(index, extension){
			if(extension.$configElem === 'objectEditorAssociation') {
				self._object2EditorAssoc[extension.$$metaClass + (extension.$mixin || '')] = extension;
				self._idToEditorAssoc[extension.$id] = extension;
			} else if(extension.$configElem === 'actionContribution') {
				var actConts = self._editorToActionContrb[extension.$objectEditorAssociationId] || [];
				actConts.push(extension);
				self._editorToActionContrb[extension.$objectEditorAssociationId] = actConts;
			} else if(extension.$configElem === 'actionHandler') {
				self._idToActionHandler[extension.$id] = extension;
			}
		});
	},
	
	getObjectEditor: function(metaClassId, $mixins, immediate) {
		var $mixin = '',
			self = this;
		
		if($mixins && $mixins.length)  {
			$mixin = $mixins[0];			
			if($.isNumeric($mixin)) {
				var clsInfoInst = infa.imf.IClassInfo.instance(),
					clsInfo = clsInfoInst.iClassById($mixin, true);	
				$mixin = clsInfo.name;
			}
		}
		
		if(immediate) {
			return self._object2EditorAssoc[metaClassId + $mixin];
		} else {
			return this.initialize().pipe(function(){
				return self._object2EditorAssoc[metaClassId + $mixin];
			});			
		}
	},
	
	
	getObjectEditorById: function(id, immediate) {
		if(immediate) {
			return this._idToEditorAssoc[id];
		} else {
			var self = this;
			return this.initialize().pipe(function(){
				return self._idToEditorAssoc[id];
			});			
		}		
	},
	
	
	getActionContributions: function(objectEditorAssociationId, immediate) {
		if(immediate) {
			return this._editorToActionContrb[objectEditorAssociationId];
		} else {
			var self = this;
			return this.initialize().pipe(function(){
				return self._editorToActionContrb[objectEditorAssociationId];
			});			
		}
	},
	
	getActionHandler: function(id, immediate) {
		if(immediate) {
			return this._idToActionHandler[id];
		} else {
			var self = this;
			return this.initialize().pipe(function(){
				return self._idToActionHandler[id];
			});			
		}
	} 
	
});
/**
 * Object New Wizard Manager
 * 
 * @author Madhu
 */

$.Class('infaw.shell.common.ObjectNewWizardManager', {
	_instance : undefined,
	  
	instance : function(){
		if (!infaw.shell.common.ObjectNewWizardManager._instance) {
			infaw.shell.common.ObjectNewWizardManager._instance = new infaw.shell.common.ObjectNewWizardManager();
		}
		return infaw.shell.common.ObjectNewWizardManager._instance;
	}
},
{
	init: function() {
		this._objeNewWizardExtns =[];
		this._object2NewWizard = {};
	},

	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();		
			this.$intializedDef = reader.read('com.informatica.tools.web.shell.objectNewWizard')
					.pipe(function(extns) {
						self._objeNewWizardExtns = extns;
						self._processExtns();
					});
		}
		return this.$intializedDef.promise();		
	},
	
	_processExtns: function() {
		var self = this;
		$.each(this._objeNewWizardExtns, function(index, extension){
			if(extension.$configElem === 'objectNewWizard') {
				self._object2NewWizard[extension.$$metaClass + (extension.$mixin || '')] = extension;
			} 
		});
	},
	
	getObjectNewWizard: function(metaClassId, $mixins, immediate) {
		var $mixin = '',
			self = this;
		
		if($mixins && $mixins.length)  {
			$mixin = $mixins[0];			
			if($.isNumeric($mixin)) {
				var clsInfoInst = infa.imf.IClassInfo.instance(),
					clsInfo = clsInfoInst.iClassById($mixin, true);	
				$mixin = clsInfo.name;
			}
		}
		
		if(immediate) {
			return self._object2NewWizard[metaClassId + $mixin];
					
		} else {
			return this.initialize().pipe(function(){
				return self._object2NewWizard[metaClassId + $mixin];
			});			
		}
	}
	
});
/**
 * Abstract New Object Panel Callback
 * 
 * @author Madhu
 */

$.Class('infaw.shell.common.AbstractNewObjectWizard', {

	_bundle: infaw.shell.common.I18nResources,
	
	init: function(obj, options) {
		this.currentObject = obj;
		this.options = options;
		this.dirty = false;
	},
	
	createUI: function(blockElementId) {
		var self = this;
		
		this.$blockElementDiv = $('#' + blockElementId).on({
			'onShowStep' : function(event, stepId, stepBlockElementId) {
				//If empty call loadContent
				if($('#' + stepBlockElementId).is(':empty')) {
					$.blockElem(blockElementId);
					$.when(self.loadContent(stepId, stepBlockElementId)).always(function() {
						$.unblockElem(blockElementId);
					});
				}
			},
			'onFinish' : function(event, saveId) {
				self._performSaveAndFinish(saveId);
			},
			'onCancel' : function() {
				self.$blockElementDiv.trigger('objectNewWizardClose');
			}
		}).infaWizard({
			icon: infaw.shell.common.ImageManager.instance().getObjectImage(this.currentObject.$$class, this.currentObject.$mixins, true),
			iconColor: infaw.shell.common.ImageManager.instance().getObjectImageColor(this.currentObject.$$class, this.currentObject.$mixins, 'activeOOFColor', true),
			title: this.currentObject.name,
			toolbar: {
				back: {
					show : this.needsBackAndNextButtons(),
					label : '<  &nbsp; ' + $.getLocalizedText(this._bundle, 'BACK_LABEL')
				},
				next : {
					show : this.needsBackAndNextButtons(),
					label : $.getLocalizedText(this._bundle, 'NEXT_LABEL') + ' &nbsp; >'
				},
				save : this.getSaveToolbarOptions(),
				cancel : {
					show : this.needsCancelButton(),
					label : $.getLocalizedText(this._bundle, 'CANCEL_LABEL')
				}			
			},
			steps: this.getSteps(),
			enableAllSteps : this.enableAllSteps(),
			onLeaveStep: function(stepId, stepBlockElementId) {
				return self.onLeaveStep(stepId, stepBlockElementId);
			}
			
		});
		
		this.newObjectWizard = $.getWidget(this.$blockElementDiv, 'infaWizard');
		this.setDirty(true);
	},
	
	getSaveToolbarOptions: function() {
		return {
			show : true,
			label : $.getLocalizedText(this._bundle, 'SAVE_LABEL'),
			dropdown : true,
			values : [{
				id : 'saveAndContinue',
				label : $.getLocalizedText(this._bundle, 'SAVE_AND_CONTINUE_LABEL')
			},{
				id : 'saveAndFinish',
				label : $.getLocalizedText(this._bundle, 'SAVE_AND_FINISH_LABEL')
			}]
		};
	},
	
    /**
     * Returns all the steps in this wizard.
     *
     * @return a list of steps
     */	
	getSteps: function() {
		
	},

	/**
	 * Load content inside step
	 */
	loadContent: function(stepId, stepBlockElementId) {
		
	},
	
	/**
	 * Called when leaving step, return true for going to next step or false for not
	 */
	onLeaveStep: function(stepId, stepBlockElementId) {
		return true;
	},
	

    /**
     * Performs any actions appropriate in response to the user 
     * having pressed the Cancel button, or refuse if canceling
     * now is not permitted.
     *
     * @return <code>true</code> to indicate the cancel request
     *   was accepted, and <code>false</code> to indicate
     *   that the cancel request was refused
     */
    performCancel: function() {
    	
    },

    
    /**
     * Performs any actions appropriate in response to the user 
     * having pressed the Finish button, or refuse if finishing
     * now is not permitted.
     *
     * @param saveId - If this was saveAndFinish or saveAndContinue
     * @param onExit - true if we are leaving/closing the instance false otherwise
     * @return <code>true</code> to indicate the finish request
     *   was accepted, and <code>false</code> to indicate
     *   that the finish request was refused
     */    
	performFinish: function(saveId, onExit) {
		
	},

    /**
     * Returns whether this wizard needs Previous and Next buttons.
     * <p>
     * The result of this method is typically used by the container.
     * </p>
     *
     * @return <code>true</code> if Previous and Next buttons are required,
     *   and <code>false</code> if none are needed
     */	
	needsBackAndNextButtons: function() {
		return true;
	},
	
	/**
     * Returns whether this wizard needs Cancel buttons.
     * <p>
     * The result of this method is typically used by the container.
     * </p>
     *
     * @return <code>true</code> if Previous and Next buttons are required,
     *   and <code>false</code> if none are needed
     */	
	needsCancelButton: function() {
		return true;
	},
	

	/**
     * Returns whether this wizard enables all the steps.
     * <p>
     * The result of this method is typically used by the container.
     * </p>
     *
     * @return <code>true</code> if all steps are to be enabled,
     *   and <code>false</code> otherwise
     */	

	enableAllSteps : function() {
		return false;
	},
	
	/**
     * Returns whether this wizard could be finished without further user
     * interaction.
     * <p>
     * The result of this method is typically used by the wizard container to enable
     * or disable the Finish button.
     * </p>
     *
     * @return <code>true</code> if the wizard could be finished,
     *   and <code>false</code> otherwise
     */	
	canFinish: function() {
		return false;
	},
	
	
	setTitle: function(newTitle) {
		this.newObjectWizard.setTitle(newTitle);
	},
	
	/**
	 * return the help id for the wizard 
	 *  
	 */
	getHelpId: function(){
		return null;
	},
	
	isDirty: function() {
		return this.dirty;
	},	
	
	setDirty: function(dirty) {
		var wasDirty = this.dirty;
		this.dirty = dirty;
		if(dirty && !wasDirty) {
			this.$blockElementDiv.trigger('objectNewWizardDirty', true);
		} else if (!dirty && wasDirty) {
			this.$blockElementDiv.trigger('objectNewWizardDirty', false);
		}
	},
	
	/**
	 * Determines if this object can be saved.
	 */
	canSave: function() {
		return false;
	},

	/**
	 * Make sure that performFinish returns a deferred 
	 * This deferred should be resolved only when all processing is done
	 * For example if this object gets saved and open a new editor for the saved object
	 * then this should resolve only when the new editor is opened.
	 * DO NOT OVERRIDE THIS
	 */
	save: function() {
		return this._performSaveAndFinish('saveAndFinish', true);
	},
	
	/**
	 * Called when user tries to navigate away from an asset that is being edited.
	 * Return false to stop navigating away from this instance otherwise return true.
	 * beforeunload {boolean} - flag that this close event is from closing the browser cannot use deferred
	 */
	showExitDialog: function(beforeunload) {
		if(beforeunload) {
			this.onLeave(beforeunload);

			return !this.isDirty();
		} else {
			var self = this;
			if(this.isDirty()) {
				return $.when(this.canSave()).then(function(res) {
					if(res === false) {
						return $.when(self._createExitDialog()).done(function(res) {
							if(res !== false) {
								return self.onLeave();
							}
						});
					}
					return $.when(self._createSaveDialog()).done(function(res) {
						if(res !== false) {
							return self.onLeave();
						}
					});
				}, function() {
					return $.when(self._createExitDialog()).done(function(res) {
						if(res !== false) {
							return self.onLeave();
						}
					});
				});
			} else {
				return true;	
			}
		}
	},
	
	/**
	 * onLeave is called whenever the object is left
	 * can take a deferred to do processing but should only resolve deferred and never reject
	 * 
	 * beforeunload {boolean} - flag that this close event is from closing the browser cannot use deferred
	 */
	onLeave: function(beforeunload) {

	},

	_createSaveDialog: function() {
		var $deferred = $.Deferred();
		var self = this;
		var $dialog = $('<div></div>')
			.html($.getLocalizedText(this._bundle, 'UNSAVED_CHANGES_MSG') + "'" + this.currentObject.name + "'?")
			.infaDialog({
				title: $.getLocalizedText(this._bundle, 'SAVE_LABEL'),
				buttonLabels: {
					SAVE : $.getLocalizedText(this._bundle, 'YES_LABEL'), 
					DONTSAVE : $.getLocalizedText(this._bundle, 'NO_LABEL'),
					CANCEL : $.getLocalizedText(this._bundle, 'CANCEL_LABEL')
				},
				buttons: {
					SAVE: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
						// We reject because it is already closing the file when it saves
						$.when(self.save()).then(function() {
							$deferred.resolve();
						}, function() {
							$deferred.reject();
						});
					},
					DONTSAVE: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
						$deferred.resolve();
					},
					CANCEL: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();		
						$deferred.reject();
					}
				},
				width:400,
				closeOnEscape: false
			});
		var dialog = $.getWidget($dialog, 'infaDialog');
		
		dialog.open(true);
	
		return $deferred.promise();			
	},
	
	_createExitDialog: function() {
		var $deferred = $.Deferred();
		var $dialog = $('<div></div>')
			.html($.getLocalizedText(this._bundle, 'UNSAVED_CHANGES_WARNING_MSG'))
			.infaDialog({
				title: $.getLocalizedText(this._bundle, 'CONFIRM_NAVIGATION'),
				buttonLabels: {
					OK : $.getLocalizedText(this._bundle, 'YES_LABEL'),
					CANCEL : $.getLocalizedText(this._bundle, 'CANCEL_LABEL')
				},
				buttons: {
					OK: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
						$deferred.resolve();
					},
					CANCEL: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();		
						$deferred.reject();
					}
				},
				width:400,
				closeOnEscape: false
			});
		var dialog = $.getWidget($dialog, 'infaDialog');
		
		dialog.open(true);
	
		return $deferred.promise();	
	},
	
	_performSaveAndFinish: function(saveId, onExit) {
		var self = this,
			$deferred = $.Deferred(), 
			blockElementId = this.$blockElementDiv.id;
		
		$.blockElem(blockElementId);
		$.when(self.performFinish(saveId, onExit)).then(function(success){
			if(success && (!saveId || saveId === 'saveAndFinish')) {
				self.$blockElementDiv.trigger('objectNewWizardSave', true);
				$deferred.resolve(success);
			} else {
				$deferred.reject();
			}
			$.unblockElem(blockElementId);
		}, function(){
			$.unblockElem(blockElementId);
			$deferred.reject();
		});
		
		return $deferred.promise();
	},
});
/**
 * Abstract Object New Panel Callback
 * 
 * @author Madhu
 */

infaw.shell.common.AbstractNewObjectWizard.extend('infaw.shell.common.AbstractNewObjectPanel', {
	createUI: function(blockElementId) {
		this._super(blockElementId);
		var $step1Content = this.newObjectWizard.getStepHolder('step1');
		return this.loadContent('step1', $step1Content.attr('id'));
	},
	
	/**
	 * Only one step in panel
	 */
	getSteps: function() {
		return [{
			id: 'step1',
			label: 'Step 1'
		}];
	},
	
	needsBackAndNextButtons: function() {
		return false;
	},
	
	canFinish: function() {
		return true;
	}	
});
/**
 * Abstract Object View
 * @author Madhu 
 * 
 */

$.Class("infaw.shell.common.AbstractObjectView",{
	currentObject:  undefined,
	_bundle: infaw.shell.common.I18nResources,
	
	init: function(obj, instanceId) {
		this.currentObject = obj;
		this.instanceId = instanceId;
		this.dirty = false;
	},
		
	/**
	 * Create the UI portion 
	 * 
	 * mode - read | edit 
	 * 
	 */
	createUI: function(blockElementId, mode) {
		this.mode = mode || 'read';
		this.$blockElementDiv = $('#' + blockElementId);
	},
	
	
	/**
	 * Update the UI portion
	 * This method will called when object is already opened and some one tries to open the same object in same mode as previous or with different mode(read or edit). 
	 * This method can be used to update the UI when mode is changed.
	 * 
	 * mode - read | edit 
	 * 
	 */
	updateUI: function(mode) {
		this.mode = mode || 'read'; 
	},	
	
	getMode: function() {
		return this.mode;
	},
	
	/**
	 * return the help id for the object editor 
	 *  
	 */
	getHelpId: function(){
		return null;
	},
	
	isDirty: function() {
		return this.dirty;
	},	

	setDirty: function(dirty) {
		if(dirty && !this.dirty) {
			this.$blockElementDiv.trigger('objectEditorDirty', true);
		} else if (!dirty && this.dirty) {
			this.$blockElementDiv.trigger('objectEditorDirty', false);
		}
		this.dirty = dirty;
	},
	
	/**
	 * Check if object can be saved
	 */
	canSave: function() {
		return false;
	},

    /**
     * Performs any actions appropriate in response to the user 
     * having pressed the Save button, or refuse if saving
     * now is not permitted.
     * 
     * Should be a promise. Resolve if successful and reject if 
     * could not be saved
     */    
	save: function() {
		// Please overwrite this and canSave
	},

	/**
	 * Called when user tries to close an asset.
	 * Return false to stop closing this instance otherwise return true.
	 * beforeunload {boolean} - flag that this close event is from closing the browser cannot use deferred
	 */
	showExitDialog: function(beforeunload) {
		if(beforeunload) {
			this.onLeave(beforeunload);

			return !this.isDirty();
		} else {
			var self = this;
			if(this.isDirty()) {
				return $.when(this.canSave()).then(function(res) {
					if(res === false) {
						return $.when(self._createExitDialog()).done(function(res) {
							if(res !== false) {
								return self.onLeave();
							}
						});
					}
					return $.when(self._createSaveDialog()).done(function(res) {
						if(res !== false) {
							return self.onLeave();
						}
					});
				}, function() {
					return $.when(self._createExitDialog()).done(function(res) {
						if(res !== false) {
							return self.onLeave();
						}
					});
				});
			} else {
				return true;	
			}
		}
	},

	/**
	 * onLeave is called whenever the object is left
	 * can take a deferred to do processing but should only resolve deferred and never reject
	 * 
	 * beforeunload {boolean} - flag that this close event is from closing the browser cannot use deferred
	 */
	onLeave: function(beforeunload) {
		
	},
	
	_createSaveDialog: function() {
		var $deferred = $.Deferred();
		
		var self = this;
		var saveFunction = function(e) {
			var dialog = $.getWidget($(this), 'infaDialog');
			dialog.destroy();
			$.when(self.save()).then(function(){
				$deferred.resolve();
			}, function() {
				$deferred.reject();
			});	
		};
		
		var $dialog = $('<div></div>')
			.html($.getLocalizedText(this._bundle, 'UNSAVED_CHANGES_MSG') + "'" + this.currentObject.name + "'?")
			.infaDialog({
				title: $.getLocalizedText(this._bundle, 'SAVE_LABEL'),
				buttonLabels: {
					SAVE : $.getLocalizedText(this._bundle, 'YES_LABEL'), 
					DONTSAVE : $.getLocalizedText(this._bundle, 'NO_LABEL'),
					CANCEL : $.getLocalizedText(this._bundle, 'CANCEL_LABEL')
				},
				buttons: {
					SAVE: saveFunction,
					DONTSAVE: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
						$deferred.resolve();
					},
					CANCEL: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();		
						$deferred.reject();
					}
				},
				width:400,
				closeOnEscape: false
			});
		var dialog = $.getWidget($dialog, 'infaDialog');
		
		dialog.open(true);
	
		return $deferred.promise();			
	},
	
	_createExitDialog: function() {
		var $deferred = $.Deferred();
		var $dialog = $('<div></div>')
			.html($.getLocalizedText(this._bundle, 'UNSAVED_CHANGES_WARNING_MSG'))
			.infaDialog({
				title: $.getLocalizedText(this._bundle, 'CONFIRM_NAVIGATION'),
				buttonLabels: {
					OK : $.getLocalizedText(this._bundle, 'YES_LABEL'),
					CANCEL : $.getLocalizedText(this._bundle, 'CANCEL_LABEL')
				},
				buttons: {
					OK: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();
						$deferred.resolve();
					},
					CANCEL: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();		
						$deferred.reject();
					}
				},
				width:400,
				closeOnEscape: false
			});
		var dialog = $.getWidget($dialog, 'infaDialog');
		
		dialog.open(true);
	
		return $deferred.promise();	
	},
});
/**
 * A Object View that supports panels and contextual panel.
 * @author Madhu 
 * 
 */

infaw.shell.common.AbstractObjectView.extend('infaw.shell.common.PaneledObjectView', {
	/**
	 * Create the UI portion 
	 * 
	 * mode - new | read | edit 
	 * 
	 */
	createUI: function(blockElementId, mode) {
		this._super(blockElementId, mode);
		this.$objectViewComposite =  $('#' + blockElementId);
		this.$objectViewComposite.infaFloatPanelComposite({
			panelOptions : this.getFloatPanelOptions()
		});
		this.$mainElement = this._getMainElement();
		
		var self =this;
		return $.when(infaw.portlet.PortletActionManager.instance().initialize()).then(function(){
			return self._createPortletContainer();
		});			
	},
	
	_createPortletContainer : function() {
		var workspaceManager = infaw.workspace.WorkspaceManager.instance(),
			objectEditorAssMgr = infaw.shell.common.ObjectEditorAssociationManager.instance(),
			objEditorAssocExtn = objectEditorAssMgr.getObjectEditorById(this.instanceId, true),
			$i18nAlias = infaw.workspaceHome.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance(),
			title = this.getTitle(),
			icon = this.getIcon(),
			iconColor = this.getIconColor(),
			randomId = $.htmlId(this.instanceId || 'paneledObjectView'),
			workspaceId = randomId + '.paneledObjectView.workspaceId',
			portletId = this.instanceId || randomId,
			portletInstanceId = randomId + '.paneledObjectView.portletInstanceId',
			configId = randomId + '.paneledObjectView.configId',
			portletProvider = {
				$configElem : 'portletProvider', 
				$workspaceId : workspaceId,
				portletInstance : [{
					$configElem: 'portletInstance',
					$configId: configId,
					$instanceId: portletInstanceId,
					$label: title
				}]
			},
			portletDescriptor = {
				$configElem: 'portletDescriptor',
				$portletId: portletId,
				$defaultPortletConfig: configId,
				$hasDropdown: objEditorAssocExtn ? objEditorAssocExtn.$hasDropdown : true,
				$hasHelp: objEditorAssocExtn ? objEditorAssocExtn.$hasHelp : true,
				$jsClass: 'infaw.portlet.AbstractPortlet',
				$label: title,
				$icon: icon,
				$iconColor: iconColor,
				$package: {},
				$columnSpan: '1',
				$rowSpan: '1'
			},
			portletConfigDescriptor = {
				$configElem: 'portletConfigDescriptor',
				$configId: configId,
				$label: 'Paneled Object View Config',
				$portletDescriptorId: portletId,
				$closable: 'false'
			},
			actionContributions = objectEditorAssMgr.getActionContributions(this.instanceId, true),
			extensions = [portletProvider, portletDescriptor, portletConfigDescriptor],
			self = this;
			
		if(actionContributions && actionContributions.length) {
			var actionHandlers = [];
			$.each(actionContributions, function(i, contribution){
				contribution.$portletDescriptorId = self.instanceId;
				extensions.push(contribution);
				
				var actions = contribution.action;
				if(actions) {
					if(!$.isArray(actions)) {
						actions = [actions];
					}
					
					$.each(actions, function(i, action){
						var actionsHandler = objectEditorAssMgr.getActionHandler(action.$actionId, true);
						extensions.push(actionsHandler);
					});
				}
			});
		}
		
		
		infaw.portlet.PortletExtensionManager.instance().addExtensions(extensions);
		
		if(actionContributions && actionContributions.length) {
			infaw.portlet.PortletActionManager.instance().updateActions(this.instanceId, actionContributions);
		}
		
		this.$mainElement.portletContainer({
			parentId: workspaceId,
			columns: 1,
			rowHeight: function(){ 
				return self.getRowHeight();
			},
			movable: false,
			resizable: false,
			data: [{key: 'objectEditorAssociation', value: this}],
			lazy: true
		});
		

		this._portletContainer = $.getWidget(this.$mainElement, 'portletContainer');	
		return this._portletContainer.createPortlets().then(function(){
			var $portlets = self._portletContainer.getPortlets(),
				portletInstance = self._portletContainer.getPortletInstance($portlets[0]);
			
			self._$portletElem = portletInstance.getPortletElem();
			$portlets[0].on('onHelp', function(event, data){
				infa.help.HelpUtils.instance().launchHelp(self.getHelpId());
			});	
			self._portletElemId = portletInstance.getPortletElemId();									
			var $eMenus = self.$mainElement.find(':extensibleMenu');
			if ($eMenus.length > 0) {				
				var $eMenu = $eMenus.eq(0);
				self._actionMenuInst = $.getWidget($eMenu, 'extensibleMenu');
				self._actionMenuInst.setContextObject(self.currentObject);
				self._actionMenuInst.refreshEnabledState();
			}			
			return self._portletElemId;
		});
		
	},
	
	getPortletElemId: function() {
		return this._portletElemId;
	},
	
	getTitle: function() {
		return this.currentObject.name;
	},		
	
	getIcon: function() {
		return infaw.shell.common.ImageManager.instance().getObjectImage(this.currentObject.$$class, this.currentObject.$mixins, true);
	},
	
	getIconColor: function() {
		return infaw.shell.common.ImageManager.instance().getObjectImageColor(this.currentObject.$$class, this.currentObject.$mixins, 'activeOOFColor', true);
	},
	
	/*
	 * Default row height is max height. 
	 */
	getRowHeight: function() {
		var containerHeight = this.$objectViewComposite.innerHeight();
		return containerHeight - 20;
	},

	getFloatPanelOptions : function() {
		var options = {
				width : this.getFloatPanelDefaultWidth()
		};
		return options;
	},

	getFloatPanelDefaultWidth : function(){
		return '300px';
	},

	getFloatPanel: function() {
		var objectViewComposite = $.getWidget(this.$objectViewComposite, 'infaFloatPanelComposite');
		var $floatPanel = objectViewComposite.getFloatPanel();
		return $.getWidget($floatPanel, 'infaFloatPanel');
	},

	_getMainElement: function() {
		var objectViewComposite = $.getWidget(this.$objectViewComposite, 'infaFloatPanelComposite');
		return objectViewComposite.getMainElement();
	},
	
	refreshToolbar: function() {
		var $infaPortlet = this._$portletElem.closest(':infaPortlet'),
			infaPortletInst = $.getWidget($infaPortlet, 'infaPortlet');
		
		if(infaPortletInst) {
			infaPortletInst.refreshActionExtensions(this.instanceId);
			
			//swapping the divs based on mode
			//In edit mode, tab order should go through form fields first and then actions
			var $portletHeaderDiv = infaPortletInst.element.find('.infaPortlet-header');
			var $portletContentDiv = infaPortletInst.element.find('.infaPortlet-content');
			if(this.mode=='edit') {
				$portletContentDiv.insertBefore($portletHeaderDiv);
				infaPortletInst.element.addClass('editPortlet-ctr');
			} else if(this.mode=='read') {
				$portletHeaderDiv.insertBefore($portletContentDiv);	
				infaPortletInst.element.removeClass('editPortlet-ctr');
			}
		}
	},
	
	
	hideActionMenu: function() {
		var $infaPortlet = this._$portletElem.closest(':infaPortlet'),
			infaPortletInst = $.getWidget($infaPortlet, 'infaPortlet');
		
		if(infaPortletInst) {
			infaPortletInst.hideDropdownMenu();
		}		
	},
	
	
	showActionMenu: function() {
		var $infaPortlet = this._$portletElem.closest(':infaPortlet'),
			infaPortletInst = $.getWidget($infaPortlet, 'infaPortlet');
		
		if(infaPortletInst) {
			infaPortletInst.showDropdownMenu();
		}		
	},
	
	setTitle: function(title) {
		var $infaPortlet = this._$portletElem.closest(':infaPortlet'),
			infaPortletInst = $.getWidget($infaPortlet, 'infaPortlet');
		
		if(infaPortletInst) {
			infaPortletInst.setLabel(title);
		}
	},
	
	getActionDropdownMenu: function() {
		this._actionMenuInst;
	},	
	
	
	refreshActionMenuState: function() {
		this._actionMenuInst.refreshEnabledState();
	}
	
	
});
/**
 * This is the class for creating login screens.
 * Users can use the extension point to add their background images, page title, Copy Right information.
 * If no images are provided by users, then the class will display a set of 4 default background Informatica images
 * The class can be extended to use username/password/namespace based authorizations 
**/


$.Class('infaw.common.BaseLoginPageView', {
	init: function(options) {
		var self = this;
		
		this.processCopyRightInformation(options.version,options.year);
		this.processPatentInformation(options.patentMessage, options.patentUrl);
		
		$.get($.url("/web.shell.common/bgImage?userDefinedDirectory=true")).always(function(userDefinedDirectory){
			if(userDefinedDirectory==="true"){
				var imageUrl = "/web.shell.common/bgImage";
				$("#mainContainer").css({"background-image":"url("+$.url(imageUrl)+")"});
			} else {
				self.processBackgroundImage(options.bgImages);
			}
		});
	
		// modeURL determines the type of login authentication
		this._modeURL = options.modeURL;
		
		this._namespaces = (options) ? options.namespaces : undefined; 
				
		this.$header = $('#LoginPageHeader').infaPageHeader({
				logo : $.url(options.logo),
				logo2: (options.logo2 == "")? null: $.url(options.logo2)
			});
		
		this.pageHeader = $.getWidget(this.$header, 'infaPageHeader');
		this.$myLoginForm = this.getFormElements();
		this.myLoginForm = $.getWidget(this.$myLoginForm, 'infaForm'),
		this.$loginButton = this.myLoginForm.getFieldHolder('blogin'),
			
		this.$loginButton.on('onSelect', function(){
			self._login();
		});
		
		this.$myLoginForm.on('keyup', function(event){
			if(event.keyCode == 13){
				self._login();
			}
		});
	},
	
	getFormElements: function(){
		var $formElements = $('#LoginForm').infaForm({
			fields: this.getFromFields() ,
//			formcls: 'infaForm-Login' ,
//			rowHeight: 26
		});
		return $formElements;
	},
	
	processCopyRightInformation: function(copyRightVersion, copyRightYear){
		$('#CopyRightVersion').text(copyRightVersion);  
		$('#CopyRightYear').text(copyRightYear);
	},
	
	processPatentInformation: function(patentMessage, patentUrl){
		if(patentMessage === "" && patentUrl === ""){
			$('#PatentDiv').remove();
			return;
		}
		
		$('#PatentMessage').text(patentMessage);
		$('#PatentUrl').append('<a href="'+ patentUrl +'"> ' + patentUrl +'</a>');
	},
	
	/**
	 * This function takes an array of image names with path.
	 * If a parameter is provided, it picks up a random element from this array, and displays that image in the background of login form 
	 * Otherwise, this function generates a random number ranged between 1 and 4 (because there are 4 default images) 
	 * It then displays that random default image
	 * 
	 **/
	processBackgroundImage: function(bgImages){
		var randomNum;
		var imageUrl;
		
		if(bgImages !== undefined && bgImages !== null && bgImages.length>0){
			randomNum = Math.floor((Math.random()*bgImages.length));
			imageUrl = bgImages[randomNum][randomNum.toString()];
		}
		else{
			randomNum = Math.ceil(Math.random()*4);
			imageUrl = '/images/shell.common/Login_Image_0'+randomNum+'.png';
		}
		
		$("#mainContainer").css({"background-image":"url("+$.url(imageUrl)+")"});
	},
	
	getFromFields: function() {
		var $i18nAlias = infaw.shell.common.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();
		
		var fields = [{
			id:'user', 
			label:$textUtils.getText($i18nAlias.USERNAME),
			wType:'infaTextbox',
			wOptions:{width:'300px'}
		},{
			id:'password', 
			label:$textUtils.getText($i18nAlias.PASSWORD),
			wType:'infaTextbox',
			wOptions: {
				password: true,
				width:'300px'
			}
		}];
		
		fields.push({
			rowSpan: 2,
        	 id:'blogin',
        	 label:'',
        	 wType:'infaButton',
        	 wOptions:{
					label: $textUtils.getText($i18nAlias.LOGIN)
        	 }
        });
		
		return fields;
	},
	
	getLoginData: function(){
		return this.myLoginForm.getValues();
	},
	
	
	_login: function() {
		// we need modeURL for authentication
		if(this._modeURL===undefined || this._modeURL===null)
			return;
		
		var that = this;
		
		var loginData = this.getLoginData();
		
		$.blockPostJSON('/' + this._modeURL, 
			$.toJSON(loginData), 
			function(object){	
				if(object.redirectURL) {					
					if(window.location.href.lastIndexOf(that._modeURL) > 0) {
						var redirectURL = object.redirectURL;														
						if(redirectURL.lastIndexOf(that._modeURL) > 0) {
							redirectURL = $.url('/');			
						}	
						window.location.href = redirectURL;
					} else {
						window.location.reload();
					}
					
				} else if(object.error) {
					var $errorIcon = $('.infaLoginErrorIcon');					
					$errorIcon.svg({
						width: 16,
						height: 16,
						loadURL: $.url('/images/common/warning.svg'),
						onLoad: function() {														
							$errorIcon.find('path, circle').css({
								fill: '#EC1B24'
							});																	
						}							
					});
					
					$('.infaLoginMsg').hide().html(object.error).slideDown();;
					that.loginFailed(object.error);
					
				} else {
					if(window.location.href.lastIndexOf(that._modeURL) > 0) {
						window.location.href = $.url('/');
					} else {
						window.location.reload();
					}
				}								
			}
		); 		
	},
	
	loginFailed: function(error){
		//clear the password field
		var form = $.getWidget($('#LoginForm'), 'infaForm');
		if(form){
			var pWidget = form.getFieldWidget('password');
			if(pWidget){
				pWidget.setValue('', true);
				pWidget.focus();
			}
		}
	}
});
/**
 * This is the class for creating login screens.
 * Users can use the extension point to add their background images, page title, Copy Right information.
 * If no images are provided by users, then the class will display a set of 4 default background Informatica images
 * The class can be extended to use username/password/namespace based authorizations 
**/


infaw.common.BaseLoginPageView("infaw.common.LoginPageView", 
{},
{
	getFormElements: function(){
		var $formElements = $('#LoginForm').infaForm({
			fields: this.getFromFields() ,
			formcls: 'infaForm-Login' ,
			rowHeight: 26
		});
		return $formElements;
	},
	
	
});
$.infaNamespace('infaw.portlet');
(function( $ ){
infaw.portlet.I18nResources = {
  CONTENT_CANNOT_BE_VIEWED : 'Cannot view assets in the panel. Contact an administrator.',
  CONFIGURE : 'Configure',
  GENERAL : 'General',
  CONFIGURATION : 'Configuration',
  PANEL_NAME : 'Panel name',
  PANEL_DESCRIPTION : 'Panel description',
  PANEL_TEMPLATE : 'Panel template',
  DESCRIPTION_PLACEHOLDER : 'Enter description',
  NAME_PLACEHOLDER : 'Enter name',
  ACTIVE_CONFIGURATION : 'Active configuration',
  NEW_PANEL : 'New Panel',
  ADD_PANEL : 'Add a Panel',
  EDIT_PANEL : 'Edit Panel',
  REMOVE_PANEL : 'Remove Panel',
  HELP_FOR_PANEL : 'Help',
  SWITCH_TO : 'Switch To',
  OPEN : 'Open',
  CLOSE : 'Close',
  RESIZE : 'Resize',
  SLIDE_OPEN : 'Slide Open',
  PIN : 'Pin',
  UNPIN : 'Un-Pin',
  NOT_ENOUGH_ROOM_TO_SHOW_THIS_PANEL : 'Not enough room to show this panel',
  PANEL_HAS_REACHED_ITS_MINIMUM_SIZE : 'Panel has reached its minimum size',
  PANEL_HAS_REACHED_ITS_MAXIMUM_SIZE : 'Panel has reached its maximum size',
  OK_LABEL : 'OK',
  CANCEL_LABEL : 'Cancel',
  EXPAND : 'Expand',
  COLLAPSE : 'Collapse'
  
}}(jQuery));

/**
 * @author clam
 */

(function($) {

	var headerHtml = '<div class="infaPortlet-header"><div class="infaPortlet-title"></div><div class="infaPortlet-headerShortcut-Menu"></div><span class="phIcons left"></span><span class="phIcons"></span></div>',
		contentHtml = '<div class="infaPortlet-content"></div>',
		portletClass = 'infaPortlet ui-widget ui-helper-clearfix ui-corner-all',
		labelWithIconClass = 'infaPortlet-icon-label',
		activeClass = 'ui-state-hover',
		activeTitleClass = 'infaActiveHeader',
		closeBtnHtml = '<div class="infaPortlet-close"></div>',
		configBtnHtml = '<div></div>',
		sepHtml = '<div class="separator"></div>',
	    dropDownMenuHtml = '<div class="infaPortlet-dropDown-Menu"></div>',
	    headerShortcutMenuHtml = '<div class="infaPortlet-headerShortcut-Menu"></div>',
	    iconDropdown = $.url('/images/portlet/action.svg'),
	    headerShortcutIcon = $.url('/images/portlet/triangleDown.png');

		// Custom selector
	$.extend($.expr[':'].infaPortlet = function (obj){
		return $(obj).hasClass('infaPortlet');
	});
	
	$.extend($.expr[':'].infaPortletHeader = function (obj){
		return $(obj).hasClass('infaPortlet-header');
	});
	
	$.extend($.expr[':'].infaPortletContent = function (obj){
		return $(obj).hasClass('infaPortlet-content');
	});

	$.widget('infa.infaPortlet', {

		options : {
			/**
			 * parent of this portlet which is the portlet container 
			 */
			parent: null,
			/**
			 * instance id for this widget 
			 */
			widgetId: '',
			/**
			 * Label at the header of the portlet
			 */
			label : '',
			/**
			 * Icon of the portlet
			 */
			icon : '',
			/**
			 * Icon Color of the portlet. Applicable only for SVG icon
			 */
			iconColor : '',
			/**
			 * Content of the portlet in html form
			 */
			content : '',
			/**
			 * True if dropdown menu is to be shown, false otherwise.
			 */
			hasDropdown: false,
			
			/**
			 * True if help gesture is to be shown, false otherwise.
			 */
			hasHelp: false,
			/**
			 * True if the portlet can be closed, false otherwise.
			 */
			closable: false,
			/**
			 * True if the portlet is configurable, false otherwise
			 */
			configurable: false,
			/**
			 * list of header shortcuts
			 */
			headerShortcuts: [],
			
			/**
			 * If specified, the id becomes the dropdown menu id, and can be
			 * used to contribute additional items to the menu through extension
			 * point.
			 */
			menuId : '',
			/**
			 * TRUE to read the extension contributions and populate the rest of the dropdown menu 
			 * right after menu widget is created, FALSE if the extension reading will be delayed 
			 * until 'processExtensions()' is called on the menu widget. This option is only 
			 * applicable for a portlet that has a drop down menu.
			 */
			lazy: false,
			
			/**
			 * Creates a portlet without a header (title/menu) for the portlet if true.
			 */
			hasHeader: true, 
			/**
			 * Adds a cssClass to portlet so that consumer can modify the css of the portlet to their needs.
			 */
			cssClass: undefined,
			/**
			 * Makes the portlet collapsible on clicking the header
			 */
			collapsible: false,
			/**
			 * Makes the Hidable on clicking the close icon
			 */
			hideable: false
		},

		_$label : null,

		_$icon : null,

		_$content : null,
		
		_editMenuItem: null,
		
		_closeMenuItem: null,
		
		_helpMenuItem: null,
		
		_configurationMenuItem: null,
		
		_create : function() {
			var opts=this.options;
			this._isLoading=false;
			this.element.addClass(portletClass);
			
			if(opts.cssClass && opts.cssClass.length > 0) {
				this.element.addClass(opts.cssClass);
			}
			
			if(opts.hasHeader) {
				this._$header = $(headerHtml).appendTo(this.element);
				this._$header.addClass('infa-movable')
					.on('mouseenter', function(){
						$(this).addClass(activeTitleClass);
					}).on('mouseleave', function(){
						$(this).removeClass(activeTitleClass);
				})
						
				// ---- label ----		
				this._$label=this._$header.children().eq(0);
				this.setLabel(opts.label);
				if (opts.icon.length) {
					this.setIcon(opts.icon, opts.iconColor);
				}
				
				// ---- action icons ----	
				this._$headerIcons=this._$header.find('.phIcons:not(.left)');
				if($.isArray(opts.headerShortcuts) && opts.headerShortcuts.length > 0){
					this._createHeaderShortcutsDropDownMenu();
				}

				if (opts.hasDropdown || opts.closable || opts.hasHelp || opts.configurable) {
					this._createExtensibleDropDownMenu();
				}
				if(opts.collapsible && opts.hasHeader){
					this._makeCollapsibleOption();
				}
				if(opts.hideable && opts.hasHeader){
					this._makeHidableOption();
				}
			}
			
			// ---- content ----			
			this._$content = $(contentHtml).appendTo(this.element).attr('id', $.htmlId('portCnt'));
			if(!opts.hasHeader) {
				this._$content.css('height', '100%');	
			}
			this._setContent(opts.content);	
			
			// ---- events ----	
			var that = this;
			this.element.on('baresize', function(evt, newWidth, newheight, oldWidth, oldHeight) {
				that._$content.trigger('onResize', [newWidth, newheight, oldWidth, oldHeight]);
			}).on('click', function(evt, ui){
				that.activate();
			});
		},
		_makeCollapsibleOption: function() {
			var $i18nAlias = infaw.portlet.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
			this._$header.css('cursor','pointer');
			var header = this._$header.first();
			var collapseIcon = $('<div tabindex=0 title = "'+$textUtils.getText($i18nAlias.COLLAPSE)+'" class="portletMin portletOpened"></div>').insertBefore(header.first().children()[0])
			var displayed = true;
			var that = this;
			var portletHeight = 0;
			this._$header.bind('click keydown',function(event){
				if(event.type=='click' || (event.type =='keydown' && event.keyCode == 13) ){
					if(displayed){
						portletHeight = that.element.height();
						that._$content.slideUp('slow', function(){
                            that.element.trigger('onCollapse');
                        });
						that.element.css('height','auto');
						displayed = false;
						$($(this).children()[0]).removeClass('portletOpened').addClass('portletClosed');
						collapseIcon.attr('title',$textUtils.getText($i18nAlias.EXPAND));
					}else{
						that.element.css('height',portletHeight);
						that._$content.slideDown('slow', function(){
                            that.element.trigger('onExpand');
                        });
						displayed = true;
						$($(this).children()[0]).removeClass('portletClosed').addClass('portletOpened');
						collapseIcon.attr('title',$textUtils.getText($i18nAlias.COLLAPSE));
					}
				}
			});
		},
		_makeHidableOption:function(){
			var that = this;
			var header = this._$header;
			var $i18nAlias = infaw.portlet.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
			var closeIcon = $('<span tabindex=0 class="portletMin closeIcon" title = "'+$textUtils.getText($i18nAlias.CLOSE)+'" style="float:right"></span>').insertBefore(header.children().last())
			closeIcon.bind('click keydown',function(event){
				if(event.type =='click' ||(event.type =='keydown' && event.keyCode == 13) ){
					that.element.hide();
					that.element.trigger('onHide');
					return false;
				}
			});
		},
		/**
		 * This creates Configurable Menu items. As of now 
		 * configurable portlets contains Edit, Remove actions 
		 */
		createConfigurableMenuItems: function() {
			if(this.options.hasHeader) {
				if(this.options.configurable) {
					var menu = this.getMenuWidget();
					var i18nAlias = infaw.portlet.I18nResources,
						textUtils = infa.i18n.TextUtils.instance();
					
					//Edit Panel
					if(!this._editMenuItem) {
						var count = menu.count(-1, false);
						if (count > 0) {
							menu.addItem('infaPortlet.closeSep', -1, 'last', 'separator');
						}
						
						this._editMenuItem = menu.addItem('infaPortlet.edit', -1, 'last', 'push', textUtils.getText(i18nAlias.EDIT_PANEL));
						var $editItem = menu.$(this._editMenuItem);
						$editItem.on('onSelect', $.proxy(function() {
							this.element.trigger('onEdit');
						}, this));
					}
					
					//Remove Panel
					if (!this._closeMenuItem) {
						this._closeMenuItem = menu.addItem('infaPortlet.close', -1, 'last', 'push', textUtils.getText(i18nAlias.REMOVE_PANEL));
						var $closeItem = menu.$(this._closeMenuItem);
						$closeItem.on('onSelect', $.proxy(function() {
							this.element.trigger('beforeClose');
							this.destroy();
						}, this));
					}
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		},

		_createExtensibleDropDownMenu : function() {
			if (this._$headerIcons.children().length) {
				$(sepHtml).appendTo(this._$headerIcons);
			}
			var $dropdown = $(dropDownMenuHtml).appendTo(this._$headerIcons);
			$dropdown.infaDropdown({
				buttonShape : 'iconic',
				buttonIcon : iconDropdown,
				menuId: this.options.menuId,
				buttonWidth: 16,
				buttonHeight: 16
			});

			var dropdown = $.getWidget($dropdown, 'infaDropdown'),
				$eMenu = dropdown.getMenu(),
				eMenu = $.getWidget($eMenu, 'extensibleMenu');
			if (eMenu && !this.options.lazy) {
				eMenu.processExtensions();
				
				if(this.options.configurable) {
					this.createConfigurableMenuItems();
				} else {
					this.createCloseMenuItem();
				}

				this.createHelpMenuItem();
			}
		},
		
		createCloseMenuItem: function() {
			if(this.options.hasHeader) {
				if (this.options.closable && !this._closeMenuItem) {
					var menu = this.getMenuWidget();
					var count = menu.count(-1, false);
					if (count > 0) {
						menu.addItem('infaPortlet.closeSep', -1, 'last', 'separator');
					}

					var i18nAlias = infaw.portlet.I18nResources,
						textUtils = infa.i18n.TextUtils.instance();
					this._closeMenuItem = menu.addItem('infaPortlet.close', -1, 'last', 'push', textUtils.getText(i18nAlias.REMOVE_PANEL));
					var $closeItem = menu.$(this._closeMenuItem);
					$closeItem.on('onSelect', $.proxy(function() {
						this.element.trigger('beforeClose');
						this.destroy();
					}, this));
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		},
		
		createHelpMenuItem: function(){
			if(this.options.hasHeader) {
				if (this.options.hasHelp && !this._helpMenuItem) {
					var menu = this.getMenuWidget();
					if(this._closeMenuItem != null){
						menu.addItem('infaPortlet.helpSep', -1, 'last', 'separator');
					}else{
						var count = menu.count(-1, false);
						if (count > 0) {
							menu.addItem('infaPortlet.helpSep', -1, 'last', 'separator');
						}
					}
					
					var i18nAlias = infaw.portlet.I18nResources,
						textUtils = infa.i18n.TextUtils.instance();
					this._helpMenuItem = menu.addItem('infaPortlet.help', -1, 'last', 'push', textUtils.getText(i18nAlias.HELP_FOR_PANEL));
					var $helpItem = menu.$(this._helpMenuItem);
					$helpItem.on('onSelect', $.proxy(function() {
						this.element.trigger('onHelp');
					}, this));
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		},
		
		removeCloseMenuItem: function() {
			if(this.options.hasHeader) {
				if (this._closeMenuItem) {
					this.getMenuWidget().remove(this._closeMenuItem);
					this._closeMenuItem = null;
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		},

		_createHeaderShortcutsDropDownMenu: function(){			
			var $headerShortCut = this._$header.find('.infaPortlet-headerShortcut-Menu'); 			
			
			$headerShortCut.infaDropdown({				
				buttonShape : 'iconic',
				buttonIcon : headerShortcutIcon
			});			
			
			var dropdown = $.getWidget($headerShortCut, 'infaDropdown'),
				$menu = dropdown.getMenu(),
				menu = dropdown.getMenuWidget(),
				button = dropdown.getButtonWidget();
			
			var $i18nAlias = infaw.portlet.I18nResources,
				$textUtils = infa.i18n.TextUtils.instance();
			button.setTooltip($textUtils.getText($i18nAlias.SWITCH_TO));
			
			
			if(menu){
				var selectedShortcut = '', pLabel;
				if(this.options.parent != null){
					var portletConfigCache = this.options.parent.getPortletConfigCache();
					if(portletConfigCache){
						selectedShortcut = portletConfigCache.getPanelProperty(this.options.widgetId, '$$selectedHeaderShortcut');
					}
				}								
				for(var i in this.options.headerShortcuts){
					var item = menu.add(-1, 'last', 'radio', this.options.headerShortcuts[i].label, 'panelHeaderShortCutGroupID');
					$(item).data('headerShortcutId', this.options.headerShortcuts[i].id);
					if(selectedShortcut != '' && this.options.headerShortcuts[i].id == selectedShortcut){
						menu.setChecked(item, true);
						pLabel = this.options.headerShortcuts[i].label;
					} else if ((!selectedShortcut || selectedShortcut != '') && i == 0) {
						menu.setChecked(item, true);
						pLabel = this.options.headerShortcuts[i].label
					}
				}
				
				if(pLabel) {
					this.setLabel(pLabel);
				}
			
				
				//attach the selection event to fire to the implementation classes
				var that = this;
				$headerShortCut.on('onSelect', function(e){
					var target = $(e.target);
					if(target.hasClass('infaMenuItem')){
						var menuItemLabel = menu.getLabel(e.target),
							headerShortcutId = $(e.target).data('headerShortcutId'); 
						that.element.trigger('onHeaderShortcutSelect', [{id: headerShortcutId, label: menuItemLabel}]);
						that.setLabel(menuItemLabel);
					}

				});
			}
		},

		/**
		 * Standard jQuery destroy: clean everything as if the widget had never been instantiated.
		 */
		destroy : function() {
			this.element.trigger('beforeDestroy')
				.empty()
				.removeClass(portletClass);
			$.Widget.prototype.destroy.call(this);
			this.element.trigger('afterDestroy');
		},

		/**
		 * setLabel(label) 
		 * Sets the given label as the display label of the portlet header.
		 * 
		 * Parameters: 
		 * - label: the new label
		 */
		setLabel : function(label) {
			if(this.options.hasHeader) {
				this._$label.text(label);
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for label');
			}
			return this;
		},

		/**
		 * getLabel() 
		 * Returns the header label.
		 * 
		 * Returns: The label
		 */
		getLabel : function() {
			if(this.options.hasHeader) {
				return this._$label.text(); 
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for label');
			}
		},

		/**
		 * setIcon(icon) 
		 * Sets the icon of the header to be the icon at the specified path.
		 * 
		 * Parameters: 
		 * - icon: the path for the new icon
		 * - icon: the color for the new icon, applicable onl
		 */
		setIcon : function(icon, iconColor) {
			if(this.options.hasHeader) {
				if(icon && /.svg/i.test(icon)) {
					//SVG Support
					var self = this;
					if (!this._$icon) {
						this._$label.addClass(labelWithIconClass);
						this._$icon = $('<div class="infaPortlet-svgicon"/>').prependTo(this._$header);
					}				
					this._$icon.svg({
						loadURL: icon,
						onLoad: function() {							
							if(iconColor) {
								self._$icon.find('path, polygon, rect, circle').css({
									fill: iconColor
								});	
								
								self._$icon.css('padding', '5px 10px');
							}
						}							
					});
					
				} else {
					if (this._$icon) {
						this._$icon.attr('src', icon);
					} else {
						this._$label.addClass(labelWithIconClass);
						this._$icon = this._$label.before('<img src="' + icon + '" class="infaPortlet-icon"/>');
					}				
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for icon');
			}
			return this;
		},
		
		/**
		 * Sets the background color of the portlet, including both the header and the content section.
		 */
		setBackground: function(headerBg) {
			this.element.css('background-color', headerBg);
		},
		
		/**
		 * Returns the background color of the portlet.
		 */
		getBackground: function() {
			return this.element.css('background-color');
		},
		
		_setContent : function(content) {
			this._$content.html(content);
			return this;
		},

		/**
		 * getContent() 
		 * Returns a jQuery object representing the main content under the header.
		 * 
		 * Returns: The content jQuery object
		 */
		getContent : function() {
			return this._$content;
		},
		
		/**
		 * clearContents() 
		 * Clears the contents of the portlet
		 */
		clearContents : function() {
			this._$content.removeData().empty();
			this._$content.unbind();
			return this;
		},

//		/**
//		 * setHeaderContent(hContent) 
//		 * Sets the given content to be the additional content in the header section that is shown 
//		 * after the label.
//		 * 
//		 * Parameters: 
//		 * - hContent: The new header content
//		 */
//		setHeaderContent : function(hContent) {
//			var $hContent = this._$label.children();
//			if (!$hContent.length) {
//				$hContent = this._$label.append('<div></div>').children();
//			}
//			$hContent.html(hContent);
//			return this;
//		},
//
//		/**
//		 * getHeaderContent() 
//		 * Returns any content in the header that is shown after the label.
//		 * 
//		 * Returns: The content in html form
//		 */
//		getHeaderContent : function() {
//			var $hContent = this._$label.children();
//			if ($hContent.length) {
//				return $hContent.html();
//			}
//		},

		/**
		 * setPosition(x, y) 
		 * Sets the position of the portlet widget to be the coordinates specified. The coorindates 
		 * are relative to the parent.
		 * 
		 * Parameters: 
		 * - x: The x-coordinate of the new position 
		 * - y: The y-coordinate of the new position
		 */
		setPosition : function(x, y) {
			var offset = this.element.parent().offset();
			this.element.offset({
				left : offset.left + x,
				top : offset.top + y
			});
		},

		/**
		 * getPosition() 
		 * Returns the position of the portlet widget relative to the parent.
		 * 
		 * Returns: The position of the portlet widget relative to the parent
		 */
		getPosition : function() {
			// var pos = this.element.position();
			// var obj = new Object();
			// obj.x = pos.left;
			// obj.y = pos.top;
			var offset = this.element.offset();
			var parentOffset = this.element.parent().offset();
			var obj = {
				x : offset.left - parentOffset.left,
				y : offset.top - parentOffset.top
			};
			return obj;
		},

		/**
		 * setWidth(width) 
		 * Sets the width of the portlet widget.
		 * 
		 * Parameters: 
		 * - width: The new width
		 */
		setWidth : function(width) {
			this.element.width(width);
			return this;
		},

		/**
		 * getWidth() 
		 * Returns the portlet width.
		 * 
		 * Returns: The width
		 */
		getWidth : function() {
			return this.element.width();
		},

		/**
		 * setHeigth(height) 
		 * Sets the height of the portlet widget.
		 * 
		 * Parameters: 
		 * - height: The new height
		 */
		setHeight : function(height) {
			this.element.height(height);
			return this;
		},

		/**
		 * getHeight() 
		 * Returns the portlet height.
		 * 
		 * Returns: The height
		 */
		getHeight : function() {
			return this.element.height();
		},
		
		showLoading: function(blockParam) {
			$.blockElem(this.element.attr('id'), blockParam);
			//this._$content.block();
			this._isLoading=true;
			return this;
		},
		
		hideLoading: function() {
			$.unblockElem(this.element.attr('id'));
			//this._$content.unblock();
			this._isLoading=false;
			return this;
		},
		isLoading: function() {			
			return this._isLoading;
		},
		
		/**
		 * activate() 
		 * Activates the portlet. A portlet is not active by default.
		 */
		activate : function() {
			return this._setActive(true);
		},

		/**
		 * Deactivate() 
		 * De-activates the portlet if it is currently active.
		 */
		deactivate : function() {
			return this._setActive(false);
		},

		/**
		 * isActive() 
		 * Returns true if the portlet is active, and false otherwise.
		 * 
		 * Returns: True if the portlet is active, and false otherwise.
		 */
		isActive : function() {
			return !this._$content.hasClass('infaNotActive');
		},

		_setActive : function(active) {
			var currActive = this.isActive();
			if (active != currActive) {
				var eventName;
				if (active) {
					//desactivate all portlets
					this.element.closest('.infaTabContents').find(':infaPortlet').infaPortlet('deactivate');
					// activate the selected portlet
					if(this._$header) {
						this._$header.addClass(activeClass);
					}
					this._$content.removeClass('infaNotActive');
					eventName = 'onActivate';
				} else {
					if(this._$header) {
						this._$header.removeClass(activeClass);
					}
					this._$content.addClass('infaNotActive');
					eventName = 'onDeactivate';
				}
				this.element.trigger('onDeactivate');
			}
			return this;
		},
		
		/**
		 * sets hasHelp attribute
		 */	
		setHasHelp : function(hasHelp) {
			if(typeof hasHelp == "boolean")
				this.options.hasHelp = hasHelp;
			else
				this.options.hasHelp = (hasHelp === "true");
		},
		
		/**
		 * sets headerShortcuts attribute
		 */	
		setHeaderShortcuts : function(headerShortcuts) {
			this.options.headerShortcuts = headerShortcuts;
		},
		
		/**
		 * Returns the jQuery object representing the dropdown menu widget for this portlet, if the 
		 * portlet has a dropdown menu.
		 */
		getMenu: function() {
			var dropdown = this._getMenuDropdown();
			if(dropdown){
				return dropdown.getMenu();
			}
		},
		
		/**
		 * Returns the dropdown menu widget for this portlet, if the portlet has a dropdown menu.
		 */
		getMenuWidget: function() {
			var dropdown = this._getMenuDropdown();
			if(dropdown){
				return dropdown.getMenuWidget();
			}
		},
		
		_getMenuDropdown: function() {
			if(this._$header) {
				var $dropdowns = this._$header.find(':infaDropdown');
				if ($dropdowns.length > 0) {
					for(var i = 0; i < $dropdowns.length; i++){
						if($dropdowns.eq(i).hasClass('infaPortlet-dropDown-Menu')){
							return $.getWidget($dropdowns.eq(i), 'infaDropdown');
						}
					}
				}
			}
		},
		
		/**
		 * Returns the widgetId for this portlet.
		 */
		getWidgetId: function() {
			return this.options.widgetId;
		},

		setClosable : function(closable) {
			if(this.options.hasHeader) {
				if (this.options.closable !== closable) {
					this.options.closable = closable;
					if(closable){
						this.createCloseMenuItem();
					}else{
						this.removeCloseMenuItem();
					}
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for close menu');
			}
			return this;
		},
		
		addMenuDropDown: function(menuId){
			if(this.options.hasHeader) {
				if (this._$headerIcons.children().length) {
					$(sepHtml).appendTo(this._$headerIcons);
				}
				var $dropdown = null;
				$dropdown = $(dropDownMenuHtml).appendTo(this._$headerIcons);
				$dropdown.infaDropdown({
					buttonShape : 'iconic',
					buttonIcon : iconDropdown,
					menuId: menuId,
					buttonWidth: 16,
					buttonHeight: 16
				});
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		},
		
		removeMenuDropDown: function(){
			if(this.options.hasHeader) {
				//destroy the menu and remove it
				this._getMenuDropdown().destroy();
				this._$headerIcons.find('.separator').remove();
				this._$headerIcons.find('.infaPortlet-dropDown-Menu').remove();
				this._closeMenuItem = null;
				this._editMenuItem = null;
				this._helpMenuItem = null;
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		}, 
		
		resetMenuDropDown: function(menuId){
			if(this.options.hasHeader) {
				this.removeMenuDropDown();
				this.addMenuDropDown(menuId);
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for dropdown menu');
			}
		},
		
		hasMenuDropDown: function(){
			if(this.options.hasHeader) {
				if(this._$headerIcons.find('.infaPortlet-dropDown-Menu').length != 0){
					return true;
				}
			} else {
				return false;
			}
		},
		
		addHeaderShortcutsDropDown: function(headerShortcuts){
			if(this.options.hasHeader) {
				var $dropdown = $(headerShortcutMenuHtml).prependTo(this._$headerIcons);
				$dropdown.infaDropdown({
					buttonShape : 'iconic',
					buttonIcon : $.url('/images/portlet/switch.gif')
				});
				var dropdown = $.getWidget($dropdown, 'infaDropdown'),
				$menu = dropdown.getMenu(),
				menu = dropdown.getMenuWidget(),
				button = dropdown.getButtonWidget();
				button.setTooltip('Switch To');
				if(menu){
					var selectedShortcut = '';
					if(this.options.parent != null){
						var portletConfigCache = this.options.parent.getPortletConfigCache();
						if(portletConfigCache){
							selectedShortcut = portletConfigCache.getPanelProperty(this.options.widgetId, '$$selectedHeaderShortcut');
						}
					}
					for(var i in headerShortcuts){
						var item = menu.add(-1, 'last', 'check', headerShortcuts[i]);
						if(selectedShortcut != '' && headerShortcuts[i] == selectedShortcut){
							menu.setChecked(item, true);
						}
					}
				
					
					//attach the selection event to fire to the implementation classes
					var that = this;
					$dropdown.on('onSelect', function(e){
						var target = $(e.target);
						if(target.hasClass('infaMenuItem')){
							var menuItemLabel = menu.getLabel(e.target); 
							var items = menu.getChildren(-1);
							for(var k in items){
								menu.setChecked(items[k], false);
							}
							menu.setChecked(e.target, true);
							that.element.trigger('onHeaderShortcutSelect', [{label: menuItemLabel}]);
						}

					});
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for shortcut dropdown');
			}
		},
		
		removeHeaderShortcutsDropDown: function(){
			if(this.options.hasHeader) {
				//destroy the menu
				var menuDropdown = this._getHeaderShortcutsDropdown();
				if(menuDropdown)
					menuDropdown.destroy();
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for shortcut dropdown');
			}
		}, 
		
		resetHeaderShortcutsDropDown: function(headerShortcuts){
			if(this.options.hasHeader) {
				this.removeHeaderShortcutsDropDown();
				this.setHeaderShortcuts(headerShortcuts);
				this._createHeaderShortcutsDropDownMenu();
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for shortcut dropdown');
			}
		},
		
		hasHeaderShortcutsDropDown: function(){
			if(this.options.hasHeader) {
				var $headerShortcutsMenu = this._$header.find('.infaPortlet-headerShortcut-Menu');
				var headerShortcutsMenu = $.getWidget($headerShortcutsMenu, 'infaDropdown');
				if(headerShortcutsMenu && headerShortcutsMenu.length != 0){
					return true;
				}
				return false;
			} else {
				return false;
			}
			
		},
		
		_getHeaderShortcutsDropdown: function(){
			var $dropdowns = this._$header.find(':infaDropdown');
			if ($dropdowns.length > 0) {
				for(var i = 0; i < $dropdowns.length; i++){
					if($dropdowns.eq(i).hasClass('infaPortlet-headerShortcut-Menu')){
						return $.getWidget($dropdowns.eq(i), 'infaDropdown');
					}
				}
			}
		},
		
		clearHeaderShortcutSelection: function(){
			if(this.options.hasHeader) {
				if(this.hasHeaderShortcutsDropDown()){
					var dropdown = this._getHeaderShortcutsDropdown();
					if(dropdown){
						var menu = dropdown.getMenuWidget();
						var items = menu.getChildren(-1);
						for(var k in items){
							menu.setChecked(items[k], false);
						}
					}
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not have header for shortcut selection');
			}
		},
		
		processActionExtensions: function(portletDescId) {
			var self = this;
			var actionManager = infaw.portlet.PortletActionManager.instance();
			$.when(
				actionManager.getContributions(portletDescId),
				actionManager.getContributions(portletDescId + infaw.portlet.PortletExtensionManager.LEFT_PORTLET_ID_SUFFIX)
			).then(function(exts, leftExts) {
				self._addActions(leftExts, true);
				self._addActions(exts, false);
			});
		},
		
		_addActions: function(exts, left) {
			if (exts.length) {
				var count = 0,
					$parent = left ? this.element.find('.phIcons.left') : this._$headerIcons,
					actionManager = infaw.portlet.PortletActionManager.instance();
				for (var i = exts.length - 1; i >= 0; i--) {
					var ext = exts[i];
					if (ext.type === 'action') {
						 // ensure left and right phIcons have distinct IDs
						var divId = this._$content.attr('id') + '_phAction' + (left ? '_left' : '') + (count++);
						$('<div class="portletAction"></div>').prependTo($parent)
										.attr('id', divId);
						actionManager.initializeAction(divId, ext.id);
					} else {
						$(sepHtml).prependTo($parent);
					}
				}
			}
		},
		
		refreshActionExtensions: function(portletDescId) {
			this.element.find('.phIcons').children().not('.infaPortlet-dropDown-Menu').remove();
			this.processActionExtensions(portletDescId);
		},
		
		hideDropdownMenu: function() {
			this.element.find('.infaPortlet-dropDown-Menu').hide();
		},
		
		showDropdownMenu: function() {
			this.element.find('.infaPortlet-dropDown-Menu').show();
		},
		
		removeIcon: function() {
			if(this.options.hasHeader) {
				this._$icon = null;
				this.element.find('.infaPortlet-svgicon').remove();
				this.element.find('.infaPortlet-icon').remove();
				this._$label.removeClass(labelWithIconClass);
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not contain icon or label');
			}
		},
		
		/**
		 * Adds Configuration Menu as header shortcuts.
		 */		
		createConfigurationMenu: function(configMenuItems) {
			if(this.options.hasHeader) {
				var $headerShortCut = this._$header.find('.infaPortlet-headerShortcut-Menu'); 			
				
				$headerShortCut.infaDropdown({				
					buttonShape : 'iconic',
					buttonIcon : headerShortcutIcon
				});			
				
				var dropdown = $.getWidget($headerShortCut, 'infaDropdown'),
					$menu = dropdown.getMenu(),
					menu = dropdown.getMenuWidget(),
					button = dropdown.getButtonWidget();
				
				var $i18nAlias = infaw.portlet.I18nResources,
					$textUtils = infa.i18n.TextUtils.instance();
				button.setTooltip($textUtils.getText($i18nAlias.SWITCH_TO));
				
				if(menu){
					menu.empty();
					var selectedConfigId = '', pLabel;
					if(this.options.parent != null){
						var portletConfigCache = this.options.parent.getPortletConfigCache();
						if(portletConfigCache){
							selectedConfigId = portletConfigCache.getPanelProperty(this.options.widgetId, '$$configId');
						}
					}								
					$(configMenuItems).each(function(index, configMenuItem){
						var item = menu.add(-1, 'last', 'radio', configMenuItem.label, 'panelHeaderShortCutGroupID');
						$(item).data('id', configMenuItem.id);
						$(item).data('config', configMenuItem.config);
						$(item).data('label', configMenuItem.label);
						if(selectedConfigId != '' && configMenuItem.id == selectedConfigId){
							menu.setChecked(item, true);
							pLabel = configMenuItem.label;
						}
					});
					
					if(pLabel) {
						this.setLabel(pLabel);
					}
				
					var that = this;
					$headerShortCut.on('onSelect', function(e){
						var target = $(e.target);
						if(target.hasClass('infaMenuItem')){					
							var id = target.data('id'),
								config = target.data('config'),
								label = target.data('label');
							
							that.element.trigger('onConfigChange',[{id: id, config: config}]);
							that.setLabel(label);
						}
					});
				}
			} else {
				infa.utils.Utils.instance.logError(this.options.widgetId + ' does not contain configurationMenu');
			}
		}

	});

}(jQuery));
/**
 * @author clam
 * 
 * A widget that contains a set of portlets.
 * It calls PortletExtensionManager for reading portlet information from extension points. 
 */
(function ($) {
	
	//static variables
	var EMPTY_PORTLET_CONFIGID = '__infaEmptyPanelConfig'; 
	
	var USER_ADDED_PORTLET_INSTANCEID_PREFIX =  '__infa_framework_panel';
	
	var SCROLL_WIDTH = 21;
	
	// Custom selector
	$.extend($.expr[':'].portletContainer = function (obj){
		return $(obj).hasClass('portletContainer');
	});
	
	$.widget('infa.portletContainer', { 
		
		skipPortletResizeEvent:false,
		windowHeight: -1,
		windowWidth: -1,
		portletIdToInstance: {}, // key is the full qualified instance id of the portlet widget(widgetId), value is the instance 
								 // of the portlet callback
		parentId : undefined,
		
		portletConfigCache: undefined,
		
		options: {
			/**
			 * parent id for this widget  of the form '<roleId>#<pageId>#<workspaceId>' e.g. 'default#infaPage.indexPage#startPageWS'
			 */
			parentId: '',
			
			/**
			 * TRUE to read the extension contributions and populate the container right after
			 * the widget is created, FALSE if the extension reading will be delayed until 
			 * 'processExtensions()' is called.
			 */
			lazy: false,
			/**
			 * The number of columns
			 */
			columns: 1,
			/**
			 * The minimum width of each column
			 */
			columnMinWidth: 50,
			/**
			 * The Row Height = 1 row span height. Value can be height or it can be function which return the height value. Function is useful when the height is calculated based on the window height.
			 */
			rowHeight: 500,			
			/**
			 * True if the portlets can be moved within the container, and false otherwise.
			 */
			movable: false,
			/**
			 * True if the portlets can be resized within the container, and false otherwise.
			 */			
			resizable: true,
			/**
			 * The width gap between each portlet
			 */
			gutterWidth:	0,
			/**
			 * The height gap between each portlet
			 */
			gutterHeight:	0,
			/**
			 * Any extra data for this widget
			 */
			data: null,
			/**
			 * Use masonry plugin for layout
			 */			
			masonry: true,
			/**
			 * This determines if we should group all portlets with the same column span
			 * i.e if there is column span with 2 column width they are all stacked on top of each other 
			 * and if there is column span of 4 they will also all be stacked on top of each other 
			 * NOTE: THIS ONLY WORKS WITH MASONRY
			 *                       __  ____
			 * With groupColumnSpan:|__||____| 	
			 *                          |____|	<-- With group Column Span portlet will be grouped with same columnSpan
			 *                          __  ____
			 * Without groupColumnSpan:|__||____|		
			 *                         |_____|	<-- Without groupColumnSpan portlet will find furthest top left spot available
			 */                        
			groupColumnSpan: false,
			/**
			 * This helps determine if we should have a bottom gutter or not only usable with groupColumnSpan 
			 * Best scenario for this option to be false is when 
			 * there there are only enough groups to fill the container and you don't need the margin at the bottom of the portlets
			 * i.e 
			 *  __  ____
			 * |  ||____| 	
			 * |__||____|	
			 * 
			 * 
			 * Note: If false will remove the bottom gutter for each group - look below for exmaple
			 * For example there are 3 groups. 
			 *  __________
			 * |__  ______| <---- (1st group will contain only 1 portlet this margin will be removed)
			 * |__||______| <---- (2nd group contains only 1 portlet this margin will be removed)
			 * |__||____| <--- (3rd group contains only 1 portlet this margin will be removed)
			 *	^ (4rth group has colSpan of 1 with 2 portlets only the bottom portlet will be removed)
			 *
			 */
			hasBottomGutter: true
		},

		_create: function() {
			this.parentId = this.options.parentId;
			this.element.attr('id', $.htmlId('portletContainer'))
					.addClass('portletContainer');
			// key is the full qualified instance id of the portlet widget(widgetId), value is the instance 
			// of the portlet callback
			this.portletIdToInstance = {}; 
			if (!this.options.lazy) {
				this.createPortlets();
			}
		},

		/**
		 * Standard jQuery destroy: clean everything as if the widget had never been instantiated. 
		 */
		destroy: function() {
			this.empty();
			$.Widget.prototype.destroy.call(this);
		},
		
		/**
		 * add(label, instanceId, [portletId, hasDropdown, closable])
		 * Creates a portlet and adds it to the container.
		 * This API can be used by the developers to programmatically add a portlet to portlet container.
		 * 
		 * Parameters:
		 * - label: label at the header of the portlet
		 * - instanceId: used in constructing widgetId of the portlet which is this instanceId
		 * - portletId: context id for this portlet, e.g. homePage.inbox. If specified, the id also
		 *   serves as the portlet dropdown menu id, and can be used to contribute additional items 
		 *   to the menu through extension point.
		 * - hasDropdown: true if dropdown is to be shown, false otherwise.
		 * - closable: true if the portlet can be closed, false otherwise.
		 * - headerShortcuts: header shortcuts that appear in a dropdown of configurable workspace
		 * - hasHelp: true if help gesture needs to be shown
		 */
		add: function(label, instanceId, portletId, hasDropdown, closable, headerShortcuts, hasHelp) {
			this._add({
				label: label, 
				instanceId: instanceId, 
				portletId: portletId, 
				hasDropdown: hasDropdown, 
				closable: closable, 
				headerShortcuts: headerShortcuts, 
				hasHelp: hasHelp, 
				lazy: false
			});
		},
		
		_add: function(opts) {
			var that = this,
				currentWorkspace = (this.options.data && this.options.data[0] && this.options.data[0].key === 'workspace') ? 
										this.options.data[0].value : undefined,
				isConfigurable = (currentWorkspace) ? currentWorkspace.isConfigurable() : false;
			
			if(this.options.groupColumnSpan) {
				var $container = this.element.children('[data-colSpan="' + opts.columnSpan + '"]');
				if($container.length === 0) {
					$container = $('<div data-colSpan="' + opts.columnSpan + '"></div>').appendTo(this.element)
						.addClass('masonry-item').data('height', 'auto');
				}
				var $portlet = $('<div></div>').appendTo($container);
			} else {
				if(opts.addAsFirstChild) {
					//adds the current portlet as first element
					var $portlet = $('<div></div>').prependTo(this.element);
				} else {
					var $portlet = $('<div></div>').appendTo(this.element);
				}

				if(this.options.masonry) {
					$portlet.addClass('masonry-item');
				}
			}
				
			$portlet.infaPortlet({ 
				parent: this,
				widgetId: opts.instanceId,
				label: opts.label, 
				icon: opts.icon,
				iconColor: opts.iconColor,
				menuId: opts.portletId, 
				hasDropdown: opts.hasDropdown, 
				hasHelp: opts.hasHelp,
				closable: opts.closable,
				configurable: opts.isConfigurable,
				headerShortcuts: opts.headerShortcuts, //isConfigurable? headerShortcuts: null,
				lazy: opts.lazy,
				cssClass: opts.cssClass,
				hasHeader: opts.hasHeader,
				collapsible: opts.collapsible,
				hideable: opts.hideable,
				loadableEvent: opts.loadableEvent
			});
			
			var data = this.options.data;
			if (data) {
				for (var i = 0; i < data.length; i++) {
					var currData = data[i];
					$portlet.data(currData.key, currData.value);
				}
			}
			
			//attach switch event to added portlet
			this.attachSwitchEvent($portlet);

			return $portlet;
		},
		
		/**
		 * remove(portlet)
		 * Removes the portlet from the container.
		 */
		remove: function(portlet) {
			portlet.element.remove();
			return this;
		},
		
		/**
		 * empty()
		 * Removes all the portlets from the container.
		 */	
		empty: function() {
			this.element.empty();
			return this;
		},
		
		/**
		 * getPortlets()
		 * Returns an array of all the portlets in the container as jQuery objects.
		 */
		getPortlets: function() {
			var $portlets = this.element.find('.infaPortlet');
			var portlets = new Array();
			for (var i = 0; i < $portlets.length; i++) {
				portlets.push($portlets.eq(i));
			};
			return portlets;
		},
		
		/**
		 * count()
		 * Returns the number of portlets in the container.
	 	 * 
		 * Returns: The number of portlets
		 */
		count: function() {
			return this.element.find('.infaPortlet').length;
		},
		
		_getPortletWidget: function($portlet) {
			return $.getWidget($portlet, 'infaPortlet');
		},
		
		createPortlets : function() {
			var that = this;
			this.portletConfigCache = new infaw.portlet.PortletConfigCache(this.parentId);
			
			var $deferred = $.Deferred();
			if(!this.parentId || this.parentId == 0) {
				$deferred.reject();
				return $deferred.promise();
			}
			
			//get the portlet instances for a given workspace id
			var $portletInstancesDeferred = this.portletConfigCache.getPortletInstanceIds();
			
			$portletInstancesDeferred.done(function(instanceIds) {
				if(instanceIds && instanceIds.length > 0){
					var portlets = [], 
						portletConfigs = {}, // map from portlet configId to an array of instanceIds that share that configId
						resourceDeferredArr = [],
						portletDescriptorIDMap = {},
						portletConfigIDMap = {}, 
						portletIdtoConfigsMap = {},//map from portletId to different types of portlet configs
						allPortletConfigs = {},//map which contains all portlet configs
						accessMgr = infaw.access.AccessManager.instance();
					
					allPortletConfigs = $.extend(true, {}, that.portletConfigCache.getPortletConfigs());
					
					for(var i=0; i< instanceIds.length;i++) {
						var instanceId = instanceIds[i], 
							configId = that._getConfigId(instanceId);
						//handle empty portlets
						if(configId === EMPTY_PORTLET_CONFIGID) {
							continue;
						}
						var instances = portletConfigs[configId];
						if (!instances) {
							instances = [];
							portletConfigs[configId] = instances;
						}
						instances.push(instanceId);
					}
					
					for (configId in portletConfigs) {
						portlets.push({id: configId, type: 'panel'}); // populating array to send to access manager
					}

					var self = this;
					accessMgr.getState(portlets, {visible: true, contentVisible: true, readOnly: true}, -1, that.options.data/*this.element.attr('id')*/).done(
						/**
						 * @param {Array.<{id, type, state: Object.<{visible, contentVisible, readOnly, allowed}>}>} states
						 */
						function(states) {
//							console.log(self.element.children());
							var instancesToRemove = {}, // 'set' to keep track of which instances to remove based on configId visibility state 
								portletStates = {};
							
							for (var j = 0; j < states.length; j++){
								var result = states[j];
								if (result){
									var instancesFromConfig = portletConfigs[result.id], configId = result.id;
									if (result.state.visible.value){
										// config is visible
										portletStates[result.id] = result;
										if (result.state.contentVisible.value) {
											var configDeferred = infaw.portlet.PortletExtensionManager.instance().getPortletConfigExtension(configId);
											configDeferred.done(function(configDescriptor) {
												portletConfigIDMap[configDescriptor.$configId] = configDescriptor;
												var descDeferred = infaw.portlet.PortletExtensionManager.instance().getPortletDescriptorExtension(configDescriptor.$portletDescriptorId);
												descDeferred.done(function(portletDescriptorExtn){
													if (portletDescriptorExtn.$package.id){ // only blockRequireResource if 'id' is present
														resourceDeferredArr.push(infa.extensibility.ResourceInclude.blockRequireResource(portletDescriptorExtn));
													}
													portletDescriptorIDMap[portletDescriptorExtn.$portletId] = portletDescriptorExtn;
												});
												
												var defaultPortletConfigId = portletDescriptorIDMap[configDescriptor.$portletDescriptorId].$defaultPortletConfigId;
												
												//if this is default configuration, then only push to portletIdtoConfigsMap
												//otherwise the order of rendering of header shortcuts will change 
												if(defaultPortletConfigId === configDescriptor.$configId) {
													//mapping portletId to array of portlet configs
													var configs = portletIdtoConfigsMap[configDescriptor.$portletDescriptorId];
													if(!configs) {
														configs = [];
														portletIdtoConfigsMap[configDescriptor.$portletDescriptorId] = configs;
													}
													configs.push(configDescriptor);
													//This config has been pushed to portletIdtoConfigsMap. So delete from allPortletConfigs
													delete allPortletConfigs[configDescriptor.$configId];
												}
											});
										}
									} else {
										for (var i = 0; i < instancesFromConfig.length ; i++){
											instancesToRemove[instancesFromConfig[i]] = true; // collect all instances to remove
										}
									}
								}
							}
							
							// remove the instances that are not visible
							for (var i = instanceIds.length-1; i >= 0; i--){
								var instanceId = instanceIds[i];
								if (instancesToRemove[instanceId]){
									instanceIds.splice(i, 1);
								}
							}
							
							//Push the remaining configs into portletIdtoConfigsMap
							for(var key in allPortletConfigs) {
								var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
								portletExtnManager.getPortletConfigExtension(key).done(function(configDescriptor){
									//mapping portletId to array of portlet configs
									var configs = portletIdtoConfigsMap[configDescriptor.$portletDescriptorId];
									if(!configs) {
										configs = [];
										portletIdtoConfigsMap[configDescriptor.$portletDescriptorId] = configs;
									}
									configs.push(configDescriptor);
								});
							}
							
							$.when.apply($, resourceDeferredArr).done(function () {
								// after loading all the extension info...
								var portletInfo = that._getPortletsInfo(instanceIds, portletStates, portletDescriptorIDMap, portletConfigIDMap);
								if($.isArray(portletInfo) && portletInfo.length > 0) {
									// some preparation code for laying out the panels and initializing the
									// content after the panels are added
									var addedPortletArr = [];
									var resourceDeferredArr2 = [];
									var instanceIdToDeferredMap = {};
									for(var i=0; i< portletInfo.length;i++) {
										var portlet = portletInfo[i];
										var $portletDeferred = $.Deferred();
										resourceDeferredArr2.push($portletDeferred);
										instanceIdToDeferredMap[portlet.instanceId] = $portletDeferred;
									}
					        		
					        		$.when.apply($, resourceDeferredArr2).done(function() {
					        			// after all the panels and their dropdown menus are initialized...
					        			
					        			// layout the panels
					        			for (var i = 0; i < addedPortletArr.length; i++) {
					        				var addedPortlet = addedPortletArr[i];
					        				var $portlet = addedPortlet.$portlet;
					        				var portlet = addedPortlet.portlet;
					        				
											
											var colSpan = portlet.columnSpan;
											if (colSpan) {
												colSpan = parseInt(colSpan, 10);
											} else {
												colSpan = 1;
											}
											//set the 
											$portlet.data('columnSpan', colSpan);
										
											var rowSpan = portlet.rowSpan;
											if (rowSpan) {
												rowSpan = parseInt(rowSpan, 10);
											} else {
												rowSpan = 1;
											}
											$portlet.data('rowSpan', rowSpan);
			
											var minWidth = portlet.minWidth;
											if (minWidth) {
												minWidth = parseInt(minWidth, 10);
												$portlet.data('minWidth', minWidth);
											}
											
											var height = portlet.height,
												minHeight = portlet.minHeight,
												maxHeight = portlet.maxHeight;
											

											if (height) {
												$portlet.data('height', height);
											}
											
											if(that.options.groupColumnSpan) {
												if (minHeight) {
													minHeight = parseInt(minHeight, 10);
													$portlet.css('min-height', minHeight);
												}
												
												if (maxHeight) {
													maxHeight = parseInt(maxHeight, 10);
													$portlet.css('max-height', maxHeight);
												}
											} else {
												if (minHeight) {
													minHeight = parseInt(minHeight, 10);
													$portlet.data('minHeight', minHeight);
												}
												
												if (maxHeight) {
													maxHeight = parseInt(maxHeight, 10);
													$portlet.data('maxHeight', maxHeight);
												}
											}
					        			}
					        			
					        			that._layoutPortlet();	
					        			
					        			var loadedArray = [];
					        			
					        			// initialize the panel content
					        			for (var i = 0; i < addedPortletArr.length; i++) {
					        				var addedPortlet = addedPortletArr[i];
					        				var portlet = addedPortlet.portlet;
					        				var configId = that._getConfigId(portlet.instanceId);
					    					//handle empty portlets
					    					if(configId === EMPTY_PORTLET_CONFIGID){
					    						continue;
					    					}
					        				var fullId = portlet.instanceId;
					        				var portletWidget = addedPortlet.portletWidget;
					        				var contentId = addedPortlet.portletContentId;
					        				var state = portletStates[portlet.configId].state;
					        				if (state.contentVisible.value) {
						        				if(portlet.jsClass !== undefined) {
							        				var jsClass =  $.toFunction(portlet.jsClass);
									    		    if (jsClass) {
									    		    	var customProps = that.portletConfigCache.getPanelCustomProperties(fullId);
									    		    	
									    		    	if(portlet.loadableEvent) {
									    		    		var $loadedDeferred = $.Deferred();
									    		    		loadedArray.push($loadedDeferred.promise());
									    		    		$('#' + contentId).one('onPortletLoaded', function() {
									    		    			$loadedDeferred.resolve();
									    		    		});
									    		    	}
									    		    	var portletInst = new jsClass(contentId, fullId, customProps);
									    		    	
									    		    	that.portletIdToInstance[fullId] = portletInst;
									    		    	portletInst.setReadOnly(state.readOnly.value);
									    		    } else {
									    		    	infa.utils.Utils.instance().logError('portlet extension jsClass ' + portlet.jsClass + ' not found');
									    		    }
						        				}
					        				} else {
					        					var portletInst = new infaw.portlet.ContentInvisiblePortlet(contentId, fullId, null, state.contentVisible.message);
							    		    	that.portletIdToInstance[fullId] = portletInst;
					        				}
					        				
					        				portletWidget.processActionExtensions(portlet.portletId);
					        			}
					        			$.when.apply($, loadedArray).done(function() {
						        			that.element.trigger('onProcessExtensions', [$deferred]);
						        			$deferred.resolve();
											that._needResize = true;
						        			that._refreshLayout();
					        			});
					        		});
					        						  
					        		// add the panels
					        		for(var i=0; i< portletInfo.length;i++) {
										var portlet = portletInfo[i];
										var contentVisible = (portletStates[portlet.configId]) ? portletStates[portlet.configId].state.contentVisible.value : undefined;
										var $portlet = that._add({
											label: portlet.label,
											instanceId: portlet.instanceId,
											portletId: portlet.portletId !== undefined ? portlet.portletId : null,
											hasDropdown: contentVisible ? (portlet.hasDropdown !== undefined ? portlet.hasDropdown === 'true': false): false, 
											closable: portlet.closable === 'true',	
											headerShortcuts: portlet.headerShortcuts,
											hasHelp: portlet.hasHelp !== undefined ? portlet.hasHelp === 'true': false,
											lazy: true,
											icon: portlet.icon, 
											iconColor: portlet.iconColor,
											cssClass: portlet.cssClass,
											hasHeader: portlet.hasHeader !== undefined ? portlet.hasHeader === 'true': true,
											addAsFirstChild: undefined,
											collapsible: portlet.collapsible !== undefined ? portlet.collapsible === 'true': false,
											hideable: portlet.hideable !== undefined ? portlet.hideable === 'true': false,
											loadableEvent: portlet.loadableEvent !== undefined ? portlet.loadableEvent === 'true': false,
											columnSpan: portlet.columnSpan
										});
										
										$portlet.on('onConfigChange', function(event, data){
											var $configPortlet = $(event.currentTarget);
											var portletInstance = that.getPortletInstance($configPortlet);
											if(portletInstance.onConfigChange){
												that._saveConfiguration($configPortlet, '$$configId', data.id);
												//save custom properties in config cache
												for (var key in data.config) {
													that._saveConfiguration($configPortlet, key, data.config[key]);
												}
												
												portletInstance.onConfigChange(data.config);
											}
										});
										
										$portlet.on('beforeClose', function(event){
											var $portletToClose = $(event.currentTarget);
											var createdBy = that._getConfiguration($portletToClose, '$$createdBy');
											if(createdBy != undefined && createdBy === 'user' ){
												that._deleteConfiguration($portletToClose);
											}else{
												that._saveConfiguration($portletToClose, '$$show', 'false');
											}										
										});
										if(!(that.options.data && that.options.data.length && that.options.data[0].key === 'objectEditorAssociation')){
											$portlet.on('onHelp', function(event, data){
												var $helpPortlet = $(event.currentTarget);
												var portletInstance = that.getPortletInstance($helpPortlet);
												if(portletInstance.getHelpId){
													var helpId = portletInstance.getHelpId();
													infa.help.HelpUtils.instance().launchHelp(helpId);
												}
											});	
										}
										$portlet.on('afterDestroy', function(event){
											var $portletToClose = $(event.currentTarget);
											
											//remove this div and this will remove it from DOM as well
											
											if(that.options.masonry) {
												that.element.masonry( 'remove', $portletToClose);
												that.element.masonry('resize');												
											} else {
												$portletToClose.remove();
											}
											//reset the positions again
											$.each(that.element.children(), function(index, item){
												that._saveConfiguration($(item), '$$position', index + 1);
											});
											
											//show addPanel link if all portlets are removed
											if(that.count()==0) {
												that.showAddPanelLink();
											}
										});
										$portlet.on('onEdit', function(event){
											var $portletToEdit = $(event.currentTarget);
											that._editPanel($portletToEdit);
										});
										var portletWidget = that._getPortletWidget($portlet);
				        				var $content = portletWidget.getContent();
				        				var contentId = $.htmlId('infaPortletCnt');
										$content.attr('id', contentId);
										addedPortletArr.push({ $portlet: $portlet, portlet: portlet, portletWidget: portletWidget, portletContentId: contentId });
										var $menu = portletWidget.getMenu();
										
										// resolve the deferred created earlier so that the panels can be
										// laid out and their content can be initialized after all the
										// panels are added
										if ($menu) {
											(function($menu, portlet, portletWidget) {
												$menu.on('onProcessExtensions', function() {
													if(portletWidget.options.configurable) {
														//will create Edit, Remove actions in dropdown
														portletWidget.createConfigurableMenuItems();
													} else {
														//will create Remove action if portlet is closable
														portletWidget.createCloseMenuItem();
													}
													
													
													var portletDescriptorId = portletConfigIDMap[portlet.configId].$portletDescriptorId;
													var configs = portletIdtoConfigsMap[portletDescriptorId];
													//if there is more than one configuration, show "Configuration" menu 
													if(configs.length > 1) {
														var configMenuItems = that._getConfigurationMenuItemsWithCustomProps(portletDescriptorIDMap[portletDescriptorId],
																															configs);
														portletWidget.createConfigurationMenu(configMenuItems);
													}
													
													portletWidget.createHelpMenuItem();
													var $portlet = $(this).closest(':infaPortlet');
													var iPortlet = $.getWidget($portlet, 'infaPortlet');
													var $content = iPortlet.getContent();
													instanceIdToDeferredMap[iPortlet.getWidgetId()].resolve();
												});
											})($menu, portlet, portletWidget);
											
											if(portletWidget.getMenuWidget() && portletWidget.getMenuWidget().processExtensions) {
												portletWidget.getMenuWidget().processExtensions();
											}
										} else {
											resourceDeferredArr2[i].resolve();
										}
					        		}
								} else {
									//There are no portlets/panels
									that.showAddPanelLink();
								}
							});
						}).fail(function(resp){
							$deferred.reject(resp);
						});
				}else {
					$deferred.resolve();
					
					//There are no portlets/panels
					that.showAddPanelLink();
				}
			});
			
			return $deferred.promise();
		},
		
		/**
		 * Returns the portlet callback instance for the given portlet widget.
		 */
		getPortletInstance: function($portlet) {
			var portlet = this._getPortletWidget($portlet);
			return this.portletIdToInstance[portlet.getWidgetId()];
		},
		
		getPortletInstanceById : function (id){
			return this.portletIdToInstance[id];
		},
		
		getSelection: function($portlet) {
			var instance = this.getPortletInstance($portlet);
			if (instance) {
				return instance.getSelection();
			}
		},		
		
		/**
		 * This API is called by the framework when an end user does 'Add Panel'
		 * to add a portlet to the workspace/dashboard at runtime
		 * 
		 */
		addPanel: function(){	
			var panelConfig = new infaw.portlet.addPanelConfig(this.portletConfigCache);
			panelConfig.createUI(this._getPaletteDeferred());
		},
		
		/**
		 * This API is used to create portlet during addPanel action
		 * This will be called after user chooses panel template
		 * 
		 */
		createPanel: function() {
			var that = this;
			var currentWorkspace = this.options.data[0].value;
			var $i18nAlias = infaw.portlet.I18nResources,
				$textUtils = infa.i18n.TextUtils.instance();
			
			var label = $textUtils.getText($i18nAlias.NEW_PANEL);
			
			//creating the unique id of the instance at runtime by appending the type of the porlet with the timestamp
			//TODO this needs to be revisited later 
			var instanceId = USER_ADDED_PORTLET_INSTANCEID_PREFIX + (new Date()).getTime();
			var $portlet = this._add({
				label: label,
				instanceId: instanceId,
				hasDropdown: true,
				closable: true,
				lazy: true,
				hasHeader: true,
				addAsFirstChild: true
			});
			
			//binding events
			$portlet.on('onConfigChange', function(event, data){
				var $configPortlet = $(event.currentTarget);
				var portletInstance = that.getPortletInstance($configPortlet);
				if(portletInstance.onConfigChange){
					that._saveConfiguration($configPortlet, '$$configId', data.id);
					//save custom properties in config cache
					for (var key in data.config) {
						that._saveConfiguration($configPortlet, key, data.config[key]);
					}
					portletInstance.onConfigChange(data.config);
				}
			});
			$portlet.on('onHelp', function(event, data){
				var $helpPortlet = $(event.currentTarget);
				var portletInstance = that.getPortletInstance($helpPortlet);
				if(portletInstance.getHelpId){
					var helpId = portletInstance.getHelpId();
					infa.help.HelpUtils.instance().launchHelp(helpId);
				}
			});
			$portlet.on('beforeClose', function(event){
				var $portletToClose = $(event.currentTarget);
				var createdBy = that._getConfiguration($portletToClose, '$$createdBy');
				if(createdBy != undefined && createdBy === 'user' ){
					that._deleteConfiguration($portletToClose);
				}else{
					that._saveConfiguration($portletToClose, '$$show', 'false');
				}
			});
			
			$portlet.on('afterDestroy', function(event){
				var $portletToClose = $(event.currentTarget);
				
				//remove this div and this will remove it from DOM as well
				if(that.options.masonry) {
					that.element.masonry( 'remove', $portletToClose);
					that.element.masonry('resize');					
				} else {
					$portletToClose.remove();
				}
				//reset the positions again
				$.each(that.element.children(), function(index, item){
					that._saveConfiguration($(item), '$$position', index + 1);
				});
				
				//show addPanel link if all portlets are removed
				if(that.count()==0) {
					that.showAddPanelLink();
				}
			});
			
			$portlet.on('onEdit', function(event){
				var $portletToEdit = $(event.currentTarget);
				that._editPanel($portletToEdit);
			});
			var portletWidget = that._getPortletWidget($portlet);
			var $content = portletWidget.getContent();
			var contentId = $.htmlId('infaPortletCnt');
			$content.attr('id', contentId);
			
			
			//update the position of all portlets
			// this will internally add new portlet to user pref object as well if it is not there already
			$.each(that.element.children(), function(index, item){
				that._saveConfiguration($(item), '$$position', index + 1);
			});
			
			//then update that this portlet is created by end user and update other properties
			that._saveConfiguration($portlet, '$$configId', EMPTY_PORTLET_CONFIGID);
			that._saveConfiguration($portlet, '$$type', 'instance');
			that._saveConfiguration($portlet, '$$createdBy', 'user');
			that._saveConfiguration($portlet, '$$label', label);
			that._saveConfiguration($portlet, '$$closable', 'true');
				
			if(that.options.masonry) {
				that.element.masonry( 'appended',  $portlet.addClass('masonry-item'));	
			}			
			
			//update the position of all portlets after layout
			$.each(that.element.children(), function(index, item){
				that._saveConfiguration($(item), '$$position', index + 1);
			});
			
			return $portlet;
		},
		
		/**returns a map of typeId to configs
		 * 
		 *  {
		 * 		typeId:   {
		 * 				 		label: '',
		 * 						defaultConfig: {id: '', label: ''},
		 * 						configs: [{configId: '', label: ''}, ...]
		 * 
		 * 				  },
		 * 
		 * 		typeId1: {
		 * 					
		 * 				 }
		 *  }
		 *  
		 */
		_getPaletteDeferred: function(){
			var paletteDeferred = $.Deferred();
			var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
			var configs = this.portletConfigCache.getPortletConfigs();
			var portletIdToConfigsMap = {};
			var allDeferreds = [];
			
			for(var key in configs) {
				var loopDeferred = $.Deferred();
				allDeferreds.push(loopDeferred);
				var configId = key;
				
				var descriptorId = configs[key]['$$descriptorId'];
				if(portletIdToConfigsMap[descriptorId] == undefined){
					var descriptorDeferred = portletExtnManager.getPortletDescriptorExtension(descriptorId);
					var currentConfigDeferred = portletExtnManager.getPortletConfigExtension(configId);
					var deferredArr = [];
					deferredArr.push(descriptorDeferred);
					deferredArr.push(currentConfigDeferred);
					//Executing the inline function to create the closure for passing variables of each iteration of the loop
					(function(configId, descriptorId, loopDeferred){
						$.when.apply($, deferredArr).done(function (arg1, arg2) {
							var portletDescriptor = arg1;
							var configDescriptor = arg2;
							var defaultConfigId = portletDescriptor.$defaultPortletConfigId;
							portletIdToConfigsMap[descriptorId] = {label : portletDescriptor.$label, configs: []};
							if(defaultConfigId === configId){
								portletIdToConfigsMap[descriptorId]['defaultConfig'] = {id: defaultConfigId, label: configDescriptor.$label };
								loopDeferred.resolve();
							}else{
								//Executing the inline function to create the closure for passing variables of each iteration of the loop
								(function(loopDeferred, defaultConfigId, configDescriptor){
									portletExtnManager.getPortletConfigExtension(defaultConfigId).done(function(defaultConfigDescriptor){
										portletIdToConfigsMap[descriptorId]['defaultConfig'] = {id: defaultConfigId, label:defaultConfigDescriptor.$label }
										portletIdToConfigsMap[descriptorId].configs.push({configId: configId, label: configDescriptor.$label});
										loopDeferred.resolve();
									});
								})(loopDeferred, defaultConfigId, configDescriptor);
							}
						});
					})(configId, descriptorId, loopDeferred);
					
				}else{
					if(portletIdToConfigsMap[descriptorId].defaultConfig.id === configId){
						loopDeferred.resolve();
					}else{
						//Executing the inline function to create the closure for passing variables of each iteration of the loop
					    (function(configId, loopDeferred){
							portletExtnManager.getPortletConfigExtension(configId).done(function(configDescriptor){
								portletIdToConfigsMap[descriptorId].configs.push({configId: configId, label: configDescriptor.$label});
								loopDeferred.resolve();
							});
					    })(configId, loopDeferred);
					}
				}
				
				
			}
			
			$.when.apply($, allDeferreds).done(function() {
				paletteDeferred.resolve(portletIdToConfigsMap);
				return;
		    });
			
			return paletteDeferred.promise();
		},
		
		_editPanel: function(portlet){
			var panelConfig = new infaw.portlet.addPanelConfig(this.portletConfigCache, portlet);
			panelConfig.createUI(this._getPaletteDeferred());
		},
		
		_getPortletsInfo: function(instanceIds, portletStates, portletDescriptorIDMap, portletConfigIDMap){
			var portletInfo = [];
			for(var j in instanceIds) {
				var instanceId = instanceIds[j];
				var configId = this._getConfigId(instanceId);
				var portletInstance = {};
				var portletDescriptor = null;
				//handle empty portlets
				if(configId !== EMPTY_PORTLET_CONFIGID &&
				   portletStates[configId].state.contentVisible.value){
					var portletConfig = portletConfigIDMap[configId];
					portletDescriptor = portletDescriptorIDMap[portletConfig.$portletDescriptorId];
					portletInstance.portletId = portletDescriptor.$portletId;
				}
				
				portletInstance.instanceId = instanceId;
				portletInstance.configId = configId;
				
				//get non configurable properties from extension point
				if(portletDescriptor != null){
					portletInstance.icon = portletDescriptor.$icon;
					portletInstance.iconColor = portletDescriptor.$iconColor;
					portletInstance.jsClass = portletDescriptor.$jsClass;
					portletInstance.packageId = portletDescriptor.$package;
					portletInstance.hasDropdown = portletDescriptor.$hasDropdown;
					portletInstance.minWidth = portletDescriptor.$minWidth;
					portletInstance.minHeight = portletDescriptor.$minHeight;
					portletInstance.maxHeight = portletDescriptor.$maxHeight;
					portletInstance.height = portletDescriptor.$height;
					portletInstance.hasHelp = portletDescriptor.$hasHelp;
					portletInstance.hasHeader = portletDescriptor.$hasHeader;
					portletInstance.cssClass = portletDescriptor.$cssClass;
					portletInstance.collapsible = portletDescriptor.$collapsible;
					portletInstance.hideable = portletDescriptor.$hideable;
					portletInstance.loadableEvent = portletDescriptor.$loadableEvent;
				}
				
				var nativeProps = this.portletConfigCache.getPanelNativeProperties(instanceId);
				//get the configurable properties from config object
				
				//DONT Add a closed/hidden portlet
				if(nativeProps['$$show'] && nativeProps['$$show'] === 'false'){
					continue;
				}
				
				portletInstance.label = nativeProps['$$label'];
				portletInstance.closable = nativeProps['$$closable'];
				portletInstance.columnSpan = nativeProps['$$columnSpan'];
				portletInstance.rowSpan = nativeProps['$$rowSpan'];
				portletInstance.position = nativeProps['$$position'];

				portletInfo.push(portletInstance);
			}

			// sort the portletInfo based on the preferred position specified in configuration
			portletInfo.sort(function(portlet1, portlet2) {
				var pos1 = portlet1.position;
				var pos2 = portlet2.position;
				if (pos1 == pos2) {
					return 0;
				}
				if (!pos1) {
					return 1;
				}
				if (!pos2) {
					return -1;
				}
				return pos1 - pos2;
			});
			
			return portletInfo;
		},
		
		
		_layoutPortlet: function() {	
			this.element.addClass('infaPadding');
			this.columnsDisplayed = this.options.columns;
			this._setPortletDimensions();		
			var that = this;			
			
			
			if(this.options.masonry) {
				this.element.masonry({
					itemSelector: '.masonry-item',
					columnWidth: function() {
						return that._getColumnWidth();
					},
					gutterWidth: this.options.gutterWidth,
					isResizable: false
				});				
			}

			if(this.options.movable) {
				this._initializeSortable();
			}	

			var $win=$(window);
			this.windowHeight = $win.height();
			this.windowWidth = $win.width();			
						
			$win.on('pageresize', function() {
				that._refreshLayout();				
			});										
				
			this.element.on({
				'onFloatPanelDock onFloatPanelResize' : function(){			
					if(that.element.width() > 0) {
						that._resizeGridItems(true);
					}
				},
				'resizePortletContainer' : function() {
					that._needResize = true;
					that._refreshLayout();
				}
			}).on('baresize', '.infaPortlet', function() {
				that._needResize = true;
				that._refreshLayout();
			});
		},
	
		_setPortletDimensions: function() {
			if(this.options.masonry) {
				this.element.width(this.element.parent().width() - 1);
				this.element.height(this.element.parent().height());
			}			
			var columnWidth = this._getColumnWidth();
			if(columnWidth <= 0) {
				this._needResize = true;
				return;
			}
			
			var $items = this.element.children(),
				that = this;
			
			// ktruong: Because we do not have a fluid design 
			// we need to hide the overflow when it is refreshing the portlet dimensions
			// we will reset the overflow after it finishes updating the children's item height/width
			var overflow = this.element.css('overflow');
			this.element.css('overflow', 'hidden');
			
			for (var i=0, len = $items.length; i < len; i++) {
				var $item = $($items[i]);
				
				if(this.options.groupColumnSpan)  {
					var columnSpanAttr = $item.attr('data-colSpan'),
						$groupItems = $item.children('.infaPortlet');
					
					$item.data('minWidth', $groupItems.eq(0).data('minWidth'));
					for(var j = 0; j < $groupItems.length; j++) {
						var $groupItem = $groupItems.eq(j),
							rowHeight = 0,
							itemHeight = this._calculateItemHeight($groupItem);
							
						if(this.options.hasBottomGutter || j !== $groupItems.length -1) {
							$groupItem.css({
								'margin-bottom': this.options.gutterHeight,
								'height': itemHeight
							});
						} else {
							if(itemHeight !== 'auto') {
								itemHeight -= this.options.gutterHeight;
							}
							$groupItem.css('height', itemHeight);
						}
					}
				} else {
					//first try to get columnSpan from config object
					var columnSpanAttr = this._getConfiguration($item, 'columnSpan');
					if(!columnSpanAttr) {
						columnSpanAttr = $item.data('columnSpan');
						if(!columnSpanAttr) {
							columnSpanAttr = $item.data('columnspan'); //HTML5 data => data-columnSpan
						}
					} 
				}
					
				var columnSpan = columnSpanAttr ? parseInt(columnSpanAttr, 10) : 1;
				//If the columnSpan is more than number of columns, set columnSpan to number of columns 
				if(columnSpan > this.columnsDisplayed)
					columnSpan = this.columnsDisplayed;
				
				var minWidthAttr = $item.data('minWidth');
				if(!minWidthAttr) {
					minWidthAttr = $item.data('minwidth'); //HTML5 data => data-minWidth
				}
				
				var minWidth = minWidthAttr ? parseInt(minWidthAttr, 10) : 0;
				while(columnWidth > 0 && columnWidth * columnSpan < minWidth && minWidth > 0) {
                    columnSpan++;
				}
				
				var borderWidth = Math.ceil($item.outerWidth() - $item.width()),
					itemWidth = columnWidth * columnSpan + this.options.gutterWidth * (columnSpan - 1) - borderWidth;
				
				// height stuff
				var itemHeight = this._calculateItemHeight($item),
					minHeight,
					maxHeight;

				var minHeightAttr =  $item.data('minHeight');
				if(!minHeightAttr){
					minHeightAttr = $item.data('minheight'); //HTML5 data					
				}
				minHeight = minHeightAttr? parseInt(minHeightAttr, 10) : undefined;
						
				var maxHeightAttr =  $item.data('maxHeight');
				if(!maxHeightAttr){
					maxHeightAttr = $item.data('maxheight'); //HTML5 data					
				}
				maxHeight = maxHeightAttr? parseInt(maxHeightAttr, 10) : undefined;
				
				this.skipPortletResizeEvent=true;				
				$item.css({
					'width'  : Math.floor(itemWidth),
					'height' : itemHeight,
					'min-height': minHeight,
					'max-height': maxHeight,
					'float'  : 'left'
				});
				this.skipPortletResizeEvent=false;
				
				if(!this.options.groupColumnSpan) {
					$item.css({
						"overflow": "hidden",
						"margin-right": this.options.gutterWidth,
						"margin-bottom": this.options.gutterHeight
					});
				}
				
				if(this.options.movable) {
					$item.find(':infaPortletHeader').css('cursor', 'move');
				}
				
				if(this.options.resizable) {
					this._makeResizable($item, rowHeight, columnWidth, minWidth);
				}
				
				$item.find('.infaPortlet-content').trigger('onPortletResize');
			}

			this.element.css('overflow', overflow);
		},
		
		_calculateItemHeight: function($item) {
			var height = $item.data('height'),
				itemHeight = 0;
			
			if (height && height.toLowerCase() === "auto") {
				itemHeight = "auto"; 
			} else if (!isNaN(parseInt(height, 10))) {
				var borderHeight = Math.ceil($item.outerHeight() - $item.height());
				itemHeight = parseInt(height, 10) - borderHeight;
			} else {	
				var rowHeight = 0,
					rowSpanAttr = this._getConfiguration($item, 'rowSpan');
				if(!rowSpanAttr) {
					rowSpanAttr =  $item.data('rowSpan');
					if(!rowSpanAttr){
						rowSpanAttr = $item.data('rowspan'); //HTML5 data => data-rowSpan
					}
				}					
				var rowSpan = rowSpanAttr ? parseInt(rowSpanAttr, 10): 1;			
				
				if($.isFunction(this.options.rowHeight)) {
					rowHeight = this.options.rowHeight();
				} else {
					rowHeight = this.options.rowHeight;
				}
				rowHeight = Math.floor(rowHeight);
				
				var borderHeight = Math.ceil($item.outerHeight() - $item.height());
				itemHeight = rowHeight * rowSpan + this.options.gutterHeight * (rowSpan - 1) - borderHeight;
			}
			return itemHeight;
		},
		
		_makeResizable : function($item, rowHeight, columnWidth, columnMinWidth) {
			var self = this;
			$item.resizable({				
				minHeight : 50,
				minWidth : columnMinWidth,
				grid : [columnWidth + this.options.gutterWidth, rowHeight + this.options.gutterHeight],
				stop: function(e, ui) {
					var rSpan = (ui.size.height + self.options.gutterHeight) / (rowHeight + self.options.gutterHeight);
					ui.element.data('rowSpan', Math.round(rSpan));
					//save to user preference
					self._saveConfiguration(ui.element, '$$rowSpan', Math.round(rSpan));
					
					
					var cSpan = (ui.size.width + self.options.gutterWidth) / (columnWidth + self.options.gutterWidth);
					ui.element.data('columnSpan', Math.round(cSpan));
					//save to user preference
					self._saveConfiguration(ui.element, '$$columnSpan', Math.round(cSpan));
					
					self._resizeGridItems(true);
				}
			});					
			
			//TODO: jQuery UI bug - jQuery draggable shows helper in wrong place when scrolled down page
			//http://bugs.jqueryui.com/ticket/3740
			//http://stackoverflow.com/questions/5791886/jquery-draggable-shows-helper-in-wrong-place-when-scrolled-down-page
		},
		
		_getColumnWidth: function() {
			if(this.options.columns === 1) {
				return this.element.width();
			}
			
			var columnWidth = 0, 
				numberOfCols = this.options.columns,
				elementWidth = this.element.width() - SCROLL_WIDTH;
			
			while(columnWidth < this.options.columnMinWidth && columnWidth >= 0) {
				columnWidth = (elementWidth - (numberOfCols - 1)  * this.options.gutterWidth) / numberOfCols;
				numberOfCols--;
			}
			
			this.columnsDisplayed = numberOfCols + 1;
			
			return Math.floor(columnWidth);
		},
		
		_initializeSortable: function(){
			var that = this;
			this.element.sortable({
				scroll: true,
				revert: true,
				handle: ':infaPortletHeader',
				cursor: 'move',
				distance: 12,
				forcePlaceholderSize: true,
				items: '> div',
				placeholder: 'infaPortlet-placeholder',
				tolerance: 'pointer',				        
				start:  function(event, ui) {  
					$.getWidget(ui.item, 'infaPortlet').activate();
					ui.item.addClass('dragging');
					
					// Add Height to Placeholder
					ui.placeholder.css({
						'float': 'left',
						'width': ui.item.width(),
						'height': ui.item.height()
					});
					
					if(that.options.masonry) {
						ui.item.removeClass('masonry-item');
						ui.placeholder.addClass('masonry-item');
						that.element.masonry('reload');	
					}					
				},
				change: function(event, ui) {
					if(that.options.masonry) {
						that.element.masonry('reload');	
					}
				},
				stop:   function(event, ui) { 
					ui.item.removeClass('dragging');
					if(that.options.masonry) {
						ui.item.addClass('masonry-item');
						that.element.masonry('reload');	
					}
					/*
					 * changing position of one portlet changes the position of all portlet in the portlet container.
					 * Set the new position of portlet to data.
					 */
					$.each(that.element.children(), function(index, item){
						that._saveConfiguration($(item), '$$position', index + 1);
					});
				}
			});					
		},		
		
		_resizeGridItems: function(resizePortlet) {
			if(this.element.is(":visible")) {	
				if(resizePortlet) {
					this._setPortletDimensions();	
				}
				if(this.options.masonry) {
					this.element.masonry('resize');	
				}
			}
		},
		
		_refreshLayout: function() {
			if(this.element.is(":visible")) {
				var w=$(window),
				ww=w.width(),
				wh=w.height();
				if(ww!=this.windowWidth || wh != this.windowHeight || this._needResize) {
					this._needResize = false;
					this.skipPortletResizeEvent=true;
					this._resizeGridItems(true);
					this.skipPortletResizeEvent=false;

					this.windowWidth = ww;
					this.windowHeight = wh;
				}
			}				
		},
		
		_saveConfiguration: function($element, propName, propValue){
			var portlet = this._getPortletWidget($element);
			var portletKey = portlet.getWidgetId();
			this.portletConfigCache.saveProperty(portletKey, propName, propValue);
		},
		
		_getConfiguration: function($element, propName){
			var portlet = this._getPortletWidget($element);
			var portletKey = portlet.getWidgetId();
			return this.portletConfigCache.getPanelProperty(portletKey, propName);
		},
		
		_deleteConfiguration: function($element){
			var portlet = this._getPortletWidget($element);
			var portletKey = portlet.getWidgetId();
			this.portletConfigCache.deletePanelConfig(portletKey);
		},
		
		_getConfigId: function(instanceId) {
			var configId = this.portletConfigCache.getPanelProperty(instanceId, '$$configId');
			return configId;
		},
		
		updateInstanceCache: function(portletWidgetId, portletInst){
			this.portletIdToInstance[portletWidgetId] = portletInst;
		},
		
		clearInstanceCache: function(portletWidgetId){
			this.portletIdToInstance[portletWidgetId] = undefined;
		},
		
		saveAndCommit: function(){
			var $deferred = $.Deferred();
			//save all configs in portletconfig cache to server
			this.portletConfigCache.saveConfigs().done(function(){
				$deferred.resolve();
			});
			
			return $deferred.promise();
		},
		
		getPortletConfigCache: function(){
			return this.portletConfigCache;
		},
			
		/**
		 * Shows Add Panel link if the workspace is configurable
		 */
		showAddPanelLink: function() {
			var currentWorkspace = (this.options.data && this.options.data[0] && this.options.data[0].key === 'workspace') ? 
					this.options.data[0].value : undefined;
			var isWSConfigurable = (currentWorkspace) ? currentWorkspace.isConfigurable() : false;
			
			if(isWSConfigurable) {
				var that = this;
	            var addPanelDiv = $('<div id="addPanelDiv"></div>').addClass("addPanelDiv");
				var hrefElement = $("<a href='#'> Add a Panel... </a>");
				addPanelDiv.append(hrefElement);
				
				hrefElement.click(function(e) {
					that.addPanel();
			    });
	
				that.element.append(addPanelDiv);
			}
		},
		
		removeAddPanelLink: function() {
			$('#addPanelDiv').remove();
		},

		/**
		 * For every portlet, switch event will be added
		 */
		attachSwitchEvent: function(portlet) {
			portlet.bind('keydown', function(e) {
				if (e.altKey && e.keyCode==80 /*Alt+p*/) {
					var portlets = $(this).parent().children();
					var currentPortletIndex = portlets.index($(this));
					var nextPortletIndex = (currentPortletIndex + 1) % portlets.length;  

					while(nextPortletIndex != currentPortletIndex) {
						var nextPortlet = portlets.eq(nextPortletIndex);
						//Find first accessible element in next portlet
						var fElement = nextPortlet.find("a, button, input, select, textarea, [tabindex='0']").filter(":visible:first");
						//if focusable element present in this portlet
						if(fElement.length != 0) {
							fElement.focus();
							break;
						} else {
							//Go to next portlet
							nextPortletIndex = (nextPortletIndex + 1) % portlets.length;
						}
					}
					
				}
	    	})
		},
		
		
		/**
		 * Provides configurarion menu items with custom properties
		 */
		_getConfigurationMenuItemsWithCustomProps: function(portletDescriptor, configs) {
			var configMenuItems = [];
			var portletConfigUtils = infaw.portlet.PortletConfigUtils.instance();
			
			var customPropertyMap = portletConfigUtils.getDefaultCustomProps(portletDescriptor);
			$(configs).each(function(index,pConfig){
				var customConfig = portletConfigUtils.applyCustomConfig(customPropertyMap,pConfig);
				var lwConfig =  portletConfigUtils.getLWConfig(customConfig);
				configMenuItems.push({id:pConfig.$configId,label:pConfig.$label,
						  config: lwConfig});
			});
			
			return configMenuItems;
		}		
	});
	
}(jQuery));
/*!
 * jQuery resize event - v1.1 - 3/14/2010
 * http://benalman.com/projects/jquery-resize-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */

// Script: jQuery resize event
//
// *Version: 1.1, Last updated: 3/14/2010*
// 
// Project Home - http://benalman.com/projects/jquery-resize-plugin/
// GitHub       - http://github.com/cowboy/jquery-resize/
// Source       - http://github.com/cowboy/jquery-resize/raw/master/jquery.ba-resize.js
// (Minified)   - http://github.com/cowboy/jquery-resize/raw/master/jquery.ba-resize.min.js (1.0kb)
// 
// About: License
// 
// Copyright (c) 2010 "Cowboy" Ben Alman,
// Dual licensed under the MIT and GPL licenses.
// http://benalman.com/about/license/
// 
// About: Examples
// 
// This working example, complete with fully commented code, illustrates a few
// ways in which this plugin can be used.
// 
// resize event - http://benalman.com/code/projects/jquery-resize/examples/resize/
// 
// About: Support and Testing
// 
// Information about what version or versions of jQuery this plugin has been
// tested with, what browsers it has been tested in, and where the unit tests
// reside (so you can test it yourself).
// 
// jQuery Versions - 1.3.2, 1.4.1, 1.4.2
// Browsers Tested - Internet Explorer 6-8, Firefox 2-3.6, Safari 3-4, Chrome, Opera 9.6-10.1.
// Unit Tests      - http://benalman.com/code/projects/jquery-resize/unit/
// 
// About: Release History
// 
// 1.1 - (3/14/2010) Fixed a minor bug that was causing the event to trigger
//       immediately after bind in some circumstances. Also changed $.fn.data
//       to $.data to improve performance.
// 1.0 - (2/10/2010) Initial release

(function($,window,undefined){
  '$:nomunge'; // Used by YUI compressor.
  
  // A jQuery object containing all non-window elements to which the resize
  // event is bound.
  var elems = $([]),
    
    // Extend $.resize if it already exists, otherwise create it.
    jq_resize = $.baresize = $.extend( $.baresize, {} ),
    
    timeout_id,
    
    // Reused strings.
    str_setTimeout = 'setTimeout',
    str_resize = 'baresize',
    str_data = str_resize + '-special-event',
    str_delay = 'delay',
    str_throttle = 'throttleWindow';
  
  // Property: jQuery.resize.delay
  // 
  // The numeric interval (in milliseconds) at which the resize event polling
  // loop executes. Defaults to 250.
  
  jq_resize[ str_delay ] = 250;
  
  // Property: jQuery.resize.throttleWindow
  // 
  // Throttle the native window object resize event to fire no more than once
  // every <jQuery.resize.delay> milliseconds. Defaults to true.
  // 
  // Because the window object has its own resize event, it doesn't need to be
  // provided by this plugin, and its execution can be left entirely up to the
  // browser. However, since certain browsers fire the resize event continuously
  // while others do not, enabling this will throttle the window resize event,
  // making event behavior consistent across all elements in all browsers.
  // 
  // While setting this property to false will disable window object resize
  // event throttling, please note that this property must be changed before any
  // window object resize event callbacks are bound.
  
  jq_resize[ str_throttle ] = true;
  
  // Event: resize event
  // 
  // Fired when an element's width or height changes. Because browsers only
  // provide this event for the window element, for other elements a polling
  // loop is initialized, running every <jQuery.resize.delay> milliseconds
  // to see if elements' dimensions have changed. You may bind with either
  // .resize( fn ) or .bind( "resize", fn ), and unbind with .unbind( "resize" ).
  // 
  // Usage:
  // 
  // > jQuery('selector').bind( 'resize', function(e) {
  // >   // element's width or height has changed!
  // >   ...
  // > });
  // 
  // Additional Notes:
  // 
  // * The polling loop is not created until at least one callback is actually
  //   bound to the 'resize' event, and this single polling loop is shared
  //   across all elements.
  // 
  // Double firing issue in jQuery 1.3.2:
  // 
  // While this plugin works in jQuery 1.3.2, if an element's event callbacks
  // are manually triggered via .trigger( 'resize' ) or .resize() those
  // callbacks may double-fire, due to limitations in the jQuery 1.3.2 special
  // events system. This is not an issue when using jQuery 1.4+.
  // 
  // > // While this works in jQuery 1.4+
  // > $(elem).css({ width: new_w, height: new_h }).resize();
  // > 
  // > // In jQuery 1.3.2, you need to do this:
  // > var elem = $(elem);
  // > elem.css({ width: new_w, height: new_h });
  // > elem.data( 'resize-special-event', { width: elem.width(), height: elem.height() } );
  // > elem.resize();
      
  $.event.special[ str_resize ] = {
    
    // Called only when the first 'resize' event callback is bound per element.
    setup: function() {
      // Since window has its own native 'resize' event, return false so that
      // jQuery will bind the event using DOM methods. Since only 'window'
      // objects have a .setTimeout method, this should be a sufficient test.
      // Unless, of course, we're throttling the 'resize' event for window.
      if ( !jq_resize[ str_throttle ] && this[ str_setTimeout ] ) { return false; }
      
      var elem = $(this);
      
      // Add this element to the list of internal elements to monitor.
      elems = elems.add( elem );
      
      // Initialize data store on the element.
      $.data( this, str_data, { w: elem.width(), h: elem.height() } );
      
      // If this is the first element added, start the polling loop.
      if ( elems.length === 1 ) {
        loopy();
      }
    },
    
    // Called only when the last 'resize' event callback is unbound per element.
    teardown: function() {
      // Since window has its own native 'resize' event, return false so that
      // jQuery will unbind the event using DOM methods. Since only 'window'
      // objects have a .setTimeout method, this should be a sufficient test.
      // Unless, of course, we're throttling the 'resize' event for window.
      if ( !jq_resize[ str_throttle ] && this[ str_setTimeout ] ) { return false; }
      
      var elem = $(this);
      
      // Remove this element from the list of internal elements to monitor.
      elems = elems.not( elem );
      
      // Remove any data stored on the element.
      elem.removeData( str_data );
      
      // If this is the last element removed, stop the polling loop.
      if ( !elems.length ) {
        clearTimeout( timeout_id );
      }
    },
    
    // Called every time a 'resize' event callback is bound per element (new in
    // jQuery 1.4).
    add: function( handleObj ) {
      // Since window has its own native 'resize' event, return false so that
      // jQuery doesn't modify the event object. Unless, of course, we're
      // throttling the 'resize' event for window.
      if ( !jq_resize[ str_throttle ] && this[ str_setTimeout ] ) { return false; }
      
      var old_handler;
      
      // The new_handler function is executed every time the event is triggered.
      // This is used to update the internal element data store with the width
      // and height when the event is triggered manually, to avoid double-firing
      // of the event callback. See the "Double firing issue in jQuery 1.3.2"
      // comments above for more information.
      
      function new_handler( e, w, h ) {
        var elem = $(this),
          data = $.data( this, str_data );
        
        // If called from the polling loop, w and h will be passed in as
        // arguments. If called manually, via .trigger( 'resize' ) or .resize(),
        // those values will need to be computed.
        data.w = w !== undefined ? w : elem.width();
        data.h = h !== undefined ? h : elem.height();
        
        old_handler.apply( this, arguments );
      };
      
      // This may seem a little complicated, but it normalizes the special event
      // .add method between jQuery 1.4/1.4.1 and 1.4.2+
      if ( $.isFunction( handleObj ) ) {
        // 1.4, 1.4.1
        old_handler = handleObj;
        return new_handler;
      } else {
        // 1.4.2+
        old_handler = handleObj.handler;
        handleObj.handler = new_handler;
      }
    }
    
  };
  
  function loopy() {
    
    // Start the polling loop, asynchronously.
    timeout_id = window[ str_setTimeout ](function(){
      
      // Iterate over all elements to which the 'resize' event is bound.
      elems.each(function(){
        var elem = $(this),
          width = elem.width(),
          height = elem.height(),
          data = $.data( this, str_data );
        
        // If element size has changed since the last time, update the element
        // data store and trigger the 'resize' event.
        if ( width !== data.w || height !== data.h ) {
          var oldW = data.w;
          var oldH = data.h;
          elem.trigger( str_resize, [ data.w = width, data.h = height, oldW, oldH ] );
        }
        
      });
      
      // Loop.
      loopy();
      
    }, jq_resize[ str_delay ] );
    
  };
  
})(jQuery,this);
/**
 * jQuery Masonry v2.1.05
 * A dynamic layout plugin for jQuery
 * The flip-side of CSS Floats
 * http://masonry.desandro.com
 *
 * Licensed under the MIT license.
 * Copyright 2012 David DeSandro
 */

/*jshint browser: true, curly: true, eqeqeq: true, forin: false, immed: false, newcap: true, noempty: true, strict: true, undef: true */
/*global jQuery: false */

(function( window, $, undefined ){

  'use strict';

  /*
   * smartresize: debounced resize event for jQuery
   *
   * latest version and complete README available on Github:
   * https://github.com/louisremi/jquery.smartresize.js
   *
   * Copyright 2011 @louis_remi
   * Licensed under the MIT license.
   */

  var $event = $.event,
      resizeTimeout;

  $event.special.smartresize = {
    setup: function() {
      $(this).bind( "resize", $event.special.smartresize.handler );
    },
    teardown: function() {
      $(this).unbind( "resize", $event.special.smartresize.handler );
    },
    handler: function( event, execAsap ) {
      // Save the context
      var context = this,
          args = arguments;

      // set correct event type
      event.type = "smartresize";

      if ( resizeTimeout ) { clearTimeout( resizeTimeout ); }
      resizeTimeout = setTimeout(function() {
        $.event.handle.apply( context, args );
      }, execAsap === "execAsap"? 0 : 100 );
    }
  };

  $.fn.smartresize = function( fn ) {
    return fn ? this.bind( "smartresize", fn ) : this.trigger( "smartresize", ["execAsap"] );
  };



// ========================= Masonry ===============================


  // our "Widget" object constructor
  $.Mason = function( options, element ){
    this.element = $( element );

    this._create( options );
    this._init();
  };

  $.Mason.settings = {
    isResizable: true,
    isAnimated: false,
    animationOptions: {
      queue: false,
      duration: 500
    },
    gutterWidth: 0,
    isRTL: false,
    isFitWidth: false,
    containerStyle: {
      position: 'relative'
    }
  };

  $.Mason.prototype = {

    _filterFindBricks: function( $elems ) {
      var selector = this.options.itemSelector;
      // if there is a selector
      // filter/find appropriate item elements
      return !selector ? $elems : $elems.filter( selector ).add( $elems.find( selector ) );
    },

    _getBricks: function( $elems ) {
      var $bricks = this._filterFindBricks( $elems )
        .css({ position: 'absolute' })
        .addClass('masonry-brick');
      return $bricks;
    },
    
    // sets up widget
    _create : function( options ) {
      
      this.options = $.extend( true, {}, $.Mason.settings, options );
      this.styleQueue = [];

      // get original styles in case we re-apply them in .destroy()
      var elemStyle = this.element[0].style;
      this.originalStyle = {
        // get height
        height: elemStyle.height || ''
      };
      // get other styles that will be overwritten
      var containerStyle = this.options.containerStyle;
      for ( var prop in containerStyle ) {
        this.originalStyle[ prop ] = elemStyle[ prop ] || '';
      }

      this.element.css( containerStyle );

      this.horizontalDirection = this.options.isRTL ? 'right' : 'left';

      this.offset = {
        x: parseInt( this.element.css( 'padding-' + this.horizontalDirection ), 10 ),
        y: parseInt( this.element.css( 'padding-top' ), 10 )
      };
      
      this.isFluid = this.options.columnWidth && typeof this.options.columnWidth === 'function';

      // add masonry class first time around
      var instance = this;
      setTimeout( function() {
        instance.element.addClass('masonry');
      }, 0 );
      
      // bind resize method
      if ( this.options.isResizable ) {
        $(window).bind( 'smartresize.masonry', function() { 
          instance.resize();
        });
      }


      // need to get bricks
      this.reloadItems();

    },
  
    // _init fires when instance is first created
    // and when instance is triggered again -> $el.masonry();
    _init : function( callback ) {
      this._getColumns();
      this._reLayout( callback );
    },

    option: function( key, value ){
      // set options AFTER initialization:
      // signature: $('#foo').bar({ cool:false });
      if ( $.isPlainObject( key ) ){
        this.options = $.extend(true, this.options, key);
      } 
    },
    
    // ====================== General Layout ======================

    // used on collection of atoms (should be filtered, and sorted before )
    // accepts atoms-to-be-laid-out to start with
    layout : function( $bricks, callback ) {

      // place each brick
      for (var i=0, len = $bricks.length; i < len; i++) {
        this._placeBrick( $bricks[i] );
      }
      
      // set the size of the container
      var containerSize = {};
      //containerSize.height = Math.max.apply( Math, this.colYs );
      if ( this.options.isFitWidth ) {
        var unusedCols = 0;
        i = this.cols;
        // count unused columns
        while ( --i ) {
          if ( this.colYs[i] !== 0 ) {
            break;
          }
          unusedCols++;
        }
        // fit container to columns that have been used;
        //containerSize.width = (this.cols - unusedCols) * this.columnWidth - this.options.gutterWidth;
      }
      this.styleQueue.push({ $el: this.element, style: containerSize });

      // are we animating the layout arrangement?
      // use plugin-ish syntax for css or animate
      var styleFn = !this.isLaidOut ? 'css' : (
            this.options.isAnimated ? 'animate' : 'css'
          ),
          animOpts = this.options.animationOptions;

      // process styleQueue
      var obj;
      for (i=0, len = this.styleQueue.length; i < len; i++) {
        obj = this.styleQueue[i];
        obj.$el[ styleFn ]( obj.style, animOpts );
      }

      // clear out queue for next time
      this.styleQueue = [];

      // provide $elems as context for the callback
      if ( callback ) {
        callback.call( $bricks );
      }
      
      this.isLaidOut = true;
    },
    
    // calculates number of columns
    // i.e. this.columnWidth = 200
    _getColumns : function() {
      var container = this.options.isFitWidth ? this.element.parent() : this.element,
          containerWidth = container.width();

                         // use fluid columnWidth function if there
      this.columnWidth = this.isFluid ? this.options.columnWidth( containerWidth ) :
                    // if not, how about the explicitly set option?
                    this.options.columnWidth ||
                    // or use the size of the first item
                    this.$bricks.outerWidth(true) ||
                    // if there's no items, use size of container
                    containerWidth;

      this.columnWidth += this.options.gutterWidth;

      this.cols = Math.floor( ( containerWidth + this.options.gutterWidth ) / this.columnWidth );
      this.cols = Math.max( this.cols, 1 );

    },

    // layout logic
    _placeBrick: function( brick ) {
      var $brick = $(brick),
          colSpan, groupCount, groupY, groupColY, j;

      //how many columns does this brick span
      colSpan = Math.ceil( $brick.outerWidth(true) / this.columnWidth );
      colSpan = Math.min( colSpan, this.cols );

      if ( colSpan === 1 ) {
        // if brick spans only one column, just like singleMode
        groupY = this.colYs;
      } else {
        // brick spans more than one column
        // how many different places could this brick fit horizontally
        groupCount = this.cols + 1 - colSpan;
        groupY = [];

        // for each group potential horizontal position
        for ( j=0; j < groupCount; j++ ) {
          // make an array of colY values for that one group
          groupColY = this.colYs.slice( j, j+colSpan );
          // and get the max value of the array
          groupY[j] = Math.max.apply( Math, groupColY );
        }

      }

      // get the minimum Y value from the columns
      var minimumY = Math.min.apply( Math, groupY ),
          shortCol = 0;
      
      // Find index of short column, the first from the left
      for (var i=0, len = groupY.length; i < len; i++) {
        if ( groupY[i] === minimumY ) {
          shortCol = i;
          break;
        }
      }

      // position the brick
      var position = {
        top: minimumY + this.offset.y
      };
      // position.left or position.right
      position[ this.horizontalDirection ] = this.columnWidth * shortCol + this.offset.x;
      this.styleQueue.push({ $el: $brick, style: position });

      // apply setHeight to necessary columns
      var setHeight = minimumY + $brick.outerHeight(true),
          setSpan = this.cols + 1 - len;
      for ( i=0; i < setSpan; i++ ) {
        this.colYs[ shortCol + i ] = setHeight;
      }

    },
    
    
    resize: function() {
      var prevColCount = this.cols;
      // get updated colCount
      this._getColumns();
      if ( this.isFluid || this.cols !== prevColCount ) {
        // if column count has changed, trigger new layout
        this._reLayout();
      }
    },
    
    
    _reLayout : function( callback ) {
      // reset columns
      var i = this.cols;
      this.colYs = [];
      while (i--) {
        this.colYs.push( 0 );
      }
      // apply layout logic to all bricks
      this.layout( this.$bricks, callback );
    },
    
    // ====================== Convenience methods ======================
    
    // goes through all children again and gets bricks in proper order
    reloadItems : function() {
      this.$bricks = this._getBricks( this.element.children() );
    },
    
    
    reload : function( callback ) {
      this.reloadItems();
      this._init( callback );
    },
    

    // convienence method for working with Infinite Scroll
    appended : function( $content, isAnimatedFromBottom, callback ) {
      if ( isAnimatedFromBottom ) {
        // set new stuff to the bottom
        this._filterFindBricks( $content ).css({ top: this.element.height() });
        var instance = this;
        setTimeout( function(){
          instance._appended( $content, callback );
        }, 1 );
      } else {
        this._appended( $content, callback );
      }
    },
    
    _appended : function( $content, callback ) {
      var $newBricks = this._getBricks( $content );
      // add new bricks to brick pool
      this.$bricks = this.$bricks.add( $newBricks );
      this.layout( $newBricks, callback );
    },
    
    // removes elements from Masonry widget
    remove : function( $content ) {
      this.$bricks = this.$bricks.not( $content );
      $content.remove();
    },
    
    // destroys widget, returns elements and container back (close) to original style
    destroy : function() {

      this.$bricks
        .removeClass('masonry-brick')
        .each(function(){
          this.style.position = '';
          this.style.top = '';
          this.style.left = '';
        });
      
      // re-apply saved container styles
      var elemStyle = this.element[0].style;
      for ( var prop in this.originalStyle ) {
        elemStyle[ prop ] = this.originalStyle[ prop ];
      }

      this.element
        .unbind('.masonry')
        .removeClass('masonry')
        .removeData('masonry');
      
      $(window).unbind('.masonry');

    }
    
  };
  
  
  // ======================= imagesLoaded Plugin ===============================
  /*!
   * jQuery imagesLoaded plugin v1.1.0
   * http://github.com/desandro/imagesloaded
   *
   * MIT License. by Paul Irish et al.
   */


  // $('#my-container').imagesLoaded(myFunction)
  // or
  // $('img').imagesLoaded(myFunction)

  // execute a callback when all images have loaded.
  // needed because .load() doesn't work on cached images

  // callback function gets image collection as argument
  //  `this` is the container

  $.fn.imagesLoaded = function( callback ) {
    var $this = this,
        $images = $this.find('img').add( $this.filter('img') ),
        len = $images.length,
        blank = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==',
        loaded = [];

    function triggerCallback() {
      callback.call( $this, $images );
    }

    function imgLoaded( event ) {
      var img = event.target;
      if ( img.src !== blank && $.inArray( img, loaded ) === -1 ){
        loaded.push( img );
        if ( --len <= 0 ){
          setTimeout( triggerCallback );
          $images.unbind( '.imagesLoaded', imgLoaded );
        }
      }
    }

    // if no images, trigger immediately
    if ( !len ) {
      triggerCallback();
    }

    $images.bind( 'load.imagesLoaded error.imagesLoaded',  imgLoaded ).each( function() {
      // cached images don't fire load sometimes, so we reset src.
      var src = this.src;
      // webkit hack from http://groups.google.com/group/jquery-dev/browse_thread/thread/eee6ab7b2da50e1f
      // data uri bypasses webkit log warning (thx doug jones)
      this.src = blank;
      this.src = src;
    });

    return $this;
  };


  // helper function for logging errors
  // $.error breaks jQuery chaining
  var logError = function( message ) {
    if ( window.console ) {
      window.console.error( message );
    }
  };
  
  // =======================  Plugin bridge  ===============================
  // leverages data method to either create or return $.Mason constructor
  // A bit from jQuery UI
  //   https://github.com/jquery/jquery-ui/blob/master/ui/jquery.ui.widget.js
  // A bit from jcarousel 
  //   https://github.com/jsor/jcarousel/blob/master/lib/jquery.jcarousel.js

  $.fn.masonry = function( options ) {
    if ( typeof options === 'string' ) {
      // call method
      var args = Array.prototype.slice.call( arguments, 1 );

      this.each(function(){
        var instance = $.data( this, 'masonry' );
        if ( !instance ) {
          logError( "cannot call methods on masonry prior to initialization; " +
            "attempted to call method '" + options + "'" );
          return;
        }
        if ( !$.isFunction( instance[options] ) || options.charAt(0) === "_" ) {
          logError( "no such method '" + options + "' for masonry instance" );
          return;
        }
        // apply method
        instance[ options ].apply( instance, args );
      });
    } else {
      this.each(function() {
        var instance = $.data( this, 'masonry' );
        if ( instance ) {
          // apply options & init
          instance.option( options || {} );
          instance._init();
        } else {
          // initialize new instance
          $.data( this, 'masonry', new $.Mason( options, this ) );
        }
      });
    }
    return this;
  };

})( window, jQuery );
/**
 * @preserve
 * jquery.layout 1.3.0 - Release Candidate 30.74
 * $Date: 2015/11/21 $
 * $Rev: 303007 $
 *
 * Copyright (c) 2012 
 *   Fabrizio Balliano (http://www.fabrizioballiano.net)
 *   Kevin Dalman (http://allpro.net)
 *
 * Dual licensed under the GPL (http://www.gnu.org/licenses/gpl.html)
 * and MIT (http://www.opensource.org/licenses/mit-license.php) licenses.
 *
 * Changelog: http://layout.jquery-dev.net/changelog.cfm#1.3.0.rc30.74
 *
 * Docs: http://layout.jquery-dev.net/documentation.html
 * Tips: http://layout.jquery-dev.net/tips.html
 * Help: http://groups.google.com/group/jquery-ui-layout
 */

/* JavaDoc Info: http://code.google.com/closure/compiler/docs/js-for-compiler.html
 * {!Object}	non-nullable type (never NULL)
 * {?string}	nullable type (sometimes NULL) - default for {Object}
 * {number=}	optional parameter
 * {*}			ALL types
 */

// NOTE: For best readability, view with a fixed-width font and tabs equal to 4-chars

;(function ($) {

// alias Math methods - used a lot!
var	min		= Math.min
,	max		= Math.max
,	round	= Math.floor

,	isStr	=  function (v) { return $.type(v) === "string"; }

	/**
	* @param {!Object}			Instance
	* @param {Array.<string>}	a_fn
	*/
,	runPluginCallbacks = function (Instance, a_fn) {
		if ($.isArray(a_fn))
			for (var i=0, c=a_fn.length; i<c; i++) {
				var fn = a_fn[i];
				try {
					if (isStr(fn)) // 'name' of a function
						fn = eval(fn);
					if ($.isFunction(fn))
						g(fn)( Instance );
				} catch (ex) {}
			}
		function g (f) { return f; }; // compiler hack
	}
,	$textUtils = infa.i18n.TextUtils.instance()
;


/*
 *	GENERIC $.layout METHODS - used by all layouts
 */
$.layout = {

	version:	"1.3.rc30.74"
,	revision:	0.033007 // 1.3.0 final = 1.0300 - major(n+).minor(nn)+patch(nn+)

	// can update code here if $.browser is phased out or logic changes
,	browser: {
		mozilla:	!!$.browser.mozilla
	,	webkit:		!!$.browser.webkit || !!$.browser.safari // webkit = jQ 1.4
	,	msie:		!!$.browser.msie
	,	isIE6:		$.browser.msie && $.browser.version == 6
	,	boxModel:	$.support.boxModel !== false || !$.browser.msie // ONLY IE reverts to old box-model - update for older jQ onReady
	,	version:	$.browser.version // not used in Layout core, but may be used by plugins
	}

	// *PREDEFINED* EFFECTS & DEFAULTS 
	// MUST list effect here - OR MUST set an fxSettings option (can be an empty hash: {})
,	effects: {

	//	Pane Open/Close Animations
		slide: {
			all:	{ duration:  "fast"	} // eg: duration: 1000, easing: "easeOutBounce"
		,	north:	{ direction: "up"	}
		,	south:	{ direction: "down"	}
		,	east:	{ direction: "right"}
		,	west:	{ direction: "left"	}
		}
	,	drop: {
			all:	{ duration:  "slow"	}
		,	north:	{ direction: "up"	}
		,	south:	{ direction: "down"	}
		,	east:	{ direction: "right"}
		,	west:	{ direction: "left"	}
		}
	,	scale: {
			all:	{ duration:	"fast"	}
		}
	//	these are not recommended, but can be used
	,	blind:		{}
	,	clip:		{}
	,	explode:	{}
	,	fade:		{}
	,	fold:		{}
	,	puff:		{}

	//	Pane Resize Animations
	,	size: {
			all:	{ easing:	"swing"	}
		}
	}

	// INTERNAL CONFIG DATA - DO NOT CHANGE THIS!
,	config: {
		optionRootKeys:	"effects,panes,north,south,west,east,center".split(",")
	,	allPanes:		"north,south,west,east,center".split(",")
	,	borderPanes:	"north,south,west,east".split(",")
	,	oppositeEdge: {
			north:	"south"
		,	south:	"north"
		,	east: 	"west"
		,	west: 	"east"
		}
	//	offscreen data
	,	offscreenCSS:	{ left: "-99999px", right: "auto" } // used by hide/close if useOffscreenClose=true
	,	offscreenReset:	"offscreenReset" // key used for data
	//	CSS used in multiple places
	,	hidden:		{ visibility: "hidden" }
	,	visible:	{ visibility: "visible" }
	//	layout element settings
	,	resizers: {
			cssReq: {
				position: 	"absolute"
			,	padding: 	0
			,	margin: 	0
			,	fontSize:	"1px"
			,	textAlign:	"left"	// to counter-act "center" alignment!
			,	overflow: 	"hidden" // prevent toggler-button from overflowing
			//	SEE $.layout.defaults.zIndexes.resizer_normal
			}
		,	cssDemo: { // DEMO CSS - applied if: options.PANE.applyDemoStyles=true
				background: "#DDD"
			,	border:		"none"
			}
		}
	,	togglers: {
			cssReq: {
				position: 	"absolute"
			,	display: 	"block"
			,	padding: 	0
			,	margin: 	0
			,	overflow:	"hidden"
			,	textAlign:	"left"
			,	fontSize:	"1px"
			,	cursor: 	"pointer"
			,	zIndex: 	1
			}
		,	cssDemo: { // DEMO CSS - applied if: options.PANE.applyDemoStyles=true
				background: "#AAA"
			}
		}
	,	content: {
			cssReq: {
				position:	"relative" /* contain floated or positioned elements */
			}
		,	cssDemo: { // DEMO CSS - applied if: options.PANE.applyDemoStyles=true
				overflow:	"auto"
			,	padding:	"10px"
			}
		,	cssDemoPane: { // DEMO CSS - REMOVE scrolling from 'pane' when it has a content-div
				overflow:	"hidden"
			,	padding:	0
			}
		}
	,	panes: { // defaults for ALL panes - overridden by 'per-pane settings' below
			cssReq: {
				position: 	"absolute"
			,	margin:		0
			//	$.layout.defaults.zIndexes.pane_normal
			}
		,	cssDemo: { // DEMO CSS - applied if: options.PANE.applyDemoStyles=true
				padding:	"10px"
			,	background:	"#FFF"
			,	border:		"1px solid #BBB"
			,	overflow:	"auto"
			}
		}
	,	north: {
			side:			"top"
		,	sizeType:		"Height"
		,	dir:			"horz"
		,	cssReq: {
				top: 		0
			,	bottom: 	"auto"
			,	left: 		0
			,	right: 		0
			,	width: 		"auto"
			//	height: 	DYNAMIC
			}
		}
	,	south: {
			side:			"bottom"
		,	sizeType:		"Height"
		,	dir:			"horz"
		,	cssReq: {
				top: 		"auto"
			,	bottom: 	0
			,	left: 		0
			,	right: 		0
			,	width: 		"auto"
			//	height: 	DYNAMIC
			}
		}
	,	east: {
			side:			"right"
		,	sizeType:		"Width"
		,	dir:			"vert"
		,	cssReq: {
				left: 		"auto"
			,	right: 		0
			,	top: 		"auto" // DYNAMIC
			,	bottom: 	"auto" // DYNAMIC
			,	height: 	"auto"
			//	width: 		DYNAMIC
			}
		}
	,	west: {
			side:			"left"
		,	sizeType:		"Width"
		,	dir:			"vert"
		,	cssReq: {
				left: 		0
			,	right: 		"auto"
			,	top: 		"auto" // DYNAMIC
			,	bottom: 	"auto" // DYNAMIC
			,	height: 	"auto"
			//	width: 		DYNAMIC
			}
		}
	,	center: {
			dir:			"center"
		,	cssReq: {
				left: 		"auto" // DYNAMIC
			,	right: 		"auto" // DYNAMIC
			,	top: 		"auto" // DYNAMIC
			,	bottom: 	"auto" // DYNAMIC
			,	height: 	"auto"
			,	width: 		"auto"
			}
		}
	}

	// CALLBACK FUNCTION NAMESPACE - used to store reusable callback functions
,	callbacks: {}

,	getParentPaneElem: function (el) {
		// must pass either a container or pane element
		var $el = $(el)
		,	layout = $el.data("layout") || $el.data("parentLayout");
		if (layout) {
			var $cont = layout.container;
			// see if this container is directly-nested inside an outer-pane
			if ($cont.data("layoutPane")) return $cont;
			var $pane = $cont.closest("."+ $.layout.defaults.panes.paneClass);
			// if a pane was found, return it
			if ($pane.data("layoutPane")) return $pane;
		}
		return null;
	}

,	getParentPaneInstance: function (el) {
		// must pass either a container or pane element
		var $pane = $.layout.getParentPaneElem(el);
		return $pane ? $pane.data("layoutPane") : null;
	}

,	getParentLayoutInstance: function (el) {
		// must pass either a container or pane element
		var $pane = $.layout.getParentPaneElem(el);
		return $pane ? $pane.data("parentLayout") : null;
	}

,	getEventObject: function (evt) {
		return typeof evt === "object" && evt.stopPropagation ? evt : null;
	}
,	parsePaneName: function (evt_or_pane) {
		// getEventObject() automatically calls .stopPropagation(), WHICH MUST BE DONE!
		var evt = $.layout.getEventObject( evt_or_pane );
		if (evt) {
			// ALWAYS stop propagation of events triggered in Layout!
			evt.stopPropagation();
			return $(this).data("layoutEdge");
		}
		else
			return evt_or_pane;
	}


	// LAYOUT-PLUGIN REGISTRATION
	// more plugins can added beyond this default list
,	plugins: {
		draggable:		!!$.fn.draggable // resizing
	,	effects: {
			core:		!!$.effects		// animimations (specific effects tested by initOptions)
		,	slide:		$.effects && ($.effects.slide || ($.effects.effect && $.effects.effect.slide)) // default effect
		}
	}

//	arrays of plugin or other methods to be triggered for events in *each layout* - will be passed 'Instance'
,	onCreate:	[]	// runs when layout is just starting to be created - right after options are set
,	onLoad:		[]	// runs after layout container and global events init, but before initPanes is called
,	onReady:	[]	// runs after initialization *completes* - ie, after initPanes completes successfully
,	onDestroy:	[]	// runs after layout is destroyed
,	onUnload:	[]	// runs after layout is destroyed OR when page unloads
,	afterOpen:	[]	// runs after setAsOpen() completes
,	afterClose:	[]	// runs after setAsClosed() completes

	/*
	*	GENERIC UTILITY METHODS
	*/

	// calculate and return the scrollbar width, as an integer
,	scrollbarWidth:		function () { return window.scrollbarWidth  || $.layout.getScrollbarSize('width'); }
,	scrollbarHeight:	function () { return window.scrollbarHeight || $.layout.getScrollbarSize('height'); }
,	getScrollbarSize:	function (dim) {
		var $c	= $('<div style="position: absolute; top: -10000px; left: -10000px; width: 100px; height: 100px; overflow: scroll;"></div>').appendTo("body");
		var d	= { width: $c.css("width") - $c[0].clientWidth, height: $c.height() - $c[0].clientHeight };
		$c.remove();
		window.scrollbarWidth	= d.width;
		window.scrollbarHeight	= d.height;
		return dim.match(/^(width|height)$/) ? d[dim] : d;
	}


	/**
	* Returns hash container 'display' and 'visibility'
	*
	* @see	$.swap() - swaps CSS, runs callback, resets CSS
	* @param  {!Object}		$E				jQuery element
	* @param  {boolean=}	[force=false]	Run even if display != none
	* @return {!Object}						Returns current style props, if applicable
	*/
,	showInvisibly: function ($E, force) {
		if ($E && $E.length && (force || $E.css("display") === "none")) { // only if not *already hidden*
			var s = $E[0].style
				// save ONLY the 'style' props because that is what we must restore
			,	CSS = { display: s.display || '', visibility: s.visibility || '' };
			// show element 'invisibly' so can be measured
			$E.css({ display: "block", visibility: "hidden" });
			return CSS;
		}
		return {};
	}

	/**
	* Returns data for setting size of an element (container or a pane).
	*
	* @see  _create(), onWindowResize() for container, plus others for pane
	* @return JSON  Returns a hash of all dimensions: top, bottom, left, right, outerWidth, innerHeight, etc
	*/
,	getElementDimensions: function ($E, inset) {
		var
		//	dimensions hash - start with current data IF passed
			d	= { css: {}, inset: {} }
		,	x	= d.css			// CSS hash
		,	i	= { bottom: 0 }	// TEMP insets (bottom = complier hack)
		,	N	= $.layout.cssNum
		,	off = $E.offset()
		,	b, p, ei			// TEMP border, padding
		;
		d.offsetLeft = off.left;
		d.offsetTop  = off.top;

		if (!inset) inset = {}; // simplify logic below

		$.each("Left,Right,Top,Bottom".split(","), function (idx, e) { // e = edge
			b = x["border" + e] = $.layout.borderWidth($E, e);
			p = x["padding"+ e] = $.layout.cssNum($E, "padding"+e);
			ei = e.toLowerCase();
			d.inset[ei] = inset[ei] >= 0 ? inset[ei] : p; // any missing insetX value = paddingX
			i[ei] = d.inset[ei] + b; // total offset of content from outer side
		});

		x.width		= $E.css("width");
		x.height	= $E.height();
		x.top		= N($E,"top",true);
		x.bottom	= N($E,"bottom",true);
		x.left		= N($E,"left",true);
		x.right		= N($E,"right",true);

		d.outerWidth	= $E.outerWidth();
		d.outerHeight	= $E.outerHeight();
		// calc the TRUE inner-dimensions, even in quirks-mode!
		d.innerWidth	= max(0, d.outerWidth  - i.left - i.right);
		d.innerHeight	= max(0, d.outerHeight - i.top  - i.bottom);
		// layoutWidth/Height is used in calcs for manual resizing
		// layoutW/H only differs from innerW/H when in quirks-mode - then is like outerW/H
		d.layoutWidth	= $E.innerWidth();
		d.layoutHeight	= $E.innerHeight();

		//if ($E.prop('tagName') === 'BODY') { debugData( d, $E.prop('tagName') ); } // DEBUG

		//d.visible	= $E.is(":visible");// && x.width > 0 && x.height > 0;

		return d;
	}

,	getElementStyles: function ($E, list) {
		var
			CSS	= {}
		,	style	= $E[0].style
		,	props	= list.split(",")
		,	sides	= "Top,Bottom,Left,Right".split(",")
		,	attrs	= "Color,Style,Width".split(",")
		,	p, s, a, i, j, k
		;
		for (i=0; i < props.length; i++) {
			p = props[i];
			if (p.match(/(border|padding|margin)$/))
				for (j=0; j < 4; j++) {
					s = sides[j];
					if (p === "border")
						for (k=0; k < 3; k++) {
							a = attrs[k];
							CSS[p+s+a] = style[p+s+a];
						}
					else
						CSS[p+s] = style[p+s];
				}
			else
				CSS[p] = style[p];
		};
		return CSS
	}

	/**
	* Return the innerWidth for the current browser/doctype
	*
	* @see  initPanes(), sizeMidPanes(), initHandles(), sizeHandles()
	* @param  {Array.<Object>}	$E  Must pass a jQuery object - first element is processed
	* @param  {number=}			outerWidth (optional) Can pass a width, allowing calculations BEFORE element is resized
	* @return {number}			Returns the innerWidth of the elem by subtracting padding and borders
	*/
,	cssWidth: function ($E, outerWidth) {
		// a 'calculated' outerHeight can be passed so borders and/or padding are removed if needed
		if (outerWidth <= 0) return 0;

		if (!$.layout.browser.boxModel) return outerWidth;

		// strip border and padding from outerWidth to get CSS Width
		var b = $.layout.borderWidth
		,	n = $.layout.cssNum
		,	W = outerWidth
				- b($E, "Left")
				- b($E, "Right")
				- n($E, "paddingLeft")		
				- n($E, "paddingRight");

		return max(0,W);
	}

	/**
	* Return the innerHeight for the current browser/doctype
	*
	* @see  initPanes(), sizeMidPanes(), initHandles(), sizeHandles()
	* @param  {Array.<Object>}	$E  Must pass a jQuery object - first element is processed
	* @param  {number=}			outerHeight  (optional) Can pass a width, allowing calculations BEFORE element is resized
	* @return {number}			Returns the innerHeight of the elem by subtracting padding and borders
	*/
,	cssHeight: function ($E, outerHeight) {
		// a 'calculated' outerHeight can be passed so borders and/or padding are removed if needed
		if (outerHeight <= 0) return 0;

		if (!$.layout.browser.boxModel) return outerHeight;

		// strip border and padding from outerHeight to get CSS Height
		var b = $.layout.borderWidth
		,	n = $.layout.cssNum
		,	H = outerHeight
			- b($E, "Top")
			- b($E, "Bottom")
			- n($E, "paddingTop")
			- n($E, "paddingBottom");

		return max(0,H);
	}

	/**
	* Returns the 'current CSS numeric value' for a CSS property - 0 if property does not exist
	*
	* @see  Called by many methods
	* @param {Array.<Object>}	$E					Must pass a jQuery object - first element is processed
	* @param {string}			prop				The name of the CSS property, eg: top, width, etc.
	* @param {boolean=}			[allowAuto=false]	true = return 'auto' if that is value; false = return 0
	* @return {(string|number)}						Usually used to get an integer value for position (top, left) or size (height, width)
	*/
,	cssNum: function ($E, prop, allowAuto) {
		if (!$E.jquery) $E = $($E);
		var CSS = $.layout.showInvisibly($E)
		,	p	= $.css($E[0], prop, true)
		,	v	= allowAuto && p=="auto" ? p : Math.round(parseFloat(p) || 0);
		$E.css( CSS ); // RESET
		return v;
	}

,	borderWidth: function (el, side) {
		if (el.jquery) el = el[0];
		var b = "border"+ side.substr(0,1).toUpperCase() + side.substr(1); // left => Left
		return $.css(el, b+"Style", true) === "none" ? 0 : Math.round(parseFloat($.css(el, b+"Width", true)) || 0);
	}

	/**
	* Mouse-tracking utility - FUTURE REFERENCE
	*
	* init: if (!window.mouse) {
	*			window.mouse = { x: 0, y: 0 };
	*			$(document).mousemove( $.layout.trackMouse );
	*		}
	*
	* @param {Object}		evt
	*
,	trackMouse: function (evt) {
		window.mouse = { x: evt.clientX, y: evt.clientY };
	}
	*/

	/**
	* SUBROUTINE for preventPrematureSlideClose option
	*
	* @param {Object}		evt
	* @param {Object=}		el
	*/
,	isMouseOverElem: function (evt, el) {
		var
			$E	= $(el || this)
		,	d	= $E.offset()
		,	T	= d.top
		,	L	= d.left
		,	R	= L + $E.outerWidth()
		,	B	= T + $E.outerHeight()
		,	x	= evt.pageX	// evt.clientX ?
		,	y	= evt.pageY	// evt.clientY ?
		;
		// if X & Y are < 0, probably means is over an open SELECT
		return ($.layout.browser.msie && x < 0 && y < 0) || ((x >= L && x <= R) && (y >= T && y <= B));
	}

	/**
	* Message/Logging Utility
	*
	* @example $.layout.msg("My message");				// log text
	* @example $.layout.msg("My message", true);		// alert text
	* @example $.layout.msg({ foo: "bar" }, "Title");	// log hash-data, with custom title
	* @example $.layout.msg({ foo: "bar" }, true, "Title", { sort: false }); -OR-
	* @example $.layout.msg({ foo: "bar" }, "Title", { sort: false, display: true }); // alert hash-data
	*
	* @param {(Object|string)}			info			String message OR Hash/Array
	* @param {(Boolean|string|Object)=}	[popup=false]	True means alert-box - can be skipped
	* @param {(Object|string)=}			[debugTitle=""]	Title for Hash data - can be skipped
	* @param {Object=}					[debugOpts]		Extra options for debug output
	*/
,	msg: function (info, popup, debugTitle, debugOpts) {
		if ($.isPlainObject(info) && window.debugData) {
			if (typeof popup === "string") {
				debugOpts	= debugTitle;
				debugTitle	= popup;
			}
			else if (typeof debugTitle === "object") {
				debugOpts	= debugTitle;
				debugTitle	= null;
			}
			var t = debugTitle || "log( <object> )"
			,	o = $.extend({ sort: false, returnHTML: false, display: false }, debugOpts);
			if (popup === true || o.display)
				debugData( info, t, o );
			else if (window.console)
				console.log(debugData( info, t, o ));
		}
		else if (popup)
			alert(info);
		else if (window.console)
			console.log(info);
		else {
			var id	= "#layoutLogger"
			,	$l = $(id);
			if (!$l.length)
				$l = createLog();
			$l.children("ul").append('<li style="padding: 4px 10px; margin: 0; border-top: 1px solid #CCC;">'+ info.replace(/\</g,"&lt;").replace(/\>/g,"&gt;") +'</li>');
		}

		function createLog () {
			var pos = $.support.fixedPosition ? 'fixed' : 'absolute'
			,	$e = $('<div id="layoutLogger" style="position: '+ pos +'; top: 5px; z-index: 999999; max-width: 25%; overflow: hidden; border: 1px solid #000; border-radius: 5px; background: #FBFBFB; box-shadow: 0 2px 10px rgba(0,0,0,0.3);">'
				+	'<div style="font-size: 13px; font-weight: bold; padding: 5px 10px; background: #F6F6F6; border-radius: 5px 5px 0 0; cursor: move;">'
				+	'<span style="float: right; padding-left: 7px; cursor: pointer;" title="Remove Console" onclick="$(this).closest(\'#layoutLogger\').remove()">X</span>Layout console.log</div>'
				+	'<ul style="font-size: 13px; font-weight: none; list-style: none; margin: 0; padding: 0 0 2px;"></ul>'
				+ '</div>'
				).appendTo("body");
			$e.css('left', $(window).width() - $e.outerWidth() - 5)
			if ($.ui.draggable) $e.draggable({ handle: ':first-child' });
			return $e;
		};
	}

};

// DEFAULT OPTIONS
$.layout.defaults = {
/*
 *	LAYOUT & LAYOUT-CONTAINER OPTIONS
 *	- none of these options are applicable to individual panes
 */
	name:						""			// Not required, but useful for buttons and used for the state-cookie
,	containerClass:				"ui-layout-container" // layout-container element
,	inset:						null		// custom container-inset values (override padding)
,	scrollToBookmarkOnLoad:		true		// after creating a layout, scroll to bookmark in URL (.../page.htm#myBookmark)
,	resizeWithWindow:			true		// bind thisLayout.resizeAll() to the window.resize event
,	resizeWithWindowDelay:		200			// delay calling resizeAll because makes window resizing very jerky
,	resizeWithWindowMaxDelay:	0			// 0 = none - force resize every XX ms while window is being resized
,	maskPanesEarly:				false		// true = create pane-masks on resizer.mouseDown instead of waiting for resizer.dragstart
,	onresizeall_start:			null		// CALLBACK when resizeAll() STARTS	- NOT pane-specific
,	onresizeall_end:			null		// CALLBACK when resizeAll() ENDS	- NOT pane-specific
,	onload_start:				null		// CALLBACK when Layout inits - after options initialized, but before elements
,	onload_end:					null		// CALLBACK when Layout inits - after EVERYTHING has been initialized
,	onunload_start:				null		// CALLBACK when Layout is destroyed OR onWindowUnload
,	onunload_end:				null		// CALLBACK when Layout is destroyed OR onWindowUnload
,	initPanes:					true		// false = DO NOT initialize the panes onLoad - will init later
,	showErrorMessages:			true		// enables fatal error messages to warn developers of common errors
,	showDebugMessages:			false		// display console-and-alert debug msgs - IF this Layout version _has_ debugging code!
//	Changing this zIndex value will cause other zIndex values to automatically change
,	zIndex:						null		// the PANE zIndex - resizers and masks will be +1
//	DO NOT CHANGE the zIndex values below unless you clearly understand their relationships
,	zIndexes: {								// set _default_ z-index values here...
		pane_normal:			0			// normal z-index for panes
	,	content_mask:			1			// applied to overlays used to mask content INSIDE panes during resizing
	,	resizer_normal:			2			// normal z-index for resizer-bars
	,	pane_sliding:			100			// applied to *BOTH* the pane and its resizer when a pane is 'slid open'
	,	pane_animate:			1000		// applied to the pane when being animated - not applied to the resizer
	,	resizer_drag:			10000		// applied to the CLONED resizer-bar when being 'dragged'
	}
,	errors: {
		pane:					"pane"		// description of "layout pane element" - used only in error messages
	,	selector:				"selector"	// description of "jQuery-selector" - used only in error messages
	,	addButtonError:			"Error Adding Button \n\nInvalid "
	,	containerMissing:		"UI Layout Initialization Error\n\nThe specified layout-container does not exist."
	,	centerPaneMissing:		"UI Layout Initialization Error\n\nThe center-pane element does not exist.\n\nThe center-pane is a required element."
	,	noContainerHeight:		"UI Layout Initialization Warning\n\nThe layout-container \"CONTAINER\" has no height.\n\nTherefore the layout is 0-height and hence 'invisible'!"
	,	callbackError:			"UI Layout Callback Error\n\nThe EVENT callback is not a valid function."
	}
/*
 *	PANE DEFAULT SETTINGS
 *	- settings under the 'panes' key become the default settings for *all panes*
 *	- ALL pane-options can also be set specifically for each panes, which will override these 'default values'
 */
,	panes: { // default options for 'all panes' - will be overridden by 'per-pane settings'
		applyDemoStyles: 		false		// NOTE: renamed from applyDefaultStyles for clarity
	,	closable:				true		// pane can open & close
	,	resizable:				true		// when open, pane can be resized 
	,	slidable:				true		// when closed, pane can 'slide open' over other panes - closes on mouse-out
	,	initClosed:				false		// true = init pane as 'closed'
	,	initHidden: 			false 		// true = init pane as 'hidden' - no resizer-bar/spacing
	//	SELECTORS
	//,	paneSelector:			""			// MUST be pane-specific - jQuery selector for pane
	,	contentSelector:		".ui-layout-content" // INNER div/element to auto-size so only it scrolls, not the entire pane!
	,	contentIgnoreSelector:	".ui-layout-ignore"	// element(s) to 'ignore' when measuring 'content'
	,	findNestedContent:		false		// true = $P.find(contentSelector), false = $P.children(contentSelector)
	//	GENERIC ROOT-CLASSES - for auto-generated classNames
	,	paneClass:				"ui-layout-pane"	// Layout Pane
	,	resizerClass:			"ui-layout-resizer"	// Resizer Bar
	,	togglerClass:			"ui-layout-toggler"	// Toggler Button
	,	buttonClass:			"ui-layout-button"	// CUSTOM Buttons	- eg: '[ui-layout-button]-toggle/-open/-close/-pin'
	//	ELEMENT SIZE & SPACING
	//,	size:					100			// MUST be pane-specific -initial size of pane
	,	minSize:				0			// when manually resizing a pane
	,	maxSize:				0			// ditto, 0 = no limit
	,	spacing_open:			6			// space between pane and adjacent panes - when pane is 'open'
	,	spacing_closed:			6			// ditto - when pane is 'closed'
	,	togglerLength_open:		50			// Length = WIDTH of toggler button on north/south sides - HEIGHT on east/west sides
	,	togglerLength_closed: 	50			// 100% OR -1 means 'full height/width of resizer bar' - 0 means 'hidden'
	,	togglerAlign_open:		"center"	// top/left, bottom/right, center, OR...
	,	togglerAlign_closed:	"center"	// 1 => nn = offset from top/left, -1 => -nn == offset from bottom/right
	,	togglerContent_open:	""			// text or HTML to put INSIDE the toggler
	,	togglerContent_closed:	""			// ditto
	//	RESIZING OPTIONS
	,	resizerDblClickToggle:	true		// 
	,	autoResize:				true		// IF size is 'auto' or a percentage, then recalc 'pixel size' whenever the layout resizes
	,	autoReopen:				true		// IF a pane was auto-closed due to noRoom, reopen it when there is room? False = leave it closed
	,	resizerDragOpacity:		1			// option for ui.draggable
	//,	resizerCursor:			""			// MUST be pane-specific - cursor when over resizer-bar
	,	maskContents:			false		// true = add DIV-mask over-or-inside this pane so can 'drag' over IFRAMES
	,	maskObjects:			false		// true = add IFRAME-mask over-or-inside this pane to cover objects/applets - content-mask will overlay this mask
	,	maskZindex:				null		// will override zIndexes.content_mask if specified - not applicable to iframe-panes
	,	resizingGrid:			false		// grid size that the resizers will snap-to during resizing, eg: [20,20]
	,	livePaneResizing:		false		// true = LIVE Resizing as resizer is dragged
	,	liveContentResizing:	false		// true = re-measure header/footer heights as resizer is dragged
	,	liveResizingTolerance:	1			// how many px change before pane resizes, to control performance
	//	SLIDING OPTIONS
	,	sliderCursor:			"pointer"	// cursor when resizer-bar will trigger 'sliding'
	,	slideTrigger_open:		"click"		// click, dblclick, mouseenter
	,	slideTrigger_close:		"mouseleave"// click, mouseleave
	,	slideDelay_open:		300			// applies only for mouseenter event - 0 = instant open
	,	slideDelay_close:		300			// applies only for mouseleave event (300ms is the minimum!)
	,	hideTogglerOnSlide:		false		// when pane is slid-open, should the toggler show?
	,	preventQuickSlideClose:	$.layout.browser.webkit // Chrome triggers slideClosed as it is opening
	,	preventPrematureSlideClose: false	// handle incorrect mouseleave trigger, like when over a SELECT-list in IE
	//	PANE-SPECIFIC TIPS & MESSAGES
	,	tips: {
			Open:				"Open"		// eg: "Open Pane"
		,	Close:				"Close"
		,	Resize:				"Resize"
		,	Slide:				"Slide Open"
		,	Pin:				"Pin"
		,	Unpin:				"Un-Pin"
		,	noRoomToOpen:		"Not enough room to show this panel."	// alert if user tries to open a pane that cannot
		,	minSizeWarning:		"Panel has reached its minimum size"	// displays in browser statusbar
		,	maxSizeWarning:		"Panel has reached its maximum size"	// ditto
		}
	//	HOT-KEYS & MISC
	,	showOverflowOnHover:	false		// will bind allowOverflow() utility to pane.onMouseOver
	,	enableCursorHotkey:		true		// enabled 'cursor' hotkeys
	//,	customHotkey:			""			// MUST be pane-specific - EITHER a charCode OR a character
	,	customHotkeyModifier:	"SHIFT"		// either 'SHIFT', 'CTRL' or 'CTRL+SHIFT' - NOT 'ALT'
	//	PANE ANIMATION
	//	NOTE: fxSss_open, fxSss_close & fxSss_size options (eg: fxName_open) are auto-generated if not passed
	,	fxName:					"slide" 	// ('none' or blank), slide, drop, scale -- only relevant to 'open' & 'close', NOT 'size'
	,	fxSpeed:				null		// slow, normal, fast, 200, nnn - if passed, will OVERRIDE fxSettings.duration
	,	fxSettings:				{}			// can be passed, eg: { easing: "easeOutBounce", duration: 1500 }
	,	fxOpacityFix:			true		// tries to fix opacity in IE to restore anti-aliasing after animation
	,	animatePaneSizing:		false		// true = animate resizing after dragging resizer-bar OR sizePane() is called
	/*  NOTE: Action-specific FX options are auto-generated from the options above if not specifically set:
		fxName_open:			"slide"		// 'Open' pane animation
		fnName_close:			"slide"		// 'Close' pane animation
		fxName_size:			"slide"		// 'Size' pane animation - when animatePaneSizing = true
		fxSpeed_open:			null
		fxSpeed_close:			null
		fxSpeed_size:			null
		fxSettings_open:		{}
		fxSettings_close:		{}
		fxSettings_size:		{}
	*/
	//	CHILD/NESTED LAYOUTS
	,	children:				null		// Layout-options for nested/child layout - even {} is valid as options
	,	containerSelector:		''			// if child is NOT 'directly nested', a selector to find it/them (can have more than one child layout!)
	,	initChildren:			true		// true = child layout will be created as soon as _this_ layout completes initialization
	,	destroyChildren:		true		// true = destroy child-layout if this pane is destroyed
	,	resizeChildren:			true		// true = trigger child-layout.resizeAll() when this pane is resized
	//	EVENT TRIGGERING
	,	triggerEventsOnLoad:	false		// true = trigger onopen OR onclose callbacks when layout initializes
	,	triggerEventsDuringLiveResize: true	// true = trigger onresize callback REPEATEDLY if livePaneResizing==true
	//	PANE CALLBACKS
	,	onshow_start:			null		// CALLBACK when pane STARTS to Show	- BEFORE onopen/onhide_start
	,	onshow_end:				null		// CALLBACK when pane ENDS being Shown	- AFTER  onopen/onhide_end
	,	onhide_start:			null		// CALLBACK when pane STARTS to Close	- BEFORE onclose_start
	,	onhide_end:				null		// CALLBACK when pane ENDS being Closed	- AFTER  onclose_end
	,	onopen_start:			null		// CALLBACK when pane STARTS to Open
	,	onopen_end:				null		// CALLBACK when pane ENDS being Opened
	,	onclose_start:			null		// CALLBACK when pane STARTS to Close
	,	onclose_end:			null		// CALLBACK when pane ENDS being Closed
	,	onresize_start:			null		// CALLBACK when pane STARTS being Resized ***FOR ANY REASON***
	,	onresize_end:			null		// CALLBACK when pane ENDS being Resized ***FOR ANY REASON***
	,	onsizecontent_start:	null		// CALLBACK when sizing of content-element STARTS
	,	onsizecontent_end:		null		// CALLBACK when sizing of content-element ENDS
	,	onswap_start:			null		// CALLBACK when pane STARTS to Swap
	,	onswap_end:				null		// CALLBACK when pane ENDS being Swapped
	,	ondrag_start:			null		// CALLBACK when pane STARTS being ***MANUALLY*** Resized
	,	ondrag_end:				null		// CALLBACK when pane ENDS being ***MANUALLY*** Resized
	}
/*
 *	PANE-SPECIFIC SETTINGS
 *	- options listed below MUST be specified per-pane - they CANNOT be set under 'panes'
 *	- all options under the 'panes' key can also be set specifically for any pane
 *	- most options under the 'panes' key apply only to 'border-panes' - NOT the the center-pane
 */
,	north: {
		paneSelector:			".ui-layout-north"
	,	size:					"auto"		// eg: "auto", "30%", .30, 200
	,	resizerCursor:			"n-resize"	// custom = url(myCursor.cur)
	,	customHotkey:			""			// EITHER a charCode (43) OR a character ("o")
	}
,	south: {
		paneSelector:			".ui-layout-south"
	,	size:					"auto"
	,	resizerCursor:			"s-resize"
	,	customHotkey:			""
	}
,	east: {
		paneSelector:			".ui-layout-east"
	,	size:					200
	,	resizerCursor:			"e-resize"
	,	customHotkey:			""
	}
,	west: {
		paneSelector:			".ui-layout-west"
	,	size:					200
	,	resizerCursor:			"w-resize"
	,	customHotkey:			""
	}
,	center: {
		paneSelector:			".ui-layout-center"
	,	minWidth:				0
	,	minHeight:				0
	}
};

$.layout.optionsMap = {
	// layout/global options - NOT pane-options
	layout: ("name,instanceKey,stateManagement,effects,inset,zIndexes,errors,"
	+	"zIndex,scrollToBookmarkOnLoad,showErrorMessages,maskPanesEarly,"
	+	"outset,resizeWithWindow,resizeWithWindowDelay,resizeWithWindowMaxDelay,"
	+	"onresizeall,onresizeall_start,onresizeall_end,onload,onunload").split(",")
//	borderPanes: [ ALL options that are NOT specified as 'layout' ]
	// default.panes options that apply to the center-pane (most options apply _only_ to border-panes)
,	center: ("paneClass,contentSelector,contentIgnoreSelector,findNestedContent,applyDemoStyles,triggerEventsOnLoad,"
	+	"showOverflowOnHover,maskContents,maskObjects,liveContentResizing,"
	+	"containerSelector,children,initChildren,resizeChildren,destroyChildren,"
	+	"onresize,onresize_start,onresize_end,onsizecontent,onsizecontent_start,onsizecontent_end").split(",")
	// options that MUST be specifically set 'per-pane' - CANNOT set in the panes (defaults) key
,	noDefault: ("paneSelector,resizerCursor,customHotkey").split(",")
};

/**
 * Processes options passed in converts flat-format data into subkey (JSON) format
 * In flat-format, subkeys are _currently_ separated with 2 underscores, like north__optName
 * Plugins may also call this method so they can transform their own data
 *
 * @param  {!Object}	hash			Data/options passed by user - may be a single level or nested levels
 * @param  {boolean=}	[addKeys=false]	Should the primary layout.options keys be added if they do not exist?
 * @return {Object}						Returns hash of minWidth & minHeight
 */
$.layout.transformData = function (hash, addKeys) {
	var	json = addKeys ? { panes: {}, center: {} } : {} // init return object
	,	branch, optKey, keys, key, val, i, c;

	if (typeof hash !== "object") return json; // no options passed

	// convert all 'flat-keys' to 'sub-key' format
	for (optKey in hash) {
		branch	= json;
		val		= hash[ optKey ];
		keys	= optKey.split("__"); // eg: west__size or north__fxSettings__duration
		c		= keys.length - 1;
		// convert underscore-delimited to subkeys
		for (i=0; i <= c; i++) {
			key = keys[i];
			if (i === c) {	// last key = value
				if ($.isPlainObject( val ))
					branch[key] = $.layout.transformData( val ); // RECURSE
				else
					branch[key] = val;
			}
			else {
				if (!branch[key])
					branch[key] = {}; // create the subkey
				// recurse to sub-key for next loop - if not done
				branch = branch[key];
			}
		}
	}
	return json;
};

// INTERNAL CONFIG DATA - DO NOT CHANGE THIS!
$.layout.backwardCompatibility = {
	// data used by renameOldOptions()
	map: {
	//	OLD Option Name:			NEW Option Name
		applyDefaultStyles:			"applyDemoStyles"
	//	CHILD/NESTED LAYOUTS
	,	childOptions:				"children"
	,	initChildLayout:			"initChildren"
	,	destroyChildLayout:			"destroyChildren"
	,	resizeChildLayout:			"resizeChildren"
	,	resizeNestedLayout:			"resizeChildren"
	//	MISC Options
	,	resizeWhileDragging:		"livePaneResizing"
	,	resizeContentWhileDragging:	"liveContentResizing"
	,	triggerEventsWhileDragging:	"triggerEventsDuringLiveResize"
	,	maskIframesOnResize:		"maskContents"
	//	STATE MANAGEMENT
	,	useStateCookie:				"stateManagement.enabled"
	,	"cookie.autoLoad":			"stateManagement.autoLoad"
	,	"cookie.autoSave":			"stateManagement.autoSave"
	,	"cookie.keys":				"stateManagement.stateKeys"
	,	"cookie.name":				"stateManagement.cookie.name"
	,	"cookie.domain":			"stateManagement.cookie.domain"
	,	"cookie.path":				"stateManagement.cookie.path"
	,	"cookie.expires":			"stateManagement.cookie.expires"
	,	"cookie.secure":			"stateManagement.cookie.secure"
	//	OLD Language options
	,	noRoomToOpenTip:			"tips.noRoomToOpen"
	,	togglerTip_open:			"tips.Close"	// open   = Close
	,	togglerTip_closed:			"tips.Open"		// closed = Open
	,	resizerTip:					"tips.Resize"
	,	sliderTip:					"tips.Slide"
	}

/**
* @param {Object}	opts
*/
,	renameOptions: function (opts) {
		var map = $.layout.backwardCompatibility.map
		,	oldData, newData, value
		;
		for (var itemPath in map) {
			oldData	= getBranch( itemPath );
			value	= oldData.branch[ oldData.key ];
			if (value !== undefined) {
				newData = getBranch( map[itemPath], true );
				newData.branch[ newData.key ] = value;
				delete oldData.branch[ oldData.key ];
			}
		}

		/**
		* @param {string}	path
		* @param {boolean=}	[create=false]	Create path if does not exist
		*/
		function getBranch (path, create) {
			var a = path.split(".") // split keys into array
			,	c = a.length - 1
			,	D = { branch: opts, key: a[c] } // init branch at top & set key (last item)
			,	i = 0, k, undef;
			for (; i<c; i++) { // skip the last key (data)
				k = a[i];
				if (D.branch[ k ] == undefined) { // child-key does not exist
					if (create) {
						D.branch = D.branch[ k ] = {}; // create child-branch
					}
					else // can't go any farther
						D.branch = {}; // branch is undefined
				}
				else
					D.branch = D.branch[ k ]; // get child-branch
			}
			return D;
		};
	}

/**
* @param {Object}	opts
*/
,	renameAllOptions: function (opts) {
		var ren = $.layout.backwardCompatibility.renameOptions;
		// rename root (layout) options
		ren( opts );
		// rename 'defaults' to 'panes'
		if (opts.defaults) {
			if (typeof opts.panes !== "object")
				opts.panes = {};
			$.extend(true, opts.panes, opts.defaults);
			delete opts.defaults;
		}
		// rename options in the the options.panes key
		if (opts.panes) ren( opts.panes );
		// rename options inside *each pane key*, eg: options.west
		$.each($.layout.config.allPanes, function (i, pane) {
			if (opts[pane]) ren( opts[pane] );
		});	
		return opts;
	}
};




/*	============================================================
 *	BEGIN WIDGET: $( selector ).layout( {options} );
 *	============================================================
 */
$.fn.layout = function (opts) {
	var

	// local aliases to global data
	browser	= $.layout.browser
,	_c		= $.layout.config

	// local aliases to utlity methods
,	cssW	= $.layout.cssWidth
,	cssH	= $.layout.cssHeight
,	elDims	= $.layout.getElementDimensions
,	styles	= $.layout.getElementStyles
,	evtObj	= $.layout.getEventObject
,	evtPane	= $.layout.parsePaneName

/**
 * options - populated by initOptions()
 */
,	options = $.extend(true, {}, $.layout.defaults)
,	effects	= options.effects = $.extend(true, {}, $.layout.effects)

/**
 * layout-state object
 */
,	state = {
		// generate unique ID to use for event.namespace so can unbind only events added by 'this layout'
		id:				"layout"+ $.now()	// code uses alias: sID
	,	initialized:	false
	,	paneResizing:	false
	,	panesSliding:	{}
	,	container:	{ 	// list all keys referenced in code to avoid compiler error msgs
			innerWidth:		0
		,	innerHeight:	0
		,	outerWidth:		0
		,	outerHeight:	0
		,	layoutWidth:	0
		,	layoutHeight:	0
		}
	,	north:		{ childIdx: 0 }
	,	south:		{ childIdx: 0 }
	,	east:		{ childIdx: 0 }
	,	west:		{ childIdx: 0 }
	,	center:		{ childIdx: 0 }
	}

/**
 * parent/child-layout pointers
 */
//,	hasParentLayout	= false	- exists ONLY inside Instance so can be set externally
,	children = {
		north:		null
	,	south:		null
	,	east:		null
	,	west:		null
	,	center:		null
	}

/*
 * ###########################
 *  INTERNAL HELPER FUNCTIONS
 * ###########################
 */

	/**
	* Manages all internal timers
	*/
,	timer = {
		data:	{}
	,	set:	function (s, fn, ms) { timer.clear(s); timer.data[s] = setTimeout(fn, ms); }
	,	clear:	function (s) { var t=timer.data; if (t[s]) {clearTimeout(t[s]); delete t[s];} }
	}

	/**
	* Alert or console.log a message - IF option is enabled.
	*
	* @param {(string|!Object)}	msg				Message (or debug-data) to display
	* @param {boolean=}			[popup=false]	True by default, means 'alert', false means use console.log
	* @param {boolean=}			[debug=false]	True means is a widget debugging message
	*/
,	_log = function (msg, popup, debug) {
		var o = options;
		if ((o.showErrorMessages && !debug) || (debug && o.showDebugMessages))
			$.layout.msg( o.name +' / '+ msg, (popup !== false) );
		return false;
	}

	/**
	* Executes a Callback function after a trigger event, like resize, open or close
	*
	* @param {string}				evtName					Name of the layout callback, eg "onresize_start"
	* @param {(string|boolean)=}	[pane=""]				This is passed only so we can pass the 'pane object' to the callback
	* @param {(string|boolean)=}	[skipBoundEvents=false]	True = do not run events bound to the elements - only the callbacks set in options
	*/
,	_runCallbacks = function (evtName, pane, skipBoundEvents) {
		var	hasPane	= pane && isStr(pane)
		,	s		= hasPane ? state[pane] : state
		,	o		= hasPane ? options[pane] : options
		,	lName	= options.name
			// names like onopen and onopen_end separate are interchangeable in options...
		,	lng		= evtName + (evtName.match(/_/) ? "" : "_end")
		,	shrt	= lng.match(/_end$/) ? lng.substr(0, lng.length - 4) : ""
		,	fn		= o[lng] || o[shrt]
		,	retVal	= "NC" // NC = No Callback
		,	args	= []
		,	$P
		;
		if ( !hasPane && $.type(pane) === 'boolean' ) {
			skipBoundEvents = pane; // allow pane param to be skipped for Layout callback
			pane = "";
		}

		// first trigger the callback set in the options
		if (fn) {
			try {
				// convert function name (string) to function object
				if (isStr( fn )) {
					if (fn.match(/,/)) {
						// function name cannot contain a comma, 
						// so must be a function name AND a parameter to pass
						args = fn.split(",")
						,	fn = eval(args[0]);
					}
					else // just the name of an external function?
						fn = eval(fn);
				}
				// execute the callback, if exists
				if ($.isFunction( fn )) {
					if (args.length)
						retVal = g(fn)(args[1]); // pass the argument parsed from 'list'
					else if ( hasPane )
						// pass data: pane-name, pane-element, pane-state, pane-options, and layout-name
						retVal = g(fn)( pane, $Ps[pane], s, o, lName );
					else // must be a layout/container callback - pass suitable info
						retVal = g(fn)( Instance, s, o, lName );
				}
			}
			catch (ex) {
				_log( options.errors.callbackError.replace(/EVENT/, $.trim((pane || "") +" "+ lng)), false );
				if ($.type(ex) === 'string' && string.length)
					_log('Exception:  '+ ex, false );
			}
		}

		// trigger additional events bound directly to the pane
		if (!skipBoundEvents && retVal !== false) {
			if ( hasPane ) { // PANE events can be bound to each pane-elements
				$P	= $Ps[pane];
				o	= options[pane];
				s	= state[pane];
				$P.triggerHandler('layoutpane'+ lng, [ pane, $P, s, o, lName ]);
				if (shrt)
					$P.triggerHandler('layoutpane'+ shrt, [ pane, $P, s, o, lName ]);
			}
			else { // LAYOUT events can be bound to the container-element
				$N.triggerHandler('layout'+ lng, [ Instance, s, o, lName ]);
				if (shrt)
					$N.triggerHandler('layout'+ shrt, [ Instance, s, o, lName ]);
			}
		}

		// ALWAYS resizeChildren after an onresize_end event - even during initialization
		// IGNORE onsizecontent_end event because causes child-layouts to resize TWICE
		if (hasPane && evtName === "onresize_end") // BAD: || evtName === "onsizecontent_end"
			resizeChildren(pane+"", true); // compiler hack -force string

		return retVal;

		function g (f) { return f; }; // compiler hack
	}


	/**
	* cure iframe display issues in IE & other browsers
	*/
,	_fixIframe = function (pane) {
		if (browser.mozilla) return; // skip FireFox - it auto-refreshes iframes onShow
		var $P = $Ps[pane];
		// if the 'pane' is an iframe, do it
		if (state[pane].tagName === "IFRAME")
			$P.css(_c.hidden).css(_c.visible); 
		else // ditto for any iframes INSIDE the pane
			$P.find('IFRAME').css(_c.hidden).css(_c.visible);
	}

	/**
	* @param  {string}		pane		Can accept ONLY a 'pane' (east, west, etc)
	* @param  {number=}		outerSize	(optional) Can pass a width, allowing calculations BEFORE element is resized
	* @return {number}		Returns the innerHeight/Width of el by subtracting padding and borders
	*/
,	cssSize = function (pane, outerSize) {
		var fn = _c[pane].dir=="horz" ? cssH : cssW;
		return fn($Ps[pane], outerSize);
	}

	/**
	* @param  {string}		pane		Can accept ONLY a 'pane' (east, west, etc)
	* @return {Object}		Returns hash of minWidth & minHeight
	*/
,	cssMinDims = function (pane) {
		// minWidth/Height means CSS width/height = 1px
		var	$P	= $Ps[pane]
		,	dir	= _c[pane].dir
		,	d	= {
				minWidth:	1001 - cssW($P, 1000)
			,	minHeight:	1001 - cssH($P, 1000)
			}
		;
		if (dir === "horz") d.minSize = d.minHeight;
		if (dir === "vert") d.minSize = d.minWidth;
		return d;
	}

	// TODO: see if these methods can be made more useful...
	// TODO: *maybe* return cssW/H from these so caller can use this info

	/**
	* @param {(string|!Object)}		el
	* @param {number=}				outerWidth
	* @param {boolean=}				[autoHide=false]
	*/
,	setOuterWidth = function (el, outerWidth, autoHide) {
		var $E = el, w;
		if (isStr(el)) $E = $Ps[el]; // west
		else if (!el.jquery) $E = $(el);
		w = cssW($E, outerWidth);
		$E.css({ width: w });
		if (w > 0) {
			if (autoHide && $E.data('autoHidden') && $E.innerHeight() > 0) {
				$E.show().data('autoHidden', false);
				if (!browser.mozilla) // FireFox refreshes iframes - IE does not
					// make hidden, then visible to 'refresh' display after animation
					$E.css(_c.hidden).css(_c.visible);
			}
		}
		else if (autoHide && !$E.data('autoHidden'))
			$E.hide().data('autoHidden', true);
	}

	/**
	* @param {(string|!Object)}		el
	* @param {number=}				outerHeight
	* @param {boolean=}				[autoHide=false]
	*/
,	setOuterHeight = function (el, outerHeight, autoHide) {
		var $E = el, h;
		if (isStr(el)) $E = $Ps[el]; // west
		else if (!el.jquery) $E = $(el);
		h = cssH($E, outerHeight);
		$E.css({ height: h, visibility: "visible" }); // may have been 'hidden' by sizeContent
		if (h > 0 && $E.innerWidth() > 0) {
			if (autoHide && $E.data('autoHidden')) {
				$E.show().data('autoHidden', false);
				if (!browser.mozilla) // FireFox refreshes iframes - IE does not
					$E.css(_c.hidden).css(_c.visible);
			}
		}
		else if (autoHide && !$E.data('autoHidden'))
			$E.hide().data('autoHidden', true);
	}


	/**
	* Converts any 'size' params to a pixel/integer size, if not already
	* If 'auto' or a decimal/percentage is passed as 'size', a pixel-size is calculated
	*
	/**
	* @param  {string}				pane
	* @param  {(string|number)=}	size
	* @param  {string=}				[dir]
	* @return {number}
	*/
,	_parseSize = function (pane, size, dir) {
		if (!dir) dir = _c[pane].dir;

		if (isStr(size) && size.match(/%/))
			size = (size === '100%') ? -1 : parseInt(size, 10) / 100; // convert % to decimal

		if (size === 0)
			return 0;
		else if (size >= 1)
			return parseInt(size, 10);

		var o = options, avail = 0;
		if (dir=="horz") // north or south or center.minHeight
			avail = sC.innerHeight - ($Ps.north ? o.north.spacing_open : 0) - ($Ps.south ? o.south.spacing_open : 0);
		else if (dir=="vert") // east or west or center.minWidth
			avail = sC.innerWidth - ($Ps.west ? o.west.spacing_open : 0) - ($Ps.east ? o.east.spacing_open : 0);

		if (size === -1) // -1 == 100%
			return avail;
		else if (size > 0) // percentage, eg: .25
			return round(avail * size);
		else if (pane=="center")
			return 0;
		else { // size < 0 || size=='auto' || size==Missing || size==Invalid
			// auto-size the pane
			var	dim	= (dir === "horz" ? "height" : "width")
			,	$P	= $Ps[pane]
			,	$C	= dim === 'height' ? $Cs[pane] : false
			,	vis	= $.layout.showInvisibly($P) // show pane invisibly if hidden
			,	szP	= $P.css(dim) // SAVE current pane size
			,	szC	= $C ? $C.css(dim) : 0 // SAVE current content size
			;
			$P.css(dim, "auto");
			if ($C) $C.css(dim, "auto");
			size = (dim === "height") ? $P.outerHeight() : $P.outerWidth(); // MEASURE
			$P.css(dim, szP).css(vis); // RESET size & visibility
			if ($C) $C.css(dim, szC);
			return size;
		}
	}

	/**
	* Calculates current 'size' (outer-width or outer-height) of a border-pane - optionally with 'pane-spacing' added
	*
	* @param  {(string|!Object)}	pane
	* @param  {boolean=}			[inclSpace=false]
	* @return {number}				Returns EITHER Width for east/west panes OR Height for north/south panes
	*/
,	getPaneSize = function (pane, inclSpace) {
		var 
			$P	= $Ps[pane]
		,	o	= options[pane]
		,	s	= state[pane]
		,	oSp	= (inclSpace ? o.spacing_open : 0)
		,	cSp	= (inclSpace ? o.spacing_closed : 0)
		;
		if (!$P || s.isHidden)
			return 0;
		else if (s.isClosed || (s.isSliding && inclSpace))
			return cSp;
		else if (_c[pane].dir === "horz")
			return $P.outerHeight() + oSp;
		else // dir === "vert"
			return $P.outerWidth() + oSp;
	}

	/**
	* Calculate min/max pane dimensions and limits for resizing
	*
	* @param  {string}		pane
	* @param  {boolean=}	[slide=false]
	*/
,	setSizeLimits = function (pane, slide) {
		if (!isInitialized()) return;
		var 
			o				= options[pane]
		,	s				= state[pane]
		,	c				= _c[pane]
		,	dir				= c.dir
		,	type			= c.sizeType.toLowerCase()
		,	isSliding		= (slide != undefined ? slide : s.isSliding) // only open() passes 'slide' param
		,	$P				= $Ps[pane]
		,	paneSpacing		= o.spacing_open
		//	measure the pane on the *opposite side* from this pane
		,	altPane			= _c.oppositeEdge[pane]
		,	altS			= state[altPane]
		,	$altP			= $Ps[altPane]
		,	altPaneSize		= (!$altP || altS.isVisible===false || altS.isSliding ? 0 : (dir=="horz" ? $altP.outerHeight() : $altP.outerWidth()))
		,	altPaneSpacing	= ((!$altP || altS.isHidden ? 0 : options[altPane][ altS.isClosed !== false ? "spacing_closed" : "spacing_open" ]) || 0)
		//	limitSize prevents this pane from 'overlapping' opposite pane
		,	containerSize	= (dir=="horz" ? sC.innerHeight : sC.innerWidth)
		,	minCenterDims	= cssMinDims("center")
		,	minCenterSize	= dir=="horz" ? max(options.center.minHeight, minCenterDims.minHeight) : max(options.center.minWidth, minCenterDims.minWidth)
		//	if pane is 'sliding', then ignore center and alt-pane sizes - because 'overlays' them
		,	limitSize		= (containerSize - paneSpacing - (isSliding ? 0 : (_parseSize("center", minCenterSize, dir) + altPaneSize + altPaneSpacing)))
		,	minSize			= s.minSize = max( _parseSize(pane, o.minSize), cssMinDims(pane).minSize )
		,	maxSize			= s.maxSize = min( (o.maxSize ? _parseSize(pane, o.maxSize) : 100000), limitSize )
		,	r				= s.resizerPosition = {} // used to set resizing limits
		,	top				= sC.inset.top
		,	left			= sC.inset.left
		,	W				= sC.innerWidth
		,	H				= sC.innerHeight
		,	rW				= o.spacing_open // subtract resizer-width to get top/left position for south/east
		;
		switch (pane) {
			case "north":	r.min = top + minSize;
							r.max = top + maxSize;
							break;
			case "west":	r.min = left + minSize;
							r.max = left + maxSize;
							break;
			case "south":	r.min = top + H - maxSize - rW;
							r.max = top + H - minSize - rW;
							break;
			case "east":	r.min = left + W - maxSize - rW;
							r.max = left + W - minSize - rW;
							break;
		};
	}

	/**
	* Returns data for setting the size/position of center pane. Also used to set Height for east/west panes
	*
	* @return JSON  Returns a hash of all dimensions: top, bottom, left, right, (outer) width and (outer) height
	*/
,	calcNewCenterPaneDims = function () {
		var d = {
			top:	getPaneSize("north", true) // true = include 'spacing' value for pane
		,	bottom:	getPaneSize("south", true)
		,	left:	getPaneSize("west", true)
		,	right:	getPaneSize("east", true)
		,	width:	0
		,	height:	0
		};

		// NOTE: sC = state.container
		// calc center-pane outer dimensions
		d.width		= sC.innerWidth - d.left - d.right;  // outerWidth
		d.height	= sC.innerHeight - d.bottom - d.top; // outerHeight
		// add the 'container border/padding' to get final positions relative to the container
		d.top		+= sC.inset.top;
		d.bottom	+= sC.inset.bottom;
		d.left		+= sC.inset.left;
		d.right		+= sC.inset.right;

		return d;
	}


	/**
	* @param {!Object}		el
	* @param {boolean=}		[allStates=false]
	*/
,	getHoverClasses = function (el, allStates) {
		var
			$El		= $(el)
		,	type	= $El.data("layoutRole")
		,	pane	= $El.data("layoutEdge")
		,	o		= options[pane]
		,	root	= o[type +"Class"]
		,	_pane	= "-"+ pane // eg: "-west"
		,	_open	= "-open"
		,	_closed	= "-closed"
		,	_slide	= "-sliding"
		,	_hover	= "-hover " // NOTE the trailing space
		,	_state	= $El.hasClass(root+_closed) ? _closed : _open
		,	_alt	= _state === _closed ? _open : _closed
		,	classes = (root+_hover) + (root+_pane+_hover) + (root+_state+_hover) + (root+_pane+_state+_hover)
		;
		if (allStates) // when 'removing' classes, also remove alternate-state classes
			classes += (root+_alt+_hover) + (root+_pane+_alt+_hover);

		if (type=="resizer" && $El.hasClass(root+_slide))
			classes += (root+_slide+_hover) + (root+_pane+_slide+_hover);

		return $.trim(classes);
	}
,	addHover	= function (evt, el) {
		var $E = $(el || this);
		if (evt && $E.data("layoutRole") === "toggler")
			evt.stopPropagation(); // prevent triggering 'slide' on Resizer-bar
		$E.addClass( getHoverClasses($E) );
	}
,	removeHover	= function (evt, el) {
		var $E = $(el || this);
		$E.removeClass( getHoverClasses($E, true) );
	}

,	onResizerEnter	= function (evt) { // ALSO called by toggler.mouseenter
		var pane	= $(this).data("layoutEdge")
		,	s		= state[pane]
		;
		// ignore closed-panes and mouse moving back & forth over resizer!
		// also ignore if ANY pane is currently resizing
		if ( s.isClosed || s.isResizing || state.paneResizing ) return;

		if ($.fn.disableSelection)
			$("body").disableSelection();
		if (options.maskPanesEarly)
			showMasks( pane, { resizing: true });
	}
,	onResizerLeave	= function (evt, el) {
		var	e		= el || this // el is only passed when called by the timer
		,	pane	= $(e).data("layoutEdge")
		,	name	= pane +"ResizerLeave"
		;
		timer.clear(pane+"_openSlider"); // cancel slideOpen timer, if set
		timer.clear(name); // cancel enableSelection timer - may re/set below
		// this method calls itself on a timer because it needs to allow
		// enough time for dragging to kick-in and set the isResizing flag
		// dragging has a 100ms delay set, so this delay must be >100
		if (!el) // 1st call - mouseleave event
			timer.set(name, function(){ onResizerLeave(evt, e); }, 200);
		// if user is resizing, then dragStop will enableSelection(), so can skip it here
		else if ( !state.paneResizing ) { // 2nd call - by timer
			if ($.fn.enableSelection)
				$("body").enableSelection();
			if (options.maskPanesEarly)
				hideMasks();
		}
	}

/*
 * ###########################
 *   INITIALIZATION METHODS
 * ###########################
 */

	/**
	* Initialize the layout - called automatically whenever an instance of layout is created
	*
	* @see  none - triggered onInit
	* @return  mixed	true = fully initialized | false = panes not initialized (yet) | 'cancel' = abort
	*/
,	_create = function () {
		// initialize config/options
		initOptions();
		var o = options
		,	s = state;

		// TEMP state so isInitialized returns true during init process
		s.creatingLayout = true;

		// init plugins for this layout, if there are any (eg: stateManagement)
		runPluginCallbacks( Instance, $.layout.onCreate );

		// options & state have been initialized, so now run beforeLoad callback
		// onload will CANCEL layout creation if it returns false
		if (false === _runCallbacks("onload_start"))
			return 'cancel';

		// initialize the container element
		_initContainer();

		// bind hotkey function - keyDown - if required
		initHotkeys();

		// bind window.onunload
		$(window).bind("unload."+ sID, unload);

		// init plugins for this layout, if there are any (eg: customButtons)
		runPluginCallbacks( Instance, $.layout.onLoad );

		// if layout elements are hidden, then layout WILL NOT complete initialization!
		// initLayoutElements will set initialized=true and run the onload callback IF successful
		if (o.initPanes) _initLayoutElements();

		delete s.creatingLayout;

		return state.initialized;
	}

	/**
	* Initialize the layout IF not already
	*
	* @see  All methods in Instance run this test
	* @return  boolean	true = layoutElements have been initialized | false = panes are not initialized (yet)
	*/
,	isInitialized = function () {
		if (state.initialized || state.creatingLayout) return true;	// already initialized
		else return _initLayoutElements();	// try to init panes NOW
	}

	/**
	* Initialize the layout - called automatically whenever an instance of layout is created
	*
	* @see  _create() & isInitialized
	* @param {boolean=}		[retry=false]	// indicates this is a 2nd try
	* @return  An object pointer to the instance created
	*/
,	_initLayoutElements = function (retry) {
		// initialize config/options
		var o = options;
		// CANNOT init panes inside a hidden container!
		if (!$N.is(":visible")) {
			// handle Chrome bug where popup window 'has no height'
			// if layout is BODY element, try again in 50ms
			// SEE: http://layout.jquery-dev.net/samples/test_popup_window.html
			if ( !retry && browser.webkit && $N[0].tagName === "BODY" )
				setTimeout(function(){ _initLayoutElements(true); }, 50);
			return false;
		}

		// a center pane is required, so make sure it exists
		if (!getPane("center").length) {
			return _log( o.errors.centerPaneMissing );
		}

		// TEMP state so isInitialized returns true during init process
		state.creatingLayout = true;

		// update Container dims
		$.extend(sC, elDims( $N, o.inset )); // passing inset means DO NOT include insetX values

		// initialize all layout elements
		initPanes();	// size & position panes - calls initHandles() - which calls initResizable()

		if (o.scrollToBookmarkOnLoad) {
			var l = self.location;
			if (l.hash) l.replace( l.hash ); // scrollTo Bookmark
		}

		// check to see if this layout 'nested' inside a pane
		if (Instance.hasParentLayout)
			o.resizeWithWindow = false;
		// bind resizeAll() for 'this layout instance' to window.resize event
		else if (o.resizeWithWindow)
			$(window).bind("resize."+ sID, windowResize);

		delete state.creatingLayout;
		state.initialized = true;

		// init plugins for this layout, if there are any
		runPluginCallbacks( Instance, $.layout.onReady );

		// now run the onload callback, if exists
		_runCallbacks("onload_end");

		return true; // elements initialized successfully
	}

	/**
	* Initialize nested layouts for a specific pane - can optionally pass layout-options
	*
	* @param {(string|Object)}	evt_or_pane	The pane being opened, ie: north, south, east, or west
	* @param {Object=}			[opts]		Layout-options - if passed, will OVERRRIDE options[pane].children
	* @return  An object pointer to the layout instance created - or null
	*/
,	createChildren = function (evt_or_pane, opts) {
		var	pane = evtPane.call(this, evt_or_pane)
		,	$P	= $Ps[pane]
		;
		if (!$P) return;
		var	$C	= $Cs[pane]
		,	s	= state[pane]
		,	o	= options[pane]
		,	sm	= options.stateManagement || {}
		,	cos = opts ? (o.children = opts) : o.children
		;
		if ( $.isPlainObject( cos ) )
			cos = [ cos ]; // convert a hash to a 1-elem array
		else if (!cos || !$.isArray( cos ))
			return;

		$.each( cos, function (idx, co) {
			if ( !$.isPlainObject( co ) ) return;

			// determine which element is supposed to be the 'child container'
			// if pane has a 'containerSelector' OR a 'content-div', use those instead of the pane
			var $containers = co.containerSelector ? $P.find( co.containerSelector ) : ($C || $P);

			$containers.each(function(){
				var $cont	= $(this)
				,	child	= $cont.data("layout") //	see if a child-layout ALREADY exists on this element
				;
				// if no layout exists, but children are set, try to create the layout now
				if (!child) {
					// TODO: see about moving this to the stateManagement plugin, as a method
					// set a unique child-instance key for this layout, if not already set
					setInstanceKey({ container: $cont, options: co }, s );
					// If THIS layout has a hash in stateManagement.autoLoad,
					// then see if it also contains state-data for this child-layout
					// If so, copy the stateData to child.options.stateManagement.autoLoad
					if ( sm.includeChildren && state.stateData[pane] ) {
						//	THIS layout's state was cached when its state was loaded
						var	paneChildren = state.stateData[pane].children || {}
						,	childState	= paneChildren[ co.instanceKey ]
						,	co_sm		= co.stateManagement || (co.stateManagement = { autoLoad: true })
						;
						// COPY the stateData into the autoLoad key
						if ( co_sm.autoLoad === true && childState ) {
							co_sm.autoSave			= false; // disable autoSave because saving handled by parent-layout
							co_sm.includeChildren	= true;  // cascade option - FOR NOW
							co_sm.autoLoad = $.extend(true, {}, childState); // COPY the state-hash
						}
					}

					// create the layout
					child = $cont.layout( co );

					// if successful, update data
					if (child) {
						// add the child and update all layout-pointers
						// MAY have already been done by child-layout calling parent.refreshChildren()
						refreshChildren( pane, child );
					}
				}
			});
		});
	}

,	setInstanceKey = function (child, parentPaneState) {
		// create a named key for use in state and instance branches
		var	$c	= child.container
		,	o	= child.options
		,	sm	= o.stateManagement
		,	key	= o.instanceKey || $c.data("layoutInstanceKey")
		;
		if (!key) key = (sm && sm.cookie ? sm.cookie.name : '') || o.name; // look for a name/key
		if (!key) key = "layout"+ (++parentPaneState.childIdx);	// if no name/key found, generate one
		else key = key.replace(/[^\w-]/gi, '_').replace(/_{2,}/g, '_');	 // ensure is valid as a hash key
		o.instanceKey = key;
		$c.data("layoutInstanceKey", key); // useful if layout is destroyed and then recreated
		return key;
	}

	/**
	* @param {string}		pane		The pane being opened, ie: north, south, east, or west
	* @param {Object=}		newChild	New child-layout Instance to add to this pane
	*/
,	refreshChildren = function (pane, newChild) {
		var	$P	= $Ps[pane]
		,	pC	= children[pane]
		,	s	= state[pane]
		,	o
		;
		// check for destroy()ed layouts and update the child pointers & arrays
		if ($.isPlainObject( pC )) {
			$.each( pC, function (key, child) {
				if (child.destroyed) delete pC[key]
			});
			// if no more children, remove the children hash
			if ($.isEmptyObject( pC ))
				pC = children[pane] = null; // clear children hash
		}

		// see if there is a directly-nested layout inside this pane
		// if there is, then there can be only ONE child-layout, so check that...
		if (!newChild && !pC) {
			newChild = $P.data("layout");
		}

		// if a newChild instance was passed, add it to children[pane]
		if (newChild) {
			// update child.state
			newChild.hasParentLayout = true; // set parent-flag in child
			// instanceKey is a key-name used in both state and children
			o = newChild.options;
			// set a unique child-instance key for this layout, if not already set
			setInstanceKey( newChild, s );
			// add pointer to pane.children hash
			if (!pC) pC = children[pane] = {}; // create an empty children hash
			pC[ o.instanceKey ] = newChild.container.data("layout"); // add childLayout instance
		}

		// ALWAYS refresh the pane.children alias, even if null
		Instance[pane].children = children[pane];

		// if newChild was NOT passed - see if there is a child layout NOW
		if (!newChild) {
			createChildren(pane); // MAY create a child and re-call this method
		}
	}

,	windowResize = function () {
		var	o = options
		,	delay = Number(o.resizeWithWindowDelay);
		if (delay < 10) delay = 100; // MUST have a delay!
		// resizing uses a delay-loop because the resize event fires repeatly - except in FF, but delay anyway
		timer.clear("winResize"); // if already running
		timer.set("winResize", function(){
			timer.clear("winResize");
			timer.clear("winResizeRepeater");
			var dims = elDims( $N, o.inset );
			// only trigger resizeAll() if container has changed size
			if (dims.innerWidth !== sC.innerWidth || dims.innerHeight !== sC.innerHeight)
				resizeAll();
		}, delay);
		// ALSO set fixed-delay timer, if not already running
		if (!timer.data["winResizeRepeater"]) setWindowResizeRepeater();
	}

,	setWindowResizeRepeater = function () {
		var delay = Number(options.resizeWithWindowMaxDelay);
		if (delay > 0)
			timer.set("winResizeRepeater", function(){ setWindowResizeRepeater(); resizeAll(); }, delay);
	}

,	unload = function () {
		var o = options;

		_runCallbacks("onunload_start");

		// trigger plugin callabacks for this layout (eg: stateManagement)
		runPluginCallbacks( Instance, $.layout.onUnload );

		_runCallbacks("onunload_end");
	}

	/**
	* Validate and initialize container CSS and events
	*
	* @see  _create()
	*/
,	_initContainer = function () {
		var
			N		= $N[0]	
		,	$H		= $("html")
		,	tag		= sC.tagName = N.tagName
		,	id		= sC.id = N.id
		,	cls		= sC.className = N.className
		,	o		= options
		,	name	= o.name
		,	props	= "position,margin,padding,border"
		,	css		= "layoutCSS"
		,	CSS		= {}
		,	hid		= "hidden" // used A LOT!
		//	see if this container is a 'pane' inside an outer-layout
		,	parent	= $N.data("parentLayout")	// parent-layout Instance
		,	pane	= $N.data("layoutEdge")		// pane-name in parent-layout
		,	isChild	= parent && pane
		,	num		= $.layout.cssNum
		,	$parent, n
		;
		// sC = state.container
		sC.selector = $N.selector.split(".slice")[0];
		sC.ref		= (o.name ? o.name +' layout / ' : '') + tag + (id ? "#"+id : cls ? '.['+cls+']' : ''); // used in messages
		sC.isBody	= (tag === "BODY");

		// try to find a parent-layout
		if (!isChild && !sC.isBody) {
			$parent = $N.closest("."+ $.layout.defaults.panes.paneClass);
			parent	= $parent.data("parentLayout");
			pane	= $parent.data("layoutEdge");
			isChild	= parent && pane;
		}

		$N	.data({
				layout: Instance
			,	layoutContainer: sID // FLAG to indicate this is a layout-container - contains unique internal ID
			})
			.addClass(o.containerClass)
		;
		var layoutMethods = {
			destroy:	''
		,	initPanes:	''
		,	resizeAll:	'resizeAll'
		,	resize:		'resizeAll'
		};
		// loop hash and bind all methods - include layoutID namespacing
		for (name in layoutMethods) {
			$N.bind("layout"+ name.toLowerCase() +"."+ sID, Instance[ layoutMethods[name] || name ]);
		}

		// if this container is another layout's 'pane', then set child/parent pointers
		if (isChild) {
			// update parent flag
			Instance.hasParentLayout = true;
			// set pointers to THIS child-layout (Instance) in parent-layout
			parent.refreshChildren( pane, Instance );
		}

		// SAVE original container CSS for use in destroy()
		if (!$N.data(css)) {
			// handle props like overflow different for BODY & HTML - has 'system default' values
			if (sC.isBody) {
				// SAVE <BODY> CSS
				$N.data(css, $.extend( styles($N, props), {
					height:		$N.css("height")
				,	overflow:	$N.css("overflow")
				,	overflowX:	$N.css("overflowX")
				,	overflowY:	$N.css("overflowY")
				}));
				// ALSO SAVE <HTML> CSS
				$H.data(css, $.extend( styles($H, 'padding'), {
					height:		"auto" // FF would return a fixed px-size!
				,	overflow:	$H.css("overflow")
				,	overflowX:	$H.css("overflowX")
				,	overflowY:	$H.css("overflowY")
				}));
			}
			else // handle props normally for non-body elements
				$N.data(css, styles($N, props+",top,bottom,left,right,width,height,overflow,overflowX,overflowY") );
		}

		try {
			// common container CSS
			CSS = {
				overflow:	hid
			,	overflowX:	hid
			,	overflowY:	hid
			};
			$N.css( CSS );

			if (o.inset && !$.isPlainObject(o.inset)) {
				// can specify a single number for equal outset all-around
				n = parseInt(o.inset, 10) || 0
				o.inset = {
					top:	n
				,	bottom:	n
				,	left:	n
				,	right:	n
				};
			}

			// format html & body if this is a full page layout
			if (sC.isBody) {
				// if HTML has padding, use this as an outer-spacing around BODY
				if (!o.outset) {
					// use padding from parent-elem (HTML) as outset
					o.outset = {
						top:	num($H, "paddingTop")
					,	bottom:	num($H, "paddingBottom")
					,	left:	num($H, "paddingLeft")
					,	right:	num($H, "paddingRight")
					};
				}
				else if (!$.isPlainObject(o.outset)) {
					// can specify a single number for equal outset all-around
					n = parseInt(o.outset, 10) || 0
					o.outset = {
						top:	n
					,	bottom:	n
					,	left:	n
					,	right:	n
					};
				}
				// HTML
				$H.css( CSS ).css({
					height:		"100%"
				,	border:		"none"	// no border or padding allowed when using height = 100%
				,	padding:	0		// ditto
				,	margin:		0
				});
				// BODY
				if (browser.isIE6) {
					// IE6 CANNOT use the trick of setting absolute positioning on all 4 sides - must have 'height'
					$N.css({
						width:		"100%"
					,	height:		"100%"
					,	border:		"none"	// no border or padding allowed when using height = 100%
					,	padding:	0		// ditto
					,	margin:		0
					,	position:	"relative"
					});
					// convert body padding to an inset option - the border cannot be measured in IE6!
					if (!o.inset) o.inset = elDims( $N ).inset;
				}
				else { // use absolute positioning for BODY to allow borders & padding without overflow
					$N.css({
						width:		"auto"
					,	height:		"auto"
					,	margin:		0
					,	position:	"absolute"	// allows for border and padding on BODY
					});
					// apply edge-positioning created above
					$N.css( o.outset );
				}
				// set current layout-container dimensions
				$.extend(sC, elDims( $N, o.inset )); // passing inset means DO NOT include insetX values
			}
			else {
				// container MUST have 'position'
				var	p = $N.css("position");
				if (!p || !p.match(/(fixed|absolute|relative)/))
					$N.css("position","relative");

				// set current layout-container dimensions
				if ( $N.is(":visible") ) {
					$.extend(sC, elDims( $N, o.inset )); // passing inset means DO NOT change insetX (padding) values
					if (sC.innerHeight < 1) // container has no 'height' - warn developer
						_log( o.errors.noContainerHeight.replace(/CONTAINER/, sC.ref) );
				}
			}

			// if container has min-width/height, then enable scrollbar(s)
			if ( num($N, "minWidth")  ) $N.parent().css("overflowX","auto");
			if ( num($N, "minHeight") ) $N.parent().css("overflowY","auto");

		} catch (ex) {}
	}

	/**
	* Bind layout hotkeys - if options enabled
	*
	* @see  _create() and addPane()
	* @param {string=}	[panes=""]	The edge(s) to process
	*/
,	initHotkeys = function (panes) {
		panes = panes ? panes.split(",") : _c.borderPanes;
		// bind keyDown to capture hotkeys, if option enabled for ANY pane
		$.each(panes, function (i, pane) {
			var o = options[pane];
			if (o.enableCursorHotkey || o.customHotkey) {
				$(document).bind("keydown."+ sID, keyDown); // only need to bind this ONCE
				return false; // BREAK - binding was done
			}
		});
	}

	/**
	* Build final OPTIONS data
	*
	* @see  _create()
	*/
,	initOptions = function () {
		var data, d, pane, key, val, i, c, o;

		// reprocess user's layout-options to have correct options sub-key structure
		opts = $.layout.transformData( opts, true ); // panes = default subkey

		// auto-rename old options for backward compatibility
		opts = $.layout.backwardCompatibility.renameAllOptions( opts );

		// if user-options has 'panes' key (pane-defaults), clean it...
		if (!$.isEmptyObject(opts.panes)) {
			// REMOVE any pane-defaults that MUST be set per-pane
			data = $.layout.optionsMap.noDefault;
			for (i=0, c=data.length; i<c; i++) {
				key = data[i];
				delete opts.panes[key]; // OK if does not exist
			}
			// REMOVE any layout-options specified under opts.panes
			data = $.layout.optionsMap.layout;
			for (i=0, c=data.length; i<c; i++) {
				key = data[i];
				delete opts.panes[key]; // OK if does not exist
			}
		}

		// MOVE any NON-layout-options from opts-root to opts.panes
		data = $.layout.optionsMap.layout;
		var rootKeys = $.layout.config.optionRootKeys;
		for (key in opts) {
			val = opts[key];
			if ($.inArray(key, rootKeys) < 0 && $.inArray(key, data) < 0) {
				if (!opts.panes[key])
					opts.panes[key] = $.isPlainObject(val) ? $.extend(true, {}, val) : val;
				delete opts[key]
			}
		}

		// START by updating ALL options from opts
		$.extend(true, options, opts);

		// CREATE final options (and config) for EACH pane
		$.each(_c.allPanes, function (i, pane) {

			// apply 'pane-defaults' to CONFIG.[PANE]
			_c[pane] = $.extend(true, {}, _c.panes, _c[pane]);

			d = options.panes;
			o = options[pane];

			// center-pane uses SOME keys in defaults.panes branch
			if (pane === 'center') {
				// ONLY copy keys from opts.panes listed in: $.layout.optionsMap.center
				data = $.layout.optionsMap.center;		// list of 'center-pane keys'
				for (i=0, c=data.length; i<c; i++) {	// loop the list...
					key = data[i];
					// only need to use pane-default if pane-specific value not set
					if (!opts.center[key] && (opts.panes[key] || !o[key]))
						o[key] = d[key]; // pane-default
				}
			}
			else {
				// border-panes use ALL keys in defaults.panes branch
				o = options[pane] = $.extend(true, {}, d, o); // re-apply pane-specific opts AFTER pane-defaults
				createFxOptions( pane );
				// ensure all border-pane-specific base-classes exist
				if (!o.resizerClass)	o.resizerClass	= "ui-layout-resizer";
				if (!o.togglerClass)	o.togglerClass	= "ui-layout-toggler";
			}
			// ensure we have base pane-class (ALL panes)
			if (!o.paneClass) o.paneClass = "ui-layout-pane";
		});

		// update options.zIndexes if a zIndex-option specified
		var zo	= opts.zIndex
		,	z	= options.zIndexes;
		if (zo > 0) {
			z.pane_normal		= zo;
			z.content_mask		= max(zo+1, z.content_mask);	// MIN = +1
			z.resizer_normal	= max(zo+2, z.resizer_normal);	// MIN = +2
		}

		// DELETE 'panes' key now that we are done - values were copied to EACH pane
		delete options.panes;


		function createFxOptions ( pane ) {
			var	o = options[pane]
			,	d = options.panes;
			// ensure fxSettings key to avoid errors
			if (!o.fxSettings) o.fxSettings = {};
			if (!d.fxSettings) d.fxSettings = {};

			$.each(["_open","_close","_size"], function (i,n) { 
				var
					sName		= "fxName"+ n
				,	sSpeed		= "fxSpeed"+ n
				,	sSettings	= "fxSettings"+ n
					// recalculate fxName according to specificity rules
				,	fxName = o[sName] =
						o[sName]	// options.west.fxName_open
					||	d[sName]	// options.panes.fxName_open
					||	o.fxName	// options.west.fxName
					||	d.fxName	// options.panes.fxName
					||	"none"		// MEANS $.layout.defaults.panes.fxName == "" || false || null || 0
				,	fxExists	= $.effects && ($.effects[fxName] || ($.effects.effect && $.effects.effect[fxName]))
				;
				// validate fxName to ensure is valid effect - MUST have effect-config data in options.effects
				if (fxName === "none" || !options.effects[fxName] || !fxExists)
					fxName = o[sName] = "none"; // effect not loaded OR unrecognized fxName

				// set vars for effects subkeys to simplify logic
				var	fx		= options.effects[fxName] || {}	// effects.slide
				,	fx_all	= fx.all	|| null				// effects.slide.all
				,	fx_pane	= fx[pane]	|| null				// effects.slide.west
				;
				// create fxSpeed[_open|_close|_size]
				o[sSpeed] =
					o[sSpeed]				// options.west.fxSpeed_open
				||	d[sSpeed]				// options.west.fxSpeed_open
				||	o.fxSpeed				// options.west.fxSpeed
				||	d.fxSpeed				// options.panes.fxSpeed
				||	null					// DEFAULT - let fxSetting.duration control speed
				;
				// create fxSettings[_open|_close|_size]
				o[sSettings] = $.extend(
					true
				,	{}
				,	fx_all					// effects.slide.all
				,	fx_pane					// effects.slide.west
				,	d.fxSettings			// options.panes.fxSettings
				,	o.fxSettings			// options.west.fxSettings
				,	d[sSettings]			// options.panes.fxSettings_open
				,	o[sSettings]			// options.west.fxSettings_open
				);
			});

			// DONE creating action-specific-settings for this pane,
			// so DELETE generic options - are no longer meaningful
			delete o.fxName;
			delete o.fxSpeed;
			delete o.fxSettings;
		}
	}

	/**
	* Initialize module objects, styling, size and position for all panes
	*
	* @see  _initElements()
	* @param {string}	pane		The pane to process
	*/
,	getPane = function (pane) {
		var sel = options[pane].paneSelector
		if (sel.substr(0,1)==="#") // ID selector
			// NOTE: elements selected 'by ID' DO NOT have to be 'children'
			return $N.find(sel).eq(0);
		else { // class or other selector
			var $P = $N.children(sel).eq(0);
			// look for the pane nested inside a 'form' element
			return $P.length ? $P : $N.children("form:first").children(sel).eq(0);
		}
	}

	/**
	* @param {Object=}		evt
	*/
,	initPanes = function (evt) {
		// stopPropagation if called by trigger("layoutinitpanes") - use evtPane utility 
		evtPane(evt);

		// NOTE: do north & south FIRST so we can measure their height - do center LAST
		$.each(_c.allPanes, function (idx, pane) {
			addPane( pane, true );
		});

		// init the pane-handles NOW in case we have to hide or close the pane below
		initHandles();

		// now that all panes have been initialized and initially-sized,
		// make sure there is really enough space available for each pane
		$.each(_c.borderPanes, function (i, pane) {
			if ($Ps[pane] && state[pane].isVisible) { // pane is OPEN
				setSizeLimits(pane);
				makePaneFit(pane); // pane may be Closed, Hidden or Resized by makePaneFit()
			}
		});
		// size center-pane AGAIN in case we 'closed' a border-pane in loop above
		sizeMidPanes("center");

		//	Chrome/Webkit sometimes fires callbacks BEFORE it completes resizing!
		//	Before RC30.3, there was a 10ms delay here, but that caused layout 
		//	to load asynchrously, which is BAD, so try skipping delay for now

		// process pane contents and callbacks, and init/resize child-layout if exists
		$.each(_c.allPanes, function (idx, pane) {
			afterInitPane(pane);
		});
	}

	/**
	* Add a pane to the layout - subroutine of initPanes()
	*
	* @see  initPanes()
	* @param {string}	pane			The pane to process
	* @param {boolean=}	[force=false]	Size content after init
	*/
,	addPane = function (pane, force) {
		if (!force && !isInitialized()) return;
		var
			o		= options[pane]
		,	s		= state[pane]
		,	c		= _c[pane]
		,	dir		= c.dir
		,	fx		= s.fx
		,	spacing	= o.spacing_open || 0
		,	isCenter = (pane === "center")
		,	CSS		= {}
		,	$P		= $Ps[pane]
		,	size, minSize, maxSize, child
		;
		// if pane-pointer already exists, remove the old one first
		if ($P)
			removePane( pane, false, true, false );
		else
			$Cs[pane] = false; // init

		$P = $Ps[pane] = getPane(pane);
		if (!$P.length) {
			$Ps[pane] = false; // logic
			return;
		}

		// SAVE original Pane CSS
		if (!$P.data("layoutCSS")) {
			var props = "position,top,left,bottom,right,width,height,overflow,zIndex,display,backgroundColor,padding,margin,border";
			$P.data("layoutCSS", styles($P, props));
		}

		// create alias for pane data in Instance - initHandles will add more
		Instance[pane] = {
			name:		pane
		,	pane:		$Ps[pane]
		,	content:	$Cs[pane]
		,	options:	options[pane]
		,	state:		state[pane]
		,	children:	children[pane]
		};

		// add classes, attributes & events
		$P	.data({
				parentLayout:	Instance		// pointer to Layout Instance
			,	layoutPane:		Instance[pane]	// NEW pointer to pane-alias-object
			,	layoutEdge:		pane
			,	layoutRole:		"pane"
			})
			.css(c.cssReq).css("zIndex", options.zIndexes.pane_normal)
			.css(o.applyDemoStyles ? c.cssDemo : {}) // demo styles
			.addClass( o.paneClass +" "+ o.paneClass+"-"+pane ) // default = "ui-layout-pane ui-layout-pane-west" - may be a dupe of 'paneSelector'
			.bind("mouseenter."+ sID, addHover )
			.bind("mouseleave."+ sID, removeHover )
			;
		var paneMethods = {
				hide:				''
			,	show:				''
			,	toggle:				''
			,	close:				''
			,	open:				''
			,	slideOpen:			''
			,	slideClose:			''
			,	slideToggle:		''
			,	size:				'sizePane'
			,	sizePane:			'sizePane'
			,	sizeContent:		''
			,	sizeHandles:		''
			,	enableClosable:		''
			,	disableClosable:	''
			,	enableSlideable:	''
			,	disableSlideable:	''
			,	enableResizable:	''
			,	disableResizable:	''
			,	swapPanes:			'swapPanes'
			,	swap:				'swapPanes'
			,	move:				'swapPanes'
			,	removePane:			'removePane'
			,	remove:				'removePane'
			,	createChildren:		''
			,	resizeChildren:		''
			,	resizeAll:			'resizeAll'
			,	resizeLayout:		'resizeAll'
			}
		,	name;
		// loop hash and bind all methods - include layoutID namespacing
		for (name in paneMethods) {
			$P.bind("layoutpane"+ name.toLowerCase() +"."+ sID, Instance[ paneMethods[name] || name ]);
		}

		// see if this pane has a 'scrolling-content element'
		initContent(pane, false); // false = do NOT sizeContent() - called later

		if (!isCenter) {
			// call _parseSize AFTER applying pane classes & styles - but before making visible (if hidden)
			// if o.size is auto or not valid, then MEASURE the pane and use that as its 'size'
			size	= s.size = _parseSize(pane, o.size);
			minSize	= _parseSize(pane,o.minSize) || 1;
			maxSize	= _parseSize(pane,o.maxSize) || 100000;
			if (size > 0) size = max(min(size, maxSize), minSize);
			s.autoResize = o.autoResize; // used with percentage sizes

			// state for border-panes
			s.isClosed  = false; // true = pane is closed
			s.isSliding = false; // true = pane is currently open by 'sliding' over adjacent panes
			s.isResizing= false; // true = pane is in process of being resized
			s.isHidden	= false; // true = pane is hidden - no spacing, resizer or toggler is visible!

			// array for 'pin buttons' whose classNames are auto-updated on pane-open/-close
			if (!s.pins) s.pins = [];
		}
		//	states common to ALL panes
		s.tagName	= $P[0].tagName;
		s.edge		= pane;		// useful if pane is (or about to be) 'swapped' - easy find out where it is (or is going)
		s.noRoom	= false;	// true = pane 'automatically' hidden due to insufficient room - will unhide automatically
		s.isVisible	= true;		// false = pane is invisible - closed OR hidden - simplify logic

		// init pane positioning
		setPanePosition( pane );

		// if pane is not visible, 
		if (dir === "horz") // north or south pane
			CSS.height = cssH($P, size);
		else if (dir === "vert") // east or west pane
			CSS.width = cssW($P, size);
		//else if (isCenter) {}

		$P.css(CSS); // apply size -- top, bottom & height will be set by sizeMidPanes
		if (dir != "horz") sizeMidPanes(pane, true); // true = skipCallback

		// if manually adding a pane AFTER layout initialization, then...
		if (state.initialized) {
			initHandles( pane );
			initHotkeys( pane );
		}

		// close or hide the pane if specified in settings
		if (o.initClosed && o.closable && !o.initHidden)
			close(pane, true, true); // true, true = force, noAnimation
		else if (o.initHidden || o.initClosed)
			hide(pane); // will be completely invisible - no resizer or spacing
		else if (!s.noRoom)
			// make the pane visible - in case was initially hidden
			$P.css("display","block");
		// ELSE setAsOpen() - called later by initHandles()

		// RESET visibility now - pane will appear IF display:block
		$P.css("visibility","visible");

		// check option for auto-handling of pop-ups & drop-downs
		if (o.showOverflowOnHover)
			$P.hover( allowOverflow, resetOverflow );

		// if manually adding a pane AFTER layout initialization, then...
		if (state.initialized) {
			afterInitPane( pane );
		}
	}

,	afterInitPane = function (pane) {
		var	$P	= $Ps[pane]
		,	s	= state[pane]
		,	o	= options[pane]
		;
		if (!$P) return;

		// see if there is a directly-nested layout inside this pane
		if ($P.data("layout"))
			refreshChildren( pane, $P.data("layout") );

		// process pane contents and callbacks, and init/resize child-layout if exists
		if (s.isVisible) { // pane is OPEN
			if (state.initialized) // this pane was added AFTER layout was created
				resizeAll(); // will also sizeContent
			else
				sizeContent(pane);

			if (o.triggerEventsOnLoad)
				_runCallbacks("onresize_end", pane);
			else // automatic if onresize called, otherwise call it specifically
				// resize child - IF inner-layout already exists (created before this layout)
				resizeChildren(pane, true); // a previously existing childLayout
		}

		// init childLayouts - even if pane is not visible
		if (o.initChildren && o.children)
			createChildren(pane);
	}

	/**
	* @param {string=}	panes		The pane(s) to process
	*/
,	setPanePosition = function (panes) {
		panes = panes ? panes.split(",") : _c.borderPanes;

		// create toggler DIVs for each pane, and set object pointers for them, eg: $R.north = north toggler DIV
		$.each(panes, function (i, pane) {
			var $P	= $Ps[pane]
			,	$R	= $Rs[pane]
			,	o	= options[pane]
			,	s	= state[pane]
			,	side =  _c[pane].side
			,	CSS	= {}
			;
			if (!$P) return; // pane does not exist - skip

			// set css-position to account for container borders & padding
			switch (pane) {
				case "north": 	CSS.top 	= sC.inset.top;
								CSS.left 	= sC.inset.left;
								CSS.right	= sC.inset.right;
								break;
				case "south": 	CSS.bottom	= sC.inset.bottom;
								CSS.left 	= sC.inset.left;
								CSS.right 	= sC.inset.right;
								break;
				case "west": 	CSS.left 	= sC.inset.left; // top, bottom & height set by sizeMidPanes()
								break;
				case "east": 	CSS.right 	= sC.inset.right; // ditto
								break;
				case "center":	// top, left, width & height set by sizeMidPanes()
			}
			// apply position
			$P.css(CSS); 

			// update resizer position
			if ($R && s.isClosed)
				$R.css(side, sC.inset[side]);
			else if ($R && !s.isHidden)
				$R.css(side, sC.inset[side] + getPaneSize(pane));
		});
	}

	/**
	* Initialize module objects, styling, size and position for all resize bars and toggler buttons
	*
	* @see  _create()
	* @param {string=}	[panes=""]	The edge(s) to process
	*/
,	initHandles = function (panes) {
		panes = panes ? panes.split(",") : _c.borderPanes;

		// create toggler DIVs for each pane, and set object pointers for them, eg: $R.north = north toggler DIV
		$.each(panes, function (i, pane) {
			var $P		= $Ps[pane];
			$Rs[pane]	= false; // INIT
			$Ts[pane]	= false;
			if (!$P) return; // pane does not exist - skip

			var 
				o		= options[pane]
			,	s		= state[pane]
			,	c		= _c[pane]
			,	paneId	= o.paneSelector.substr(0,1) === "#" ? o.paneSelector.substr(1) : ""
			,	rClass	= o.resizerClass
			,	tClass	= o.togglerClass
			,	spacing	= (s.isVisible ? o.spacing_open : o.spacing_closed)
			,	_pane	= "-"+ pane // used for classNames
			,	_state	= (s.isVisible ? "-open" : "-closed") // used for classNames
			,	I		= Instance[pane]
				// INIT RESIZER BAR
			,	$R		= I.resizer = $Rs[pane] = $("<div></div>")
				// INIT TOGGLER BUTTON
			,	$T		= I.toggler = (o.closable ? $Ts[pane] = $("<div></div>") : false)
			;

			//if (s.isVisible && o.resizable) ... handled by initResizable
			if (!s.isVisible && o.slidable)
				$R.attr("title", $textUtils.getText(infaw.portlet.I18nResources.SLIDE_OPEN)).css("cursor", o.sliderCursor);

			$R	// if paneSelector is an ID, then create a matching ID for the resizer, eg: "#paneLeft" => "paneLeft-resizer"
				.attr("id", paneId ? paneId +"-resizer" : "" )
				.data({
					parentLayout:	Instance
				,	layoutPane:		Instance[pane]	// NEW pointer to pane-alias-object
				,	layoutEdge:		pane
				,	layoutRole:		"resizer"
				})
				.css(_c.resizers.cssReq).css("zIndex", options.zIndexes.resizer_normal)
				.css(o.applyDemoStyles ? _c.resizers.cssDemo : {}) // add demo styles
				.addClass(rClass +" "+ rClass+_pane)
				.hover(addHover, removeHover) // ALWAYS add hover-classes, even if resizing is not enabled - handle with CSS instead
				.hover(onResizerEnter, onResizerLeave) // ALWAYS NEED resizer.mouseleave to balance toggler.mouseenter
				.appendTo($N) // append DIV to container
			;
			if (o.resizerDblClickToggle)
				$R.bind("dblclick."+ sID, toggle );

			if ($T) {
				$T	// if paneSelector is an ID, then create a matching ID for the resizer, eg: "#paneLeft" => "#paneLeft-toggler"
					.attr("id", paneId ? paneId +"-toggler" : "" )
					.data({
						parentLayout:	Instance
					,	layoutPane:		Instance[pane]	// NEW pointer to pane-alias-object
					,	layoutEdge:		pane
					,	layoutRole:		"toggler"
					})
					.css(_c.togglers.cssReq) // add base/required styles
					.css(o.applyDemoStyles ? _c.togglers.cssDemo : {}) // add demo styles
					.addClass(tClass +" "+ tClass+_pane)
					.hover(addHover, removeHover) // ALWAYS add hover-classes, even if toggling is not enabled - handle with CSS instead
					.bind("mouseenter", onResizerEnter) // NEED toggler.mouseenter because mouseenter MAY NOT fire on resizer
					.appendTo($R) // append SPAN to resizer DIV
				;
				// ADD INNER-SPANS TO TOGGLER
				if (o.togglerContent_open) // ui-layout-open
					$("<span>"+ o.togglerContent_open +"</span>")
						.data({
							layoutEdge:		pane
						,	layoutRole:		"togglerContent"
						})
						.data("layoutRole", "togglerContent")
						.data("layoutEdge", pane)
						.addClass("content content-open")
						.css("display","none")
						.appendTo( $T )
						//.hover( addHover, removeHover ) // use ui-layout-toggler-west-hover .content-open instead!
					;
				if (o.togglerContent_closed) // ui-layout-closed
					$("<span>"+ o.togglerContent_closed +"</span>")
						.data({
							layoutEdge:		pane
						,	layoutRole:		"togglerContent"
						})
						.addClass("content content-closed")
						.css("display","none")
						.appendTo( $T )
						//.hover( addHover, removeHover ) // use ui-layout-toggler-west-hover .content-closed instead!
					;
				// ADD TOGGLER.click/.hover
				enableClosable(pane);
			}

			// add Draggable events
			initResizable(pane);

			// ADD CLASSNAMES & SLIDE-BINDINGS - eg: class="resizer resizer-west resizer-open"
			if (s.isVisible)
				setAsOpen(pane);	// onOpen will be called, but NOT onResize
			else {
				setAsClosed(pane);	// onClose will be called
				bindStartSlidingEvents(pane, true); // will enable events IF option is set
			}

		});

		// SET ALL HANDLE DIMENSIONS
		sizeHandles();
	}


	/**
	* Initialize scrolling ui-layout-content div - if exists
	*
	* @see  initPane() - or externally after an Ajax injection
	* @param {string}	pane			The pane to process
	* @param {boolean=}	[resize=true]	Size content after init
	*/
,	initContent = function (pane, resize) {
		if (!isInitialized()) return;
		var 
			o	= options[pane]
		,	sel	= o.contentSelector
		,	I	= Instance[pane]
		,	$P	= $Ps[pane]
		,	$C
		;
		if (sel) $C = I.content = $Cs[pane] = (o.findNestedContent)
			? $P.find(sel).eq(0) // match 1-element only
			: $P.children(sel).eq(0)
		;
		if ($C && $C.length) {
			$C.data("layoutRole", "content");
			// SAVE original Content CSS
			if (!$C.data("layoutCSS"))
				$C.data("layoutCSS", styles($C, "height"));
			$C.css( _c.content.cssReq );
			if (o.applyDemoStyles) {
				$C.css( _c.content.cssDemo ); // add padding & overflow: auto to content-div
				$P.css( _c.content.cssDemoPane ); // REMOVE padding/scrolling from pane
			}
			// ensure no vertical scrollbar on pane - will mess up measurements
			if ($P.css("overflowX").match(/(scroll|auto)/)) {
				$P.css("overflow", "hidden");
			}
			state[pane].content = {}; // init content state
			if (resize !== false) sizeContent(pane);
			// sizeContent() is called AFTER init of all elements
		}
		else
			I.content = $Cs[pane] = false;
	}


	/**
	* Add resize-bars to all panes that specify it in options
	* -dependancy: $.fn.resizable - will skip if not found
	*
	* @see  _create()
	* @param {string=}	[panes=""]	The edge(s) to process
	*/
,	initResizable = function (panes) {
		var	draggingAvailable = $.layout.plugins.draggable
		,	side // set in start()
		;
		panes = panes ? panes.split(",") : _c.borderPanes;

		$.each(panes, function (idx, pane) {
			var o = options[pane];
			if (!draggingAvailable || !$Ps[pane] || !o.resizable) {
				o.resizable = false;
				return true; // skip to next
			}

			var s		= state[pane]
			,	z		= options.zIndexes
			,	c		= _c[pane]
			,	side	= c.dir=="horz" ? "top" : "left"
			,	$P 		= $Ps[pane]
			,	$R		= $Rs[pane]
			,	base	= o.resizerClass
			,	lastPos	= 0 // used when live-resizing
			,	r, live // set in start because may change
			//	'drag' classes are applied to the ORIGINAL resizer-bar while dragging is in process
			,	resizerClass		= base+"-drag"				// resizer-drag
			,	resizerPaneClass	= base+"-"+pane+"-drag"		// resizer-north-drag
			//	'helper' class is applied to the CLONED resizer-bar while it is being dragged
			,	helperClass			= base+"-dragging"			// resizer-dragging
			,	helperPaneClass		= base+"-"+pane+"-dragging" // resizer-north-dragging
			,	helperLimitClass	= base+"-dragging-limit"	// resizer-drag
			,	helperPaneLimitClass = base+"-"+pane+"-dragging-limit"	// resizer-north-drag
			,	helperClassesSet	= false 					// logic var
			;

			if (!s.isClosed)
				$R.attr("title", $textUtils.getText(infaw.portlet.I18nResources.RESIZE))
				  .css("cursor", o.resizerCursor); // n-resize, s-resize, etc

			$R.draggable({
				containment:	$N[0] // limit resizing to layout container
			,	axis:			(c.dir=="horz" ? "y" : "x") // limit resizing to horz or vert axis
			,	delay:			0
			,	distance:		1
			,	grid:			o.resizingGrid
			//	basic format for helper - style it using class: .ui-draggable-dragging
			,	helper:			"clone"
			,	opacity:		o.resizerDragOpacity
			,	addClasses:		false // avoid ui-state-disabled class when disabled
			//,	iframeFix:		o.draggableIframeFix // TODO: consider using when bug is fixed
			,	zIndex:			z.resizer_drag

			,	start: function (e, ui) {
					// REFRESH options & state pointers in case we used swapPanes
					o = options[pane];
					s = state[pane];
					// re-read options
					live = o.livePaneResizing;

					// ondrag_start callback - will CANCEL hide if returns false
					// TODO: dragging CANNOT be cancelled like this, so see if there is a way?
					if (false === _runCallbacks("ondrag_start", pane)) return false;

					s.isResizing		= true; // prevent pane from closing while resizing
					state.paneResizing	= pane; // easy to see if ANY pane is resizing
					timer.clear(pane+"_closeSlider"); // just in case already triggered

					// SET RESIZER LIMITS - used in drag()
					setSizeLimits(pane); // update pane/resizer state
					r = s.resizerPosition;
					lastPos = ui.position[ side ]

					$R.addClass( resizerClass +" "+ resizerPaneClass ); // add drag classes
					helperClassesSet = false; // reset logic var - see drag()

					// DISABLE TEXT SELECTION (probably already done by resizer.mouseOver)
					$('body').disableSelection(); 

					// MASK PANES CONTAINING IFRAMES, APPLETS OR OTHER TROUBLESOME ELEMENTS
					showMasks( pane, { resizing: true });
				}

			,	drag: function (e, ui) {
					if (!helperClassesSet) { // can only add classes after clone has been added to the DOM
						//$(".ui-draggable-dragging")
						ui.helper
							.addClass( helperClass +" "+ helperPaneClass ) // add helper classes
							.css({ right: "auto", bottom: "auto" })	// fix dir="rtl" issue
							.children().css("visibility","hidden")	// hide toggler inside dragged resizer-bar
						;
						helperClassesSet = true;
						// draggable bug!? RE-SET zIndex to prevent E/W resize-bar showing through N/S pane!
						if (s.isSliding) $Ps[pane].css("zIndex", z.pane_sliding);
					}
					// CONTAIN RESIZER-BAR TO RESIZING LIMITS
					var limit = 0;
					if (ui.position[side] < r.min) {
						ui.position[side] = r.min;
						limit = -1;
					}
					else if (ui.position[side] > r.max) {
						ui.position[side] = r.max;
						limit = 1;
					}
					// ADD/REMOVE dragging-limit CLASS
					if (limit) {
						ui.helper.addClass( helperLimitClass +" "+ helperPaneLimitClass ); // at dragging-limit
						window.defaultStatus = (limit>0 && pane.match(/(north|west)/)) || (limit<0 && pane.match(/(south|east)/)) ? $textUtils.getText(infaw.portlet.I18nResources.PANEL_HAS_REACHED_ITS_MAXIMUM_SIZE) : $textUtils.getText(infaw.portlet.I18nResources.PANEL_HAS_REACHED_ITS_MINIMUM_SIZE);
					}
					else {
						ui.helper.removeClass( helperLimitClass +" "+ helperPaneLimitClass ); // not at dragging-limit
						window.defaultStatus = "";
					}
					// DYNAMICALLY RESIZE PANES IF OPTION ENABLED
					// won't trigger unless resizer has actually moved!
					if (live && Math.abs(ui.position[side] - lastPos) >= o.liveResizingTolerance) {
						lastPos = ui.position[side];
						resizePanes(e, ui, pane)
					}
				}

			,	stop: function (e, ui) {
					$('body').enableSelection(); // RE-ENABLE TEXT SELECTION
					window.defaultStatus = ""; // clear 'resizing limit' message from statusbar
					$R.removeClass( resizerClass +" "+ resizerPaneClass ); // remove drag classes from Resizer
					s.isResizing		= false;
					state.paneResizing	= false; // easy to see if ANY pane is resizing
					resizePanes(e, ui, pane, true); // true = resizingDone
				}

			});
		});

		/**
		* resizePanes
		*
		* Sub-routine called from stop() - and drag() if livePaneResizing
		*
		* @param {!Object}		evt
		* @param {!Object}		ui
		* @param {string}		pane
		* @param {boolean=}		[resizingDone=false]
		*/
		var resizePanes = function (evt, ui, pane, resizingDone) {
			var	dragPos	= ui.position
			,	c		= _c[pane]
			,	o		= options[pane]
			,	s		= state[pane]
			,	resizerPos
			;
			switch (pane) {
				case "north":	resizerPos = dragPos.top; break;
				case "west":	resizerPos = dragPos.left; break;
				case "south":	resizerPos = sC.layoutHeight - dragPos.top  - o.spacing_open; break;
				case "east":	resizerPos = sC.layoutWidth  - dragPos.left - o.spacing_open; break;
			};
			// remove container margin from resizer position to get the pane size
			var newSize = resizerPos - sC.inset[c.side];

			// Disable OR Resize Mask(s) created in drag.start
			if (!resizingDone) {
				// ensure we meet liveResizingTolerance criteria
				if (Math.abs(newSize - s.size) < o.liveResizingTolerance)
					return; // SKIP resize this time
				// resize the pane
				manualSizePane(pane, newSize, false, true); // true = noAnimation
				sizeMasks(); // resize all visible masks
			}
			else { // resizingDone
				// ondrag_end callback
				if (false !== _runCallbacks("ondrag_end", pane))
					manualSizePane(pane, newSize, false, true); // true = noAnimation
				hideMasks(true); // true = force hiding all masks even if one is 'sliding'
				if (s.isSliding) // RE-SHOW 'object-masks' so objects won't show through sliding pane
					showMasks( pane, { resizing: true });
			}
		};
	}

	/**
	*	sizeMask
	*
	*	Needed to overlay a DIV over an IFRAME-pane because mask CANNOT be *inside* the pane
	*	Called when mask created, and during livePaneResizing
	*/
,	sizeMask = function () {
		var $M		= $(this)
		,	pane	= $M.data("layoutMask") // eg: "west"
		,	s		= state[pane]
		;
		// only masks over an IFRAME-pane need manual resizing
		if (s.tagName == "IFRAME" && s.isVisible) // no need to mask closed/hidden panes
			$M.css({
				top:	s.offsetTop
			,	left:	s.offsetLeft
			,	width:	s.outerWidth
			,	height:	s.outerHeight
			});
		/* ALT Method...
		var $P = $Ps[pane];
		$M.css( $P.position() ).css({ width: $P[0].offsetWidth, height: $P[0].offsetHeight });
		*/
	}
,	sizeMasks = function () {
		$Ms.each( sizeMask ); // resize all 'visible' masks
	}

	/**
	* @param {string}	pane		The pane being resized, animated or isSliding
	* @param {Object=}	[args]		(optional) Options: which masks to apply, and to which panes
	*/
,	showMasks = function (pane, args) {
		var	c		= _c[pane]
		,	panes	=  ["center"]
		,	z		= options.zIndexes
		,	a		= $.extend({
						objectsOnly:	false
					,	animation:		false
					,	resizing:		true
					,	sliding:		state[pane].isSliding
					},	args )
		,	o, s
		;
		if (a.resizing)
			panes.push( pane );
		if (a.sliding)
			panes.push( _c.oppositeEdge[pane] ); // ADD the oppositeEdge-pane

		if (c.dir === "horz") {
			panes.push("west");
			panes.push("east");
		}

		$.each(panes, function(i,p){
			s = state[p];
			o = options[p];
			if (s.isVisible && ( o.maskObjects || (!a.objectsOnly && o.maskContents) )) {
				getMasks(p).each(function(){
					sizeMask.call(this);
					this.style.zIndex = s.isSliding ? z.pane_sliding+1 : z.pane_normal+1
					this.style.display = "block";
				});
			}
		});
	}

	/**
	* @param {boolean=}	force		Hide masks even if a pane is sliding
	*/
,	hideMasks = function (force) {
		// ensure no pane is resizing - could be a timing issue
		if (force || !state.paneResizing) {
			$Ms.hide(); // hide ALL masks
		}
		// if ANY pane is sliding, then DO NOT remove masks from panes with maskObjects enabled
		else if (!force && !$.isEmptyObject( state.panesSliding )) {
			var	i = $Ms.length - 1
			,	p, $M;
			for (; i >= 0; i--) {
				$M	= $Ms.eq(i);
				p	= $M.data("layoutMask");
				if (!options[p].maskObjects) {
					$M.hide();
				}
			}
		}
	}

	/**
	* @param {string}	pane
	*/
,	getMasks = function (pane) {
		var $Masks	= $([])
		,	$M, i = 0, c = $Ms.length
		;
		for (; i<c; i++) {
			$M = $Ms.eq(i);
			if ($M.data("layoutMask") === pane)
				$Masks = $Masks.add( $M );
		}
		if ($Masks.length)
			return $Masks;
		else
			return createMasks(pane);
	}

	/**
	* createMasks
	*
	* Generates both DIV (ALWAYS used) and IFRAME (optional) elements as masks
	* An IFRAME mask is created *under* the DIV when maskObjects=true, because a DIV cannot mask an applet
	*
	* @param {string}	pane
	*/
,	createMasks = function (pane) {
		var
			$P		= $Ps[pane]
		,	s		= state[pane]
		,	o		= options[pane]
		,	z		= options.zIndexes
		//,	objMask	= o.maskObjects && s.tagName != "IFRAME" // check for option
		,	$Masks	= $([])
		,	isIframe, el, $M, css, i
		;
		if (!o.maskContents && !o.maskObjects) return $Masks;
		// if o.maskObjects=true, then loop TWICE to create BOTH kinds of mask, else only create a DIV
		for (i=0; i < (o.maskObjects ? 2 : 1); i++) {
			isIframe = o.maskObjects && i==0;
			el = document.createElement( isIframe ? "iframe" : "div" );
			$M = $(el).data("layoutMask", pane); // add data to relate mask to pane
			el.className = "ui-layout-mask ui-layout-mask-"+ pane; // for user styling
			css = el.style;
			// styles common to both DIVs and IFRAMES
			css.display		= "block";
			css.position	= "absolute";
			css.background	= "#FFF";
			if (isIframe) { // IFRAME-only props
				el.frameborder = 0;
				el.src		= "about:blank";
				//el.allowTransparency = true; - for IE, but breaks masking ability!
				css.opacity	= 0;
				css.filter	= "Alpha(Opacity='0')";
				css.border	= 0;
			}
			// if pane is an IFRAME, then must mask the pane itself
			if (s.tagName == "IFRAME") {
				// NOTE sizing done by a subroutine so can be called during live-resizing
				css.zIndex	= z.pane_normal+1; // 1-higher than pane
				$N.append( el ); // append to LAYOUT CONTAINER
			}
			// otherwise put masks *inside the pane* to mask its contents
			else {
				$M.addClass("ui-layout-mask-inside-pane");
				css.zIndex	= o.maskZindex || z.content_mask; // usually 1, but customizable
				css.top		= 0;
				css.left	= 0;
				css.width	= "100%";
				css.height	= "100%";
				$P.append( el ); // append INSIDE pane element
			}
			// add to return object
			$Masks = $Masks.add( el );
			// add Mask to cached array so can be resized & reused
			$Ms = $Ms.add( el );
		}
		return $Masks;
	}


	/**
	* Destroy this layout and reset all elements
	*
	* @param {boolean=}	[destroyChildren=false]		Destory Child-Layouts first?
	*/
,	destroy = function (evt_or_destroyChildren, destroyChildren) {
		// UNBIND layout events and remove global object
		$(window).unbind("."+ sID);		// resize & unload
		$(document).unbind("."+ sID);	// keyDown (hotkeys)

		if (typeof evt_or_destroyChildren === "object")
			// stopPropagation if called by trigger("layoutdestroy") - use evtPane utility 
			evtPane(evt_or_destroyChildren);
		else // no event, so transfer 1st param to destroyChildren param
			destroyChildren = evt_or_destroyChildren;

		// need to look for parent layout BEFORE we remove the container data, else skips a level
		//var parentPane = Instance.hasParentLayout ? $.layout.getParentPaneInstance( $N ) : null;

		// reset layout-container
		$N	.clearQueue()
			.removeData("layout")
			.removeData("layoutContainer")
			.removeClass(options.containerClass)
			.unbind("."+ sID) // remove ALL Layout events
		;

		// remove all mask elements that have been created
		$Ms.remove();

		// loop all panes to remove layout classes, attributes and bindings
		$.each(_c.allPanes, function (i, pane) {
			removePane( pane, false, true, destroyChildren ); // true = skipResize
		});

		// do NOT reset container CSS if is a 'pane' (or 'content') in an outer-layout - ie, THIS layout is 'nested'
		var css = "layoutCSS";
		if ($N.data(css) && !$N.data("layoutRole")) // RESET CSS
			$N.css( $N.data(css) ).removeData(css);

		// for full-page layouts, also reset the <HTML> CSS
		if (sC.tagName === "BODY" && ($N = $("html")).data(css)) // RESET <HTML> CSS
			$N.css( $N.data(css) ).removeData(css);

		// trigger plugins for this layout, if there are any
		runPluginCallbacks( Instance, $.layout.onDestroy );

		// trigger state-management and onunload callback
		unload();

		// clear the Instance of everything except for container & options (so could recreate)
		// RE-CREATE: myLayout = myLayout.container.layout( myLayout.options );
		for (var n in Instance)
			if (!n.match(/^(container|options)$/)) delete Instance[ n ];
		// add a 'destroyed' flag to make it easy to check
		Instance.destroyed = true;

		// if this is a child layout, CLEAR the child-pointer in the parent
		/* for now the pointer REMAINS, but with only container, options and destroyed keys
		if (parentPane) {
			var layout	= parentPane.pane.data("parentLayout")
			,	key		= layout.options.instanceKey || 'error';
			// THIS SYNTAX MAY BE WRONG!
			parentPane.children[key] = layout.children[ parentPane.name ].children[key] = null;
		}
		*/

		return Instance; // for coding convenience
	}

	/**
	* Remove a pane from the layout - subroutine of destroy()
	*
	* @see  destroy()
	* @param {(string|Object)}	evt_or_pane			The pane to process
	* @param {boolean=}			[remove=false]		Remove the DOM element?
	* @param {boolean=}			[skipResize=false]	Skip calling resizeAll()?
	* @param {boolean=}			[destroyChild=true]	Destroy Child-layouts? If not passed, obeys options setting
	*/
,	removePane = function (evt_or_pane, remove, skipResize, destroyChild) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$P	= $Ps[pane]
		,	$C	= $Cs[pane]
		,	$R	= $Rs[pane]
		,	$T	= $Ts[pane]
		;
		// NOTE: elements can still exist even after remove()
		//		so check for missing data(), which is cleared by removed()
		if ($P && $.isEmptyObject( $P.data() )) $P = false;
		if ($C && $.isEmptyObject( $C.data() )) $C = false;
		if ($R && $.isEmptyObject( $R.data() )) $R = false;
		if ($T && $.isEmptyObject( $T.data() )) $T = false;

		if ($P) $P.stop(true, true);

		var	o	= options[pane]
		,	s	= state[pane]
		,	d	= "layout"
		,	css	= "layoutCSS"
		,	pC	= children[pane]
		,	hasChildren	= $.isPlainObject( pC ) && !$.isEmptyObject( pC )
		,	destroy		= destroyChild !== undefined ? destroyChild : o.destroyChildren
		;
		// FIRST destroy the child-layout(s)
		if (hasChildren && destroy) {
			$.each( pC, function (key, child) {
				if (!child.destroyed)
					child.destroy(true);// tell child-layout to destroy ALL its child-layouts too
				if (child.destroyed)	// destroy was successful
					delete pC[key];
			});
			// if no more children, remove the children hash
			if ($.isEmptyObject( pC )) {
				pC = children[pane] = null; // clear children hash
				hasChildren = false;
			}
		}

		// Note: can't 'remove' a pane element with non-destroyed children
		if ($P && remove && !hasChildren)
			$P.remove(); // remove the pane-element and everything inside it
		else if ($P && $P[0]) {
			//	create list of ALL pane-classes that need to be removed
			var	root	= o.paneClass // default="ui-layout-pane"
			,	pRoot	= root +"-"+ pane // eg: "ui-layout-pane-west"
			,	_open	= "-open"
			,	_sliding= "-sliding"
			,	_closed	= "-closed"
			,	classes	= [	root, root+_open, root+_closed, root+_sliding,		// generic classes
							pRoot, pRoot+_open, pRoot+_closed, pRoot+_sliding ]	// pane-specific classes
			;
			$.merge(classes, getHoverClasses($P, true)); // ADD hover-classes
			// remove all Layout classes from pane-element
			$P	.removeClass( classes.join(" ") ) // remove ALL pane-classes
				.removeData("parentLayout")
				.removeData("layoutPane")
				.removeData("layoutRole")
				.removeData("layoutEdge")
				.removeData("autoHidden")	// in case set
				.unbind("."+ sID) // remove ALL Layout events
				// TODO: remove these extra unbind commands when jQuery is fixed
				//.unbind("mouseenter"+ sID)
				//.unbind("mouseleave"+ sID)
			;
			// do NOT reset CSS if this pane/content is STILL the container of a nested layout!
			// the nested layout will reset its 'container' CSS when/if it is destroyed
			if (hasChildren && $C) {
				// a content-div may not have a specific width, so give it one to contain the Layout
				$C.width( $C.width() );
				$.each( pC, function (key, child) {
					child.resizeAll(); // resize the Layout
				});
			}
			else if ($C)
				$C.css( $C.data(css) ).removeData(css).removeData("layoutRole");
			// remove pane AFTER content in case there was a nested layout
			if (!$P.data(d))
				$P.css( $P.data(css) ).removeData(css);
		}

		// REMOVE pane resizer and toggler elements
		if ($T) $T.remove();
		if ($R) $R.remove();

		// CLEAR all pointers and state data
		Instance[pane] = $Ps[pane] = $Cs[pane] = $Rs[pane] = $Ts[pane] = false;
		s = { removed: true };

		if (!skipResize)
			resizeAll();
	}


/*
 * ###########################
 *	   ACTION METHODS
 * ###########################
 */

	/**
	* @param {string}	pane
	*/
,	_hidePane = function (pane) {
		var $P	= $Ps[pane]
		,	o	= options[pane]
		,	s	= $P[0].style
		;
		if (o.useOffscreenClose) {
			if (!$P.data(_c.offscreenReset))
				$P.data(_c.offscreenReset, { left: s.left, right: s.right });
			$P.css( _c.offscreenCSS );
		}
		else
			$P.hide().removeData(_c.offscreenReset);
	}

	/**
	* @param {string}	pane
	*/
,	_showPane = function (pane) {
		var $P	= $Ps[pane]
		,	o	= options[pane]
		,	off	= _c.offscreenCSS
		,	old	= $P.data(_c.offscreenReset)
		,	s	= $P[0].style
		;
		$P	.show() // ALWAYS show, just in case
			.removeData(_c.offscreenReset);
		if (o.useOffscreenClose && old) {
			if (s.left == off.left)
				s.left = old.left;
			if (s.right == off.right)
				s.right = old.right;
		}
	}


	/**
	* Completely 'hides' a pane, including its spacing - as if it does not exist
	* The pane is not actually 'removed' from the source, so can use 'show' to un-hide it
	*
	* @param {(string|Object)}	evt_or_pane			The pane being hidden, ie: north, south, east, or west
	* @param {boolean=}			[noAnimation=false]	
	*/
,	hide = function (evt_or_pane, noAnimation) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	o	= options[pane]
		,	s	= state[pane]
		,	$P	= $Ps[pane]
		,	$R	= $Rs[pane]
		;
		if (!$P || s.isHidden) return; // pane does not exist OR is already hidden

		// onhide_start callback - will CANCEL hide if returns false
		if (state.initialized && false === _runCallbacks("onhide_start", pane)) return;

		s.isSliding = false; // just in case
		delete state.panesSliding[pane];

		// now hide the elements
		if ($R) $R.hide(); // hide resizer-bar
		if (!state.initialized || s.isClosed) {
			s.isClosed = true; // to trigger open-animation on show()
			s.isHidden  = true;
			s.isVisible = false;
			if (!state.initialized)
				_hidePane(pane); // no animation when loading page
			sizeMidPanes(_c[pane].dir === "horz" ? "" : "center");
			if (state.initialized || o.triggerEventsOnLoad)
				_runCallbacks("onhide_end", pane);
		}
		else {
			s.isHiding = true; // used by onclose
			close(pane, false, noAnimation); // adjust all panes to fit
		}
	}

	/**
	* Show a hidden pane - show as 'closed' by default unless openPane = true
	*
	* @param {(string|Object)}	evt_or_pane			The pane being opened, ie: north, south, east, or west
	* @param {boolean=}			[openPane=false]
	* @param {boolean=}			[noAnimation=false]
	* @param {boolean=}			[noAlert=false]
	*/
,	show = function (evt_or_pane, openPane, noAnimation, noAlert) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	o	= options[pane]
		,	s	= state[pane]
		,	$P	= $Ps[pane]
		,	$R	= $Rs[pane]
		;
		if (!$P || !s.isHidden) return; // pane does not exist OR is not hidden

		// onshow_start callback - will CANCEL show if returns false
		if (false === _runCallbacks("onshow_start", pane)) return;

		s.isShowing = true; // used by onopen/onclose
		//s.isHidden  = false; - will be set by open/close - if not cancelled
		s.isSliding = false; // just in case
		delete state.panesSliding[pane];

		// now show the elements
		//if ($R) $R.show(); - will be shown by open/close
		if (openPane === false)
			close(pane, true); // true = force
		else
			open(pane, false, noAnimation, noAlert); // adjust all panes to fit
	}


	/**
	* Toggles a pane open/closed by calling either open or close
	*
	* @param {(string|Object)}	evt_or_pane		The pane being toggled, ie: north, south, east, or west
	* @param {boolean=}			[slide=false]
	*/
,	toggle = function (evt_or_pane, slide) {
		if (!isInitialized()) return;
		var	evt		= evtObj(evt_or_pane)
		,	pane	= evtPane.call(this, evt_or_pane)
		,	s		= state[pane]
		;
		if (evt) // called from to $R.dblclick OR triggerPaneEvent
			evt.stopImmediatePropagation();
		if (s.isHidden)
			show(pane); // will call 'open' after unhiding it
		else if (s.isClosed)
			open(pane, !!slide);
		else
			close(pane);
	}


	/**
	* Utility method used during init or other auto-processes
	*
	* @param {string}	pane   The pane being closed
	* @param {boolean=}	[setHandles=false]
	*/
,	_closePane = function (pane, setHandles) {
		var
			$P	= $Ps[pane]
		,	s	= state[pane]
		;
		_hidePane(pane);
		s.isClosed = true;
		s.isVisible = false;
		// UNUSED: if (setHandles) setAsClosed(pane, true); // true = force
	}

	/**
	* Close the specified pane (animation optional), and resize all other panes as needed
	*
	* @param {(string|Object)}	evt_or_pane			The pane being closed, ie: north, south, east, or west
	* @param {boolean=}			[force=false]
	* @param {boolean=}			[noAnimation=false]
	* @param {boolean=}			[skipCallback=false]
	*/
,	close = function (evt_or_pane, force, noAnimation, skipCallback) {
		var	pane = evtPane.call(this, evt_or_pane);
		// if pane has been initialized, but NOT the complete layout, close pane instantly
		if (!state.initialized && $Ps[pane]) {
			_closePane(pane); // INIT pane as closed
			return;
		}
		if (!isInitialized()) return;

		var
			$P	= $Ps[pane]
		,	$R	= $Rs[pane]
		,	$T	= $Ts[pane]
		,	o	= options[pane]
		,	s	= state[pane]
		,	c	= _c[pane]
		,	doFX, isShowing, isHiding, wasSliding;

		// QUEUE in case another action/animation is in progress
		$N.queue(function( queueNext ){

			if ( !$P
			||	(!o.closable && !s.isShowing && !s.isHiding)	// invalid request // (!o.resizable && !o.closable) ???
			||	(!force && s.isClosed && !s.isShowing)			// already closed
			) return queueNext();

			// onclose_start callback - will CANCEL hide if returns false
			// SKIP if just 'showing' a hidden pane as 'closed'
			var abort = !s.isShowing && false === _runCallbacks("onclose_start", pane);

			// transfer logic vars to temp vars
			isShowing	= s.isShowing;
			isHiding	= s.isHiding;
			wasSliding	= s.isSliding;
			// now clear the logic vars (REQUIRED before aborting)
			delete s.isShowing;
			delete s.isHiding;

			if (abort) return queueNext();

			doFX		= !noAnimation && !s.isClosed && (o.fxName_close != "none");
			s.isMoving	= true;
			s.isClosed	= true;
			s.isVisible	= false;
			// update isHidden BEFORE sizing panes
			if (isHiding) s.isHidden = true;
			else if (isShowing) s.isHidden = false;

			if (s.isSliding) // pane is being closed, so UNBIND trigger events
				bindStopSlidingEvents(pane, false); // will set isSliding=false
			else // resize panes adjacent to this one
				sizeMidPanes(_c[pane].dir === "horz" ? "" : "center", false); // false = NOT skipCallback

			// if this pane has a resizer bar, move it NOW - before animation
			setAsClosed(pane);

			// CLOSE THE PANE
			if (doFX) { // animate the close
				lockPaneForFX(pane, true);	// need to set left/top so animation will work
				$P.hide( o.fxName_close, o.fxSettings_close, o.fxSpeed_close, function () {
					lockPaneForFX(pane, false); // undo
					if (s.isClosed) close_2();
					queueNext();
				});
			}
			else { // hide the pane without animation
				_hidePane(pane);
				close_2();
				queueNext();
			};
		});

		// SUBROUTINE
		function close_2 () {
			s.isMoving	= false;
			bindStartSlidingEvents(pane, true); // will enable if o.slidable = true

			// if opposite-pane was autoClosed, see if it can be autoOpened now
			var altPane = _c.oppositeEdge[pane];
			if (state[ altPane ].noRoom) {
				setSizeLimits( altPane );
				makePaneFit( altPane );
			}

			if (!skipCallback && (state.initialized || o.triggerEventsOnLoad)) {
				// onclose callback - UNLESS just 'showing' a hidden pane as 'closed'
				if (!isShowing)	_runCallbacks("onclose_end", pane);
				// onhide OR onshow callback
				if (isShowing)	_runCallbacks("onshow_end", pane);
				if (isHiding)	_runCallbacks("onhide_end", pane);
			}
		}
	}

	/**
	* @param {string}	pane	The pane just closed, ie: north, south, east, or west
	*/
,	setAsClosed = function (pane) {
		var
			$P		= $Ps[pane]
		,	$R		= $Rs[pane]
		,	$T		= $Ts[pane]
		,	o		= options[pane]
		,	s		= state[pane]
		,	side	= _c[pane].side
		,	rClass	= o.resizerClass
		,	tClass	= o.togglerClass
		,	_pane	= "-"+ pane // used for classNames
		,	_open	= "-open"
		,	_sliding= "-sliding"
		,	_closed	= "-closed"
		;
		$R
			.css(side, sC.inset[side]) // move the resizer
			.removeClass( rClass+_open +" "+ rClass+_pane+_open )
			.removeClass( rClass+_sliding +" "+ rClass+_pane+_sliding )
			.addClass( rClass+_closed +" "+ rClass+_pane+_closed )
		;
		// DISABLE 'resizing' when closed - do this BEFORE bindStartSlidingEvents?
		if (o.resizable && $.layout.plugins.draggable)
			$R
				.draggable("disable")
				.removeClass("ui-state-disabled") // do NOT apply disabled styling - not suitable here
				.css("cursor", "default")
				.attr("title","")
			;

		// if pane has a toggler button, adjust that too
		if ($T) {
			$T
				.removeClass( tClass+_open +" "+ tClass+_pane+_open )
				.addClass( tClass+_closed +" "+ tClass+_pane+_closed )
				.attr("title", $textUtils.getText(infaw.portlet.I18nResources.OPEN)) // may be blank
			;
			// toggler-content - if exists
			$T.children(".content-open").hide();
			$T.children(".content-closed").css("display","block");
		}

		// sync any 'pin buttons'
		syncPinBtns(pane, false);

		if (state.initialized) {
			// resize 'length' and position togglers for adjacent panes
			sizeHandles();
		}
	}

	/**
	* Open the specified pane (animation optional), and resize all other panes as needed
	*
	* @param {(string|Object)}	evt_or_pane			The pane being opened, ie: north, south, east, or west
	* @param {boolean=}			[slide=false]
	* @param {boolean=}			[noAnimation=false]
	* @param {boolean=}			[noAlert=false]
	*/
,	open = function (evt_or_pane, slide, noAnimation, noAlert) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$P	= $Ps[pane]
		,	$R	= $Rs[pane]
		,	$T	= $Ts[pane]
		,	o	= options[pane]
		,	s	= state[pane]
		,	c	= _c[pane]
		,	doFX, isShowing
		;
		// QUEUE in case another action/animation is in progress
		$N.queue(function( queueNext ){

			if ( !$P
			||	(!o.resizable && !o.closable && !s.isShowing)	// invalid request
			||	(s.isVisible && !s.isSliding)					// already open
			) return queueNext();

			// pane can ALSO be unhidden by just calling show(), so handle this scenario
			if (s.isHidden && !s.isShowing) {
				queueNext(); // call before show() because it needs the queue free
				show(pane, true);
				return;
			}

			if (s.autoResize && s.size != o.size) // resize pane to original size set in options
				sizePane(pane, o.size, true, true, true); // true=skipCallback/noAnimation/forceResize
			else
				// make sure there is enough space available to open the pane
				setSizeLimits(pane, slide);

			// onopen_start callback - will CANCEL open if returns false
			var cbReturn = _runCallbacks("onopen_start", pane);

			if (cbReturn === "abort")
				return queueNext();

			// update pane-state again in case options were changed in onopen_start
			if (cbReturn !== "NC") // NC = "No Callback"
				setSizeLimits(pane, slide);

			if (s.minSize > s.maxSize) { // INSUFFICIENT ROOM FOR PANE TO OPEN!
				syncPinBtns(pane, false); // make sure pin-buttons are reset
				if (!noAlert && $textUtils.getText(infaw.portlet.I18nResources.NOT_ENOUGH_ROOM_TO_SHOW_THIS_PANEL))
					alert($textUtils.getText(infaw.portlet.I18nResources.NOT_ENOUGH_ROOM_TO_SHOW_THIS_PANEL));
				return queueNext(); // ABORT
			}

			if (slide) // START Sliding - will set isSliding=true
				bindStopSlidingEvents(pane, true); // BIND trigger events to close sliding-pane
			else if (s.isSliding) // PIN PANE (stop sliding) - open pane 'normally' instead
				bindStopSlidingEvents(pane, false); // UNBIND trigger events - will set isSliding=false
			else if (o.slidable)
				bindStartSlidingEvents(pane, false); // UNBIND trigger events

			s.noRoom = false; // will be reset by makePaneFit if 'noRoom'
			makePaneFit(pane);

			// transfer logic var to temp var
			isShowing = s.isShowing;
			// now clear the logic var
			delete s.isShowing;

			doFX		= !noAnimation && s.isClosed && (o.fxName_open != "none");
			s.isMoving	= true;
			s.isVisible	= true;
			s.isClosed	= false;
			// update isHidden BEFORE sizing panes - WHY??? Old?
			if (isShowing) s.isHidden = false;

			if (doFX) { // ANIMATE
				// mask adjacent panes with objects
				lockPaneForFX(pane, true);	// need to set left/top so animation will work
					$P.show( o.fxName_open, o.fxSettings_open, o.fxSpeed_open, function() {
					lockPaneForFX(pane, false); // undo
					if (s.isVisible) open_2(); // continue
					queueNext();
				});
			}
			else { // no animation
				_showPane(pane);// just show pane and...
				open_2();		// continue
				queueNext();
			};
		});

		// SUBROUTINE
		function open_2 () {
			s.isMoving	= false;

			// cure iframe display issues
			_fixIframe(pane);

			// NOTE: if isSliding, then other panes are NOT 'resized'
			if (!s.isSliding) { // resize all panes adjacent to this one
				sizeMidPanes(_c[pane].dir=="vert" ? "center" : "", false); // false = NOT skipCallback
			}

			// set classes, position handles and execute callbacks...
			setAsOpen(pane);
		};
	
	}

	/**
	* @param {string}	pane		The pane just opened, ie: north, south, east, or west
	* @param {boolean=}	[skipCallback=false]
	*/
,	setAsOpen = function (pane, skipCallback) {
		var 
			$P		= $Ps[pane]
		,	$R		= $Rs[pane]
		,	$T		= $Ts[pane]
		,	o		= options[pane]
		,	s		= state[pane]
		,	side	= _c[pane].side
		,	rClass	= o.resizerClass
		,	tClass	= o.togglerClass
		,	_pane	= "-"+ pane // used for classNames
		,	_open	= "-open"
		,	_closed	= "-closed"
		,	_sliding= "-sliding"
		;
		$R
			.css(side, sC.inset[side] + getPaneSize(pane)) // move the resizer
			.removeClass( rClass+_closed +" "+ rClass+_pane+_closed )
			.addClass( rClass+_open +" "+ rClass+_pane+_open )
		;
		if (s.isSliding)
			$R.addClass( rClass+_sliding +" "+ rClass+_pane+_sliding )
		else // in case 'was sliding'
			$R.removeClass( rClass+_sliding +" "+ rClass+_pane+_sliding )

		removeHover( 0, $R ); // remove hover classes
		if (o.resizable && $.layout.plugins.draggable)
			$R	.draggable("enable")
				.css("cursor", o.resizerCursor)
				.attr("title", $textUtils.getText(infaw.portlet.I18nResources.RESIZE));
		else if (!s.isSliding)
			$R.css("cursor", "default"); // n-resize, s-resize, etc

		// if pane also has a toggler button, adjust that too
		if ($T) {
			$T	.removeClass( tClass+_closed +" "+ tClass+_pane+_closed )
				.addClass( tClass+_open +" "+ tClass+_pane+_open )
				.attr("title", $textUtils.getText(infaw.portlet.I18nResources.CLOSE)); // may be blank
			removeHover( 0, $T ); // remove hover classes
			// toggler-content - if exists
			$T.children(".content-closed").hide();
			$T.children(".content-open").css("display","block");
		}

		// sync any 'pin buttons'
		syncPinBtns(pane, !s.isSliding);

		// update pane-state dimensions - BEFORE resizing content
		$.extend(s, elDims($P));

		if (state.initialized) {
			// resize resizer & toggler sizes for all panes
			sizeHandles();
			// resize content every time pane opens - to be sure
			sizeContent(pane, true); // true = remeasure headers/footers, even if 'pane.isMoving'
		}

		if (!skipCallback && (state.initialized || o.triggerEventsOnLoad) && $P.is(":visible")) {
			// onopen callback
			_runCallbacks("onopen_end", pane);
			// onshow callback - TODO: should this be here?
			if (s.isShowing) _runCallbacks("onshow_end", pane);

			// ALSO call onresize because layout-size *may* have changed while pane was closed
			if (state.initialized)
				_runCallbacks("onresize_end", pane);
		}

		// TODO: Somehow sizePane("north") is being called after this point???
	}


	/**
	* slideOpen / slideClose / slideToggle
	*
	* Pass-though methods for sliding
	*/
,	slideOpen = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	evt		= evtObj(evt_or_pane)
		,	pane	= evtPane.call(this, evt_or_pane)
		,	s		= state[pane]
		,	delay	= options[pane].slideDelay_open
		;
		// prevent event from triggering on NEW resizer binding created below
		if (evt) evt.stopImmediatePropagation();

		if (s.isClosed && evt && evt.type === "mouseenter" && delay > 0)
			// trigger = mouseenter - use a delay
			timer.set(pane+"_openSlider", open_NOW, delay);
		else
			open_NOW(); // will unbind events if is already open

		/**
		* SUBROUTINE for timed open
		*/
		function open_NOW () {
			if (!s.isClosed) // skip if no longer closed!
				bindStopSlidingEvents(pane, true); // BIND trigger events to close sliding-pane
			else if (!s.isMoving)
				open(pane, true); // true = slide - open() will handle binding
		};
	}

,	slideClose = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	evt		= evtObj(evt_or_pane)
		,	pane	= evtPane.call(this, evt_or_pane)
		,	o		= options[pane]
		,	s		= state[pane]
		,	delay	= s.isMoving ? 1000 : 300 // MINIMUM delay - option may override
		;
		if (s.isClosed || s.isResizing)
			return; // skip if already closed OR in process of resizing
		else if (o.slideTrigger_close === "click")
			close_NOW(); // close immediately onClick
		else if (o.preventQuickSlideClose && s.isMoving)
			return; // handle Chrome quick-close on slide-open
		else if (o.preventPrematureSlideClose && evt && $.layout.isMouseOverElem(evt, $Ps[pane]))
			return; // handle incorrect mouseleave trigger, like when over a SELECT-list in IE
		else if (evt) // trigger = mouseleave - use a delay
			// 1 sec delay if 'opening', else .3 sec
			timer.set(pane+"_closeSlider", close_NOW, max(o.slideDelay_close, delay));
		else // called programically
			close_NOW();

		/**
		* SUBROUTINE for timed close
		*/
		function close_NOW () {
			if (s.isClosed) // skip 'close' if already closed!
				bindStopSlidingEvents(pane, false); // UNBIND trigger events - TODO: is this needed here?
			else if (!s.isMoving)
				close(pane); // close will handle unbinding
		};
	}

	/**
	* @param {(string|Object)}	evt_or_pane		The pane being opened, ie: north, south, east, or west
	*/
,	slideToggle = function (evt_or_pane) {
		var pane = evtPane.call(this, evt_or_pane);
		toggle(pane, true);
	}


	/**
	* Must set left/top on East/South panes so animation will work properly
	*
	* @param {string}	pane	The pane to lock, 'east' or 'south' - any other is ignored!
	* @param {boolean}	doLock  true = set left/top, false = remove
	*/
,	lockPaneForFX = function (pane, doLock) {
		var $P	= $Ps[pane]
		,	s	= state[pane]
		,	o	= options[pane]
		,	z	= options.zIndexes
		;
		if (doLock) {
			showMasks( pane, { animation: true, objectsOnly: true });
			$P.css({ zIndex: z.pane_animate }); // overlay all elements during animation
			if (pane=="south")
				$P.css({ top: sC.inset.top + sC.innerHeight - $P.outerHeight() });
			else if (pane=="east")
				$P.css({ left: sC.inset.left + sC.innerWidth - $P.outerWidth() });
		}
		else { // animation DONE - RESET CSS
			hideMasks();
			$P.css({ zIndex: (s.isSliding ? z.pane_sliding : z.pane_normal) });
			if (pane=="south")
				$P.css({ top: "auto" });
			// if pane is positioned 'off-screen', then DO NOT screw with it!
			else if (pane=="east" && !$P.css("left").match(/\-99999/))
				$P.css({ left: "auto" });
			// fix anti-aliasing in IE - only needed for animations that change opacity
			if (browser.msie && o.fxOpacityFix && o.fxName_open != "slide" && $P.css("filter") && $P.css("opacity") == 1)
				$P[0].style.removeAttribute('filter');
		}
	}


	/**
	* Toggle sliding functionality of a specific pane on/off by adding removing 'slide open' trigger
	*
	* @see  open(), close()
	* @param {string}	pane	The pane to enable/disable, 'north', 'south', etc.
	* @param {boolean}	enable	Enable or Disable sliding?
	*/
,	bindStartSlidingEvents = function (pane, enable) {
		var o		= options[pane]
		,	$P		= $Ps[pane]
		,	$R		= $Rs[pane]
		,	evtName	= o.slideTrigger_open.toLowerCase()
		;
		if (!$R || (enable && !o.slidable)) return;

		// make sure we have a valid event
		if (evtName.match(/mouseover/))
			evtName = o.slideTrigger_open = "mouseenter";
		else if (!evtName.match(/(click|dblclick|mouseenter)/)) 
			evtName = o.slideTrigger_open = "click";

		// must remove double-click-toggle when using dblclick-slide
		if (o.resizerDblClickToggle && evtName.match(/click/)) {
			$R[enable ? "unbind" : "bind"]('dblclick.'+ sID, toggle)
		}

		$R
			// add or remove event
			[enable ? "bind" : "unbind"](evtName +'.'+ sID, slideOpen)
			// set the appropriate cursor & title/tip
			.css("cursor", enable ? o.sliderCursor : "default")
			.attr("title", enable ? $textUtils.getText(infaw.portlet.I18nResources.SLIDE_OPEN) : "")
		;
	}

	/**
	* Add or remove 'mouseleave' events to 'slide close' when pane is 'sliding' open or closed
	* Also increases zIndex when pane is sliding open
	* See bindStartSlidingEvents for code to control 'slide open'
	*
	* @see  slideOpen(), slideClose()
	* @param {string}	pane	The pane to process, 'north', 'south', etc.
	* @param {boolean}	enable	Enable or Disable events?
	*/
,	bindStopSlidingEvents = function (pane, enable) {
		var	o		= options[pane]
		,	s		= state[pane]
		,	c		= _c[pane]
		,	z		= options.zIndexes
		,	evtName	= o.slideTrigger_close.toLowerCase()
		,	action	= (enable ? "bind" : "unbind")
		,	$P		= $Ps[pane]
		,	$R		= $Rs[pane]
		;
		timer.clear(pane+"_closeSlider"); // just in case

		if (enable) {
			s.isSliding = true;
			state.panesSliding[pane] = true;
			// remove 'slideOpen' event from resizer
			// ALSO will raise the zIndex of the pane & resizer
			bindStartSlidingEvents(pane, false);
		}
		else {
			s.isSliding = false;
			delete state.panesSliding[pane];
		}

		// RE/SET zIndex - increases when pane is sliding-open, resets to normal when not
		$P.css("zIndex", enable ? z.pane_sliding : z.pane_normal);
		$R.css("zIndex", enable ? z.pane_sliding+2 : z.resizer_normal); // NOTE: mask = pane_sliding+1

		// make sure we have a valid event
		if (!evtName.match(/(click|mouseleave)/))
			evtName = o.slideTrigger_close = "mouseleave"; // also catches 'mouseout'

		// add/remove slide triggers
		$R[action](evtName, slideClose); // base event on resize
		// need extra events for mouseleave
		if (evtName === "mouseleave") {
			// also close on pane.mouseleave
			$P[action]("mouseleave."+ sID, slideClose);
			// cancel timer when mouse moves between 'pane' and 'resizer'
			$R[action]("mouseenter."+ sID, cancelMouseOut);
			$P[action]("mouseenter."+ sID, cancelMouseOut);
		}

		if (!enable)
			timer.clear(pane+"_closeSlider");
		else if (evtName === "click" && !o.resizable) {
			// IF pane is not resizable (which already has a cursor and tip) 
			// then set the a cursor & title/tip on resizer when sliding
			$R.css("cursor", enable ? o.sliderCursor : "default");
			$R.attr("title", enable ? $textUtils.getText(infaw.portlet.I18nResources.CLOSE) : ""); // use Toggler-tip, eg: "Close Pane"
		}

		// SUBROUTINE for mouseleave timer clearing
		function cancelMouseOut (evt) {
			timer.clear(pane+"_closeSlider");
			evt.stopPropagation();
		}
	}


	/**
	* Hides/closes a pane if there is insufficient room - reverses this when there is room again
	* MUST have already called setSizeLimits() before calling this method
	*
	* @param {string}	pane					The pane being resized
	* @param {boolean=}	[isOpening=false]		Called from onOpen?
	* @param {boolean=}	[skipCallback=false]	Should the onresize callback be run?
	* @param {boolean=}	[force=false]
	*/
,	makePaneFit = function (pane, isOpening, skipCallback, force) {
		var
			o	= options[pane]
		,	s	= state[pane]
		,	c	= _c[pane]
		,	$P	= $Ps[pane]
		,	$R	= $Rs[pane]
		,	isSidePane 	= c.dir==="vert"
		,	hasRoom		= false
		;
		// special handling for center & east/west panes
		if (pane === "center" || (isSidePane && s.noVerticalRoom)) {
			// see if there is enough room to display the pane
			// ERROR: hasRoom = s.minHeight <= s.maxHeight && (isSidePane || s.minWidth <= s.maxWidth);
			hasRoom = (s.maxHeight >= 0);
			if (hasRoom && s.noRoom) { // previously hidden due to noRoom, so show now
				_showPane(pane);
				if ($R) $R.show();
				s.isVisible = true;
				s.noRoom = false;
				if (isSidePane) s.noVerticalRoom = false;
				_fixIframe(pane);
			}
			else if (!hasRoom && !s.noRoom) { // not currently hidden, so hide now
				_hidePane(pane);
				if ($R) $R.hide();
				s.isVisible = false;
				s.noRoom = true;
			}
		}

		// see if there is enough room to fit the border-pane
		if (pane === "center") {
			// ignore center in this block
		}
		else if (s.minSize <= s.maxSize) { // pane CAN fit
			hasRoom = true;
			if (s.size > s.maxSize) // pane is too big - shrink it
				sizePane(pane, s.maxSize, skipCallback, true, force); // true = noAnimation
			else if (s.size < s.minSize) // pane is too small - enlarge it
				sizePane(pane, s.minSize, skipCallback, true, force); // true = noAnimation
			// need s.isVisible because new pseudoClose method keeps pane visible, but off-screen
			else if ($R && s.isVisible && $P.is(":visible")) {
				// make sure resizer-bar is positioned correctly
				// handles situation where nested layout was 'hidden' when initialized
				var	pos = s.size + sC.inset[c.side];
				if ($.layout.cssNum( $R, c.side ) != pos) $R.css( c.side, pos );
			}

			// if was previously hidden due to noRoom, then RESET because NOW there is room
			if (s.noRoom) {
				// s.noRoom state will be set by open or show
				if (s.wasOpen && o.closable) {
					if (o.autoReopen)
						open(pane, false, true, true); // true = noAnimation, true = noAlert
					else // leave the pane closed, so just update state
						s.noRoom = false;
				}
				else
					show(pane, s.wasOpen, true, true); // true = noAnimation, true = noAlert
			}
		}
		else { // !hasRoom - pane CANNOT fit
			if (!s.noRoom) { // pane not set as noRoom yet, so hide or close it now...
				s.noRoom = true; // update state
				s.wasOpen = !s.isClosed && !s.isSliding;
				if (s.isClosed){} // SKIP
				else if (o.closable) // 'close' if possible
					close(pane, true, true); // true = force, true = noAnimation
				else // 'hide' pane if cannot just be closed
					hide(pane, true); // true = noAnimation
			}
		}
	}


	/**
	* sizePane / manualSizePane
	* sizePane is called only by internal methods whenever a pane needs to be resized
	* manualSizePane is an exposed flow-through method allowing extra code when pane is 'manually resized'
	*
	* @param {(string|Object)}	evt_or_pane				The pane being resized
	* @param {number}			size					The *desired* new size for this pane - will be validated
	* @param {boolean=}			[skipCallback=false]	Should the onresize callback be run?
	* @param {boolean=}			[noAnimation=false]
	* @param {boolean=}			[force=false]			Force resizing even if does not seem necessary
	*/
,	manualSizePane = function (evt_or_pane, size, skipCallback, noAnimation, force) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	o	= options[pane]
		,	s	= state[pane]
		//	if resizing callbacks have been delayed and resizing is now DONE, force resizing to complete...
		,	forceResize = force || (o.livePaneResizing && !s.isResizing)
		;
		// ANY call to manualSizePane disables autoResize - ie, percentage sizing
		s.autoResize = false;
		// flow-through...
		sizePane(pane, size, skipCallback, noAnimation, forceResize); // will animate resize if option enabled
	}

	/**
	* @param {(string|Object)}	evt_or_pane				The pane being resized
	* @param {number}			size					The *desired* new size for this pane - will be validated
	* @param {boolean=}			[skipCallback=false]	Should the onresize callback be run?
	* @param {boolean=}			[noAnimation=false]
	* @param {boolean=}			[force=false]			Force resizing even if does not seem necessary
	*/
,	sizePane = function (evt_or_pane, size, skipCallback, noAnimation, force) {
		if (!isInitialized()) return;
		var	pane	= evtPane.call(this, evt_or_pane) // probably NEVER called from event?
		,	o		= options[pane]
		,	s		= state[pane]
		,	$P		= $Ps[pane]
		,	$R		= $Rs[pane]
		,	side	= _c[pane].side
		,	dimName	= _c[pane].sizeType.toLowerCase()
		,	skipResizeWhileDragging = s.isResizing && !o.triggerEventsDuringLiveResize
		,	doFX	= noAnimation !== true && o.animatePaneSizing
		,	oldSize, newSize
		;
		// QUEUE in case another action/animation is in progress
		$N.queue(function( queueNext ){
			// calculate 'current' min/max sizes
			setSizeLimits(pane); // update pane-state
			oldSize = s.size;
			size = _parseSize(pane, size); // handle percentages & auto
			size = max(size, _parseSize(pane, o.minSize));
			size = min(size, s.maxSize);
			if (size < s.minSize) { // not enough room for pane!
				queueNext(); // call before makePaneFit() because it needs the queue free
				makePaneFit(pane, false, skipCallback);	// will hide or close pane
				return;
			}

			// IF newSize is same as oldSize, then nothing to do - abort
			if (!force && size === oldSize)
				return queueNext();

			s.newSize = size;

			// onresize_start callback CANNOT cancel resizing because this would break the layout!
			if (!skipCallback && state.initialized && s.isVisible)
				_runCallbacks("onresize_start", pane);

			// resize the pane, and make sure its visible
			newSize = cssSize(pane, size);

			if (doFX && $P.is(":visible")) { // ANIMATE
				var fx		= $.layout.effects.size[pane] || $.layout.effects.size.all
				,	easing	= o.fxSettings_size.easing || fx.easing
				,	z		= options.zIndexes
				,	props	= {};
				props[ dimName ] = newSize +'px';
				s.isMoving = true;
				// overlay all elements during animation
				$P.css({ zIndex: z.pane_animate })
				  .show().animate( props, o.fxSpeed_size, easing, function(){
					// reset zIndex after animation
					$P.css({ zIndex: (s.isSliding ? z.pane_sliding : z.pane_normal) });
					s.isMoving = false;
					delete s.newSize;
					sizePane_2(); // continue
					queueNext();
				});
			}
			else { // no animation
				$P.css( dimName, newSize );	// resize pane
				delete s.newSize;
				// if pane is visible, then 
				if ($P.is(":visible"))
					sizePane_2(); // continue
				else {
					// pane is NOT VISIBLE, so just update state data...
					// when pane is *next opened*, it will have the new size
					s.size = size;				// update state.size
					$.extend(s, elDims($P));	// update state dimensions
				}
				queueNext();
			};

		});

		// SUBROUTINE
		function sizePane_2 () {
			/*	Panes are sometimes not sized precisely in some browsers!?
			 *	This code will resize the pane up to 3 times to nudge the pane to the correct size
			 */
			var	actual	= dimName==='width' ? $P.outerWidth() : $P.outerHeight()
			,	tries	= [{
						   	pane:		pane
						,	count:		1
						,	target:		size
						,	actual:		actual
						,	correct:	(size === actual)
						,	attempt:	size
						,	cssSize:	newSize
						}]
			,	lastTry = tries[0]
			,	thisTry	= {}
			,	msg		= 'Inaccurate size after resizing the '+ pane +'-pane.'
			;
			while ( !lastTry.correct ) {
				thisTry = { pane: pane, count: lastTry.count+1, target: size };

				if (lastTry.actual > size)
					thisTry.attempt = max(0, lastTry.attempt - (lastTry.actual - size));
				else // lastTry.actual < size
					thisTry.attempt = max(0, lastTry.attempt + (size - lastTry.actual));

				thisTry.cssSize = cssSize(pane, thisTry.attempt);
				$P.css( dimName, thisTry.cssSize );

				thisTry.actual	= dimName=='width' ? $P.outerWidth() : $P.outerHeight();
				thisTry.correct	= (size === thisTry.actual);

				// log attempts and alert the user of this *non-fatal error* (if showDebugMessages)
				if ( tries.length === 1) {
					_log(msg, false, true);
					_log(lastTry, false, true);
				}
				_log(thisTry, false, true);
				// after 4 tries, is as close as its gonna get!
				if (tries.length > 3) break;

				tries.push( thisTry );
				lastTry = tries[ tries.length - 1 ];
			}
			// END TESTING CODE

			// update pane-state dimensions
			s.size	= size;
			$.extend(s, elDims($P));

			if (s.isVisible && $P.is(":visible")) {
				// reposition the resizer-bar
				if ($R) $R.css( side, size + sC.inset[side] );
				// resize the content-div
				sizeContent(pane);
			}

			if (!skipCallback && !skipResizeWhileDragging && state.initialized && s.isVisible)
				_runCallbacks("onresize_end", pane);

			// resize all the adjacent panes, and adjust their toggler buttons
			// when skipCallback passed, it means the controlling method will handle 'other panes'
			if (!skipCallback) {
				// also no callback if live-resize is in progress and NOT triggerEventsDuringLiveResize
				if (!s.isSliding) sizeMidPanes(_c[pane].dir=="horz" ? "" : "center", skipResizeWhileDragging, force);
				sizeHandles();
			}

			// if opposite-pane was autoClosed, see if it can be autoOpened now
			var altPane = _c.oppositeEdge[pane];
			if (size < oldSize && state[ altPane ].noRoom) {
				setSizeLimits( altPane );
				makePaneFit( altPane, false, skipCallback );
			}

			// DEBUG - ALERT user/developer so they know there was a sizing problem
			if (tries.length > 1)
				_log(msg +'\nSee the Error Console for details.', true, true);
		}
	}

	/**
	* @see  initPanes(), sizePane(), 	resizeAll(), open(), close(), hide()
	* @param {(Array.<string>|string)}	panes					The pane(s) being resized, comma-delmited string
	* @param {boolean=}					[skipCallback=false]	Should the onresize callback be run?
	* @param {boolean=}					[force=false]
	*/
,	sizeMidPanes = function (panes, skipCallback, force) {
		panes = (panes ? panes : "east,west,center").split(",");

		$.each(panes, function (i, pane) {
			if (!$Ps[pane]) return; // NO PANE - skip
			var 
				o		= options[pane]
			,	s		= state[pane]
			,	$P		= $Ps[pane]
			,	$R		= $Rs[pane]
			,	isCenter= (pane=="center")
			,	hasRoom	= true
			,	CSS		= {}
			//	if pane is not visible, show it invisibly NOW rather than for *each call* in this script
			,	visCSS	= $.layout.showInvisibly($P)

			,	newCenter	= calcNewCenterPaneDims()
			;

			// update pane-state dimensions
			$.extend(s, elDims($P));

			if (pane === "center") {
				if (!force && s.isVisible && newCenter.width === s.outerWidth && newCenter.height === s.outerHeight) {
					$P.css(visCSS);
					return true; // SKIP - pane already the correct size
				}
				// set state for makePaneFit() logic
				$.extend(s, cssMinDims(pane), {
					maxWidth:	newCenter.width
				,	maxHeight:	newCenter.height
				});
				CSS = newCenter;
				s.newWidth	= CSS.width;
				s.newHeight	= CSS.height;
				// convert OUTER width/height to CSS width/height 
				CSS.width	= cssW($P, CSS.width);
				// NEW - allow pane to extend 'below' visible area rather than hide it
				CSS.height	= cssH($P, CSS.height);
				hasRoom		= CSS.width >= 0 && CSS.height >= 0; // height >= 0 = ALWAYS TRUE NOW

				// during layout init, try to shrink east/west panes to make room for center
				if (!state.initialized && o.minWidth > newCenter.width) {
					var
						reqPx	= o.minWidth - s.outerWidth
					,	minE	= options.east.minSize || 0
					,	minW	= options.west.minSize || 0
					,	sizeE	= state.east.size
					,	sizeW	= state.west.size
					,	newE	= sizeE
					,	newW	= sizeW
					;
					if (reqPx > 0 && state.east.isVisible && sizeE > minE) {
						newE = max( sizeE-minE, sizeE-reqPx );
						reqPx -= sizeE-newE;
					}
					if (reqPx > 0 && state.west.isVisible && sizeW > minW) {
						newW = max( sizeW-minW, sizeW-reqPx );
						reqPx -= sizeW-newW;
					}
					// IF we found enough extra space, then resize the border panes as calculated
					if (reqPx === 0) {
						if (sizeE && sizeE != minE)
							sizePane('east', newE, true, true, force); // true = skipCallback/noAnimation - initPanes will handle when done
						if (sizeW && sizeW != minW)
							sizePane('west', newW, true, true, force); // true = skipCallback/noAnimation
						// now start over!
						sizeMidPanes('center', skipCallback, force);
						$P.css(visCSS);
						return; // abort this loop
					}
				}
			}
			else { // for east and west, set only the height, which is same as center height
				// set state.min/maxWidth/Height for makePaneFit() logic
				if (s.isVisible && !s.noVerticalRoom)
					$.extend(s, elDims($P), cssMinDims(pane))
				if (!force && !s.noVerticalRoom && newCenter.height === s.outerHeight) {
					$P.css(visCSS);
					return true; // SKIP - pane already the correct size
				}
				// east/west have same top, bottom & height as center
				CSS.top		= newCenter.top;
				CSS.bottom	= newCenter.bottom;
				s.newSize	= newCenter.height
				// NEW - allow pane to extend 'below' visible area rather than hide it
				CSS.height	= cssH($P, newCenter.height);
				s.maxHeight	= CSS.height;
				hasRoom		= (s.maxHeight >= 0); // ALWAYS TRUE NOW
				if (!hasRoom) s.noVerticalRoom = true; // makePaneFit() logic
			}

			if (hasRoom) {
				// resizeAll passes skipCallback because it triggers callbacks after ALL panes are resized
				if (!skipCallback && state.initialized)
					_runCallbacks("onresize_start", pane);

				$P.css(CSS); // apply the CSS to pane
				if (pane !== "center")
					sizeHandles(pane); // also update resizer length
				if (s.noRoom && !s.isClosed && !s.isHidden)
					makePaneFit(pane); // will re-open/show auto-closed/hidden pane
				if (s.isVisible) {
					$.extend(s, elDims($P)); // update pane dimensions
					if (state.initialized) sizeContent(pane); // also resize the contents, if exists
				}
			}
			else if (!s.noRoom && s.isVisible) // no room for pane
				makePaneFit(pane); // will hide or close pane

			// reset visibility, if necessary
			$P.css(visCSS);

			delete s.newSize;
			delete s.newWidth;
			delete s.newHeight;

			if (!s.isVisible)
				return true; // DONE - next pane

			/*
			* Extra CSS for IE6 or IE7 in Quirks-mode - add 'width' to NORTH/SOUTH panes
			* Normally these panes have only 'left' & 'right' positions so pane auto-sizes
			* ALSO required when pane is an IFRAME because will NOT default to 'full width'
			*	TODO: Can I use width:100% for a north/south iframe?
			*	TODO: Sounds like a job for $P.outerWidth( sC.innerWidth ) SETTER METHOD
			*/
			if (pane === "center") { // finished processing midPanes
				var fix = browser.isIE6 || !browser.boxModel;
				if ($Ps.north && (fix || state.north.tagName=="IFRAME")) 
					$Ps.north.css("width", cssW($Ps.north, sC.innerWidth));
				if ($Ps.south && (fix || state.south.tagName=="IFRAME"))
					$Ps.south.css("width", cssW($Ps.south, sC.innerWidth));
			}

			// resizeAll passes skipCallback because it triggers callbacks after ALL panes are resized
			if (!skipCallback && state.initialized)
				_runCallbacks("onresize_end", pane);
		});
	}


	/**
	* @see  window.onresize(), callbacks or custom code
	* @param {(Object|boolean)=}	evt_or_refresh	If 'true', then also reset pane-positioning
	*/
,	resizeAll = function (evt_or_refresh) {
		var	oldW	= sC.innerWidth
		,	oldH	= sC.innerHeight
		;
		// stopPropagation if called by trigger("layoutdestroy") - use evtPane utility 
		evtPane(evt_or_refresh);

		// cannot size layout when 'container' is hidden or collapsed
		if (!$N.is(":visible")) return;

		if (!state.initialized) {
			_initLayoutElements();
			return; // no need to resize since we just initialized!
		}

		if (evt_or_refresh === true && $.isPlainObject(options.outset)) {
			// update container CSS in case outset option has changed
			$N.css( options.outset );
		}
		// UPDATE container dimensions
		$.extend(sC, elDims( $N, options.inset ));
		if (!sC.outerHeight) return;

		// if 'true' passed, refresh pane & handle positioning too
		if (evt_or_refresh === true) {
			setPanePosition();
		}

		// onresizeall_start will CANCEL resizing if returns false
		// state.container has already been set, so user can access this info for calcuations
		if (false === _runCallbacks("onresizeall_start")) return false;

		var	// see if container is now 'smaller' than before
			shrunkH	= (sC.innerHeight < oldH)
		,	shrunkW	= (sC.innerWidth < oldW)
		,	$P, o, s
		;
		// NOTE special order for sizing: S-N-E-W
		$.each(["south","north","east","west"], function (i, pane) {
			if (!$Ps[pane]) return; // no pane - SKIP
			o = options[pane];
			s = state[pane];
			if (s.autoResize && s.size != o.size) // resize pane to original size set in options
				sizePane(pane, o.size, true, true, true); // true=skipCallback/noAnimation/forceResize
			else {
				setSizeLimits(pane);
				makePaneFit(pane, false, true, true); // true=skipCallback/forceResize
			}
		});

		sizeMidPanes("", true, true); // true=skipCallback/forceResize
		sizeHandles(); // reposition the toggler elements

		// trigger all individual pane callbacks AFTER layout has finished resizing
		$.each(_c.allPanes, function (i, pane) {
			$P = $Ps[pane];
			if (!$P) return; // SKIP
			if (state[pane].isVisible) // undefined for non-existent panes
				_runCallbacks("onresize_end", pane); // callback - if exists
		});

		_runCallbacks("onresizeall_end");
		//_triggerLayoutEvent(pane, 'resizeall');
	}

	/**
	* Whenever a pane resizes or opens that has a nested layout, trigger resizeAll
	*
	* @param {(string|Object)}	evt_or_pane		The pane just resized or opened
	*/
,	resizeChildren = function (evt_or_pane, skipRefresh) {
		var	pane = evtPane.call(this, evt_or_pane);

		if (!options[pane].resizeChildren) return;

		// ensure the pane-children are up-to-date
		if (!skipRefresh) refreshChildren( pane );
		var pC = children[pane];
		if ($.isPlainObject( pC )) {
			// resize one or more children
			$.each( pC, function (key, child) {
				child.resizeAll();
			});
		}
	}

	/**
	* IF pane has a content-div, then resize all elements inside pane to fit pane-height
	*
	* @param {(string|Object)}	evt_or_panes		The pane(s) being resized
	* @param {boolean=}			[remeasure=false]	Should the content (header/footer) be remeasured?
	*/
,	sizeContent = function (evt_or_panes, remeasure) {
		if (!isInitialized()) return;

		var panes = evtPane.call(this, evt_or_panes);
		panes = panes ? panes.split(",") : _c.allPanes;

		$.each(panes, function (idx, pane) {
			var
				$P	= $Ps[pane]
			,	$C	= $Cs[pane]
			,	o	= options[pane]
			,	s	= state[pane]
			,	m	= s.content // m = measurements
			;
			if (!$P || !$C || !$P.is(":visible")) return true; // NOT VISIBLE - skip

			// if content-element was REMOVED, update OR remove the pointer
			if (!$C.length) {
				initContent(pane, false);	// false = do NOT sizeContent() - already there!
				if (!$C) return;			// no replacement element found - pointer have been removed
			}

			// onsizecontent_start will CANCEL resizing if returns false
			if (false === _runCallbacks("onsizecontent_start", pane)) return;

			// skip re-measuring offsets if live-resizing
			if ((!s.isMoving && !s.isResizing) || o.liveContentResizing || remeasure || m.top == undefined) {
				_measure();
				// if any footers are below pane-bottom, they may not measure correctly,
				// so allow pane overflow and re-measure
				if (m.hiddenFooters > 0 && $P.css("overflow") === "hidden") {
					$P.css("overflow", "visible");
					_measure(); // remeasure while overflowing
					$P.css("overflow", "hidden");
				}
			}
			// NOTE: spaceAbove/Below *includes* the pane paddingTop/Bottom, but not pane.borders
			var newH = s.innerHeight - (m.spaceAbove - s.css.paddingTop) - (m.spaceBelow - s.css.paddingBottom);

			if (!$C.is(":visible") || m.height != newH) {
				// size the Content element to fit new pane-size - will autoHide if not enough room
				setOuterHeight($C, newH, true); // true=autoHide
				m.height = newH; // save new height
			};

			if (state.initialized)
				_runCallbacks("onsizecontent_end", pane);

			function _below ($E) {
				return max(s.css.paddingBottom, (parseInt($E.css("marginBottom"), 10) || 0));
			};

			function _measure () {
				var
					ignore	= options[pane].contentIgnoreSelector
				,	$Fs		= $C.nextAll().not(".ui-layout-mask").not(ignore || ":lt(0)") // not :lt(0) = ALL
				,	$Fs_vis	= $Fs.filter(':visible')
				,	$F		= $Fs_vis.filter(':last')
				;
				m = {
					top:			$C[0].offsetTop
				,	height:			$C.outerHeight()
				,	numFooters:		$Fs.length
				,	hiddenFooters:	$Fs.length - $Fs_vis.length
				,	spaceBelow:		0 // correct if no content footer ($E)
				}
					m.spaceAbove	= m.top; // just for state - not used in calc
					m.bottom		= m.top + m.height;
				if ($F.length)
					//spaceBelow = (LastFooter.top + LastFooter.height) [footerBottom] - Content.bottom + max(LastFooter.marginBottom, pane.paddingBotom)
					m.spaceBelow = ($F[0].offsetTop + $F.outerHeight()) - m.bottom + _below($F);
				else // no footer - check marginBottom on Content element itself
					m.spaceBelow = _below($C);
			};
		});
	}


	/**
	* Called every time a pane is opened, closed, or resized to slide the togglers to 'center' and adjust their length if necessary
	*
	* @see  initHandles(), open(), close(), resizeAll()
	* @param {(string|Object)=}		evt_or_panes	The pane(s) being resized
	*/
,	sizeHandles = function (evt_or_panes) {
		var panes = evtPane.call(this, evt_or_panes)
		panes = panes ? panes.split(",") : _c.borderPanes;

		$.each(panes, function (i, pane) {
			var 
				o	= options[pane]
			,	s	= state[pane]
			,	$P	= $Ps[pane]
			,	$R	= $Rs[pane]
			,	$T	= $Ts[pane]
			,	$TC
			;
			if (!$P || !$R) return;

			var
				dir			= _c[pane].dir
			,	_state		= (s.isClosed ? "_closed" : "_open")
			,	spacing		= o["spacing"+ _state]
			,	togAlign	= o["togglerAlign"+ _state]
			,	togLen		= o["togglerLength"+ _state]
			,	paneLen
			,	left
			,	offset
			,	CSS = {}
			;

			if (spacing === 0) {
				$R.hide();
				return;
			}
			else if (!s.noRoom && !s.isHidden) // skip if resizer was hidden for any reason
				$R.show(); // in case was previously hidden

			// Resizer Bar is ALWAYS same width/height of pane it is attached to
			if (dir === "horz") { // north/south
				//paneLen = $P.outerWidth(); // s.outerWidth || 
				paneLen = sC.innerWidth; // handle offscreen-panes
				s.resizerLength = paneLen;
				left = $.layout.cssNum($P, "left")
				$R.css({
					width:	cssW($R, paneLen) // account for borders & padding
				,	height:	cssH($R, spacing) // ditto
				,	left:	left > -9999 ? left : sC.inset.left // handle offscreen-panes
				});
			}
			else { // east/west
				paneLen = $P.outerHeight(); // s.outerHeight || 
				s.resizerLength = paneLen;
				$R.css({
					height:	cssH($R, paneLen) // account for borders & padding
				,	width:	cssW($R, spacing) // ditto
				,	top:	sC.inset.top + getPaneSize("north", true) // TODO: what if no North pane?
				//,	top:	$.layout.cssNum($Ps["center"], "top")
				});
			}

			// remove hover classes
			removeHover( o, $R );

			if ($T) {
				if (togLen === 0 || (s.isSliding && o.hideTogglerOnSlide)) {
					$T.hide(); // always HIDE the toggler when 'sliding'
					return;
				}
				else
					$T.show(); // in case was previously hidden

				if (!(togLen > 0) || togLen === "100%" || togLen > paneLen) {
					togLen = paneLen;
					offset = 0;
				}
				else { // calculate 'offset' based on options.PANE.togglerAlign_open/closed
					if (isStr(togAlign)) {
						switch (togAlign) {
							case "top":
							case "left":	offset = 0;
											break;
							case "bottom":
							case "right":	offset = paneLen - togLen;
											break;
							case "middle":
							case "center":
							default:		offset = round((paneLen - togLen) / 2); // 'default' catches typos
						}
					}
					else { // togAlign = number
						var x = parseInt(togAlign, 10); //
						if (togAlign >= 0) offset = x;
						else offset = paneLen - togLen + x; // NOTE: x is negative!
					}
				}

				if (dir === "horz") { // north/south
					var width = cssW($T, togLen);
					$T.css({
						width:	width  // account for borders & padding
					,	height:	cssH($T, spacing) // ditto
					,	left:	offset // TODO: VERIFY that toggler  positions correctly for ALL values
					,	top:	0
					});
					// CENTER the toggler content SPAN
					$T.children(".content").each(function(){
						$TC = $(this);
						$TC.css("marginLeft", round((width-$TC.outerWidth())/2)); // could be negative
					});
				}
				else { // east/west
					var height = cssH($T, togLen);
					$T.css({
						height:	height // account for borders & padding
					,	width:	cssW($T, spacing) // ditto
					,	top:	offset // POSITION the toggler
					,	left:	0
					});
					// CENTER the toggler content SPAN
					$T.children(".content").each(function(){
						$TC = $(this);
						$TC.css("marginTop", round((height-$TC.outerHeight())/2)); // could be negative
					});
				}

				// remove ALL hover classes
				removeHover( 0, $T );
			}

			// DONE measuring and sizing this resizer/toggler, so can be 'hidden' now
			if (!state.initialized && (o.initHidden || s.noRoom)) {
				$R.hide();
				if ($T) $T.hide();
			}
		});
	}


	/**
	* @param {(string|Object)}	evt_or_pane
	*/
,	enableClosable = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$T	= $Ts[pane]
		,	o	= options[pane]
		;
		if (!$T) return;
		o.closable = true;
		$T	.bind("click keydown."+ sID, function(evt){ 
					if (evt.type === 'keydown' && evt.which !== 13 /*enter*/) {
						return;
					}
					evt.stopPropagation(); toggle(pane); 
				})
			.css("visibility", "visible")
			.css("cursor", "pointer")
			.attr("title", state[pane].isClosed ? $textUtils.getText(infaw.portlet.I18nResources.OPEN) : $textUtils.getText(infaw.portlet.I18nResources.CLOSE)) // may be blank
			.show();
	}
	/**
	* @param {(string|Object)}	evt_or_pane
	* @param {boolean=}			[hide=false]
	*/
,	disableClosable = function (evt_or_pane, hide) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$T	= $Ts[pane]
		;
		if (!$T) return;
		options[pane].closable = false;
		// is closable is disable, then pane MUST be open!
		if (state[pane].isClosed) open(pane, false, true);
		$T	.unbind("."+ sID)
			.css("visibility", hide ? "hidden" : "visible") // instead of hide(), which creates logic issues
			.css("cursor", "default")
			.attr("title", "");
	}


	/**
	* @param {(string|Object)}	evt_or_pane
	*/
,	enableSlidable = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$R	= $Rs[pane]
		;
		if (!$R || !$R.data('draggable')) return;
		options[pane].slidable = true; 
		if (state[pane].isClosed)
			bindStartSlidingEvents(pane, true);
	}
	/**
	* @param {(string|Object)}	evt_or_pane
	*/
,	disableSlidable = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$R	= $Rs[pane]
		;
		if (!$R) return;
		options[pane].slidable = false; 
		if (state[pane].isSliding)
			close(pane, false, true);
		else {
			bindStartSlidingEvents(pane, false);
			$R	.css("cursor", "default")
				.attr("title", "");
			removeHover(null, $R[0]); // in case currently hovered
		}
	}


	/**
	* @param {(string|Object)}	evt_or_pane
	*/
,	enableResizable = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$R	= $Rs[pane]
		,	o	= options[pane]
		;
		if (!$R || !$R.data('draggable')) return;
		o.resizable = true; 
		$R.draggable("enable");
		if (!state[pane].isClosed)
			$R	.css("cursor", o.resizerCursor)
			 	.attr("title", $textUtils.getText(infaw.portlet.I18nResources.RESIZE));
	}
	/**
	* @param {(string|Object)}	evt_or_pane
	*/
,	disableResizable = function (evt_or_pane) {
		if (!isInitialized()) return;
		var	pane = evtPane.call(this, evt_or_pane)
		,	$R	= $Rs[pane]
		;
		if (!$R || !$R.data('draggable')) return;
		options[pane].resizable = false; 
		$R	.draggable("disable")
			.css("cursor", "default")
			.attr("title", "");
		removeHover(null, $R[0]); // in case currently hovered
	}


	/**
	* Move a pane from source-side (eg, west) to target-side (eg, east)
	* If pane exists on target-side, move that to source-side, ie, 'swap' the panes
	*
	* @param {(string|Object)}	evt_or_pane1	The pane/edge being swapped
	* @param {string}			pane2			ditto
	*/
,	swapPanes = function (evt_or_pane1, pane2) {
		if (!isInitialized()) return;
		var pane1 = evtPane.call(this, evt_or_pane1);
		// change state.edge NOW so callbacks can know where pane is headed...
		state[pane1].edge = pane2;
		state[pane2].edge = pane1;
		// run these even if NOT state.initialized
		if (false === _runCallbacks("onswap_start", pane1)
		 ||	false === _runCallbacks("onswap_start", pane2)
		) {
			state[pane1].edge = pane1; // reset
			state[pane2].edge = pane2;
			return;
		}

		var
			oPane1	= copy( pane1 )
		,	oPane2	= copy( pane2 )
		,	sizes	= {}
		;
		sizes[pane1] = oPane1 ? oPane1.state.size : 0;
		sizes[pane2] = oPane2 ? oPane2.state.size : 0;

		// clear pointers & state
		$Ps[pane1] = false; 
		$Ps[pane2] = false;
		state[pane1] = {};
		state[pane2] = {};
		
		// ALWAYS remove the resizer & toggler elements
		if ($Ts[pane1]) $Ts[pane1].remove();
		if ($Ts[pane2]) $Ts[pane2].remove();
		if ($Rs[pane1]) $Rs[pane1].remove();
		if ($Rs[pane2]) $Rs[pane2].remove();
		$Rs[pane1] = $Rs[pane2] = $Ts[pane1] = $Ts[pane2] = false;

		// transfer element pointers and data to NEW Layout keys
		move( oPane1, pane2 );
		move( oPane2, pane1 );

		// cleanup objects
		oPane1 = oPane2 = sizes = null;

		// make panes 'visible' again
		if ($Ps[pane1]) $Ps[pane1].css(_c.visible);
		if ($Ps[pane2]) $Ps[pane2].css(_c.visible);

		// fix any size discrepancies caused by swap
		resizeAll();

		// run these even if NOT state.initialized
		_runCallbacks("onswap_end", pane1);
		_runCallbacks("onswap_end", pane2);

		return;

		function copy (n) { // n = pane
			var
				$P	= $Ps[n]
			,	$C	= $Cs[n]
			;
			return !$P ? false : {
				pane:		n
			,	P:			$P ? $P[0] : false
			,	C:			$C ? $C[0] : false
			,	state:		$.extend(true, {}, state[n])
			,	options:	$.extend(true, {}, options[n])
			}
		};

		function move (oPane, pane) {
			if (!oPane) return;
			var
				P		= oPane.P
			,	C		= oPane.C
			,	oldPane = oPane.pane
			,	c		= _c[pane]
			//	save pane-options that should be retained
			,	s		= $.extend(true, {}, state[pane])
			,	o		= options[pane]
			//	RETAIN side-specific FX Settings - more below
			,	fx		= { resizerCursor: o.resizerCursor }
			,	re, size, pos
			;
			$.each("fxName,fxSpeed,fxSettings".split(","), function (i, k) {
				fx[k +"_open"]  = o[k +"_open"];
				fx[k +"_close"] = o[k +"_close"];
				fx[k +"_size"]  = o[k +"_size"];
			});

			// update object pointers and attributes
			$Ps[pane] = $(P)
				.data({
					layoutPane:		Instance[pane]	// NEW pointer to pane-alias-object
				,	layoutEdge:		pane
				})
				.css(_c.hidden)
				.css(c.cssReq)
			;
			$Cs[pane] = C ? $(C) : false;

			// set options and state
			options[pane]	= $.extend(true, {}, oPane.options, fx);
			state[pane]		= $.extend(true, {}, oPane.state);

			// change classNames on the pane, eg: ui-layout-pane-east ==> ui-layout-pane-west
			re = new RegExp(o.paneClass +"-"+ oldPane, "g");
			P.className = P.className.replace(re, o.paneClass +"-"+ pane);

			// ALWAYS regenerate the resizer & toggler elements
			initHandles(pane); // create the required resizer & toggler

			// if moving to different orientation, then keep 'target' pane size
			if (c.dir != _c[oldPane].dir) {
				size = sizes[pane] || 0;
				setSizeLimits(pane); // update pane-state
				size = max(size, state[pane].minSize);
				// use manualSizePane to disable autoResize - not useful after panes are swapped
				manualSizePane(pane, size, true, true); // true/true = skipCallback/noAnimation
			}
			else // move the resizer here
				$Rs[pane].css(c.side, sC.inset[c.side] + (state[pane].isVisible ? getPaneSize(pane) : 0));


			// ADD CLASSNAMES & SLIDE-BINDINGS
			if (oPane.state.isVisible && !s.isVisible)
				setAsOpen(pane, true); // true = skipCallback
			else {
				setAsClosed(pane);
				bindStartSlidingEvents(pane, true); // will enable events IF option is set
			}

			// DESTROY the object
			oPane = null;
		};
	}


	/**
	* INTERNAL method to sync pin-buttons when pane is opened or closed
	* Unpinned means the pane is 'sliding' - ie, over-top of the adjacent panes
	*
	* @see  open(), setAsOpen(), setAsClosed()
	* @param {string}	pane   These are the params returned to callbacks by layout()
	* @param {boolean}	doPin  True means set the pin 'down', False means 'up'
	*/
,	syncPinBtns = function (pane, doPin) {
		if ($.layout.plugins.buttons)
			$.each(state[pane].pins, function (i, selector) {
				$.layout.buttons.setPinState(Instance, $(selector), pane, doPin);
			});
	}

;	// END var DECLARATIONS

	/**
	* Capture keys when enableCursorHotkey - toggle pane if hotkey pressed
	*
	* @see  document.keydown()
	*/
	function keyDown (evt) {
		if (!evt) return true;
		var code = evt.keyCode;
		if (code < 33) return true; // ignore special keys: ENTER, TAB, etc

		var
			PANE = {
				38: "north" // Up Cursor	- $.ui.keyCode.UP
			,	40: "south" // Down Cursor	- $.ui.keyCode.DOWN
			,	37: "west"  // Left Cursor	- $.ui.keyCode.LEFT
			,	39: "east"  // Right Cursor	- $.ui.keyCode.RIGHT
			}
		,	ALT		= evt.altKey // no worky!
		,	SHIFT	= evt.shiftKey
		,	CTRL	= evt.ctrlKey
		,	CURSOR	= (CTRL && code >= 37 && code <= 40)
		,	o, k, m, pane
		;

		if (CURSOR && options[PANE[code]].enableCursorHotkey) // valid cursor-hotkey
			pane = PANE[code];
		else if (CTRL || SHIFT) // check to see if this matches a custom-hotkey
			$.each(_c.borderPanes, function (i, p) { // loop each pane to check its hotkey
				o = options[p];
				k = o.customHotkey;
				m = o.customHotkeyModifier; // if missing or invalid, treated as "CTRL+SHIFT"
				if ((SHIFT && m=="SHIFT") || (CTRL && m=="CTRL") || (CTRL && SHIFT)) { // Modifier matches
					if (k && code === (isNaN(k) || k <= 9 ? k.toUpperCase().charCodeAt(0) : k)) { // Key matches
						pane = p;
						return false; // BREAK
					}
				}
			});

		// validate pane
		if (!pane || !$Ps[pane] || !options[pane].closable || state[pane].isHidden)
			return true;

		toggle(pane);

		evt.stopPropagation();
		evt.returnValue = false; // CANCEL key
		return false;
	};


/*
 * ######################################
 *	UTILITY METHODS
 *	called externally or by initButtons
 * ######################################
 */

	/**
	* Change/reset a pane overflow setting & zIndex to allow popups/drop-downs to work
	*
	* @param {Object=}   [el]	(optional) Can also be 'bound' to a click, mouseOver, or other event
	*/
	function allowOverflow (el) {
		if (!isInitialized()) return;
		if (this && this.tagName) el = this; // BOUND to element
		var $P;
		if (isStr(el))
			$P = $Ps[el];
		else if ($(el).data("layoutRole"))
			$P = $(el);
		else
			$(el).parents().each(function(){
				if ($(this).data("layoutRole")) {
					$P = $(this);
					return false; // BREAK
				}
			});
		if (!$P || !$P.length) return; // INVALID

		var
			pane	= $P.data("layoutEdge")
		,	s		= state[pane]
		;

		// if pane is already raised, then reset it before doing it again!
		// this would happen if allowOverflow is attached to BOTH the pane and an element 
		if (s.cssSaved)
			resetOverflow(pane); // reset previous CSS before continuing

		// if pane is raised by sliding or resizing, or its closed, then abort
		if (s.isSliding || s.isResizing || s.isClosed) {
			s.cssSaved = false;
			return;
		}

		var
			newCSS	= { zIndex: (options.zIndexes.resizer_normal + 1) }
		,	curCSS	= {}
		,	of		= $P.css("overflow")
		,	ofX		= $P.css("overflowX")
		,	ofY		= $P.css("overflowY")
		;
		// determine which, if any, overflow settings need to be changed
		if (of != "visible") {
			curCSS.overflow = of;
			newCSS.overflow = "visible";
		}
		if (ofX && !ofX.match(/(visible|auto)/)) {
			curCSS.overflowX = ofX;
			newCSS.overflowX = "visible";
		}
		if (ofY && !ofY.match(/(visible|auto)/)) {
			curCSS.overflowY = ofX;
			newCSS.overflowY = "visible";
		}

		// save the current overflow settings - even if blank!
		s.cssSaved = curCSS;

		// apply new CSS to raise zIndex and, if necessary, make overflow 'visible'
		$P.css( newCSS );

		// make sure the zIndex of all other panes is normal
		$.each(_c.allPanes, function(i, p) {
			if (p != pane) resetOverflow(p);
		});

	};
	/**
	* @param {Object=}   [el]	(optional) Can also be 'bound' to a click, mouseOver, or other event
	*/
	function resetOverflow (el) {
		if (!isInitialized()) return;
		if (this && this.tagName) el = this; // BOUND to element
		var $P;
		if (isStr(el))
			$P = $Ps[el];
		else if ($(el).data("layoutRole"))
			$P = $(el);
		else
			$(el).parents().each(function(){
				if ($(this).data("layoutRole")) {
					$P = $(this);
					return false; // BREAK
				}
			});
		if (!$P || !$P.length) return; // INVALID

		var
			pane	= $P.data("layoutEdge")
		,	s		= state[pane]
		,	CSS		= s.cssSaved || {}
		;
		// reset the zIndex
		if (!s.isSliding && !s.isResizing)
			$P.css("zIndex", options.zIndexes.pane_normal);

		// reset Overflow - if necessary
		$P.css( CSS );

		// clear var
		s.cssSaved = false;
	};

/*
 * #####################
 * CREATE/RETURN LAYOUT
 * #####################
 */

	// validate that container exists
	var $N = $(this).eq(0); // FIRST matching Container element
	if (!$N.length) {
		return _log( options.errors.containerMissing );
	};

	// Users retrieve Instance of a layout with: $N.layout() OR $N.data("layout")
	// return the Instance-pointer if layout has already been initialized
	if ($N.data("layoutContainer") && $N.data("layout"))
		return $N.data("layout"); // cached pointer

	// init global vars
	var 
		$Ps	= {}	// Panes x5		- set in initPanes()
	,	$Cs	= {}	// Content x5	- set in initPanes()
	,	$Rs	= {}	// Resizers x4	- set in initHandles()
	,	$Ts	= {}	// Togglers x4	- set in initHandles()
	,	$Ms	= $([])	// Masks - up to 2 masks per pane (IFRAME + DIV)
	//	aliases for code brevity
	,	sC	= state.container // alias for easy access to 'container dimensions'
	,	sID	= state.id // alias for unique layout ID/namespace - eg: "layout435"
	;

	// create Instance object to expose data & option Properties, and primary action Methods
	var Instance = {
	//	layout data
		options:			options			// property - options hash
	,	state:				state			// property - dimensions hash
	//	object pointers
	,	container:			$N				// property - object pointers for layout container
	,	panes:				$Ps				// property - object pointers for ALL Panes: panes.north, panes.center
	,	contents:			$Cs				// property - object pointers for ALL Content: contents.north, contents.center
	,	resizers:			$Rs				// property - object pointers for ALL Resizers, eg: resizers.north
	,	togglers:			$Ts				// property - object pointers for ALL Togglers, eg: togglers.north
	//	border-pane open/close
	,	hide:				hide			// method - ditto
	,	show:				show			// method - ditto
	,	toggle:				toggle			// method - pass a 'pane' ("north", "west", etc)
	,	open:				open			// method - ditto
	,	close:				close			// method - ditto
	,	slideOpen:			slideOpen		// method - ditto
	,	slideClose:			slideClose		// method - ditto
	,	slideToggle:		slideToggle		// method - ditto
	//	pane actions
	,	setSizeLimits:		setSizeLimits	// method - pass a 'pane' - update state min/max data
	,	_sizePane:			sizePane		// method -intended for user by plugins only!
	,	sizePane:			manualSizePane	// method - pass a 'pane' AND an 'outer-size' in pixels or percent, or 'auto'
	,	sizeContent:		sizeContent		// method - pass a 'pane'
	,	swapPanes:			swapPanes		// method - pass TWO 'panes' - will swap them
	,	showMasks:			showMasks		// method - pass a 'pane' OR list of panes - default = all panes with mask option set
	,	hideMasks:			hideMasks		// method - ditto'
	//	pane element methods
	,	initContent:		initContent		// method - ditto
	,	addPane:			addPane			// method - pass a 'pane'
	,	removePane:			removePane		// method - pass a 'pane' to remove from layout, add 'true' to delete the pane-elem
	,	createChildren:		createChildren	// method - pass a 'pane' and (optional) layout-options (OVERRIDES options[pane].children
	,	refreshChildren:	refreshChildren	// method - pass a 'pane' and a layout-instance
	//	special pane option setting
	,	enableClosable:		enableClosable	// method - pass a 'pane'
	,	disableClosable:	disableClosable	// method - ditto
	,	enableSlidable:		enableSlidable	// method - ditto
	,	disableSlidable:	disableSlidable	// method - ditto
	,	enableResizable:	enableResizable	// method - ditto
	,	disableResizable:	disableResizable// method - ditto
	//	utility methods for panes
	,	allowOverflow:		allowOverflow	// utility - pass calling element (this)
	,	resetOverflow:		resetOverflow	// utility - ditto
	//	layout control
	,	destroy:			destroy			// method - no parameters
	,	initPanes:			isInitialized	// method - no parameters
	,	resizeAll:			resizeAll		// method - no parameters
	//	callback triggering
	,	runCallbacks:		_runCallbacks	// method - pass evtName & pane (if a pane-event), eg: trigger("onopen", "west")
	//	alias collections of options, state and children - created in addPane and extended elsewhere
	,	hasParentLayout:	false			// set by initContainer()
	,	children:			children		// pointers to child-layouts, eg: Instance.children.west.layoutName
	,	north:				false			// alias group: { name: pane, pane: $Ps[pane], options: options[pane], state: state[pane], children: children[pane] }
	,	south:				false			// ditto
	,	west:				false			// ditto
	,	east:				false			// ditto
	,	center:				false			// ditto
	};

	// create the border layout NOW
	if (_create() === 'cancel') // onload_start callback returned false to CANCEL layout creation
		return null;
	else // true OR false -- if layout-elements did NOT init (hidden or do not exist), can auto-init later
		return Instance; // return the Instance object

}


/*	OLD versions of jQuery only set $.support.boxModel after page is loaded
 *	so if this is IE, use support.boxModel to test for quirks-mode (ONLY IE changes boxModel).
 */
$(function(){
	var b = $.layout.browser;
	if (b.msie) b.boxModel = $.support.boxModel;
});


})( jQuery );
// END Layout - keep internal vars internal!



// START Plugins - shared wrapper, no global vars
(function ($) {


/**
 * jquery.layout.state 1.0
 * $Date: 2015/11/21 $
 *
 * Copyright (c) 2012 
 *   Kevin Dalman (http://allpro.net)
 *
 * Dual licensed under the GPL (http://www.gnu.org/licenses/gpl.html)
 * and MIT (http://www.opensource.org/licenses/mit-license.php) licenses.
 *
 * @requires: UI Layout 1.3.0.rc30.1 or higher
 * @requires: $.ui.cookie (above)
 *
 * @see: http://groups.google.com/group/jquery-ui-layout
 */
/*
 *	State-management options stored in options.stateManagement, which includes a .cookie hash
 *	Default options saves ALL KEYS for ALL PANES, ie: pane.size, pane.isClosed, pane.isHidden
 *
 *	// STATE/COOKIE OPTIONS
 *	@example $(el).layout({
				stateManagement: {
					enabled:	true
				,	stateKeys:	"east.size,west.size,east.isClosed,west.isClosed"
				,	cookie:		{ name: "appLayout", path: "/" }
				}
			})
 *	@example $(el).layout({ stateManagement__enabled: true }) // enable auto-state-management using cookies
 *	@example $(el).layout({ stateManagement__cookie: { name: "appLayout", path: "/" } })
 *	@example $(el).layout({ stateManagement__cookie__name: "appLayout", stateManagement__cookie__path: "/" })
 *
 *	// STATE/COOKIE METHODS
 *	@example myLayout.saveCookie( "west.isClosed,north.size,south.isHidden", {expires: 7} );
 *	@example myLayout.loadCookie();
 *	@example myLayout.deleteCookie();
 *	@example var JSON = myLayout.readState();	// CURRENT Layout State
 *	@example var JSON = myLayout.readCookie();	// SAVED Layout State (from cookie)
 *	@example var JSON = myLayout.state.stateData;	// LAST LOADED Layout State (cookie saved in layout.state hash)
 *
 *	CUSTOM STATE-MANAGEMENT (eg, saved in a database)
 *	@example var JSON = myLayout.readState( "west.isClosed,north.size,south.isHidden" );
 *	@example myLayout.loadState( JSON );
 */

/**
 *	UI COOKIE UTILITY
 *
 *	A $.cookie OR $.ui.cookie namespace *should be standard*, but until then...
 *	This creates $.ui.cookie so Layout does not need the cookie.jquery.js plugin
 *	NOTE: This utility is REQUIRED by the layout.state plugin
 *
 *	Cookie methods in Layout are created as part of State Management 
 */
if (!$.ui) $.ui = {};
$.ui.cookie = {

	// cookieEnabled is not in DOM specs, but DOES works in all browsers,including IE6
	acceptsCookies: !!navigator.cookieEnabled

,	read: function (name) {
		var
			c		= document.cookie
		,	cs		= c ? c.split(';') : []
		,	pair	// loop var
		;
		for (var i=0, n=cs.length; i < n; i++) {
			pair = $.trim(cs[i]).split('='); // name=value pair
			if (pair[0] == name) // found the layout cookie
				return decodeURIComponent(pair[1]);

		}
		return null;
	}

,	write: function (name, val, cookieOpts) {
		var
			params	= ''
		,	date	= ''
		,	clear	= false
		,	o		= cookieOpts || {}
		,	x		= o.expires
		;
		if (x && x.toUTCString)
			date = x;
		else if (x === null || typeof x === 'number') {
			date = new Date();
			if (x > 0)
				date.setDate(date.getDate() + x);
			else {
				date.setFullYear(1970);
				clear = true;
			}
		}
		if (date)		params += ';expires='+ date.toUTCString();
		if (o.path)		params += ';path='+ o.path;
		if (o.domain)	params += ';domain='+ o.domain;
		if (o.secure)	params += ';secure';
		document.cookie = name +'='+ (clear ? "" : encodeURIComponent( val )) + params; // write or clear cookie
	}

,	clear: function (name) {
		$.ui.cookie.write(name, '', {expires: -1});
	}

};
// if cookie.jquery.js is not loaded, create an alias to replicate it
// this may be useful to other plugins or code dependent on that plugin
if (!$.cookie) $.cookie = function (k, v, o) {
	var C = $.ui.cookie;
	if (v === null)
		C.clear(k);
	else if (v === undefined)
		return C.read(k);
	else
		C.write(k, v, o);
};


// tell Layout that the state plugin is available
$.layout.plugins.stateManagement = true;

//	Add State-Management options to layout.defaults
$.layout.config.optionRootKeys.push("stateManagement");
$.layout.defaults.stateManagement = {
	enabled:		false	// true = enable state-management, even if not using cookies
,	autoSave:		true	// Save a state-cookie when page exits?
,	autoLoad:		true	// Load the state-cookie when Layout inits?
,	animateLoad:	true	// animate panes when loading state into an active layout
,	includeChildren: true	// recurse into child layouts to include their state as well
	// List state-data to save - must be pane-specific
,	stateKeys:	"north.size,south.size,east.size,west.size,"+
				"north.isClosed,south.isClosed,east.isClosed,west.isClosed,"+
				"north.isHidden,south.isHidden,east.isHidden,west.isHidden"
,	cookie: {
		name:	""	// If not specified, will use Layout.name, else just "Layout"
	,	domain:	""	// blank = current domain
	,	path:	""	// blank = current page, '/' = entire website
	,	expires: ""	// 'days' to keep cookie - leave blank for 'session cookie'
	,	secure:	false
	}
};
// Set stateManagement as a layout-option, NOT a pane-option
$.layout.optionsMap.layout.push("stateManagement");

/*
 *	State Management methods
 */
$.layout.state = {

	/**
	 * Get the current layout state and save it to a cookie
	 *
	 * myLayout.saveCookie( keys, cookieOpts )
	 *
	 * @param {Object}			inst
	 * @param {(string|Array)=}	keys
	 * @param {Object=}			cookieOpts
	 */
	saveCookie: function (inst, keys, cookieOpts) {
		var o	= inst.options
		,	sm	= o.stateManagement
		,	oC	= $.extend(true, {}, sm.cookie, cookieOpts || null)
		,	data = inst.state.stateData = inst.readState( keys || sm.stateKeys ) // read current panes-state
		;
		$.ui.cookie.write( oC.name || o.name || "Layout", $.layout.state.encodeJSON(data), oC );
		return $.extend(true, {}, data); // return COPY of state.stateData data
	}

	/**
	 * Remove the state cookie
	 *
	 * @param {Object}	inst
	 */
,	deleteCookie: function (inst) {
		var o = inst.options;
		$.ui.cookie.clear( o.stateManagement.cookie.name || o.name || "Layout" );
	}

	/**
	 * Read & return data from the cookie - as JSON
	 *
	 * @param {Object}	inst
	 */
,	readCookie: function (inst) {
		var o = inst.options;
		var c = $.ui.cookie.read( o.stateManagement.cookie.name || o.name || "Layout" );
		// convert cookie string back to a hash and return it
		return c ? $.layout.state.decodeJSON(c) : {};
	}

	/**
	 * Get data from the cookie and USE IT to loadState
	 *
	 * @param {Object}	inst
	 */
,	loadCookie: function (inst) {
		var c = $.layout.state.readCookie(inst); // READ the cookie
		if (c) {
			inst.state.stateData = $.extend(true, {}, c); // SET state.stateData
			inst.loadState(c); // LOAD the retrieved state
		}
		return c;
	}

	/**
	 * Update layout options from the cookie, if one exists
	 *
	 * @param {Object}		inst
	 * @param {Object=}		stateData
	 * @param {boolean=}	animate
	 */
,	loadState: function (inst, data, opts) {
		if (!$.isPlainObject( data ) || $.isEmptyObject( data )) return;

		// normalize data & cache in the state object
		data = inst.state.stateData = $.layout.transformData( data ); // panes = default subkey

		// add missing/default state-restore options
		var smo = inst.options.stateManagement;
		opts = $.extend({
			animateLoad:		false //smo.animateLoad
		,	includeChildren:	smo.includeChildren
		}, opts );

		if (!inst.state.initialized) {
			/*
			 *	layout NOT initialized, so just update its options
			 */
			// MUST remove pane.children keys before applying to options
			// use a copy so we don't remove keys from original data
			var o = $.extend(true, {}, data);
			//delete o.center; // center has no state-data - only children
			$.each($.layout.config.allPanes, function (idx, pane) {
				if (o[pane]) delete o[pane].children;		   
			 });
			// update CURRENT layout-options with saved state data
			$.extend(true, inst.options, o);
		}
		else {
			/*
			 *	layout already initialized, so modify layout's configuration
			 */
			var noAnimate = !opts.animateLoad
			,	o, c, h, state, open
			;
			$.each($.layout.config.borderPanes, function (idx, pane) {
				o = data[ pane ];
				if (!$.isPlainObject( o )) return; // no key, skip pane

				s	= o.size;
				c	= o.initClosed;
				h	= o.initHidden;
				ar	= o.autoResize
				state	= inst.state[pane];
				open	= state.isVisible;

				// reset autoResize
				if (ar)
					state.autoResize = ar;
				// resize BEFORE opening
				if (!open)
					inst._sizePane(pane, s, false, false, false); // false=skipCallback/noAnimation/forceResize
				// open/close as necessary - DO NOT CHANGE THIS ORDER!
				if (h === true)			inst.hide(pane, noAnimate);
				else if (c === true)	inst.close(pane, false, noAnimate);
				else if (c === false)	inst.open (pane, false, noAnimate);
				else if (h === false)	inst.show (pane, false, noAnimate);
				// resize AFTER any other actions
				if (open)
					inst._sizePane(pane, s, false, false, noAnimate); // animate resize if option passed
			});

			/*
			 *	RECURSE INTO CHILD-LAYOUTS
			 */
			if (opts.includeChildren) {
				var paneStateChildren, childState;
				$.each(inst.children, function (pane, paneChildren) {
					paneStateChildren = data[pane] ? data[pane].children : 0;
					if (paneStateChildren && paneChildren) {
						$.each(paneChildren, function (stateKey, child) {
							childState = paneStateChildren[stateKey];
							if (child && childState)
								child.loadState( childState );
						});
					}
				});
			}
		}
	}

	/**
	 * Get the *current layout state* and return it as a hash
	 *
	 * @param {Object=}		inst	// Layout instance to get state for
	 * @param {object=}		[opts]	// State-Managements override options
	 */
,	readState: function (inst, opts) {
		// backward compatility
		if ($.type(opts) === 'string') opts = { keys: opts };
		if (!opts) opts = {};
		var	sm		= inst.options.stateManagement
		,	ic		= opts.includeChildren
		,	recurse	= ic !== undefined ? ic : sm.includeChildren
		,	keys	= opts.stateKeys || sm.stateKeys
		,	alt		= { isClosed: 'initClosed', isHidden: 'initHidden' }
		,	state	= inst.state
		,	panes	= $.layout.config.allPanes
		,	data	= {}
		,	pair, pane, key, val
		,	ps, pC, child, array, count, branch
		;
		if ($.isArray(keys)) keys = keys.join(",");
		// convert keys to an array and change delimiters from '__' to '.'
		keys = keys.replace(/__/g, ".").split(',');
		// loop keys and create a data hash
		for (var i=0, n=keys.length; i < n; i++) {
			pair = keys[i].split(".");
			pane = pair[0];
			key  = pair[1];
			if ($.inArray(pane, panes) < 0) continue; // bad pane!
			val = state[ pane ][ key ];
			if (val == undefined) continue;
			if (key=="isClosed" && state[pane]["isSliding"])
				val = true; // if sliding, then *really* isClosed
			( data[pane] || (data[pane]={}) )[ alt[key] ? alt[key] : key ] = val;
		}

		// recurse into the child-layouts for each pane
		if (recurse) {
			$.each(panes, function (idx, pane) {
				pC = inst.children[pane];
				ps = state.stateData[pane];
				if ($.isPlainObject( pC ) && !$.isEmptyObject( pC )) {
					// ensure a key exists for this 'pane', eg: branch = data.center
					branch = data[pane] || (data[pane] = {});
					if (!branch.children) branch.children = {};
					$.each( pC, function (key, child) {
						// ONLY read state from an initialize layout
						if ( child.state.initialized )
							branch.children[ key ] = $.layout.state.readState( child );
						// if we have PREVIOUS (onLoad) state for this child-layout, KEEP IT!
						else if ( ps && ps.children && ps.children[ key ] ) {
							branch.children[ key ] = $.extend(true, {}, ps.children[ key ] );
						}
					});
				}
			});
		}

		return data;
	}

	/**
	 *	Stringify a JSON hash so can save in a cookie or db-field
	 */
,	encodeJSON: function (JSON) {
		return parse(JSON);
		function parse (h) {
			var D=[], i=0, k, v, t // k = key, v = value
			,	a = $.isArray(h)
			;
			for (k in h) {
				v = h[k];
				t = typeof v;
				if (t == 'string')		// STRING - add quotes
					v = '"'+ v +'"';
				else if (t == 'object')	// SUB-KEY - recurse into it
					v = parse(v);
				D[i++] = (!a ? '"'+ k +'":' : '') + v;
			}
			return (a ? '[' : '{') + D.join(',') + (a ? ']' : '}');
		};
	}

	/**
	 *	Convert stringified JSON back to a hash object
	 *	@see		$.parseJSON(), adding in jQuery 1.4.1
	 */
,	decodeJSON: function (str) {
		try { return $.parseJSON ? $.parseJSON(str) : window["eval"]("("+ str +")") || {}; }
		catch (e) { return {}; }
	}


,	_create: function (inst) {
		var _	= $.layout.state
		,	o	= inst.options
		,	sm	= o.stateManagement
		;
		//	ADD State-Management plugin methods to inst
		 $.extend( inst, {
		//	readCookie - update options from cookie - returns hash of cookie data
			readCookie:		function () { return _.readCookie(inst); }
		//	deleteCookie
		,	deleteCookie:	function () { _.deleteCookie(inst); }
		//	saveCookie - optionally pass keys-list and cookie-options (hash)
		,	saveCookie:		function (keys, cookieOpts) { return _.saveCookie(inst, keys, cookieOpts); }
		//	loadCookie - readCookie and use to loadState() - returns hash of cookie data
		,	loadCookie:		function () { return _.loadCookie(inst); }
		//	loadState - pass a hash of state to use to update options
		,	loadState:		function (stateData, opts) { _.loadState(inst, stateData, opts); }
		//	readState - returns hash of current layout-state
		,	readState:		function (keys) { return _.readState(inst, keys); }
		//	add JSON utility methods too...
		,	encodeJSON:		_.encodeJSON
		,	decodeJSON:		_.decodeJSON
		});

		// init state.stateData key, even if plugin is initially disabled
		inst.state.stateData = {};

		// autoLoad MUST BE one of: data-array, data-hash, callback-function, or TRUE
		if ( !sm.autoLoad ) return;

		//	When state-data exists in the autoLoad key USE IT,
		//	even if stateManagement.enabled == false
		if ($.isPlainObject( sm.autoLoad )) {
			if (!$.isEmptyObject( sm.autoLoad )) {
				inst.loadState( sm.autoLoad );
			}
		}
		else if ( sm.enabled ) {
			// update the options from cookie or callback
			// if options is a function, call it to get stateData
			if ($.isFunction( sm.autoLoad )) {
				var d = {};
				try {
					d = sm.autoLoad( inst, inst.state, inst.options, inst.options.name || '' ); // try to get data from fn
				} catch (e) {}
				if (d && $.isPlainObject( d ) && !$.isEmptyObject( d ))
					inst.loadState(d);
			}
			else // any other truthy value will trigger loadCookie
				inst.loadCookie();
		}
	}

,	_unload: function (inst) {
		var sm = inst.options.stateManagement;
		if (sm.enabled && sm.autoSave) {
			// if options is a function, call it to save the stateData
			if ($.isFunction( sm.autoSave )) {
				try {
					sm.autoSave( inst, inst.state, inst.options, inst.options.name || '' ); // try to get data from fn
				} catch (e) {}
			}
			else // any truthy value will trigger saveCookie
				inst.saveCookie();
		}
	}

};

// add state initialization method to Layout's onCreate array of functions
$.layout.onCreate.push( $.layout.state._create );
$.layout.onUnload.push( $.layout.state._unload );




/**
 * jquery.layout.buttons 1.0
 * $Date: 2015/11/21 $
 *
 * Copyright (c) 2012 
 *   Kevin Dalman (http://allpro.net)
 *
 * Dual licensed under the GPL (http://www.gnu.org/licenses/gpl.html)
 * and MIT (http://www.opensource.org/licenses/mit-license.php) licenses.
 *
 * @requires: UI Layout 1.3.0.rc30.1 or higher
 *
 * @see: http://groups.google.com/group/jquery-ui-layout
 *
 * Docs: [ to come ]
 * Tips: [ to come ]
 */

// tell Layout that the state plugin is available
$.layout.plugins.buttons = true;

//	Add buttons options to layout.defaults
$.layout.defaults.autoBindCustomButtons = false;
// Specify autoBindCustomButtons as a layout-option, NOT a pane-option
$.layout.optionsMap.layout.push("autoBindCustomButtons");

/*
 *	Button methods
 */
$.layout.buttons = {

	/**
	* Searches for .ui-layout-button-xxx elements and auto-binds them as layout-buttons
	*
	* @see  _create()
	*
	* @param  {Object}		inst	Layout Instance object
	*/
	init: function (inst) {
		var pre		= "ui-layout-button-"
		,	layout	= inst.options.name || ""
		,	name;
		$.each("toggle,open,close,pin,toggle-slide,open-slide".split(","), function (i, action) {
			$.each($.layout.config.borderPanes, function (ii, pane) {
				$("."+pre+action+"-"+pane).each(function(){
					// if button was previously 'bound', data.layoutName was set, but is blank if layout has no 'name'
					name = $(this).data("layoutName") || $(this).attr("layoutName");
					if (name == undefined || name === layout)
						inst.bindButton(this, action, pane);
				});
			});
		});
	}

	/**
	* Helper function to validate params received by addButton utilities
	*
	* Two classes are added to the element, based on the buttonClass...
	* The type of button is appended to create the 2nd className:
	*  - ui-layout-button-pin		// action btnClass
	*  - ui-layout-button-pin-west	// action btnClass + pane
	*  - ui-layout-button-toggle
	*  - ui-layout-button-open
	*  - ui-layout-button-close
	*
	* @param {Object}			inst		Layout Instance object
	* @param {(string|!Object)}	selector	jQuery selector (or element) for button, eg: ".ui-layout-north .toggle-button"
	* @param {string}   		pane 		Name of the pane the button is for: 'north', 'south', etc.
	*
	* @return {Array.<Object>}	If both params valid, the element matching 'selector' in a jQuery wrapper - otherwise returns null
	*/
,	get: function (inst, selector, pane, action) {
		var $E	= $(selector)
		,	o	= inst.options
		,	err	= o.errors.addButtonError
		;
		if (!$E.length) { // element not found
			$.layout.msg(err +" "+ o.errors.selector +": "+ selector, true);
		}
		else if ($.inArray(pane, $.layout.config.borderPanes) < 0) { // invalid 'pane' sepecified
			$.layout.msg(err +" "+ o.errors.pane +": "+ pane, true);
			$E = $("");  // NO BUTTON
		}
		else { // VALID
			var btn = o[pane].buttonClass +"-"+ action;
			$E	.addClass( btn +" "+ btn +"-"+ pane )
				.data("layoutName", o.name); // add layout identifier - even if blank!
		}
		return $E;
	}


	/**
	* NEW syntax for binding layout-buttons - will eventually replace addToggle, addOpen, etc.
	*
	* @param {Object}			inst		Layout Instance object
	* @param {(string|!Object)}	selector	jQuery selector (or element) for button, eg: ".ui-layout-north .toggle-button"
	* @param {string}			action
	* @param {string}			pane
	*/
,	bind: function (inst, selector, action, pane) {
		var _ = $.layout.buttons;
		switch (action.toLowerCase()) {
			case "toggle":			_.addToggle	(inst, selector, pane); break;	
			case "open":			_.addOpen	(inst, selector, pane); break;
			case "close":			_.addClose	(inst, selector, pane); break;
			case "pin":				_.addPin	(inst, selector, pane); break;
			case "toggle-slide":	_.addToggle	(inst, selector, pane, true); break;	
			case "open-slide":		_.addOpen	(inst, selector, pane, true); break;
		}
		return inst;
	}

	/**
	* Add a custom Toggler button for a pane
	*
	* @param {Object}			inst		Layout Instance object
	* @param {(string|!Object)}	selector	jQuery selector (or element) for button, eg: ".ui-layout-north .toggle-button"
	* @param {string}  			pane 		Name of the pane the button is for: 'north', 'south', etc.
	* @param {boolean=}			slide 		true = slide-open, false = pin-open
	*/
,	addToggle: function (inst, selector, pane, slide) {
		$.layout.buttons.get(inst, selector, pane, "toggle")
			.click(function(evt){
				inst.toggle(pane, !!slide);
				evt.stopPropagation();
			});
		return inst;
	}

	/**
	* Add a custom Open button for a pane
	*
	* @param {Object}			inst		Layout Instance object
	* @param {(string|!Object)}	selector	jQuery selector (or element) for button, eg: ".ui-layout-north .toggle-button"
	* @param {string}			pane 		Name of the pane the button is for: 'north', 'south', etc.
	* @param {boolean=}			slide 		true = slide-open, false = pin-open
	*/
,	addOpen: function (inst, selector, pane, slide) {
		$.layout.buttons.get(inst, selector, pane, "open")
			.attr("title", $textUtils.getText(infaw.portlet.I18nResources.OPEN))
			.click(function (evt) {
				inst.open(pane, !!slide);
				evt.stopPropagation();
			});
		return inst;
	}

	/**
	* Add a custom Close button for a pane
	*
	* @param {Object}			inst		Layout Instance object
	* @param {(string|!Object)}	selector	jQuery selector (or element) for button, eg: ".ui-layout-north .toggle-button"
	* @param {string}   		pane 		Name of the pane the button is for: 'north', 'south', etc.
	*/
,	addClose: function (inst, selector, pane) {
		$.layout.buttons.get(inst, selector, pane, "close")
			.attr("title", $textUtils.getText(infaw.portlet.I18nResources.CLOSE))
			.click(function (evt) {
				inst.close(pane);
				evt.stopPropagation();
			});
		return inst;
	}

	/**
	* Add a custom Pin button for a pane
	*
	* Four classes are added to the element, based on the paneClass for the associated pane...
	* Assuming the default paneClass and the pin is 'up', these classes are added for a west-pane pin:
	*  - ui-layout-pane-pin
	*  - ui-layout-pane-west-pin
	*  - ui-layout-pane-pin-up
	*  - ui-layout-pane-west-pin-up
	*
	* @param {Object}			inst		Layout Instance object
	* @param {(string|!Object)}	selector	jQuery selector (or element) for button, eg: ".ui-layout-north .toggle-button"
	* @param {string}   		pane 		Name of the pane the pin is for: 'north', 'south', etc.
	*/
,	addPin: function (inst, selector, pane) {
		var	_	= $.layout.buttons
		,	$E	= _.get(inst, selector, pane, "pin");
		if ($E.length) {
			var s = inst.state[pane];
			$E.click(function (evt) {
				_.setPinState(inst, $(this), pane, (s.isSliding || s.isClosed));
				if (s.isSliding || s.isClosed) inst.open( pane ); // change from sliding to open
				else inst.close( pane ); // slide-closed
				evt.stopPropagation();
			});
			// add up/down pin attributes and classes
			_.setPinState(inst, $E, pane, (!s.isClosed && !s.isSliding));
			// add this pin to the pane data so we can 'sync it' automatically
			// PANE.pins key is an array so we can store multiple pins for each pane
			s.pins.push( selector ); // just save the selector string
		}
		return inst;
	}

	/**
	* Change the class of the pin button to make it look 'up' or 'down'
	*
	* @see  addPin(), syncPins()
	*
	* @param {Object}			inst	Layout Instance object
	* @param {Array.<Object>}	$Pin	The pin-span element in a jQuery wrapper
	* @param {string}			pane	These are the params returned to callbacks by layout()
	* @param {boolean}			doPin	true = set the pin 'down', false = set it 'up'
	*/
,	setPinState: function (inst, $Pin, pane, doPin) {
		var updown = $Pin.attr("pin");
		if (updown && doPin === (updown=="down")) return; // already in correct state
		var
			o		= inst.options[pane]
		,	pin		= o.buttonClass +"-pin"
		,	side	= pin +"-"+ pane
		,	UP		= pin +"-up "+	side +"-up"
		,	DN		= pin +"-down "+side +"-down"
		;
		$Pin
			.attr("pin", doPin ? "down" : "up") // logic
			.attr("title", doPin ? $textUtils.getText(infaw.portlet.I18nResources.UNPIN) : $textUtils.getText(infaw.portlet.I18nResources.PIN))
			.removeClass( doPin ? UP : DN ) 
			.addClass( doPin ? DN : UP ) 
		;
	}

	/**
	* INTERNAL function to sync 'pin buttons' when pane is opened or closed
	* Unpinned means the pane is 'sliding' - ie, over-top of the adjacent panes
	*
	* @see  open(), close()
	*
	* @param {Object}			inst	Layout Instance object
	* @param {string}	pane	These are the params returned to callbacks by layout()
	* @param {boolean}	doPin	True means set the pin 'down', False means 'up'
	*/
,	syncPinBtns: function (inst, pane, doPin) {
		// REAL METHOD IS _INSIDE_ LAYOUT - THIS IS HERE JUST FOR REFERENCE
		$.each(inst.state[pane].pins, function (i, selector) {
			$.layout.buttons.setPinState(inst, $(selector), pane, doPin);
		});
	}


,	_load: function (inst) {
		var	_	= $.layout.buttons;
		// ADD Button methods to Layout Instance
		// Note: sel = jQuery Selector string
		$.extend( inst, {
			bindButton:		function (sel, action, pane) { return _.bind(inst, sel, action, pane); }
		//	DEPRECATED METHODS
		,	addToggleBtn:	function (sel, pane, slide) { return _.addToggle(inst, sel, pane, slide); }
		,	addOpenBtn:		function (sel, pane, slide) { return _.addOpen(inst, sel, pane, slide); }
		,	addCloseBtn:	function (sel, pane) { return _.addClose(inst, sel, pane); }
		,	addPinBtn:		function (sel, pane) { return _.addPin(inst, sel, pane); }
		});

		// init state array to hold pin-buttons
		for (var i=0; i<4; i++) {
			var pane = $.layout.config.borderPanes[i];
			inst.state[pane].pins = [];
		}

		// auto-init buttons onLoad if option is enabled
		if ( inst.options.autoBindCustomButtons )
			_.init(inst);
	}

,	_unload: function (inst) {
		// TODO: unbind all buttons???
	}

};

// add initialization method to Layout's onLoad array of functions
$.layout.onLoad.push(  $.layout.buttons._load );
//$.layout.onUnload.push( $.layout.buttons._unload );



/**
 * jquery.layout.browserZoom 1.0
 * $Date: 2015/11/21 $
 *
 * Copyright (c) 2012 
 *   Kevin Dalman (http://allpro.net)
 *
 * Dual licensed under the GPL (http://www.gnu.org/licenses/gpl.html)
 * and MIT (http://www.opensource.org/licenses/mit-license.php) licenses.
 *
 * @requires: UI Layout 1.3.0.rc30.1 or higher
 *
 * @see: http://groups.google.com/group/jquery-ui-layout
 *
 * TODO: Extend logic to handle other problematic zooming in browsers
 * TODO: Add hotkey/mousewheel bindings to _instantly_ respond to these zoom event
 */

// tell Layout that the plugin is available
$.layout.plugins.browserZoom = true;

$.layout.defaults.browserZoomCheckInterval = 1000;
$.layout.optionsMap.layout.push("browserZoomCheckInterval");

/*
 *	browserZoom methods
 */
$.layout.browserZoom = {

	_init: function (inst) {
		// abort if browser does not need this check
		if ($.layout.browserZoom.ratio() !== false)
			$.layout.browserZoom._setTimer(inst);
	}

,	_setTimer: function (inst) {
		// abort if layout destroyed or browser does not need this check
		if (inst.destroyed) return;
		var o	= inst.options
		,	s	= inst.state
		//	don't need check if inst has parentLayout, but check occassionally in case parent destroyed!
		//	MINIMUM 100ms interval, for performance
		,	ms	= inst.hasParentLayout ?  5000 : Math.max( o.browserZoomCheckInterval, 100 )
		;
		// set the timer
		setTimeout(function(){
			if (inst.destroyed || !o.resizeWithWindow) return;
			var d = $.layout.browserZoom.ratio();
			if (d !== s.browserZoom) {
				s.browserZoom = d;
				inst.resizeAll();
			}
			// set a NEW timeout
			$.layout.browserZoom._setTimer(inst);
		}
		,	ms );
	}

,	ratio: function () {
		var w	= window
		,	s	= screen
		,	d	= document
		,	dE	= d.documentElement || d.body
		,	b	= $.layout.browser
		,	v	= b.version
		,	r, sW, cW
		;
		// we can ignore all browsers that fire window.resize event onZoom
		if ((b.msie && v > 8)
		||	!b.msie
		) return false; // don't need to track zoom

		if (s.deviceXDPI && s.systemXDPI) // syntax compiler hack
			return calc(s.deviceXDPI, s.systemXDPI);
		// everything below is just for future reference!
		if (b.webkit && (r = d.body.getBoundingClientRect))
			return calc((r.left - r.right), d.body.offsetWidth);
		if (b.webkit && (sW = w.outerWidth))
			return calc(sW, w.innerWidth);
		if ((sW = s.width) && (cW = dE.clientWidth))
			return calc(sW, cW);
		return false; // no match, so cannot - or don't need to - track zoom

		function calc (x,y) { return (parseInt(x,10) / parseInt(y,10) * 100).toFixed(); }
	}

};
// add initialization method to Layout's onLoad array of functions
$.layout.onReady.push( $.layout.browserZoom._init );


})( jQuery );
$.Class('infaw.portlet.AbstractPortlet', {
	_blockElementId: undefined,
	_$portletDiv: undefined,
	_instanceId: undefined,
	_readOnly: undefined,
	
	_customPropMap: null,
	
	_configManager: null,
	
	/**
	 * Parameters:
	 *  - blockElementId: the id of the DOM element where the portlet content is to be added
	 *  - instanceId: It is a unique namespaced identifier for a portlet instance
	 *                Every portlet implementation jsClass class can use instanceId or getInstanceId API to get it
	 *  - customPropMap: It is a map of custom property key(id) value pair
	 */
	init: function(blockElementId, instanceId, customPropMap) {
		this._blockElementId = blockElementId;
		this._$portletDiv = $('#'+ blockElementId);
		
		this._$portletDiv.on('onPortletResize', $.proxy(function(){
			this.onResize();
		}, this));
		
		this._instanceId = instanceId;
		this._customPropMap = customPropMap;
		this._registerEvent();
		this._configManager = infaw.configuration.ConfigurationManager.instance();
		
		var bg = this.getBackground();
		if (bg) {
			var $portlet = this._$portletDiv.closest(':infaPortlet');
			var portlet = $.getWidget($portlet, 'infaPortlet');
			portlet.setBackground(bg);
		}
	},
	
	/**
	 * Returns the fully qualified id of this portlet instance. See instanceId in init().
	 */
	getInstanceId: function() {
		return this._instanceId;
	},
	
	/**
	 * Subclasses can override this to specify a different background color for the panel.
	 */
	getBackground: function() {
		return undefined;
	},
	
	setReadOnly: function(readOnly) {
		if (this._readOnly !== readOnly) {
			this._readOnly = readOnly;
			this.readOnlyChanged();
		}
	},
	
	isReadOnly: function() {
		return this._readOnly;
	},

	/**
	 * Subclasses can override this to handle the change of state
	 */
	readOnlyChanged: function() {
	},
	
	refreshMenu: function() {
		var $portlet = this._$portletDiv.closest(':infaPortlet');
		var infaPortlet = $.getWidget($portlet, 'infaPortlet');
		if (infaPortlet.hasMenuDropDown()) {
			if(this.eMenu === undefined) {
				this.eMenu = infaPortlet.getMenuWidget();
			}
			this.eMenu.refreshState();			
		}
	},
	
	/**
	 * fired when the configuration of the portlet is changed
	 * Parameters:
	 * props - key value pairs of config properties
	 */
	onConfigChange: function(props){
	},
	/**
	 * fired when any property value is changed on the portlet configuration
	 * name - property name
	 * value - property value
	 */
	onCustomPropertyChange: function(propId, propVal){
	},
	
	/**
	 * Returns the jQuery object representing this portlet
	 */
	getPortletElem: function() {
		return this._$portletDiv;
	},
	
	getPortletElemId: function() {
		return this._blockElementId;
	},
	
	_getEventManager: function() {
		var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		return workspace.getEventManager();
	},
	
	_registerEvent: function(){
		var self = this;
		var eventMgr = this._getEventManager();
		if (eventMgr) {
			eventMgr.registerEvents({				
				'onCustomPropertyChange': function(event, obj){
					if(obj.panelInstanceId == self._instanceId){
						self.onCustomPropertyChange(obj.customPropertyId, obj.customPropertyValue);
					}
			    },
			    'onConfigChange': function(event, obj){
					if(obj.panelInstanceId == self._instanceId){
						self.onConfigChange(obj.config);
					}
			    }
			});
		}
	},
	
	onResize: function(){},
	
	/**
	 * Returns saved property value for the key
	 */
	getProperty: function(key){
		var $deferred = $.Deferred();
		var inputconfigArr = [];
		inputconfigArr.push(key);
		this._configManager.getConfigs(inputconfigArr).done(function(returnArr){
			if(returnArr.length === 0 ){
				$deferred.resolve(null);
			}else{
				$deferred.resolve(returnArr[0]['value']);
			}
		});
		return $deferred.promise();
	},
	
	/**
	 * Save property
	 */
	saveProperty: function(key, value){
		var $deferred = $.Deferred();
		var inputconfigArr = [];
		inputconfigArr.push({'key': key, 'value': value});
		this._configManager.updateConfigs(inputconfigArr).done(function(){
				$deferred.resolve();
		});
		return $deferred.promise();
	},
	
		
	/**
	 * delete property 
	 */
	deleteProperty: function(key){
		var $deferred = $.Deferred();
		var inputconfigArr = [];
		inputconfigArr.push(key);
		this._configManager.deleteConfigs(inputconfigArr).done(function(){
				$deferred.resolve();
		});
		return $deferred.promise();
	},
	
	/**
	 * save portlet custom property defined in the extension point
	 * params: custom property id and value 
	 */
	savePortletCustomProperty: function(propId, propValue){
		var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		if(workspace){
			var portletContainer = workspace.getPortletContainer();
			if(portletContainer){
				var portletConfigCache = portletContainer.getPortletConfigCache();
				if(portletConfigCache){
					portletConfigCache.saveProperty(this._instanceId, propId, propValue);
					//now fire an event to contextual panel if it is open for this portlet
					if(workspace.isFloatPanelVisible()){
						var currFloatPanel = workspace.getFloatPanel();
						if(currFloatPanel.getUIContext() === this._instanceId){
							var eventMgr = this._getEventManager();
							var that = this;
							eventMgr.sendEvent('onCustomPropChangeForContextualPanel', {							
								panelInstanceId: that._instanceId,
								customPropertyId: propId,
								customPropertyValue: propValue
							});
						}
					}
				}
			}
		}
	},
	
	getPortletCustomProperty: function(propId){
		var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		if(workspace){
			var portletContainer = workspace.getPortletContainer();
			if(portletContainer){
				var portletConfigCache = portletContainer.getPortletConfigCache();
				if(portletConfigCache){
					return portletConfigCache.getPanelProperty(this._instanceId, propId);
				}
			}
		}
	},
	
	/**
	 * return the help id for the portlet 
	 *  
	 */
	getHelpId: function(){
		return null;
	},
	
	onLoaded: function() {
		$('#' + this._blockElementId).trigger("onPortletLoaded");
	},
	
	/**
	 * Returns the outermost jQuery portlet
	 */
	getOuterPortlet: function() {
		return this._$portletDiv.closest(':infaPortlet')
	}
	
});

/**
 * @author clam
 */
$.Class('infaw.portlet.PortletUtils',
		
	// static methods 
	{  
		_instance : undefined,
	
		instance : function(){
			if (infaw.portlet.PortletUtils._instance == undefined)
				infaw.portlet.PortletUtils._instance = new infaw.portlet.PortletUtils();         
			return infaw.portlet.PortletUtils._instance;
		} 
	},
	
	// prototype methods
	{
		
		/**
		 * Returns the portlet instance for the given child DOM element.
		 */
		getPortletInstance: function($elem) { 
			var $portlet = $elem.closest(':infaPortlet');
			var $portletContainer = $portlet.closest(':portletContainer');
			var portletContainer = $.getWidget($portletContainer, 'portletContainer');
			return portletContainer ? portletContainer.getPortletInstance($portlet) : undefined;
		},
		
		/**
		 * Returns the workspace instance for the given child DOM element.
		 */
		getWorkspace: function($elem) {
			var $portlet = $elem.closest(':infaPortlet');
			if ($portlet) {
				return $portlet.data('workspace');
			}
		},
		
		/**
		 * Returns the event manager associated with the given DOM element.
		 */
		getEventManager: function($elem) {
			var $portlet = $elem.closest(':infaPortlet');
			if ($portlet) {
				var workspace = $portlet.data('workspace');
				if (workspace) {
					return workspace.getEventManager();
				}
			}
		}
		
	}
);

/**
 * This manager class is responsible for reading portlet extension point. 
 * Both PortletConfigurationProvider and PortletContainer can call the APIs in this class to get extensions
 * corresponding to a portlet provider/portletDesciptor. The extensions are read once at the time of startup and are cached for later use.
 * 
 */

$.Class("infaw.portlet.PortletExtensionManager", 
{
	LEFT_PORTLET_ID_SUFFIX: '##left',
	
	_instance : undefined,
	
	_portletIdToDescriptorExtensionMap: {},
	
	_configIdToConfigExtensionMap: {},
	
	_workspaceIdToExtensionsMap: {},
	
	// map of portlet descriptor id to the action contributions
	_portletIdToActionExtsMap: {},
	
	// map of action handler id to the extension
	_actionHandlerIdToExtMap: {},

	instance : function(){
		if (infaw.portlet.PortletExtensionManager._instance == undefined)
			infaw.portlet.PortletExtensionManager._instance = new infaw.portlet.PortletExtensionManager();         
		return infaw.portlet.PortletExtensionManager._instance;
	}  

},
{
	intialized: false,
	
	_initialize : function() {
		var $deferred = $.Deferred();				
		var that = this;
		var reader = infa.extensibility.ExtensionReader.instance();
		reader.read("com.informatica.tools.web.shell.portletContainer").done(				
			/**
			 * extensions array containing portletProviders or portletDescriptors or portletConfigDescriptors
			 * 
			 * @param {Array.<{$configElem, $workspaceId, $portletId, $configId, portletInstance: Array.<{$configId, $instanceId, $position, $label}>, portletConfig: Array.<{$configId, nonOverridable}>,
			 *  $label, $icon, $jsClass, $packageId, $hasDropdown, $columnSpan, $rowSpan, $minWidth, $defaultPortletConfigId, customPropertyProvider: Object.<{$customPropertiesJSCallback, customPropertyDescriptor: Array.<{$id, $displayName, $defaultValue, $required}>}>,
			 *  $portletDescriptorId, $closable, $movable, $maximizable, customProperty: Array.<{$id, $value}>}>} extensions
			 *        
			 */
			function(extensions) {			
				that.addExtensions(extensions);
				that.intialized = true;
				$deferred.resolve();
			}
		);	
		
		return $deferred.promise();
	},
	
	getPortletProviderExtensions: function(workspaceId){
		var $deferred = $.Deferred();
		var self = this;
		if(!this.intialized) {
			var $initDeferred = this._initialize();
			$initDeferred.done(function() {
				$deferred.resolve(infaw.portlet.PortletExtensionManager._workspaceIdToExtensionsMap[workspaceId]);
			});									  	
		} else {
			$deferred.resolve(infaw.portlet.PortletExtensionManager._workspaceIdToExtensionsMap[workspaceId]);
		}
		
		return $deferred.promise();
	},
	
	getPortletDescriptorExtension: function(portletId){
		var $deferred = $.Deferred();
		var self = this;
		if(!this.intialized) {
			var $initDeferred = this._initialize();
			$initDeferred.done(function() {
				$deferred.resolve(infaw.portlet.PortletExtensionManager._portletIdToDescriptorExtensionMap[portletId]);
			});									  	
		} else {
			$deferred.resolve(infaw.portlet.PortletExtensionManager._portletIdToDescriptorExtensionMap[portletId]);
		}
		
		return $deferred.promise();
	},
	
	getPortletConfigExtension: function(configId){
		var $deferred = $.Deferred();
		var self = this;
		if(!this.intialized) {
			var $initDeferred = this._initialize();
			$initDeferred.done(function() {
				$deferred.resolve(infaw.portlet.PortletExtensionManager._configIdToConfigExtensionMap[configId]);
			});									  	
		} else {
			$deferred.resolve(infaw.portlet.PortletExtensionManager._configIdToConfigExtensionMap[configId]);
		}
		
		return $deferred.promise();
	},
	
	getActionContributionExtnsMap: function() {
		var $deferred = $.Deferred();
		var self = this;
		if(!this.intialized) {
			var $initDeferred = this._initialize();
			$initDeferred.done(function() {
				$deferred.resolve(infaw.portlet.PortletExtensionManager._portletIdToActionExtsMap);
			});									  	
		} else {
			$deferred.resolve(infaw.portlet.PortletExtensionManager._portletIdToActionExtsMap);
		}
		
		return $deferred.promise();
	},
	
	getActionHandler: function(actionId) {
		var $deferred = $.Deferred();
		var self = this;
		if(!this.intialized) {
			var $initDeferred = this._initialize();
			$initDeferred.done(function() {
				$deferred.resolve(infaw.portlet.PortletExtensionManager._actionHandlerIdToExtMap[actionId]);
			});									  	
		} else {
			$deferred.resolve(infaw.portlet.PortletExtensionManager._actionHandlerIdToExtMap[actionId]);
		}
		
		return $deferred.promise();
	},
	
	addExtensions : function(extensions){
		for(var index in extensions) {
			var extension = extensions[index];
			if(extension.$configElem == 'portletProvider'){
				if(infaw.portlet.PortletExtensionManager._workspaceIdToExtensionsMap[extension.$workspaceId] == undefined){
					infaw.portlet.PortletExtensionManager._workspaceIdToExtensionsMap[extension.$workspaceId] = [];
				}
				var providerIDExtensionsArray = infaw.portlet.PortletExtensionManager._workspaceIdToExtensionsMap[extension.$workspaceId];
				providerIDExtensionsArray.push(extension);
			}else if(extension.$configElem =='portletDescriptor'){
				infaw.portlet.PortletExtensionManager._portletIdToDescriptorExtensionMap[extension.$portletId] = extension;
			}else if(extension.$configElem =='portletConfigDescriptor'){
				infaw.portlet.PortletExtensionManager._configIdToConfigExtensionMap[extension.$configId] = extension;
			} else if (extension.$configElem == 'actionContribution') {
				var portletDescId = extension.$portletDescriptorId;
				if (extension.$alignment === 'left') {
					portletDescId += infaw.portlet.PortletExtensionManager.LEFT_PORTLET_ID_SUFFIX;
				}
				var extnsArr = infaw.portlet.PortletExtensionManager._portletIdToActionExtsMap[portletDescId];
				if(extnsArr) {
					extnsArr.push(extension);
				} else {
					extnsArr = [];
					extnsArr.push(extension);
					infaw.portlet.PortletExtensionManager._portletIdToActionExtsMap[portletDescId] = extnsArr;
				}
			} else if (extension.$configElem == 'actionHandler') {
				infaw.portlet.PortletExtensionManager._actionHandlerIdToExtMap[extension.$id] = extension;
			}
		}
	}
	
});
	 	

/**
 * @author akukreja 
 * A UI control for panel configuration
 * Notes: This file is not used as of now. We can use when we want configurable panels
 */

$.Class("infaw.portlet.PortletConfigComposite", 
{
	//static variables
	EMPTY_PORTLET_CONFIGID : '__infaEmptyPanelConfig' 
},
{
	//panel widget which this composite is editing
	currentPortlet:  undefined,
	
	//current template instance
	currentTemplateInstance: undefined,
	
	//current portlet config
	currentPortletConfig: undefined,
	
	//current config
	currentPortletDescriptor: undefined,
	
	//default config-map for the active configuration
	defaultConfigProps: undefined,
	
	//portletKey
	portletKey: undefined,
	
	portletConfigCache: undefined,
	
	init: function(portlet, portletConfigCache) {
		this.currentPortlet = portlet;
		this.portletKey = portlet.getWidgetId();
		this.portletConfigCache = portletConfigCache;
	},
	
		
	
	/**
	 * create a UI control as well as handle updates to the UI.
	 */
	createUI: function(blockElementID, paletteDeferred) {
		this.$controlDiv = $('#'+ blockElementID);	
		this.$controlDiv.children().remove();
		
		var $infaTabs = $('<div id="' + $.htmlId('panelConfigControlTabs') + '"></div>').appendTo(this.$controlDiv).infaTabs();		
		
		this._infaTabs = $.getWidget($infaTabs, 'infaTabs');
		
		var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		this._eventManager = workspace.getEventManager();
		
		var that = this;

		//check if it already has a configId in the preference - means the portlet has been created
		//already amd opened for edit
		var configId = this.portletConfigCache.getPanelProperty(this.portletKey,'$$configId');
		if(configId && configId != '__infaEmptyPanelConfig'){
			var $portletDetailsPromise = that._getPortletDetailsPromise(configId);				
			$portletDetailsPromise.then(function(portletConfig, portletDescriptor){
				that.currentPortletConfig = portletConfig;
				that.currentPortletDescriptor = portletDescriptor;
				//that._setTemplate(portletConfig.$portletDescriptorId, configId);
				//$templateField.setValue(portletConfig.$portletDescriptorId);
			});
		}
		
		// add the tabs
		var $i18nAlias = infaw.portlet.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		
		//general tab
		var tab = this._infaTabs.add($textUtils.getText($i18nAlias.GENERAL), undefined, false);
		$(tab).data('tabId', 'general');
		var id = tab.id;

		//configure tab
		tab = this._infaTabs.add($textUtils.getText($i18nAlias.CONFIGURATION), undefined, false);
		$(tab).data('tabId', 'configuration');
		
		this._populateGeneralTab(id, paletteDeferred);

	},
	
	_populateGeneralTab: function(blockElementID, paletteDeferred){
		var that = this;
		var $generalDiv = $('#'+ blockElementID);
		this.$generalForm = $('<div></div>').appendTo($generalDiv);
		
		paletteDeferred.done(
				
				function(portletIdToConfigsMap){
			
			/**a map of typeId to configs
			 * 
			 *  {
			 * 		typeId:   {
			 * 				 		label: '',
			 * 						defaultConfig: {id: '', label: ''},
			 * 						configs: [{configId: '', label: ''}, ...]
			 * 
			 * 				  },
			 * 
			 * 		typeId1: {
			 * 					
			 * 				 }
			 *  }
			 *  
			 */
			
			var templateList = [];
			for(var key in portletIdToConfigsMap){
				templateList.push({id: key, label: portletIdToConfigsMap[key].label});
			}
			
			var $i18nAlias = infaw.portlet.I18nResources,
				$textUtils = infa.i18n.TextUtils.instance();
			
			that.$generalForm = that.$generalForm.infaForm({
				fields: [ 
				           
				         {
				        	 id:'name', 
				        	 label:$textUtils.getText($i18nAlias.PANEL_NAME), 
				        	 required:true, 
				        	 wType:'infaTextbox', 
				        	 wOptions: {
				        		 lines:2,
					        	 placeHolder: $textUtils.getText($i18nAlias.NAME_PLACEHOLDER+'...')
				        	 }
				         },
				         
				         {
				        	 id:'description', 
				        	 label:$textUtils.getText($i18nAlias.PANEL_DESCRIPTION), 
				        	 wType:'infaTextbox', 
				        	 wOptions: {
				        		 lines:2,
					        	 placeHolder: $textUtils.getText($i18nAlias.DESCRIPTION_PLACEHOLDER+'...')
				        	 }
				         },
				        			         
				         {
				        	 id:'template', 
				        	 label:$textUtils.getText($i18nAlias.PANEL_TEMPLATE), 
				        	 wType:'infaListbox',
				        	 wOptions:{
									allowNull:true,
									list: templateList
							 }
				         },
				         {
				        	 id:'activeConfiguration', 
				        	 label:$textUtils.getText($i18nAlias.ACTIVE_CONFIGURATION), 
				        	 wType:'infaListbox',
				        	 wOptions:{
									allowNull:false,
									list: []//configList
							 }
				         }
			         ]
			});
			
			that.generalForm = $.getWidget(that.$generalForm, 'infaForm');	
			
			//name field
			var $nameField = that.generalForm.getFieldHolder('name');
			var label = that.portletConfigCache.getPanelProperty(that.portletKey, '$$label');
			$nameField.infaTextbox('setValue', label);
			$nameField.on('onChange', function(event){
				var field = $(event.currentTarget);
				var newLabel = field.infaTextbox('getValue');
				//save the changed label in user preferences
				that.portletConfigCache.saveProperty(that.portletKey, '$$label', newLabel);
				//change the header of the portletWidget
				that.currentPortlet.setLabel(newLabel);
				var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
				workspace.getFloatPanel().setTitle(newLabel);
			});
			
			//description field
			var $descField = that.generalForm.getFieldHolder('description');
			var desc = that.portletConfigCache.getPanelProperty(that.portletKey, '$$description');
			if(desc){
				$descField.infaTextbox('setValue', desc);
			}
			$descField.on('onChange', function(event){
				var field = $(event.currentTarget);
				var newDesc = field.infaTextbox('getValue');
				//save the changed label in user preferences
				that.portletConfigCache.saveProperty(that.portletKey, '$$description', newDesc);
			});
			
			var $templateField = that.generalForm.getFieldHolder('template');
			var $activeConfigField = that.generalForm.getFieldHolder('activeConfiguration');
			
			//listener for template change
			$templateField.change(function(e){
				
				var templateId =  $(e.target).val();
				var configMap = portletIdToConfigsMap[templateId];
				
				that.currentPortletConfig = undefined;
				that.currentPortletDescriptor = undefined;
				
				//set the default
				that._setTemplate(templateId,configMap);			
			});
			
			//listener for config change			
			$activeConfigField.change(function(e){
				var configId =  $(e.target).val();
				that._setConfig(configId);
				//restore the configs to default
				that._restoreDefaultConfig();			
				//notify the portlet that the config has changed
				that._notifyConfigChanged();
				//populate the config tab
				that._populateProperties(configId);
			});
			
			//set the initial value of the template drop down 
			if(that.currentPortletConfig){
				var createPanelContent = false; //pass this flag to avoid creating panel contents during an edit operation
				var templateListWidget = $.getWidget($templateField, 'infaListbox');
				templateListWidget.setValue(that.currentPortletConfig.$portletDescriptorId);
				var portletDescId = that.currentPortletConfig.$portletDescriptorId;
				that._setTemplate(portletDescId, portletIdToConfigsMap[portletDescId], createPanelContent);
			}
			
		});
		
	},
	
	_populateConfigurationTab: function(configId){
		//create the tab for editing Custom properties
		var tab = this._infaTabs.getTabByIndex(1);
		$('#'+tab.id).empty();
		var $configDiv = $('#'+ tab.id);
		this.$propertiesForm = $('<div></div>').appendTo($configDiv);
		this._populateProperties(configId);
	},
	
	_populateProperties: function(configId){
		var that = this;
		if(configId !== infaw.configuration.ConfigurationManager.EMPTY_PORTLET_CONFIGID){
			var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
			var $portletDetailsPromise = this._getPortletDetailsPromise(configId);
			
			$portletDetailsPromise.then(function(portletConfig, portletDescriptor){
				//first get the default values from portletDescriptor
				//a map of propertyId to {descriptor, value}
				var propertyMap = that._getDefaultCustomProps(portletDescriptor);
				
				//override the values from config
				propertyMap = that._applyCustomConfig(propertyMap, portletConfig);
				
				//override the values from user preferences/configuration
				propertyMap = that._applyPreferences(propertyMap);
				
				//TODO call the custom properties callback for smart rendering
				
				//get form fields
				var formFields= that._getPropertiesFormFields(propertyMap);	
				
				if($.getWidget(that.$propertiesForm, 'infaForm')) {
					that.$propertiesForm.infaForm('destroy');
				}
					
				that.$propertiesForm.infaForm({
					fields: formFields
				});
				
				that.propertiesForm = $.getWidget(that.$propertiesForm, 'infaForm');
				
				//initialize controls for form fields and set initial values
				that._initializePropertiesControls(propertyMap);
				
				//attach the change events with all the property fields to throw property change event and save the property to portlet config cache
				$.each(formFields, function(index, formField) {
					var $field=that.propertiesForm.getFieldHolder(formField.id);
					$field.on('onChange', function(event){
						//update rest of the fields if needed here updateFields(formField.id)
						var currentField = $(event.currentTarget);
						var propObj = currentField.data('propInfo');
						var value = null;
						switch(propObj.controlType) {
							case 'infaListbox':
								value = currentField.infaListbox('getValue');
								break;
							
							case 'infaTextbox':
								value = currentField.infaTextbox('getValue');
								break;
							
						}
						that.portletConfigCache.saveProperty(that.portletKey, propObj.propertyId, value);
										
						//now fire the event to panel implementations
						that._eventManager.sendEvent('onCustomPropertyChange', {							
							panelInstanceId: that.portletKey,
							customPropertyId: propObj.propertyId,
							customPropertyValue: value
						});
					});
				});
				
				//attach an event handler in case any custom property is changed from the header shortcut
				that._eventManager.registerEvents({				
						'onCustomPropChangeForContextualPanel': function(event, obj){
							if(obj.panelInstanceId == that.portletKey){
								if(that.propertiesForm){
									var $field = that.propertiesForm.getFieldHolder(obj.customPropertyId);
									var propObj = $field.data('propInfo');
									switch(propObj.controlType) {
									case 'infaListbox':
										$field.infaListbox('setValue', obj.customPropertyValue, true);
										break;
									
									case 'infaTextbox':
										$field.infaTextbox('setValue', obj.customPropertyValue, true);
										break;
									
									}
								}
							}
					    }
				});
				
			});
		}
	},
	
	//gets the map of custom properties with the default values from the descriptor
	/**
	 * @param {Object.<{$portletId, $label, $icon, $jsClass, $packageId, $hasDropdown, $columnSpan, $rowSpan, $minWidth, $defaultPortletConfigId, customPropertyProvider: Object.<{$customPropertiesJSCallback, customPropertyDescriptor: Array.<{$id, $displayName, $defaultValue, $required}>}>}>} portletDescriptor
	 */
	_getDefaultCustomProps: function(portletDescriptor){
		var propertyMap = {};
		if(portletDescriptor.customPropertyProvider){
			var customProps = [];
			if($.isArray(portletDescriptor.customPropertyProvider.customPropertyDescriptor)){
				customProps = portletDescriptor.customPropertyProvider.customPropertyDescriptor;
			}
			else if(portletDescriptor.customPropertyProvider.customPropertyDescriptor !== undefined){
				customProps.push(portletDescriptor.customPropertyProvider.customPropertyDescriptor);
			}
			
			for(var k in customProps){
				var customPropDesc = customProps[k];
				propertyMap[customPropDesc.$id] = {descriptor: customPropDesc, value: customPropDesc.$defaultValue};
			}
		}
		return propertyMap;
	},
	
	//applies the custom property values from portletConfig on top of the propertyMap
	/**
	 * @param {Object.<{$portletDescriptorId, $closable, $movable, $maximizable, $configId, $label, customProperty: Array.<{$id, $value}>}>} portletConfig
	 */
	_applyCustomConfig: function(propertyMap, portletConfig){
		if(portletConfig.customProperty){
			var configCustomProps = [];
			//override the values specified in portlet configuration object
			if($.isArray(portletConfig.customProperty)){
				configCustomProps = portletConfig.customProperty;
			}else{
				configCustomProps.push(portletConfig.customProperty);
			}
			for(var n in configCustomProps){
				var custPropId = configCustomProps[n].$id;
				if(propertyMap[custPropId]){
					propertyMap[custPropId].value = configCustomProps[n].$value;
				}
			}
		}
		return propertyMap;
	},
	
	//applies the custom property values from user preferences on top of the propertyMap
	_applyPreferences: function(propertyMap){
		var configProps = this.portletConfigCache.getPanelCustomProperties(this.portletKey);
		for(var key in configProps){
			if(propertyMap[key]){
				propertyMap[key].value = configProps[key];
			}
		}
		return propertyMap;
	},
	
	_getPropertiesFormFields: function(propertyMap){
		var propertyFields = [];
		for(var key in propertyMap){
			var fieldObj = {};
			fieldObj.id = key;
			var propDesc = propertyMap[key].descriptor;
			fieldObj.label = propDesc.$displayName;
			if(propDesc.$required && propDesc.$required === 'true'){
				fieldObj.required = true;
			}
			propertyFields.push(fieldObj);
		}
		
		return propertyFields;
	},
	
	_initializePropertiesControls: function(propertyMap){
		for(var key in propertyMap){
			var propId = key;
			var propDesc = propertyMap[key].descriptor;
			var $field=this.propertiesForm.getFieldHolder(propId);
			if(propDesc.combo){
				//add options
				/**
				 * @type {Array.<{$value, $displayValue}>}
				 * 
				 */
				var items = [];
				if($.isArray(propDesc.combo.comboItem)){
					items = propDesc.combo.comboItem;
				}else{
					items.push(propDesc.combo.comboItem);
				}
				var itemList = [];
				for(var i in items){
					var item = items[i];
					itemList.push({id :item.$value, label: item.$displayValue !== undefined? item.$displayValue : item.$value });
				}
				$field.infaListbox({list: itemList});
				$field.data('propInfo', {propertyId: propId, controlType: 'infaListbox'});
				if(propDesc.combo.$editable === 'false'){
					$field.infaListbox('disable');
				}
				//set the value
				$field.infaListbox('setValue', propertyMap[key].value);
				
			}else if(propDesc.checkbox){
				//TODO
			}else if(propDesc.text){
				$field.infaTextbox({maxLength: propDesc.text.$maxLength, lines: propDesc.text.$lines});
				$field.data('propInfo', {propertyId: propId, controlType: 'infaTextbox'});
				if(propDesc.text.$editable === 'false'){
					$field.infaTextbox('disable');
				}
				//set the value
				$field.infaTextbox('setValue', propertyMap[key].value);
				
			}else if(propDesc.spinner){
				//TODO
			}else if(propDesc.customControl){
				//TODO
			}else{
				$field.infaTextbox();
				$field.data('propInfo', {propertyId: propId, controlType: 'infaTextbox'});
				//set the value
				$field.infaTextbox('setValue', propertyMap[key].value);
			}
		}
	},
	
	_setConfig: function(configId){
		var that = this;
		this.portletConfigCache.saveProperty(this.portletKey, '$$configId', configId);
		var $configPromise = that._getConfig(configId);
		$configPromise.then(function(portletConfig){			
			if(portletConfig){
				that.currentPortletConfig = portletConfig;
				that.currentPortlet.setClosable(portletConfig.$closable != "false");
			}
		});					
	},
	
	_getConfig: function(configId){
		var $deferred = $.Deferred();
		var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
		portletExtnManager.getPortletConfigExtension(configId).done(function(portletConfig){
			$deferred.resolve(portletConfig);
		});
		return $deferred.promise();
	},
	
	_notifyConfigChanged: function(){
		//notify the panel with the new config
		this._eventManager.sendEvent('onConfigChange', {
			panelInstanceId: this.portletKey,
			config:this.defaultConfigProps
		});
	},
	
	_getDefaultConfig: function(){
		var config = this._getDefaultCustomProps(this.currentPortletDescriptor);
		config = this._applyCustomConfig(config,this.currentPortletConfig);
		return this._getLWConfig(config);
	},
	
	
	/**
	 * @param {Object.<string, {label, defaultConfig: Object.<{id, label}>, configs: Array.<{configId, label}>}>}  configMap
	 */
	_setTemplate: function(currentTemplate, configMap, createContent){
		//create options for the config dropdown
		var configMenuItems = [];
		configMenuItems.push({id:configMap.defaultConfig.id,label:configMap.defaultConfig.label});
		$(configMap.configs).each(function(index,config){
			configMenuItems.push({id:config.configId,label:config.label});
		});
		
		//name field
		var $activeConfigField = this.generalForm.getFieldHolder('activeConfiguration');		
		var listBox = $.getWidget($activeConfigField, 'infaListbox');
		listBox.setOptions(configMenuItems);
		
		var configId = configMenuItems[0].id; 
		if(this.currentPortletConfig){
			configId = this.currentPortletConfig.$configId;
			listBox.setValue(configId);
		}
		
		//populate the config tab
		this._populateConfigurationTab(configId);
		if(createContent != false){
			var that = this;
			//get the default config
			var $configPromise = that._getConfig(configId);
			$configPromise.then(function (portletConfig) {
				that.currentPortletConfig = portletConfig;
			    var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
		    	//get the descriptor
		        portletExtnManager.getPortletDescriptorExtension(portletConfig.$portletDescriptorId).done(function (portletDescriptor) {
		            if (portletDescriptor) {
		            	that.currentPortletDescriptor = portletDescriptor;
		            	
		            	var resourceDeferredArr = [];
						if (portletDescriptor.$package.id){ // only blockRequireResource if 'id' is present
							resourceDeferredArr.push(infa.extensibility.ResourceInclude.blockRequireResource(portletDescriptor));
						}
	
						$.when.apply($, resourceDeferredArr).done(function () {
			            	//clear the instance cache entry
			            	var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
			            	workspace.getPortletContainer().clearInstanceCache(that.currentPortlet.getWidgetId());
			            		            	
			            	//switch the menu if needed
			            	var oldHasDropDown = that.currentPortlet.hasMenuDropDown();
			            	var newClosable = portletConfig.$closable === 'true';
			            	that.currentPortlet.setClosable(newClosable);
			            	
			            	var newHasDropDown = portletDescriptor.$hasDropdown === 'true' || newClosable;
			            	if(oldHasDropDown == true){
			            		//old portlet had dropdown
			            		if(newHasDropDown){
			            			//both old and new have dropdown, reset with the new one
			            			that.currentPortlet.resetMenuDropDown(portletDescriptor.$portletId);
			            		}else{
			            			//old had and new one does not, remove it
			            			that.currentPortlet.removeMenuDropDown();
			            		}
			            	}else{
			            		//old does not have drop down
			            		if(newHasDropDown){
			            			//only if new has it, add it
			            			that.currentPortlet.addMenuDropDown(portletDescriptor.$portletId);
			            		}
			            	}
			            	var $menu = that.currentPortlet.getMenu();
			            	var menuDeferred = $.Deferred();
							
							if ($menu) {
								$menu.on('onProcessExtensions', function() {
									that.currentPortlet.createCloseMenuItem();
									menuDeferred.resolve();
								});
								that.currentPortlet.getMenuWidget().processExtensions();
							}else{
								menuDeferred.resolve();
							}
							menuDeferred.done(function(){
							
								var $jsClass = portletDescriptor.$jsClass;
								if ($jsClass !== undefined) {
									var content = that.currentPortlet.getContent().get(0);
									var fullId = that.currentPortlet.getWidgetId();
									var jsClass = $.toFunction($jsClass);
									if (jsClass) {
										that.currentPortlet.clearContents();
										//add the view contents
										var defaultConfig = that._restoreDefaultConfig();
										that.currentTemplateInstance = new jsClass(content.id, fullId, defaultConfig);
										//update the instance cache in portletContainer
										var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
										workspace.getPortletContainer().updateInstanceCache(fullId, that.currentTemplateInstance);
									}
								}
							});
						});
		            }
		        });
			});
		}
		
		//set the config
		this._setConfig(configId);
		
	},
	
	_restoreDefaultConfig: function(){
		this.defaultConfigProps = this._getDefaultConfig();		
		for(var id in this.defaultConfigProps){
			this.portletConfigCache.saveProperty(this.portletKey, id, this.defaultConfigProps[id]);
		}
		//additionally push all the native config of the selected config to the user preference
		//TODO: add other properties
		this.portletConfigCache.saveProperty(this.portletKey, '$$closable', this.currentPortletConfig['$closable']);		
		return this.defaultConfigProps;
	},
	
	//_getDefaultConfig return {key:{value:'val1',....},{},..}. This util will create a simple map of {key:val1,...}
	_getLWConfig: function(configProps){
		var map = {};
		for(var key in configProps){
			var val = configProps[key];
			if(val instanceof Object){
				if(val.value){
					map[key] = val.value;
				}
			}else{
				map[key] = configProps[key];
			}
		}
		return map;
	},
	
	_getPortletDetailsPromise: function(configId){
		var $deferred = $.Deferred();
		var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
		portletExtnManager.getPortletConfigExtension(configId).done(function(portletConfig){
			portletExtnManager.getPortletDescriptorExtension(portletConfig.$portletDescriptorId).done(function(portletDescriptor){
				$deferred.resolve(portletConfig, portletDescriptor);
			});
		});
		return $deferred.promise();
	}
	
});
/**
 * @author clam
 * 
 * A representation of a panel whose content cannot be seen. An error message is shown in the 
 * content area.
 */
infaw.portlet.AbstractPortlet.extend("infaw.portlet.ContentInvisiblePortlet", 
{
	init: function(blockElementId, instanceId, config, message) {
		this._super(blockElementId, instanceId, config);
		
		var $i18nAlias = infaw.portlet.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
	
		$('#' + blockElementId).html(message ? $.infa.Validate.cleanXSSContent(message) : $textUtils.getText($i18nAlias.CONTENT_CANNOT_BE_VIEWED));
	}
	
}); 
/**
 *
 */
$.Class("infaw.portlet.PortletConfigCache", {
	
	NATIVE_PROPERTY_PREFIX: '$$'

}, {

	_workspaceId: undefined,
	
	//delta cache with key only changed properties
	_portletPreferences : undefined,
	
	//merged cache with all the properties 
	_mergedPortletConfigObjects : undefined,
	
	//palette
	_configIdToConfigMap: undefined,
	
	//instance array for the portlet container to create portlets
	_portletInstances : undefined,
	
	_initialized: false,
	
	_portletInstanceIds : undefined,
	
	_configManager : null,
	
	_portletConfigIds: undefined,
	
	_deletedConfigs: undefined,
	
	_dirtyConfigs: undefined,
	
	_dynamicPanelIds: undefined,
	
	init: function(workspaceId){
		this._workspaceId = workspaceId;
		this._configManager = infaw.configuration.ConfigurationManager.instance();
		this._portletPreferences = {};
		this._mergedPortletConfigObjects = {};
		this._portletInstances = [];
		this._portletInstanceIds = [];
		this._portletConfigIds = [];
		this._configIdToConfigMap = {};
		this._deletedConfigs = [];
		this._dirtyConfigs = [];
		this._dynamicPanelIds = [];
	},
	
    _initialize: function () {
    	var that = this;
    	var $deferred = $.Deferred();
    	this._readPortletExtensions().done(function(){
    		that._buildConfigCache().done(function(){
    			that._initialized = true;
    			$deferred.resolve();
    		});
    	});
    	
    	return $deferred.promise();
    	
    },

    //gets a property value for a given panel
    getPanelProperty: function(panelId,key){
    	var config = this._mergedPortletConfigObjects[panelId];
    	return config[key];
    },

    //gets all native properties of a given panel
    getPanelNativeProperties: function(panelId){
    	var nativeProps = {};
    	var config = this._mergedPortletConfigObjects[panelId];
    	if(config){
    		$.each(config,function(key,value){
        		if(key.indexOf('$$') > -1){
        			nativeProps[key] = value;
        		}
        	});
    	}
    	
    	return nativeProps;
    },
    
  //gets all custom properties of a given panel
    getPanelCustomProperties: function(panelId){
    	var custom = {};
    	var config = this._mergedPortletConfigObjects[panelId];
    	if(config){
    		$.each(config,function(key,value){
        		if(key.indexOf('$$') > -1){
        			return;
        		}
        		custom[key] = value;
        	});
    	}
    	
    	return custom;
    },
    
    //delete a panel config
    deletePanelConfig: function(panelId){
    	//update the deleted config references
    	if(this._deletedConfigs.indexOf(panelId) === -1){
    		this._deletedConfigs.push(panelId);
    	}
    },
    
    saveProperty: function(panelId, key, value){
    	//update dirty config array
    	if(this._dirtyConfigs.indexOf(panelId) === -1){
    		this._dirtyConfigs.push(panelId);
    	}
    	
    	//update delta
    	var pref = this._portletPreferences[panelId];
    	if(!pref){
    		pref = {};
    		this._portletPreferences[panelId] = pref;
    	}
    	pref[key] = value;
    	//update merged
    	var merged = this._mergedPortletConfigObjects[panelId];
    	if(!merged){
    		
    		//if the config is not found in the master config cache, it is a newly added panel
    		if(this._dynamicPanelIds.indexOf(panelId) === -1){
    			this._dynamicPanelIds.push(panelId);
    		}
    		
    		merged = {};
    		this._mergedPortletConfigObjects[panelId] = merged;
    	}
    	merged[key] = value;
    	
    },
    
    saveConfigs: function(){
    	var $deferred = $.Deferred();
    	var that = this;
    	var updatedConfigs = [];
    	var deletedConfigs = [];
    	$.each(this._portletPreferences, function(id,value){
    		var config =  that._portletPreferences[id];
    		if(that._dirtyConfigs.indexOf(id) > -1){
    			updatedConfigs.push({'key': that._createPortletInstanceKey(id), 'value': config});
    		}
    		//panel can also be deleted after updating
    		if(that._deletedConfigs.indexOf(id) > -1){
    			deletedConfigs.push(that._createPortletInstanceKey(id));
    		}
    	});
    	
    	if(updatedConfigs.length <=0  && deletedConfigs.length <= 0){
    		$deferred.resolve();
    	}
    	
    	if(updatedConfigs.length > 0 && deletedConfigs.length > 0){
			           
    		var deffArr = [];
    		deffArr.push(this._configManager.updateConfigs(updatedConfigs));
    		deffArr.push(this._configManager.deleteConfigs(deletedConfigs));
    		$.when.apply($, deffArr).done(function () {
    			
   	    		$.each(that._deletedConfigs, function(i,panelId){
   		    		//update merged cache
   		           	delete that._mergedPortletConfigObjects[panelId];
   		            
   		           	//update preferences
   		            delete that._portletPreferences[panelId];
   		            	
   		            //remove the id from the workspace panel array
   		            var index = that._dynamicPanelIds.indexOf(panelId);
   		            if(index > -1){
   		            	that._dynamicPanelIds.splice(index, 1);
   		            }	
   		    	});
   			 
            	//clear the dirty cache
   			 	that._dirtyConfigs.length = 0;
   			 
   			 	//clear the deleted cache
   			 	that._deletedConfigs.length = 0;
   			 	
	            $deferred.resolve();
    			
    	    });
    	}
    	
    	//update configs
    	if(updatedConfigs.length > 0 && deletedConfigs.length <= 0){
	    	this._configManager.updateConfigs(updatedConfigs).done(function(){
            	 //clear the dirty cache
    			 that._dirtyConfigs.length = 0;
    			 $deferred.resolve();
	    	});
    	}
    	
    	//delete configs
    	if(deletedConfigs.length > 0 && updatedConfigs.length <= 0){
    		
    		this._configManager.deleteConfigs(deletedConfigs).done(function () {
    			
        		$.each(that._deletedConfigs, function(i,panelId){
    	    		//update merged cache
        			delete that._mergedPortletConfigObjects[panelId];
    	           	//update preferences
    	           	delete that._portletPreferences[panelId];
    	            	
    	           	//remove the id from the workspace panel array
    	           	var index = that._dynamicPanelIds.indexOf(panelId);
    	           	if(index > -1){
    	           		that._dynamicPanelIds.splice(index, 1);
    	           	}
    	    	});
        		
    			//clear the deleted cache
   			 	that._deletedConfigs.length = 0;
   			 	$deferred.resolve();

	    	});
    	}
    	
    	return $deferred.promise();
    	
    }, 
    
    //returns array of ID
    getPortletInstanceIds : function(){
    	var $deferred = $.Deferred();
    	var that = this;
    	
    	if(!this._initialized){    	
    		
    		var $initDeferred = this._initialize();
    		
    		$initDeferred.done(function(){
        		/*$.each(that._portletInstances, function(index,value){
            		that._portletInstanceIds.push(value.instanceId);
            	});*/
        		$deferred.resolve(that._portletInstanceIds);
        	});
    	}else{
    		$deferred.resolve(that._portletInstanceIds);
    	}
    	
    	return $deferred.promise();
    },
    
    _readPortletExtensions: function () {
    	
    	var $masterDeferred = $.Deferred();
    	this.configObject = {};

    	var that = this;
    	var $deferred = infaw.portlet.PortletExtensionManager.instance().getPortletProviderExtensions(this._workspaceId);

    	$deferred.done(function (portletProviderIDArr) {
    	    if (portletProviderIDArr) {
    	        var portletInfoDeffered = that._getPortletInfo(portletProviderIDArr);
    	        portletInfoDeffered.done(function (portletInfo) {
    	            that._portletInstances = portletInfo.instances;
    	            $.each(that._portletInstances,function(i,portletInstance){
    	            	that._portletInstanceIds.push(portletInstance.instanceId);
    	            });
    	            that._configIdToConfigMap = portletInfo.configs;
    	            $masterDeferred.resolve();
    	        });
    	    } else {
    	    	$masterDeferred.resolve();
    	    }
    	});
    	
    	return $masterDeferred.promise();
    },
    
    _buildConfigCache: function(){
    	var $deferred = $.Deferred();
    	var that = this;
    	//load the portlet preferences and merge them with instance properties
        this._loadPortletPreferences().done(function(){
        	that._mergePreferences();
        	$deferred.resolve();
        });
        return $deferred.promise();
    },
    
    //reads the preferences of the portlets that participate in this portlet container 
    _loadPortletPreferences: function(){
    	var that =  this;
    	var $deferred = $.Deferred();
		this._dynamicPanelIds = [];
    	
    	var keyObj = {};
    	keyObj['workspaceId'] = this._workspaceId;
    	keyObj['typeName'] = 'portletInstance';
		
    	this._configManager.queryConfigs(keyObj).done(function(configs){
    		if($.isArray(configs)){
    			$.each(configs, function(index, config){
    				var key = config.key;
    				var instanceId = key.portletInstanceId;
    				that._portletPreferences[instanceId] = config.value;
    				//if it is dynamic panel
    				if(config.value["$$createdBy"] == "user") {
    					that._dynamicPanelIds.push(instanceId);
    					that._portletInstanceIds.push(instanceId);
    				}
    			})
    		}
    		$deferred.resolve();
    	});
    	
    	return $deferred.promise();
    },
    
    //returns object {configs: {configId : {descriptorId: '',  ...}, configId2: { ...}}}, instances: [{instanceId: '', configId: '', ....}, ...]}
    _getPortletInfo: function (portletProviderIDArr) {
        var infoDeffered = $.Deferred();
        var portletInfo = {};
        portletInfo.instances = [];
        var infoDeferredArr = [];
        var that = this;
        /**
         * @type {Object.<{descriptorId}>}
         */
        var _configIdToConfigsMap = {};
        portletInfo.configs = _configIdToConfigsMap;
        for (var i in portletProviderIDArr) {
            /**
             * @type {Object.<{portletInstance, portletConfig}>}
             */
            var portletProviderExtn = portletProviderIDArr[i];
            var instances = [];
            var portletConfigs = [];
            if ($.isArray(portletProviderExtn.portletInstance)) {
                instances = portletProviderExtn.portletInstance;
            }
            else if (portletProviderExtn.portletInstance !== undefined) {
                instances.push(portletProviderExtn.portletInstance);
            }
            if ($.isArray(portletProviderExtn.portletConfig)) {
                portletConfigs = portletProviderExtn.portletConfig;
            }
            else if (portletProviderExtn.portletConfig !== undefined) {
                portletConfigs.push(portletProviderExtn.portletConfig);
            }
            for (var j in instances) {
                var instanceDeffered = $.Deferred();
                infoDeferredArr.push(instanceDeffered);
                /**
                 * @type {Object.<{$configId}>}
                 */
                var instance = instances[j];
                var $configDeferred = infaw.portlet.PortletExtensionManager.instance().getPortletConfigExtension(instance.$configId);
                //Executing the inline function to create the closure for passing variables of each iteration of the loop
                (function (instanceDeffered, instance) {
                    $configDeferred.done(function (portletConfig) {

                        if (instance && portletConfig) {
                            var $descriptorDeferred = infaw.portlet.PortletExtensionManager.instance().getPortletDescriptorExtension(portletConfig.$portletDescriptorId);
                            //Executing the inline function to create the closure for passing variables of each iteration of the loop
                            (function (instanceDeffered, instance, portletConfig) {
                                $descriptorDeferred.done(function (portletDescriptor) {
                                    // Populating the portlet config id to portlet config map
                                    var configurationId = portletConfig.$configId;
                                    if (_configIdToConfigsMap[configurationId] == undefined) {
                                        _configIdToConfigsMap[configurationId] = {
                                            '$$descriptorId': portletDescriptor.$portletId,
                                            '$$type': 'portletConfig'
                                            
                                        };
                                    }

                                    var portletInstance = {};
                                    portletInstance.instanceId = instance.$instanceId;
                                    portletInstance.properties = {};
                                    
                                    //config property
                                    portletInstance.properties['$$configId'] = portletConfig.$configId;
                                    
                                    //descriptor property
                                    portletInstance.properties['$$descriptorId'] = portletDescriptor.$portletId;

                                    //adding 'type' property to determine that it is an instance
                                    portletInstance.properties['$$type'] = 'portletInstance';

                                    //label property
                                    portletInstance.properties['$$label'] = instance.$label;

                                    //position property
                                    portletInstance.properties['$$position'] = instance.$position;

                                    //closable property
                                    portletInstance.properties['$$closable'] = portletConfig.$closable;

                                    //columnSpan property
                                    portletInstance.properties['$$columnSpan'] = portletDescriptor.$columnSpan;

                                    //rowSpan property
                                    portletInstance.properties['$$rowSpan'] = portletDescriptor.$rowSpan;
                                    
                                    portletInstance.properties['$$icon'] = portletDescriptor.$icon;
                					portletInstance.properties['$$jsClass'] = portletDescriptor.$jsClass;
                					portletInstance.properties['$$packageId'] = portletDescriptor.$package;
                					portletInstance.properties['$$hasDropdown'] = portletDescriptor.$hasDropdown;
                					portletInstance.properties['$$minWidth'] = portletDescriptor.$minWidth;
                					portletInstance.properties['$$hasHelp'] = portletDescriptor.$hasHelp;


                                    //TODO read custom properties
                                    if (portletDescriptor.customPropertyProvider) {
                                        var customProps = [];
                                        if ($.isArray(portletDescriptor.customPropertyProvider.customPropertyDescriptor)) {
                                            customProps = portletDescriptor.customPropertyProvider.customPropertyDescriptor;
                                        }
                                        else if (portletDescriptor.customPropertyProvider.customPropertyDescriptor !== undefined) {
                                            customProps.push(portletDescriptor.customPropertyProvider.customPropertyDescriptor);
                                        }

                                        for (var k in customProps) {
                                            /**
                                             * @type {Object.<{$defaultValue}>}
                                             */
                                            var customDesc = customProps[k];
                                            portletInstance.properties[customDesc.$id] = customDesc.$defaultValue;
                                        }

                                        /**
                                         * @type {Array.<{$id,$value}>}
                                         */
                                        var configCustomProps = [];
                                        //override the values specified in portlet configuration object
                                        if ($.isArray(portletConfig.customProperty)) {
                                            configCustomProps = portletConfig.customProperty;
                                        }
                                        else if (portletConfig.customProperty !== undefined) {
                                            configCustomProps.push(portletConfig.customProperty);
                                        }
                                        for (var n in configCustomProps) {
                                            var custPropId = configCustomProps[n].$id;
                                            if (portletInstance.properties[custPropId]) {
                                                portletInstance.properties[custPropId] = configCustomProps[n].$value;
                                            }
                                        }
                                    }

                                    portletInfo.instances.push(portletInstance);

                                    instanceDeffered.resolve();
                                });
                            })(instanceDeffered, instance, portletConfig);
                        }
                    });
                })(instanceDeffered, instance);
            }

            for (var j in portletConfigs) {
                var configDeffered = $.Deferred();
                infoDeferredArr.push(configDeffered);
                var portletConfig = portletConfigs[j];
                var $configDeferred = infaw.portlet.PortletExtensionManager.instance().getPortletConfigExtension(portletConfig.$configId);
                //Executing the inline function to create the closure for passing variables of each iteration of the loop
                (function (configDeffered, portletConfig) {
                    $configDeferred.done(
                    /**
                     * @param {Object.<{$portletDescriptorId}>} portletConfigDescriptor
                     */

                    function (portletConfigDescriptor) {

                        if (portletConfigDescriptor) {
                            // Populating the portlet config id to portlet config map
                            var configurationId = portletConfig['$configId'];
                            that._portletConfigIds.push(configurationId);
                            if (_configIdToConfigsMap[configurationId] == undefined) {
                            	_configIdToConfigsMap[configurationId] = {
                                		'$$descriptorId': portletConfigDescriptor.$portletDescriptorId,
                                        '$$type': 'portletConfig'
                                };
                            }

                        }

                        configDeffered.resolve();
                    });
                })(configDeffered, portletConfig);
            }

        }
        $.when.apply($, infoDeferredArr).done(function () {
            infoDeffered.resolve(portletInfo);
            return;
        });
        return infoDeffered.promise();
    },
    
    //merges the preferences with the base configuration read from the extensions
    _mergePreferences: function(){
    	var that = this;
    	this._mergedPortletConfigObjects =  {};
    	$.each(this._portletInstances, function(index, portletInstance){
    		var instanceId = portletInstance.instanceId;
    		var props = portletInstance.properties;
    		var preference = that._portletPreferences[instanceId];
    		if(preference){    			
    			$.each(preference,function(key,value){
   					props[key] = value;
    			}); 
    		}
			that._mergedPortletConfigObjects[instanceId] = props;
    	});
    	
    	//now go over dynamic panel ids to add any new preferences
    	$.each(this._dynamicPanelIds, function(index, dynamicPanelId){
    		var preference = that._portletPreferences[dynamicPanelId];
    		if(preference){
    			that._mergedPortletConfigObjects[dynamicPanelId] = preference;
    		}
    	});
    },
    
    _createPortletInstanceKey: function(instanceId){
    	var keyObj = {};
    	keyObj['workspaceId'] = this._workspaceId;
    	keyObj['portletInstanceId'] = instanceId;
    	keyObj['typeName'] = 'portletInstance';
		return keyObj;
    },
    
    getPortletConfigs: function(){
    	return this._configIdToConfigMap;
    }

});
/**
 * A widget that contains a set of pane.
 * Wrapper for jQuery Layout Plugin
 * 
 * @author Madhu
 */

(function ($) {
		
	$.widget('infa.paneContainer', { 
				
		options: {
			containerCSS: 'infaPaneContainer',
			centerPane : undefined,
			northPane  : undefined,
			southPane  : undefined,
			eastPane   : undefined,
			westPane   : undefined,
			lazy 	   : false,
			//callbacks
			beforeClose: undefined,
			
			layoutOptions : {
				resizerClass: undefined, //'ui-state-default',
				spacing_open : 0,
				spacing_closed : 35,
				togglerLength_closed: -1,
				togglerAlign_closed: 'left',
				scrollToBookmarkOnLoad : false
			}
		},

		_create: function() {
			this.id = $.htmlId('paneContainer');
			this.element.attr('id', this.id)
						.addClass(this.options.containerCSS);
			
			if (!this.options.lazy) {
				this.createPanes();
			}
			
			this._registerEvents();
		},
		
		createPanes: function() {
			var h = [],
				opts = this.options,
				layoutOptions = this._getLayoutOptions(h, opts);
						
			this.layoutInst = this.element.html(h.join(''))
						.layout(layoutOptions);
			
			this.toolbarWidgets = {};
			
			this.addToolbars(opts);
			
			this.attachSwitchEvent();
			
		},
		
		
		_getLayoutOptions: function(h, opts) {
			var self = this,
				layoutOpts = $.extend(true, {}, this.options.layoutOptions, opts.layoutOptions);
			
			layoutOpts.onresizeall_end = function() {
				self._onLayoutResize();
			}
			
			if(opts.centerPane) {
				h.push(this._addPane(h, layoutOpts, opts.centerPane, 'center', 'infaCenterPane'));
			}
			
			if(opts.northPane) {
				h.push(this._addPane(h, layoutOpts, opts.northPane, 'north', 'infaNorthPane'));
			}

			if(opts.southPane) {
				h.push(this._addPane(h, layoutOpts, opts.southPane, 'south', 'infaSouthPane'));
			}

			if(opts.eastPane) {
				h.push(this._addPane(h, layoutOpts, opts.eastPane, 'east', 'infaEastPane'));
			}

			if(opts.westPane) {
				h.push(this._addPane(h, layoutOpts, opts.westPane, 'west', 'infaWestPane'));
			}
			
			return layoutOpts;
		},
		
		_addPane: function(h, layoutOpts, paneOptions, paneEdge, paneCSS) {
			if(paneOptions.paneCSS) {
				paneCSS = paneOptions.paneCSS;
			}
			
			if(!paneOptions.childPanes) {
				paneCSS = 'infaPane ' + paneCSS;
			}
			
			h.push('<div class="' + paneCSS + '" id="' + this.id + paneOptions.id  + '" data-paneid="' + paneOptions.id + '">');
			layoutOpts[paneEdge + '__paneSelector'] = '#' + this.id + paneOptions.id;
			
			
			if(paneOptions.layoutOptions) {
				var paneLayoutOptions = $.extend({resizable: false, slidable: false}, paneOptions.layoutOptions);
				$.each(paneOptions.layoutOptions, function(key, value){
					layoutOpts[paneEdge + '__' + key] = value;
				});
			}
			
			if(paneOptions.childPanes) {
				layoutOpts[paneEdge + '__children'] = this._getLayoutOptions(h, paneOptions.childPanes);
				layoutOpts[paneEdge + '__resizeChildren'] = function() {
					this._onLayoutResize();
				}
			} else {
				//Add Header label, close button & content div
				
				if(paneOptions.title) {
					h.push('<div class="infaPaneHeader">');				
					
					if(paneOptions.collapsible) {
						h.push('<span tabindex="0" class="infaPaneToggle ui-icon ui-icon-triangle-1-s" data-paneid="' + paneOptions.id + '"></span>');
						
						var toggleCloseContent = [];
						toggleCloseContent.push('<div class="infaPaneTogglerHeader">');				
						toggleCloseContent.push('<span tabindex="0" class="infaPaneToggle ui-icon ui-icon-triangle-1-e" data-paneid="' + paneOptions.id + '"></span>');
						toggleCloseContent.push('<span class="infaPaneTitle">' + paneOptions.title + '</span>');	
						
						layoutOpts[paneEdge + '__togglerContent_closed'] = toggleCloseContent.join('');
					}
					
					h.push('<span class="infaPaneTitle">' + paneOptions.title + '</span>');
					
					if(paneOptions.closeButton){
						h.push('<a href="#" class="infaPaneClose" role="button" data-paneid="' + paneOptions.id + '">');	
						h.push('<span class="ui-icon ui-icon-close">close</span>');
						h.push('</a>');
					}else if(paneOptions.toolbar) {
						h.push('<div class="infaPaneToolbar">');
						h.push(this._getToolbarFieldsHTML(paneOptions));
						h.push('</div>');
					}										
					h.push('</div>');						
				}
				
				var contentCSS = 'infaPaneContent';
				
				if(paneOptions.contentCSS) {
					contentCSS += ' ' + paneOptions.contentCSS;
				}

				h.push('<div class="'+ contentCSS + '" id="' + this.id + paneOptions.id  + '-panecontentDiv">');										
				h.push('</div>');
				
			}
			
			h.push('</div>');			
		},
		
	  _getToolbarFieldsHTML: function(paneOptions) {
	    	var h =[],
	    		fields = paneOptions.toolbar,
	    		fMax=fields.length;
			for(var i=fMax-1;i>=0;i--){
				var f=fields[i],
					fID=paneOptions.id+f.id,
					fLabel=f.label,
					cssString = f.hidden ? ' style="display: none;"' : '';
				
				
				if(f.wType === 'seperator' || f.wType === 'separator') {
					h.push('<div class="infaPaneToolbarFieldSeparator"></div>');
					continue;
				}
				
				var labelcls = 'infaPaneToolbarLabel';
				if(f.labelcls) {
					labelcls = f.labelcls;								
				}
				
				var fieldcls = 'infaPaneToolbarField';
				if(f.fieldcls) {
					fieldcls = f.fieldcls;								
				}
				
				h.push('<div class="' + fieldcls + '" id="',fID,'"></div>');
				
				if(fLabel && fLabel!=''){
					h.push('<div class="' + labelcls + '"><label for="',fID,'">', fLabel,':</label></div>');
				}else{
					h.push('<div class="' + labelcls + '"></div>');
				}				
								
			} 
			
			return h.join('');
	    },
		
		addToolbars : function(opts){
			if(opts){
				this.addToolbar(opts.centerPane);
				this.addToolbar(opts.eastPane);
				this.addToolbar(opts.westPane);
				this.addToolbar(opts.northPane);
				this.addToolbar(opts.southPane);
			}
		},
		
		addToolbar: function(paneOptions){
			if(paneOptions){
				if(paneOptions.toolbar) {
					this.addToolbarFields(paneOptions);
				}
				
				if(paneOptions.childPanes){
					this.addToolbars(paneOptions.childPanes);
				}
			}
		},
		
		addToolbarFields: function(paneOptions){
			var fields = paneOptions.toolbar,
			self= this;
	    	$.each(fields, function(index, f){
				var fID=paneOptions.id + f.id,
					fWType=f.wType;				
				if(fWType && fWType !== 'seperator' && fWType !== 'separator'){
					var $div=$('#'+fID);
					
					if(f.events) {
						$div.on(f.events);
					}
					
					$div[fWType](f.wOptions);
					
					self.toolbarWidgets[fID]=$.getWidget($div, fWType);
				}
			});	
		},
		
		getToolbarWidget: function(paneId, widgetId){
			return this.toolbarWidgets[paneId + widgetId];
		},
		
		_beforeClose: function(paneId){
			if(this.options.beforeClose){
				return this.options.beforeClose(paneId);
			}
			
			return true;
		},
		
		_registerEvents: function(){
			var self = this;
			this.element.on('click', '.infaPaneClose', function(event){
				var paneId = $(this).data('paneid');
				$.when(self._beforeClose(paneId)).then(function(canClose){
					if(canClose) self.hidePane(paneId);
				});
				
				return false;
			})
			.on('click keydown', '.infaPaneToggle', function(event){
				if (event.type === 'keydown' && event.which !== 13 /*enter*/) {
					return;
				}
				
				if($(this).hasClass('ui-icon-triangle-1-s')) {
					var paneId = $(this).data('paneid');
					$.when(self._beforeClose(paneId)).then(function(canClose){
						if(canClose){
							var $pane = $('#' + self.id + paneId),
							$paneTitleSpan = $pane.find('.infaPaneTitle'),
							title = $paneTitleSpan.text() || '',
							h = [];
						
							h.push('<div class="infaPaneTogglerHeader">');				
							h.push('<span tabindex="0" class="infaPaneToggle ui-icon ui-icon-triangle-1-e" data-paneid="' + paneId + '"></span>');
							h.push('<span class="infaPaneTitle">' + title + '</span>');									
							h.push('</div>');
							
							self.setToggleContent(paneId, h.join(''));
							
							self.closePane(paneId);
						}
					});
				}
				
				return false;
			});			
			
			this.element.find('.infaPane').each(function(){
				var $pane = $(this);
				$pane.on('baresize', function(event, newWidth, newheight, oldWidth, oldHeight){
					$pane.find('.infaPaneContent').trigger('onResize', [newWidth, newheight, oldWidth, oldHeight]);
				});
			});
			
		},
		
		_onLayoutResize: function(){			
			//this.element.trigger('onResize');
		},
		
		getPaneContentDiv: function(paneId) {
			var paneDivId = this.id + paneId;
			return $('#' + paneDivId).find('.infaPaneContent');
		},
		
		openPane: function(paneId){
			var $pane = $('#' + this.id + paneId),
				paneLayoutInstance = $pane.data('parentLayout'),
				paneEdge = $pane.data('layoutEdge');
			
			if(paneLayoutInstance && paneEdge) {
				paneLayoutInstance.open(paneEdge);	
				paneLayoutInstance.resizeAll();
				this.element.trigger('onPaneOpen', [paneId])
			}
		},
		
		closePane: function(paneId){
			var $pane = $('#' + this.id + paneId),
				paneLayoutInstance = $pane.data('parentLayout'),
				paneEdge = $pane.data('layoutEdge');
			
			if(paneLayoutInstance && paneEdge) {
				paneLayoutInstance.close(paneEdge, true);	
				paneLayoutInstance.resizeAll();
				this.element.trigger('onPaneClose', [paneId]);
			}
		},
		
		hidePane: function(paneId){
			var $pane = $('#' + this.id + paneId),
				paneLayoutInstance = $pane.data('parentLayout'),
				paneEdge = $pane.data('layoutEdge');
			
			if(paneLayoutInstance && paneEdge) {
				paneLayoutInstance.hide(paneEdge);	
				paneLayoutInstance.resizeAll();
				this.element.trigger('onPaneHide', [paneId]);
			}
		},
		
		allowOverflow: function(paneId) {
			var $pane = $('#' + this.id + paneId),
				paneLayoutInstance = $pane.data('parentLayout');
			
			if(paneLayoutInstance) {
				paneLayoutInstance.allowOverflow($pane);
			}
		},
		
		setPaneTitle: function(paneId, title) {
			if(this.isPaneOpen(paneId)) {
				var $pane = $('#' + this.id + paneId),
					$paneTitleSpan = $pane.find('.infaPaneTitle');
				
				if($paneTitleSpan[0]) {
					$paneTitleSpan.text(title);
				}				
			} else {
				var $paneToggleContent = $('#' + this.id + paneId + '-toggler');
					$paneTitleSpan = $paneToggleContent.find('.infaPaneTitle');
				
				if($paneTitleSpan[0]) {
					$paneTitleSpan.text(title);
				}
			}
		},
		
		isPaneOpen: function(paneId) {
			var $pane = $('#' + this.id + paneId),
				paneLayoutInstance = $pane.data('parentLayout'),
				paneEdge = $pane.data('layoutEdge'),
				layoutState = paneLayoutInstance.state,
				edgeLayoutState = layoutState[paneEdge];
			
			return ! edgeLayoutState.isClosed;
			
		},
		
		getPaneSize: function(paneId){
			var $pane = $('#' + this.id + paneId),
			paneLayoutInstance = $pane.data('parentLayout'),
			paneEdge = $pane.data('layoutEdge');
		
			if(paneLayoutInstance && paneEdge) {
				var state = paneLayoutInstance.state[paneEdge];
				if(state){
					return state.size;
				}
			}
		},
		
		setPaneSize: function(paneId, size){
			var $pane = $('#' + this.id + paneId),
			paneLayoutInstance = $pane.data('parentLayout'),
			paneEdge = $pane.data('layoutEdge');
		
			if(paneLayoutInstance && paneEdge) {
				paneLayoutInstance.sizePane(paneEdge, size);	
				this.element.trigger('onPaneResize', [paneId]);
			}
		},
		
		setPaneResizable: function(paneId, resizable){
			var resizerId = '#' + this.id + paneId + '-resizer';
			if(resizable){
				$(resizerId).show();
			}else{
				$(resizerId).hide();
			}
		},
		
		setPaneCollapsible: function(paneId, collapsible){
			var $pane = $('#' + this.id + paneId);
			if(collapsible){
				$pane.find('.infaPaneToggle').show();
			}else{
				$pane.find('.infaPaneToggle').hide();
			}
			
		},
		
		isPaneClose: function(paneId) {
			var $pane = $('#' + this.id + paneId),
				paneLayoutInstance = $pane.data('parentLayout'),
				paneEdge = $pane.data('layoutEdge'),
				layoutState = paneLayoutInstance.state,
				edgeLayoutState = layoutState[paneEdge];
			
			return edgeLayoutState.isClosed;			
		},
		
		setReadOnly: function(paenId, readOnly) {
			
		},
		
		setToggleContent: function(paneId, htmlContent) {			
			var $paneToggleContent = $('#' + this.id + paneId + '-toggler');
			$paneToggleContent.html(htmlContent).css('margin-left', 0);
		},
		
		destroy: function(){
			this.element.unbind();
			$.Widget.prototype.destroy.call(this);	
		},
	
		/**
		 * For every pane, switch event will be added
		 */
		attachSwitchEvent: function() {
			var panes = this.element.find(".infaPane");
			var that = this;
			
			for(var i=0;i<panes.length;i++) {
				$(panes[i]).bind('keydown', function(e) {
					if (e.altKey && e.keyCode==80 /*Alt+p*/) {
						e.stopPropagation();
						var visiblePanes = that.element.find(".infaPane").filter(":visible");
						var currentPaneIndex = visiblePanes.index($(this));
						var nextPaneIndex = (currentPaneIndex + 1) % visiblePanes.length;  
						
						while(nextPaneIndex != currentPaneIndex) {
							var nextPane = visiblePanes.eq(nextPaneIndex);
							//Find first accessible element in next pane
							var fElement = nextPane.find("a, button, input, select, textarea, [tabindex='0']").filter(":visible:first");
							//if focusable element present in this pane
							if(fElement.length != 0) {
								fElement.focus();
								break;
							} else {
								//Go to next pane
								nextPaneIndex = (nextPaneIndex + 1) % visiblePanes.length;
							}
						}
					}
		    	})
			}
		}		
	});
	
}(jQuery));
/**
 * @author clam
 * 
 * Manages actions contributed to the title section of the panels.
 */
$.Class('infaw.portlet.PortletActionManager', 
{
	_instance : undefined,

	instance : function(){
		if (infaw.portlet.PortletActionManager._instance === undefined) {
			infaw.portlet.PortletActionManager._instance = new infaw.portlet.PortletActionManager();
		}			         
		return infaw.portlet.PortletActionManager._instance;
	}  

},
{
	// a map with portlet descriptor id as the key and an array of actions as the value
	_portletIdToContributions: undefined,	
	
	initialize: function() {
		if(!this._$initializedDef) {
			var self = this,			
				reader = infa.extensibility.ExtensionReader.instance(),
				portletExtnMgr = infaw.portlet.PortletExtensionManager.instance();
			
			this._portletIdToContributions = {};			
			this._$initializedDef = $.when(portletExtnMgr.getActionContributionExtnsMap())
					.then(function(portletIdToActionExtsMap){
						$.each(portletIdToActionExtsMap, function(portletDescId, actionExtsMap) {
							var refItemIdToExtMap = new Object();
							$.each(actionExtsMap, function(index, extension) {															
								var locationURI = extension.$locationURI;
								if (locationURI) {
									var refItemId = locationURI.refId;
									var ext = refItemIdToExtMap[refItemId];
									if (!ext) {
										refItemIdToExtMap[refItemId] = new Object();
										ext = refItemIdToExtMap[refItemId];
									}
									var bucket;
									if (locationURI.placement == 'before') {
										bucket = ext.before;
										if (!bucket) {
											ext.before = new Array();
											bucket = ext.before;
										}
									} else {
										bucket = ext.after;
										if (!bucket) {
											ext.after = new Array();
											bucket = ext.after;
										}
									}
									bucket.push(extension);
								}								
							});
							
							self._portletIdToContributions[portletDescId] = [];
							self._buildEndof(refItemIdToExtMap, self._portletIdToContributions[portletDescId]);							
						});						
					});
			
		}		
		return this._$initializedDef;
	},
	
	initializeAction: function(blockElementId, actionId) {
		infaw.portlet.PortletExtensionManager.instance().getActionHandler(actionId).done(function(ext) {	
			var jsClassInstance = ext.$jsClassInstance;             	
			if(jsClassInstance === undefined) {
				infa.extensibility.ResourceInclude.blockRequireResource(ext, -1).then(function(){
					var cls = $.toFunction(ext.$jsClass);
					if (cls) {
						jsClassInstance = new cls();
						ext.$jsClassInstance = jsClassInstance;
						jsClassInstance.initAction(blockElementId, actionId);
					} else {
	    		    	infa.utils.Utils.instance().logError('portlet action handler jsClass ' + ext.$jsClass + ' not found');
	    		    }         			
				});	
			} else {
				jsClassInstance.initAction(blockElementId, actionId);
			}    		    
		});
	},
	
	/**
	 * Returns an array of actions contributed to the portlet with the given portlet descriptor id. 
	 * Each entry in the array contains the following:
	 * 
	 * - type: the type of the contribution, "action" if the contribution is an action, "separator" 
	 *   if the contribution is a separator.
	 * - id: the id associated with the action. N/A for a separator.
	 */
	getContributions: function(portletDescId) {
		var self = this;
		return this.initialize().then(function() {
			return self._portletIdToContributions[portletDescId] || [];
		});
	},
	
	_buildEndof: function(refItemIdToExtMap, contributions) {
    	if (refItemIdToExtMap) {
    		var ext = refItemIdToExtMap['endof'];
    		if (ext) {
    			var bucket = ext.after;
    			if (bucket) {
    		    	for (var i = 0; i < bucket.length; i++) {
    					var extension = bucket[i];
    					if (extension.action) {
    						if (extension.action.length) {
    							for (var j = 0; j < extension.action.length; j++) {
    								this._addContributionCommand(refItemIdToExtMap, extension.action[j], contributions);
    							}
    						} else {
    							this._addContributionCommand(refItemIdToExtMap, extension.action, contributions);
    						}
    					}
    					if (extension.separator) {
    						if (extension.separator.length) {
    							for (var j = 0; j < extension.separator.length; j++) {
    								this._addContributionCommand(refItemIdToExtMap, extension.separator[j], contributions);
    							}
    						} else {
    							this._addContributionCommand(refItemIdToExtMap, extension.separator, contributions);
    						}
    					}
    				}
    	    	}
    		}
    	}
    },
    
    _addContributionCommand: function(refItemIdToExtMap, extCommand, contributions) {
    	var ext;
    	if (refItemIdToExtMap && extCommand.$id) {
    		ext = refItemIdToExtMap[extCommand.$id];
    	}
		if (ext && ext.before) {
			for (var i = 0; i < ext.before.length; i++) {
				if (ext.before[i].action) {
					this._addContributionCommand(refItemIdToExtMap, ext.before[i].action, contributions);
				}
				if (ext.before[i].separator) {
					this._addContributionCommand(refItemIdToExtMap, ext.before[i].separator, contributions);
				}
			}
		}

		if (extCommand && extCommand.length) {
			for (var i = 0; i < extCommand.length; i++) {
				this._addContributionCommand(refItemIdToExtMap, extCommand[i], contributions);
			}
		} else {
			if (extCommand.$actionId) {
				contributions.push({type: 'action', id: extCommand.$actionId});
			} else if (extCommand.$visible === 'true') {
				contributions.push({type: 'separator'});
			}
		}
		
		if (ext && ext.after) {
			for (var i = 0; i < ext.after.length; i++) {
				if (ext.after[i].action) {
					this._addContributionCommand(refItemIdToExtMap, ext.after[i].action, contributions);
				}
				if (ext.after[i].separator) {
					this._addContributionCommand(refItemIdToExtMap, ext.after[i].separator, contributions);
				}
			}
		}
    },
    
    updateActions: function(portletDescId, actionExtsMap) {
    	var self = this;
		var refItemIdToExtMap = new Object();
		$.each(actionExtsMap, function(index, extension) {															
			var locationURI = extension.$locationURI;
			if (locationURI) {
				var refItemId = locationURI.refId;
				var ext = refItemIdToExtMap[refItemId];
				if (!ext) {
					refItemIdToExtMap[refItemId] = new Object();
					ext = refItemIdToExtMap[refItemId];
				}
				var bucket;
				if (locationURI.placement == 'before') {
					bucket = ext.before;
					if (!bucket) {
						ext.before = new Array();
						bucket = ext.before;
					}
				} else {
					bucket = ext.after;
					if (!bucket) {
						ext.after = new Array();
						bucket = ext.after;
					}
				}
				bucket.push(extension);
			}								
		});
		
		this._portletIdToContributions[portletDescId] = [];
		this._buildEndof(refItemIdToExtMap, this._portletIdToContributions[portletDescId]);							
			
	}
	
});
/**
 * @author sdonthul 
 * A UI control for panel configuration
 */

$.Class("infaw.portlet.addPanelConfig", 
{
	//panel which this config is editing
	currentPortlet: undefined,
		
	//panel widget which this config is editing
	currentPortletWidget:  undefined,
	
	//current template instance
	currentTemplateInstance: undefined,
	
	//current portlet config
	currentPortletConfig: undefined,
	
	//current config
	currentPortletDescriptor: undefined,
	
	//default config-map for the active configuration
	defaultConfigProps: undefined,
	
	//portletKey
	portletKey: undefined,
	
	portletConfigCache: undefined,
	
	init: function(portletConfigCache, portlet) {
		if(portlet) {
			this.currentPortlet = portlet;
			this.currentPortletWidget = $.getWidget(portlet, 'infaPortlet');
			this.portletKey = this.currentPortletWidget.getWidgetId();
		}
		this.portletConfigCache = portletConfigCache;
	},
	
		
	
	/**
	 * create a UI control as well as handle updates to the UI.
	 */
	createUI: function(paletteDeferred) {
		var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		this._eventManager = workspace.getEventManager();
		
		var that = this;

		//check if it already has a configId in the preference - means the portlet has been created
		//already and opened for edit
		if(this.portletKey) {
			var configId = this.portletConfigCache.getPanelProperty(this.portletKey,'$$configId');
			if(configId){
				var $portletDetailsPromise = that._getPortletDetailsPromise(configId);				
				$portletDetailsPromise.then(function(portletConfig, portletDescriptor){
					that.currentPortletConfig = portletConfig;
					that.currentPortletDescriptor = portletDescriptor;
				});
			}
		}
				
		this.createDialog(paletteDeferred);
	},
	
	createDialog: function(paletteDeferred){
		var that = this;
        var $panelEditDialog = $('<div id="' + $.htmlId('panelEditDialog') + '" ></div>').appendTo($('body')),  
        $panelEditForm =  $('<div id="' + $.htmlId('panelEditForm') + '" ></div>').appendTo($panelEditDialog).width(450); 
        that.templateList = [];
        
        paletteDeferred.done(
        	function(portletIdToConfigsMap){
        		for(var key in portletIdToConfigsMap){
        			that.templateList.push({id: key, label: portletIdToConfigsMap[key].label});
        		}
			
		        var $i18nAlias = infaw.portlet.I18nResources,
		        $textUtils = infa.i18n.TextUtils.instance();
			
		        $panelEditForm.infaForm({   
		        	formcls: 'infaForm-Style1', 
		        	columns: 1, 
		        	rowHeight: 40, 
		        	fields: [ 
				         {
				        	 id:'template', 
				        	 label:$textUtils.getText($i18nAlias.PANEL_TEMPLATE),
				        	 required:true,
				        	 wType:'infaListbox',
				        	 wOptions:{
									allowNull:true,
									list: that.templateList
							 }
				         },
				         {
				        	 id:'configuration', 
				        	 label:$textUtils.getText($i18nAlias.CONFIGURATION), 
				        	 wType:'infaListbox',
				        	 wOptions:{
									allowNull:false,
									list: []//configList
							 },
							 readOnly: true
				         }
				   ] 
		     
		        });  
		      
		        that.panelEditForm = $.getWidget($panelEditForm, 'infaForm');	
		
		        $panelEditDialog.infaDialog({ 
		        	width: 470, 
		        	buttonLabels: {
						OK : $i18nAlias.OK_LABEL,
						Cancel :  $i18nAlias.CANCEL_LABEL
					},					
		        	buttons: { 
		        		OK: function(e) { 
		        			var dialog = $.getWidget($(this), 'infaDialog'); 
		        			var panelForm = $.getWidget($panelEditForm, 'infaForm'); 
		        			panelForm.validate().then( function(isValid) {
		        				if(isValid) {
		        					var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
									var portletContainer = workspace.getPortletContainer();
									//if there are no portlets/panels yet
									if(portletContainer.count()==0) {
										//remove Add a Panel link
										portletContainer.removeAddPanelLink();	
									}
									
		        					//if it is new panel action
		        					if(!that.portletKey) {
		        						//create panel
										var portlet = portletContainer.createPanel();
										that.currentPortlet = portlet;
			        					that.currentPortletWidget = $.getWidget(portlet, 'infaPortlet');
			        					that.portletKey = that.currentPortletWidget.getWidgetId();	
		        					}
		        					        						        					
		        					var $templateField = that.panelEditForm.getFieldHolder('template');
		        					var templateId = $templateField.infaListbox('getValue');
		        					var configMap = portletIdToConfigsMap[templateId];
		        					
		        					var $configField = that.panelEditForm.getFieldHolder('configuration');
		        					var configId = $configField.infaListbox('getValue');
		        					var panelName = $configField.infaListbox('getValueLabel');
		        					
		        					//save the changed label in user preferences
		        					that.portletConfigCache.saveProperty(that.portletKey, '$$label', panelName);
		        					//change the header of the portletWidget
		        					that.currentPortletWidget.setLabel(panelName);
		        					
		        					//set the config
		        					that._setConfig(configId);
		        					
		        					//set the template
		        					that._setTemplate(templateId, configMap, configId);
		        					        					
		        					dialog.destroy();
		        				}
		        			});
		        		}, 
		        		Cancel: function(e) {
		        			var dialog = $.getWidget($(this), 'infaDialog'); 
		        			dialog.destroy(); 
		        		} 
		        	}, 
		        	modal: true
		        });
		    
		        that.panelEditDialog = $.getWidget($panelEditDialog, 'infaDialog'); 
		      
		        that.panelEditDialog.setTitle($i18nAlias.ADD_PANEL);
		        that.panelEditDialog.open(); 

		        var $templateField = that.panelEditForm.getFieldHolder('template');
				var $configField = that.panelEditForm.getFieldHolder('configuration');	
		        
		        if(that.portletKey) {
		    		that.panelEditDialog.setTitle($i18nAlias.EDIT_PANEL);
		    			    		
		    		//set the initial value of the template drop down
		    		if(that.currentPortletConfig){
		    			var templateListWidget = $.getWidget($templateField, 'infaListbox');
		    			templateListWidget.setValue(that.currentPortletConfig.$portletDescriptorId);
		    			var configMap = portletIdToConfigsMap[that.currentPortletConfig.$portletDescriptorId];
		    			that._toggleConfigurationDropdown($templateField.infaListbox('getValueLabel'),configMap, true);
		    		}
		        } 		
				
				//listener for template change
				$templateField.change(function(e){
					var templateId =  $(e.target).val();
					var templateLabel = portletIdToConfigsMap[templateId].label;				
					that._toggleConfigurationDropdown(templateLabel,portletIdToConfigsMap[templateId],false);
				});

        	}
        );
	},
	
	_toggleConfigurationDropdown: function(templateLabel, configMap, isEditPanelAction) {
		
		var $configField = this.panelEditForm.getFieldHolder('configuration');	
		var listBox = $.getWidget($configField, 'infaListbox');
		
		
		if(configMap.configs.length > 0) {
			//Enable "Configuration" dropdown 
			this.panelEditForm.setFieldReadOnly('configuration', false);
			
			var configMenuItems = this._getConfigurationMenuItems(configMap);	
			listBox.setOptions(configMenuItems);
			
			if(isEditPanelAction){
				listBox.setValue(this.currentPortletConfig.$configId);
			}
			
		} else {
			listBox.setOptions([{id:configMap.defaultConfig.id, label:templateLabel}]);
			
			//Disable "Configuration" dropdown 
			this.panelEditForm.setFieldReadOnly('configuration', true);
		}
		
	},
	
	_getConfigurationMenuItems: function(configMap) {
		var configMenuItems = [];
		configMenuItems.push({id:configMap.defaultConfig.id,label:configMap.defaultConfig.label});
		$(configMap.configs).each(function(index,config){
			configMenuItems.push({id:config.configId,label:config.label});
		});
		
		return configMenuItems;
	},
	
	_getConfigurationMenuItemsWithCustomProps: function(configMap) {
		var configMenuItems = [],
			that=this;
		
		var portletConfigUtils = infaw.portlet.PortletConfigUtils.instance();
		var customPropertyMap = portletConfigUtils.getDefaultCustomProps(this.currentPortletDescriptor);
		var $configPromise = this._getConfig(configMap.defaultConfig.id);
		$configPromise.then(function (pConfig) {
			var customConfig = portletConfigUtils.applyCustomConfig(customPropertyMap,pConfig);
			var lwConfig =  portletConfigUtils.getLWConfig(customConfig);
			configMenuItems.push({id:configMap.defaultConfig.id,label:configMap.defaultConfig.label,
				  config: lwConfig});
		});

		$(configMap.configs).each(function(index,config){
			var $configPromise = that._getConfig(config.configId);
			$configPromise.then(function (pConfig) {
				var customConfig = portletConfigUtils.applyCustomConfig(customPropertyMap,pConfig);
				var lwConfig =  portletConfigUtils.getLWConfig(customConfig);
				configMenuItems.push({id:config.configId,label:config.label,
					  config: lwConfig});
			});
		});
		
		return configMenuItems;
	},
	
	/**
	 * @param {Object.<string, {label, defaultConfig: Object.<{id, label}>, configs: Array.<{configId, label}>}>}  configMap
	 */
	_setTemplate: function(currentTemplate, configMap, configId){
		
		var that = this;

		//get the default config
		var $configPromise = that._getConfig(configId);
		$configPromise.then(function (portletConfig) {
			that.currentPortletConfig = portletConfig;
		    var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
	    	//get the descriptor
	        portletExtnManager.getPortletDescriptorExtension(portletConfig.$portletDescriptorId).done(function (portletDescriptor) {
	            if (portletDescriptor) {
	            	that.currentPortletDescriptor = portletDescriptor;
	            	
	            	var resourceDeferredArr = [];
					if (portletDescriptor.$package.id){ // only blockRequireResource if 'id' is present
						resourceDeferredArr.push(infa.extensibility.ResourceInclude.blockRequireResource(portletDescriptor));
					}

					$.when.apply($, resourceDeferredArr).done(function () {
		            	//clear the instance cache entry
		            	var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		            	workspace.getPortletContainer().clearInstanceCache(that.currentPortletWidget.getWidgetId());
		            	
		            	//set closable as true
		            	that.currentPortletWidget.setClosable(true);
		            	
            			//both old and new have dropdown, reset with the new one
            			that.currentPortletWidget.resetMenuDropDown(portletDescriptor.$portletId);
		            	
            			//set hasHelp
            			that.currentPortletWidget.setHasHelp(portletDescriptor.$hasHelp);
            			
            			//set icon,iconColor
            			if(portletDescriptor.$icon) {
            				that.currentPortletWidget.setIcon(portletDescriptor.$icon, portletDescriptor.$iconColor);
            			} else {
            				that.currentPortletWidget.removeIcon();
            			}
            			
            			//set rowspan, colspan, minWidth
						var colSpan = portletDescriptor.$columnSpan;
						colSpan = colSpan ? parseInt(colSpan, 10) : 1;

						var rowSpan = portletDescriptor.$rowSpan;
						rowSpan = rowSpan ? parseInt(rowSpan, 10) : 1;
						
						var minWidth = portletDescriptor.$minWidth;
						minWidth = minWidth ? parseInt(minWidth, 10) : 0;
						
						that.currentPortlet.data('columnSpan', colSpan);
						that.currentPortlet.data('rowSpan', rowSpan);
						that.currentPortlet.data('minWidth', minWidth);
						
						var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
						var portletContainer = workspace.getPortletContainer();
						
						portletContainer._saveConfiguration(that.currentPortlet, '$$rowSpan', rowSpan);
						portletContainer._saveConfiguration(that.currentPortlet, '$$columnSpan', colSpan);
						
						//now refresh the layout of the workspace
						portletContainer.skipPortletResizeEvent=true;
						portletContainer._resizeGridItems(true);
						portletContainer.skipPortletResizeEvent=false; 
						
		            	var $menu = that.currentPortletWidget.getMenu();
		            	var menuDeferred = $.Deferred();
						
						if ($menu) {
							$menu.on('onProcessExtensions', function() {
								//Add the configurable items
								that.currentPortletWidget.createConfigurableMenuItems();
								
								//create configuration dropdown
								if(configMap.configs.length > 0) {
									var configMenuItems = that._getConfigurationMenuItemsWithCustomProps(configMap);
									that.currentPortletWidget.createConfigurationMenu(configMenuItems);
								} else {
									that.currentPortletWidget.removeHeaderShortcutsDropDown();
								}
								
								//Create Help MenuItem
								that.currentPortletWidget.createHelpMenuItem();
								menuDeferred.resolve();
							});
							that.currentPortletWidget.getMenuWidget().processExtensions();
						}else{
							menuDeferred.resolve();
						}
						menuDeferred.done(function(){
							var $jsClass = portletDescriptor.$jsClass;
							if ($jsClass !== undefined) {
								var content = that.currentPortletWidget.getContent().get(0);
								var fullId = that.currentPortletWidget.getWidgetId();
								var jsClass = $.toFunction($jsClass);
								if (jsClass) {
									that.currentPortletWidget.clearContents();
									//add the view contents
									var defaultConfig = that._restoreDefaultConfig();
									that.currentTemplateInstance = new jsClass(content.id, fullId, defaultConfig);
									//update the instance cache in portletContainer
									var workspace = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
									workspace.getPortletContainer().updateInstanceCache(fullId, that.currentTemplateInstance);
								}
							}
						});
					});
	            }
	        });
		});
			
	},

	_setConfig: function(configId){
		var that = this;
		this.portletConfigCache.saveProperty(this.portletKey, '$$configId', configId);
		var $configPromise = that._getConfig(configId);
		$configPromise.then(function(portletConfig){			
			if(portletConfig){
				that.currentPortletConfig = portletConfig;
			}
		});					
	},
	
	_getConfig: function(configId){
		var $deferred = $.Deferred();
		var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
		portletExtnManager.getPortletConfigExtension(configId).done(function(portletConfig){
			$deferred.resolve(portletConfig);
		});
		return $deferred.promise();
	},
	
	_getDefaultConfig: function(){
		var portletConfigUtils = infaw.portlet.PortletConfigUtils.instance();
		var config = portletConfigUtils.getDefaultCustomProps(this.currentPortletDescriptor);
		config = portletConfigUtils.applyCustomConfig(config,this.currentPortletConfig);
		return portletConfigUtils.getLWConfig(config);
	},
	
	_restoreDefaultConfig: function(){
		this.defaultConfigProps = this._getDefaultConfig();		
		for(var id in this.defaultConfigProps){
			this.portletConfigCache.saveProperty(this.portletKey, id, this.defaultConfigProps[id]);
		}
		//additionally push all the native config of the selected config to the user preference
		//TODO: add other properties
		this.portletConfigCache.saveProperty(this.portletKey, '$$closable', true);		
		return this.defaultConfigProps;
	},
	
	_getPortletDetailsPromise: function(configId){
		var $deferred = $.Deferred();
		var portletExtnManager = infaw.portlet.PortletExtensionManager.instance();
		portletExtnManager.getPortletConfigExtension(configId).done(function(portletConfig){
			portletExtnManager.getPortletDescriptorExtension(portletConfig.$portletDescriptorId).done(function(portletDescriptor){
				$deferred.resolve(portletConfig, portletDescriptor);
			});
		});
		return $deferred.promise();
	}
	
});
/**
 * @author sdonthul
 * 
 * Utility file which contains methods related to portlet configuration
 */
$.Class('infaw.portlet.PortletConfigUtils', 
	// static methods
	{
		_instance : undefined,
	
		instance : function(){
			if (infaw.portlet.PortletConfigUtils._instance === undefined) {
				infaw.portlet.PortletConfigUtils._instance = new infaw.portlet.PortletConfigUtils();
			}			         
			return infaw.portlet.PortletConfigUtils._instance;
		}  
	
	},
	
	// prototype methods
	{
		//gets the map of custom properties with the default values from the descriptor
		/**
		 * @param {Object.<{$portletId, $label, $icon, $jsClass, $packageId, $hasDropdown, $columnSpan, $rowSpan, $minWidth, $defaultPortletConfigId, customPropertyProvider: Object.<{$customPropertiesJSCallback, customPropertyDescriptor: Array.<{$id, $displayName, $defaultValue, $required}>}>}>} portletDescriptor
		 */
		getDefaultCustomProps: function(portletDescriptor){
			var propertyMap = {};
			if(portletDescriptor.customPropertyProvider){
				var customProps = [];
				if($.isArray(portletDescriptor.customPropertyProvider.customPropertyDescriptor)){
					customProps = portletDescriptor.customPropertyProvider.customPropertyDescriptor;
				}
				else if(portletDescriptor.customPropertyProvider.customPropertyDescriptor !== undefined){
					customProps.push(portletDescriptor.customPropertyProvider.customPropertyDescriptor);
				}
				
				for(var k in customProps){
					var customPropDesc = customProps[k];
					propertyMap[customPropDesc.$id] = {descriptor: customPropDesc, value: customPropDesc.$defaultValue};
				}
			}
			return propertyMap;
		},
		
		//applies the custom property values from portletConfig on top of the propertyMap
		/**
		 * @param {Object.<{$portletDescriptorId, $closable, $movable, $maximizable, $configId, $label, customProperty: Array.<{$id, $value}>}>} portletConfig
		 */
		applyCustomConfig: function(propertyMap, portletConfig){
			if(portletConfig.customProperty){
				var configCustomProps = [];
				//override the values specified in portlet configuration object
				if($.isArray(portletConfig.customProperty)){
					configCustomProps = portletConfig.customProperty;
				}else{
					configCustomProps.push(portletConfig.customProperty);
				}
				for(var n in configCustomProps){
					var custPropId = configCustomProps[n].$id;
					if(propertyMap[custPropId]){
						propertyMap[custPropId].value = configCustomProps[n].$value;
					}
				}
			}
			return propertyMap;
		},
		
		//This util will create a simple map of {key:val1,...}
		/**
		 * @param {key:{value:'val1',....},{},..} configProps
		 */		
		getLWConfig: function(configProps){
			var map = {};
			for(var key in configProps){
				var val = configProps[key];
				if(val instanceof Object){
					if(val.value){
						map[key] = val.value;
					}
				}else{
					map[key] = configProps[key];
				}
			}
			return map;
		}
	}
);
$.infaNamespace('infaw.workspace');
(function( $ ){
infaw.workspace.I18nResources = {
  ADD_PANEL : 'Add a Panel',
  NEW : 'New',
  HOME : 'Home',
  OPEN : 'Open',
  RECENTLY_OPENED : 'Recently Opened',
  ACTIONS : 'ACTIONS',
  UNSAVED_CHANGES_WARNING_MSG : 'You have unsaved changes.',
  ERROR_OBJECT_DELETED_OR_MODIFIED : 'The object has been modified or deleted by another user.',
  UNSAVED_CLOSE_ALL_TITLE : 'Close Tabs',
  CANCEL_LABEL : 'Cancel',
  OK_LABEL : 'OK',
  UNSAVED_CLOSE_ALL_MSG : '&lt;br&gt;You have unsaved changes. All unsaved changes will be lost.&lt;br&gt;&lt;br&gt; Select the assets to save. Disabled assets cannot be saved.&lt;br&gt;&lt;br&gt;',
  CLOSE_ALL_ASSETS : 'Close Assets',
  OPEN_ASSETS : 'Open Assets'
  
}}(jQuery));

/**
 * @author clam
 * Workspace Manager
 * This manager class is responsible for rendering workspaces in a page.
 * It calls WorkspaceExtensionManager for reading workspace information from extension points. It can call ConfigurationManager
 * to read/set any preferences for a workspace using the key '<workspaceId>'.
 */
$.Class('infaw.workspace.WorkspaceManager',
	// static methods 
	{  
		_instance : undefined,
		
		instance : function(){
			if (infaw.workspace.WorkspaceManager._instance === undefined) {
				infaw.workspace.WorkspaceManager._instance = new infaw.workspace.WorkspaceManager();
				// Create initializeDef here so that if anyone tries to check when workspaces are initialized 
				// They can check this initializeDef previously checking if
				// workspaces were initialized it would be undefined (in which case done)
				infaw.workspace.WorkspaceManager._instance._$initializeDef = $.Deferred();
			}				         
			return infaw.workspace.WorkspaceManager._instance;
		} 
	},
	
	// prototype methods
	{		
	
		bundle: infaw.workspace.I18nResources,
		
		_contextId: undefined,
		
		_hrefWorkspaceID: undefined,
		
		_skipStateChangeEvent: false,
		
		// key is workspaceId, value contains the following properties:
		// - extension: extension contribution information,
		// - workspaceInst: the actual workspace instance, if the workspace has already been activated and initialized
		_workspaceMap: {},	
		
		_menuProviderMap: {},
		
		//to indicate whether workspace hover menu is home menu or not
		_isHomeMenuMap:{},
			
		initialize: function(contextId, $elem, pageURL) {
			this._contextId = contextId;   
			this.$elem = $elem;
			this.pageURL = pageURL;
			var that = this;

			var tabCounter = window.localStorage.getItem('tabCounter') || 0;
			
			this.tabCounter = parseInt(tabCounter) + 1;
			window.localStorage.setItem('tabCounter', this.tabCounter);
						
			this._registerEvents();
			
			$.when(this._processWSExtensions()).then(function(){
				$.when(that._initializeHistoryState()).then(function(res) {
					that._$initializeDef.resolve(res);
				}, function(res) {
					that._$initializeDef.reject(res);
				});
			}, function(res) {
				that._$initializeDef.reject(res);
			});
			return this._$initializeDef.promise();								
		},
		
		_processWSExtensions: function() {
			var $deferred = $.Deferred(),
				that = this,
				i;	
			infaw.workspace.WorkspaceExtensionManager.instance().getActiveWorkspaceId(that._contextId).done(function(activeWorkspaceId){
				infaw.workspace.WorkspaceExtensionManager.instance().getAllAllowedWorkspaceExtensions(that._contextId).done(function(sortedExtensions){
					that._readMenuExt().done(function() {
						
						if(!sortedExtensions || sortedExtensions.length === 0) {
							return $deferred.reject().promise();
						}

						// sort the extensions based on the preferred position specified in extension contributions
						sortedExtensions.sort(function(ext1, ext2) {
							var pos1 = ext1.$position;
							var pos2 = ext2.$position;
							if (pos1 === pos2) {
								return 0;
							}
							if (!pos1) {
								return 1;
							}
							if (!pos2) {
								return -1;
							}
							return pos1 - pos2;
						});

						// infaTabs fires onSelect event with ui.firstTime == true when the first tab is
						// added, and the workspace manager uses this event to determine when the
						// content of a tab should be loaded. This means if the tabs are added in order,
						// the first tab will always be loaded, even if the active workspace is not the
						// first tab. A workaround is to add the active workspace first before the rest.
						var activeTabIndex = 0;
						that._activeExtnWSID = sortedExtensions[0].$workspaceId;
						if (activeWorkspaceId) {
							that._activeExtnWSID = activeWorkspaceId;
							for (i = 0; i < sortedExtensions.length; i++) {
								if (sortedExtensions[i].$workspaceId === activeWorkspaceId) {
									activeTabIndex = i;

									break;
								}
							}
						}

						
						var chain =  function(deferreds){
							
							var handleStep, handleDeferred,
							def = $.Deferred();

							handleStep = function () {
								if (!deferreds.length) {
									def.resolve();
									return;
								}
								var deferred = deferreds.shift();								
								handleDeferred(deferred);					
							};
							
							handleDeferred = function (deferred) {
								deferred.always(function () {
									handleStep();
								});
							};

							handleStep();
							return def.promise();
						};

						var extension, wsIcon, tab;

						// add active workspace first and then the workspaces that go after it
						var extensions = [], steps = [];
						for (i = activeTabIndex; i < sortedExtensions.length; i++) {
							extension = sortedExtensions[i];
							that._registerWorkspace(extension);
							extensions.push(extension);
							steps.push(that._addWorkspace(extension));
						}

						$.when(chain(steps)).always(function(){
							// next add the remaining workspaces that go before the active one
							extensions = [], steps = [];
							for (i = activeTabIndex - 1; i >= 0; i--) {
								extension = sortedExtensions[i];
								that._registerWorkspace(extension);
								extensions.push(extension);
								steps.push(that._addWorkspace(extension));
							}
							
							//If only one workspace hide WS tabs
							$.when(chain(steps)).always(function(){
								infaw.workspace.WorkspaceStrategy.instance().onWorkspacesAdded();
								
								if(extensions.length > 0){
									var isFound = false;
									for(var i = 0; i < extensions.length; i++){
										var extension = extensions[i];
										if(that._activeExtnWSID === extension.$workspaceId){
											isFound = true;
											break;
										}
									}
									if(!isFound){
										that._activeExtnWSID = extensions[0].$workspaceId;
									}				
								}

								$deferred.resolve();
							});
						});
					});		
				});
			});


			return $deferred.promise();
		},
		
		_addWorkspace: function(extension){
			var that = this, $deferred = $.Deferred(), tab;
			$.when(that._isPermanent(extension))
			.done(function(isPermanent){
				infaw.workspace.WorkspaceStrategy.instance().addWorkspace(extension, isPermanent);
				$deferred.resolve();
			});
			
			return $deferred.promise();
			
		},
		
		_isPermanent : function(extension){
			if(extension.$permanent === undefined){
				return true;
			}
			if(extension.$permanent !== 'false' && extension.$permanent !== false &&
					extension.$permanent !== 'true' && extension.$permanent !== true){//its a callback
				return this._getWSClassInstance(extension.$workspaceId).then(function(instance) {
					if(instance[extension.$permanent] instanceof Function){
						return instance[extension.$permanent]();
					}else{
						return false;
					}
				});
			}
			
			return (extension.$permanent !== 'false' && extension.$permanent !== false);
		},
		
		_registerEvents: function() {
			this._registerBrowserEvents();
			this._registerWsStateChangeEvents();
		},
		
		_registerBrowserEvents: function() {
			var self = this;
			$(window).on({
				'pageresize' : function() {	
					infaw.workspace.WorkspaceStrategy.instance().onPageResize();		
				},
				'statechange' : function(e) {     //equivalent to 'popstate' event
					self._onPopState(e);
				},
				'beforeunload' : function(e) {
					if(self._loggedout) {
						return;
					}
					var canLeave = true;		
					// Check to see if any of the workspace has any dirty objects
					$.each(self._workspaceMap, function(currentWsId, workspace){
						if(workspace && workspace.workspaceInst){
							var workspaceInst = workspace.workspaceInst;
							if(workspaceInst.onWorkspaceLeave(true) === false) {
								canLeave = false;
								return false;
							}
						}
					});
					
					if(!canLeave) {
						var i18nAlias = infaw.workspace.I18nResources;
						var textUtils = infa.i18n.TextUtils.instance();
						return textUtils.getText(i18nAlias.UNSAVED_CHANGES_WARNING_MSG);
					}
				},
				'unload' : function(e) { 
					self.onUnLoad();
				}
			});
		},
		
		_registerWsStateChangeEvents: function() {
			var self = this;
			this.$elem.on('onWsStateChange', '.infaWSContents', function(event, stateObj) {
				if(stateObj.$ws) {
					if( self.getActiveWorkspaceId() === stateObj.$ws ) {
						self.pushState(stateObj);
					} else {
						self._workspaceMap[stateObj.$ws].workspaceStateObj = stateObj;
					}
				}
			});
		},
		
		_registerWorkspace: function(extension) {
			this._workspaceMap[extension.$workspaceId] = { 
				extension: extension,
				workspaceStateObj: {
					$ws : extension.$workspaceId
				}
			};
		},
		
		selectHome: function(workspaceId) {
			this.selectInstance(workspaceId);
		},
		
		_readMenuExt: function() {
			var $deferred = $.Deferred();
			var self = this;
			var reader = infa.extensibility.ExtensionReader.instance();
	    	reader.read("com.informatica.tools.web.shell.extensibleWorkspaces").done(
				function(extensions) {
					$.each(extensions, function(index, extension) {
						if (extension.$configElem === 'menuProvider') {
							self._menuProviderMap[extension.$workspaceId] = true;
							//Populating isHomeMenu attribute for workspace containing hover menu
							if(extension.$isHomeMenu == "false") 
								self._isHomeMenuMap[extension.$workspaceId] = false;
							else
								self._isHomeMenuMap[extension.$workspaceId] = true;
						}
					});
					$deferred.resolve();
				}
			);
	    	return $deferred.promise();
		},
		
		addPanelSelected: function(workspaceId) {
			var self = this;
			
			$.when(this.selectInstance(workspaceId)).done(function() {
				var workspace = self._workspaceMap[workspaceId];
				var workspaceInst = self.getWorkspace(workspaceId);
				if(workspaceInst) {
					workspaceInst.addPanel();
				}
			});
		},
		
		_populateWSContent: function(workspaceId, blockElemId) {
			var $deferred = $.Deferred(),
				workspace = this._workspaceMap[workspaceId],
				extension = workspace.extension;
			this._getWSClassInstance(workspaceId, blockElemId).done(function(workspaceInst) {
				if(extension.$isConfigurable && extension.$isConfigurable === 'true') {
					workspaceInst.setConfigurable(true);
				}
				if(extension.$multiTabs && extension.$multiTabs === 'true') {
					workspaceInst.setMultiObj(true);
				}
//				that._populateWorkspaceToolbar(workspace, $wsElem, mainWSId, workspaceId);
				if(workspaceInst && workspaceInst.initialize) {
					$.when(workspaceInst.initialize(blockElemId, workspaceId)).then(function(){
						$deferred.resolve();
					});
				} else {
					$deferred.reject('jsClass not found');
				}
			}, this).fail(function(error) {
				infa.utils.Utils.instance().logError(error);
			});
			return $deferred.promise();
		},
		
		_getWSClassInstance : function(workspaceId, blockElemId){
			var that = this, 
				$deferred = $.Deferred(),
				workspace = this._workspaceMap[workspaceId],
				extension = workspace.extension;
			
			if(workspace.workspaceInst){
				$deferred.resolve(workspace.workspaceInst);
			}else{
				infa.extensibility.ResourceInclude.blockRequireResource(extension, blockElemId).done(function(data) {
					var jsClass = $.toFunction(extension.$jsClass);
					if (jsClass) {
						var workspaceInst = workspace.workspaceInst = new jsClass();
						$deferred.resolve(workspaceInst);
					} else {
						infa.utils.Utils.instance().logError('workspace extension jsClass ' + extension.$jsClass + ' not found');
						$deferred.reject('jsClass not found');
					}
				}, this).fail(function() {
					infa.utils.Utils.instance().logError('JS package ' + extension.$package.id + ' not found');
				});
			}
			
			return $deferred.promise();
		},
		
		_populateWorkspaceToolbar: function(workspace, $wsElem, mainWSId, workspaceId){
			var self = this;
			var extension = workspace.extension;

			//add the options menu to toolbar if the workspace is configurable or it has options
			if((extension.$isConfigurable && extension.$isConfigurable === 'true') ||  
					(extension.$hasOptionsDropdown && extension.$hasOptionsDropdown === 'true')) {
				//Works similar to infaPortlet drop down menu

				workspace.$wsOptions = $('<span class="wsOptions"></span>')
				.appendTo($wsElem)
				.infaDropdown({
					buttonIcon: $.url('/web.pageheader/images/dropdown.gif'),
					menuId: extension.$workspaceId
				});

				//process the menu extensions if workspace has options
				if(extension.$hasOptionsDropdown && extension.$hasOptionsDropdown === 'true'){
					var dropdown = $.getWidget(workspace.$wsOptions, 'infaDropdown');
					var $eMenu = dropdown.getMenu();
					var eMenu = $.getWidget($eMenu, 'extensibleMenu');
					if (eMenu) {
						eMenu.processExtensions();
					}
				}
				
				var $i18nAlias = infaw.workspace.I18nResources,
					$textUtils = infa.i18n.TextUtils.instance();

				//add the 'Add Panel' menu if the workspace is configurable
				if(extension.$isConfigurable && extension.$isConfigurable === 'true'){
					workspace.optionMenu=$.getWidget($.getWidget(workspace.$wsOptions, 'infaDropdown').getMenu(), 'infaMenu');
					workspace.optionMenu.add(-1, 'last', 'push', $textUtils.getText($i18nAlias.ADD_PANEL));
				}

				var that = this;
				workspace.$wsOptions.on('onSelect', function(e){
					var menuItem = workspace.optionMenu.getLabel(e.target); 
					if(menuItem === $textUtils.getText($i18nAlias.ADD_PANEL)) {
						that.getActiveWorkspace().addPanel();
					}
				});
			}
		},
		
		selectWorkspace: function(workspaceId, selectHome, modes, skipStateChangeEvent) {
			if(selectHome === undefined) {
				selectHome = true;
			}
			
			var workspace = this._workspaceMap[workspaceId];
			// if workspace is undefined, then get the active workspace id. This is needed for embeddable search case
			if(!workspace){ 
				workspace = this._workspaceMap[this.getActiveWorkspaceId()];
			}
			if(workspace) {
				// When selecting a workspace with activeInstance, a dialog pops up asking if you want to leave
				// We want to create the $deferred earlier so we can wait until dialog confirmation before navigating away
				var $deferred = workspace.$selDeferred = $.Deferred();

				if(this.getActiveWorkspaceId() !== workspaceId) {
					// We are most switching to an object instance so we don't want to 
					// change state for switching to this workspace
					if( skipStateChangeEvent === true ) {
						this._skipStateChangeEvent = skipStateChangeEvent;
					}
					infaw.workspace.WorkspaceStrategy.instance().selectWorkspace(workspaceId, selectHome, modes);
				} else {
					$deferred.resolve(this.getActiveWorkspace());
				}
				
				var self = this;
				return $deferred.promise().done(function() {
					self._skipStateChangeEvent = false;
				});
			}
		},
		
		/**
		 * Remove the workspace
		 */
		removeWorkspace: function(workspaceId) {
			infaw.workspace.WorkspaceStrategy.instance().removeWorkspace(workspaceId);
		},
		
		getActiveWorkspace: function() {
			return this.getWorkspace(this.getActiveWorkspaceId());			
		},
		
		getActiveWorkspaceId: function() {
			return infaw.workspace.WorkspaceStrategy.instance().getActiveWorkspaceId();			
		},

		getWorkspace: function(workspaceId) {
			var workspace = this._workspaceMap[workspaceId];
			if (workspace) {
				return workspace.workspaceInst;
			}
		},
		
		getWorkspaceColor: function(workspaceId){
			var workspace = this._workspaceMap[workspaceId];
			if (workspace){
				return workspace.extension.$color;
			}
		},
		
		getWorkspaceName: function(workspaceId){
			var workspace = this._workspaceMap[workspaceId];
			if (workspace){
				return workspace.extension.$label;
			}
		},
		
		getWorkspaceHomeLabel: function(workspaceId){
			var workspace = this._workspaceMap[workspaceId];
			if (workspace){
				return workspace.extension.$homeLabel;
			}
		},
		
		/**
		 * Add workspace object instance. Select workspace if not selected
		 * options - {
		 *		workspaceId		:	'',
		 *		instanceId		:	'',
		 *		instanceName	:	'',
		 *		icon			:	'',
		 *		metaClassName	:	'',
		 *		mixin			:	'',
		 *      location // optional for showing the path of the instance 
		 * } 
		 */
		addInstance: function(options) {
			var workspaceId = options.workspaceId;
			var $wsPromise;
			
			if(this.getActiveWorkspaceId() !== workspaceId) {
				$wsPromise = this.selectWorkspace(workspaceId, false, {addInstance: true}, true);
			} else {
				$wsPromise = this.getWorkspace(workspaceId);
			}
			
			return $.when($wsPromise).then(function(workspaceInst) {
				if(workspaceInst && workspaceInst.addInstance) {
					return workspaceInst.addInstance(options);
				}
			});
		},
		
		isWorkspaceHomeActive: function(workspaceId) {
			var workspaceInst = this.getWorkspace(workspaceId);
			if(workspaceInst && workspaceInst.isWorkspaceHomeActive) {
				return workspaceInst.isWorkspaceHomeActive();	
			}
		},
		
		removeInstance: function(workspaceId, instanceId, skipHomeSelect){
			var workspaceInst = this.getWorkspace(workspaceId);
			if(workspaceInst && workspaceInst.removeInstance) {
				workspaceInst.removeInstance(instanceId, skipHomeSelect);	
			}
		},

		isInstanceExists: function(workspaceId, instanceId) {
			var workspaceInst = this.getWorkspace(workspaceId);
			if(!instanceId || !workspaceInst) {
				return false; 
			}
			if(workspaceInst && workspaceInst.isInstanceExists) {
				return workspaceInst.isInstanceExists(instanceId);
			}
		},		
		
		/**
		 * Select object instance. Workspace will be selected first if we are not in the right workspace.
		 */
		selectInstance: function(workspaceId, instanceId) {
			var $wsPromise;
			if(this.getActiveWorkspaceId() !== workspaceId) {
				if(instanceId) {
					$wsPromise = this.selectWorkspace(workspaceId, false, {selectInstance: true}, true);
				} else {
					$wsPromise = this.selectWorkspace(workspaceId, true, {selectHome: true}, true);
				}
			} else {
				$wsPromise = this.getWorkspace(workspaceId);
			}
			
			return $.when($wsPromise).then(function(workspaceInst) {
				if(workspaceInst && workspaceInst.selectInstance) {
					return workspaceInst.selectInstance(instanceId);	
				}
			});
		},

		/**
		 * Get the ActiveInstance for that particular workspace
		 * which means the object being edited at the this time
		 * If workspaceId is not passed, current active workspace will be used.
		 */
		getActiveInstance: function(workspaceId){
			var workspaceInst;
			if(!workspaceId) {
				workspaceInst = this.getActiveWorkspace();	
			} else {
				workspaceInst = this.getWorkspace(workspaceId);
			}
			if(workspaceInst && workspaceInst.getActiveInstance) {
				return workspaceInst.getActiveInstance();
			}
		},

		getActiveInstanceId: function(workspaceId){
			var workspaceInst;
			if(!workspaceId) {
				workspaceInst = this.getActiveWorkspace();	
			} else {
				workspaceInst = this.getWorkspace(workspaceId);
			}
			if(workspaceInst && workspaceInst.getActiveInstanceId) {
				return workspaceInst.getActiveInstanceId();	
			}
		},
		
		getActiveInstanceHelpId: function(){
			var activeInstance = this.getActiveInstance();
			if(activeInstance && activeInstance.getHelpId) {
				return activeInstance.getHelpId();
			}
			return null;
		},
		
		updateInstanceName: function(workspaceId, instanceId, name) {
			var workspaceInst = this.getWorkspace(workspaceId);
			if(workspaceInst) {
				workspaceInst.updateInstanceName(instanceId, name);
			}
		},
		
		updateInstanceView: function(workspaceId, instanceId, instanceView){
			var workspaceInst = this.getWorkspace(workspaceId);
			if(workspaceInst && workspaceInst.updateInstanceView) {
				workspaceInst.updateInstanceView(instanceId, instanceView);	
			}
		},
		
		
		/**
		 * Based on metaClass ($$class) & optional mixin ($mixin) it will find the supported workspace and call workspaceInst.newObject(lwObject, options) 
		 */
		newObject: function(lwObject, options) {
			var self= this,
				wsExtnManager = infaw.workspace.WorkspaceExtensionManager.instance(),
				iClsInfoInst = infa.imf.IClassInfo.instance(),
				$iClsInfoDef = $.isNumeric(lwObject.$$class) ? iClsInfoInst.iClassById(lwObject.$$class) : 
									iClsInfoInst.iClassByName(lwObject.$$class);

			$.blockElem();
			return $iClsInfoDef.then(function(clsInfo){
				return wsExtnManager.getSupportedObjectWorkspaceId(clsInfo.id, lwObject.$mixins)
				.then(function(workspaceId){
					if(workspaceId) {
						lwObject.$$class = clsInfo.id;

						var $wsPromise; 
						if(self.getActiveWorkspaceId() !== workspaceId) {
							$wsPromise = self.selectWorkspace(workspaceId, false, {selectInstance:true}, true);
						} else {
							$wsPromise = self.getWorkspace(workspaceId);
						}

						return $.when($wsPromise).then(function(workspaceInst) {
							if(workspaceInst && workspaceInst.newObject) {
								return workspaceInst.newObject(lwObject, options);
							}
						});
					}
				}).always(function() {
					$.unblockElem();
				});
			});
		},
		
		
		/**
		 * Based on metaClass ($$class) & optional mixin ($mixin) it will find the supported workspace and call workspaceInst.openObject(lwObject, mode) 
		 * mode - new | read | edit 
		 */
		openObject: function(lwObject, mode) {
			var self= this,
				wsExtnManager = infaw.workspace.WorkspaceExtensionManager.instance();

			$.blockElem();
			return wsExtnManager.getSupportedObjectWorkspaceId(lwObject.$$class, lwObject.$mixins)
				.then(function(workspaceId){
					if(workspaceId) {
						var $wsPromise; 
						if(self.getActiveWorkspaceId() !== workspaceId) {
							$wsPromise = self.selectWorkspace(workspaceId, false, {selectInstance:true}, true);
						} else {
							$wsPromise = self.getWorkspace(workspaceId);
						}
	
						return $.when($wsPromise).then(function(workspaceInst) {
							if(workspaceInst && workspaceInst.openObject) {
								return workspaceInst.openObject(lwObject, mode);
							}
						});
					}
				},
				function(resp) {
					infaw.shell.common.Utils.showErrorFromResponse(resp);
				}).always(function() {
					$.unblockElem();
				}); 
		},
		
		/**
		 * IE9 doesn't support History API
		 * Using hashchange in case of IE9
		 * And History API for IE10, Chrome & Firefox
		 */
		_initializeHistoryState : function() {
			var self = this,
				urlQuery = this._getURLQuery(),
				stateParam = this._getUrlParam('wstate', urlQuery),
				stateObjFromURL = stateParam ? RISON.parse(stateParam) : {},				
				stateURL = '?wstate=';
			
			return $.when(this._getWorkspaceIdFromURL(stateObjFromURL)).then(function(workspaceId){
				stateObjFromURL.$ws = workspaceId;				

				var workspace = self._workspaceMap[workspaceId];
				workspace.workspaceStateObj = stateObjFromURL;
				
				var skipWorkspaceSelect = true;
				return self.selectWorkspace(workspaceId, undefined, undefined, skipWorkspaceSelect).then(function(){	
					self._currentStateObj = stateObjFromURL = workspace.workspaceStateObj;
					
					stateURL += RISON.urlencode(RISON.stringify(stateObjFromURL));	

					//Global State - Search/Notifications/Errors, etc...
					var globalStateParam = self._getUrlParam('gstate', urlQuery),
						globalStateObjFromURL = globalStateParam ? RISON.parse(globalStateParam) : {},
						globalId = globalStateObjFromURL ? globalStateObjFromURL.$id : undefined,
						globalStateURL = '&gstate=';
					
					self._globalStateObj = globalStateObjFromURL;
					//stateURL += globalStateURL + RISON.stringify(globalStateObjFromURL);
						
					self._pageTitle = document.title;
					History.replaceState({wstate: stateObjFromURL, gstate: globalStateObjFromURL}, self._pageTitle, stateURL);				
					
					
					if(self._globalStateObj.$id === 'search') {
						var criteria = self._globalStateObj.criteria,
							searchTerm = criteria.text;
							
						infaw.search.SearchManager.instance().search(searchTerm, criteria);
					}
				});				
			});	
			
		},
		
		_getWorkspaceIdFromURL: function(stateObjFromURL) {
			var wsExtnMgr = infaw.workspace.WorkspaceExtensionManager.instance(),
				self = this;
			if(stateObjFromURL) {
				if (stateObjFromURL.$ws && this._workspaceMap[stateObjFromURL.$ws] &&
				    infaw.workspace.WorkspaceStrategy.instance().isWorkspaceUrlable(stateObjFromURL)) {
					if(wsExtnMgr.isWorkspaceAllowed(this._contextId, stateObjFromURL.$ws)) {
						return stateObjFromURL.$ws;	
					} else {
						return this._activeExtnWSID;
					}					
				} else {
					var object = stateObjFromURL.$obj;
					if(object) {					
						var lwObject = this.getLwObjectFromState(object);
						// TODO: Re-Direct to 404 Page? 
						if(lwObject) {
							if($.isNumeric(lwObject.$$class)) {
								return $.when(wsExtnMgr.getSupportedObjectWorkspaceId(lwObject.$$class, 
										lwObject.$mixins, true)).then(function(workspaceId){
									if(wsExtnMgr.isWorkspaceAllowed(self._contextId, workspaceId)) {
										return workspaceId;	
									} else {
										return self._activeExtnWSID;
									}
								});	
							} else {
								/* return $.when(infa.imf.IClassInfo.instance().iClassByName(lwObject.$$class)).then(function(clsInfo) {
									if(clsInfo) {
										return $.when(wsExtnMgr.getSupportedObjectWorkspaceId(clsInfo.id, 
												lwObject.$mixins, true)).then(function(workspaceId){
													if(wsExtnMgr.isWorkspaceAllowed(self._contextId, workspaceId)) {
														return workspaceId;	
													} else {
														return self._activeExtnWSID;
													}	
												});	
									} else {
										return self._activeExtnWSID;
									}
								});*/
							}
						}					
					}
				}
			} 			
			
			return this._activeExtnWSID;
		},
		
		getLwObjectFromState: function(objectStr) {
			var objArr = objectStr.split('@');
			
			if(objArr && objArr.length >= 2 && objArr[0].indexOf('newObject') == -1) {
				var lwObject = {
						$$IID: objArr[0],
						$$class: objArr[1]
					};
					
				if( objArr.length >= 3) { 
					lwObject.$mixins = [objArr[2]];	
				}			
				return lwObject;
			}
		},
		
		/**
		 * wstateObj - Workspace State Object
		 * gstateObj - Global State Object
		 */
		pushState : function(wstateObj, gstateObj) {
			if(this._skipStateChangeEvent || (wstateObj === undefined && gstateObj === undefined)) {
				return true;
			}
			var stateURL = '?wstate=',
				globalStateURL = '&gstate=';
				
			if(!wstateObj) {
				wstateObj = this._currentStateObj;
			} else {
				var workspace = this._workspaceMap[wstateObj.$ws];
				this._currentStateObj = workspace.workspaceStateObj = wstateObj;
			}
			
			if(!gstateObj) {
				gstateObj = this._globalStateObj;
			} else {
				this._globalStateObj = gstateObj;
			}

			stateURL += RISON.urlencode(RISON.stringify(wstateObj)); //+ globalStateURL + RISON.stringify(gstateObj);
			History.pushState(
					{
						wstate: wstateObj, 
						gstate: gstateObj
					}, 
					this._pageTitle, 
					stateURL
			);					
		},		
		
		_onPopState : function(e) {
			var self = this,
			popState = window.History.getState(),
			popStateObj = (popState) ? popState.data : undefined,
			workspaceStateObj = (popStateObj) ? popStateObj.wstate : undefined;
				
				
			if(workspaceStateObj && this._currentStateObj && 
					! $.isSameObj(workspaceStateObj, this._currentStateObj)) {				
				var workspaceId = workspaceStateObj.$ws,
					workspace = this._workspaceMap[workspaceId],
					workspaceInst = workspace.workspaceInst,
					oldStateObj = this._currentStateObj;
				
				this._currentStateObj = workspace.workspaceStateObj = workspaceStateObj;
				if(workspaceId && this._workspaceMap[workspaceId] && 
						workspaceId !== oldStateObj.$ws) {
					$.when(this.selectWorkspace(workspaceId)).then(function(){						
						if(workspaceInst && workspaceInst.onPopState) {
							return workspaceInst.onPopState(workspaceStateObj, oldStateObj);
						}
					});
				} else {
					if(workspaceInst && workspaceInst.onPopState) {
						workspaceInst.onPopState(workspaceStateObj, oldStateObj);
					}
				}
			}
		},
		
		_getURLQuery : function() {
			var href = this._baseURI = $(location).attr('href'),
			query = href.replace(this.pageURL, '');
			return query;
		},
		
		_getStateObjFromURLQuery : function(query) {
			var queryArr = query.split('/'),
				stateObj = {};			
			for(var i = 2; i < queryArr.length; i = i + 2) {
				if(queryArr[i] && queryArr[i+1]) {
					stateObj[queryArr[i]] = decodeURIComponent(queryArr[i+1]);	
				}				
			}			
			return stateObj;
		},
		
		_getUrlParam : function(param, urlQuery) {
			//return decodeURIComponent((new RegExp(param + '/' + '([^\/]+?)(\/)').exec(urlQuery)||[,""])[1].replace(/\+/g, '%20'))||null;
			return decodeURIComponent((new RegExp(param + '=' + '([^&;]+?)(&|#|;|$)').exec(urlQuery)||[,""])[1].replace(/\+/g, '%20'))||null;	
		},
		
		/**
		 * Returns current global state object
		 */
		getGlobalStateObj: function() {
			return this._globalStateObj;
		},

		getWorkspaceStateObj : function(workspaceId) {
			var workspace = this._workspaceMap[workspaceId];
			return workspace.workspaceStateObj;
		},
		
		
		getGlobalSearchURL : function() {
			if(this._globalStateObj) {
				return this.pageURL + '?gstate=' + RISON.urlencode(RISON.stringify(this._globalStateObj));	
			}
			return undefined;			 
		},
		
		beforeLogout: function() {
			var objInstances = [];
			$.each(this._workspaceMap, function(workspaceId, workspace) {
				var workspaceInst = workspace.workspaceInst;
				if(workspaceInst && workspaceInst.beforeLogout) {
					var instances = workspaceInst.beforeLogout();
					if(instances) {
						instances.workspaceId = workspaceId;
						objInstances.push(instances);
					}
				}
			});

			return this._createLogoutDialog(objInstances);
		},
		
		onLogout: function() {
			this._loggedout = true;
			window.localStorage.removeItem('tabCounter');
			var $defArr = [];
			$.each(this._workspaceMap, function(workspaceID, workspace){
				var workspaceInst = workspace.workspaceInst;
				if(workspaceInst && workspaceInst.onLogout) {
					$defArr.push(workspaceInst.onLogout());
				}
			});
			return $.when.apply($, $defArr);
		},
		
		/**
		 * Helper method that creates a dialog asking if user wants to save all instances
		 * 
		 * @param {Array.<Object>} objInstances - Array of Objects
		 * @param [objInstances].savable - savable instances associated with workspaceInst
		 * @param [objInstances].unsavable - unsavable instances associated with workspaceInst
		 * @param [objInstances].workspaceId - workspaceId for the workspaceInst
		 */
		_createLogoutDialog: function(objInstances) {
			var instanceIdToWsIdMap = {}, savableInstances = [], unsavableInstances = [], wsIdToObjIds = {};
			for(var i = objInstances.length - 1; i >= 0; i--) {
				var savable = objInstances[i].savable,
					unsavable = objInstances[i].unsavable,
					workspaceId = objInstances[i].workspaceId,
					instanceIds = [];
				for(var j = savable.length - 1; j >= 0; j--) {
					var instanceId = savable[j].id;
					instanceIdToWsIdMap[instanceId] = workspaceId;
					savableInstances.push(savable[j]);
					instanceIds.push(instanceId);
				}
				
				for(var j = unsavable.length - 1; j >= 0; j--) {
					var instanceId = unsavable[j].id;
					unsavableInstances.push(unsavable[j]);
					instanceIds.push(instanceId);
				}
				
				wsIdToObjIds[workspaceId] = instanceIds;
			}

			if( savableInstances.length === 0 && unsavableInstances.length === 0 ) {
				// No dirty instances so we don't need to create close dialog
				return;
			}
			
			var $deferred = $.Deferred(),
				$dialog = $('<div></div>'),
				$closeGrid = $('<div></div>'),
				self = this;
			
			var saveSelected = function(e) {
				var instanceGrid = $.getWidget($closeGrid, 'infaGrid');
				var selectedRows = instanceGrid.getSelectedRow();
				
				var instanceArr = []; 
				for(var i = 0, len = selectedRows.length; i < len; i++) {
					instanceArr.push(instanceGrid.getRowDataObject(selectedRows[i]));
				}

				$.getWidget($(this), 'infaDialog').destroy();
				
				$.when(self._saveAndRemoveInstances(instanceArr, instanceIdToWsIdMap, wsIdToObjIds)).then(function() {
					$deferred.resolve();
				}, function() {
					$deferred.reject();
				});
			};
			
			$dialog.html($.getLocalizedText(this.bundle, 'UNSAVED_CLOSE_ALL_MSG'))
				.infaDialog({
					title: $.getLocalizedText(this.bundle, 'CLOSE_ALL_ASSETS'),
					buttonLabels: {
						OK : $.getLocalizedText(this.bundle, 'OK_LABEL'),
						CANCEL : $.getLocalizedText(this.bundle, 'CANCEL_LABEL')
					},
					buttons: {
						OK: saveSelected,
						CANCEL: function(e) {
							var dialog = $.getWidget($(this), 'infaDialog');
							dialog.destroy();		
							$deferred.reject();
						}
					},
					width:400,
					closeOnEscape: false,
					canClose: false
				});
			var dialog = $.getWidget($dialog, 'infaDialog');
			
			dialog.open(true);
			var gridModel = new infaw.workspace.CloseAllGridModel(savableInstances, unsavableInstances);
			$closeGrid.appendTo($dialog).infaGrid({
				rowModel: gridModel.rowModel,
				columnModel: gridModel.columnModel,
				sortname: 'name',
				columnInfo: [
				    {
				    	name : 'name',
				    	label : 'Name',
				    	showIcon: true
				    }
				],
				autowidth: true,
				height: '200',
				checkboxes: true
			});
			var instanceGrid = $.getWidget($closeGrid, 'infaGrid');

			return $deferred.promise();		
		},
		
		_saveAndRemoveInstances: function(instanceArr, instanceIdToWsIdMap, wsIdToObjIds) {
			var wsIdToSavedArrMap = {};
			for(var i = instanceArr.length - 1; i >= 0; i--) {
				var workspaceId = instanceIdToWsIdMap[instanceArr[i].id];
				if(!wsIdToSavedArrMap[workspaceId]) {
					wsIdToSavedArrMap[workspaceId] = [];
				}
				wsIdToSavedArrMap[workspaceId].push(instanceArr[i]);
			}
			
			var self = this,
				rejectFlag = false,		// rejectFlag = false means that all instances was closed properly and that we can resolve
				$promiseArr = [],
				firstFailedInstanceId, 	// We want to save the first failed instance so that we can select it and show the user why we didn't log out
				firstFailedWorkspaceId; // Save first failed workspace so that we can select workspace for above reason
			$.each(wsIdToObjIds, function(workspaceId, instanceIds) {
				var workspaceInst = self.getWorkspace(workspaceId);
				if(workspaceInst && workspaceInst.removeInstances) {
					var $deferred = $.Deferred(),
						savedArr = wsIdToSavedArrMap[workspaceId] ? wsIdToSavedArrMap[workspaceId] : [];
					
					$.when(workspaceInst.removeInstances(instanceIds, savedArr)).fail(function(failedInstanceId) {
						if(!rejectFlag) {
							// We want to keep track of the first instance/workspace that failed so we can select it back
							firstFailedInstanceId = failedInstanceId;
							firstFailedWorkspaceId = workspaceId;
							rejectFlag = true;	// Instance could not be saved so we want to reject
						}
					}).always(function() {
						// We always want to resolve so that we can attempt to save all the instances
						// If we reject even once this would have caused the workspace to not try to save other instances in other workspaces
						$deferred.resolve();
					});
					$promiseArr.push($deferred.promise());
				}
			});
			
			var $deferred = $.Deferred();
			$.when.apply($, $promiseArr).then(function() {
				if(rejectFlag) {
					$deferred.reject();
					// Select the instance that first failed so user knows why they didn't log out
					self.selectInstance(firstFailedWorkspaceId, firstFailedInstanceId);
				} else {
					$deferred.resolve();
				}
			});
			
			return $deferred.promise();
		},
		
		onUnLoad: function() {
			var counter = this.tabCounter - 1;
			if(counter && window.localStorage.getItem('tabCounter')) {
				window.localStorage.setItem('tabCounter', counter);
			} else {
				window.localStorage.removeItem('tabCounter');
			}
			var self = this;
			$.each(this._workspaceMap, function(workspaceID, _workspace){
				var workspaceInstance = _workspace.workspaceInst;
				if(workspaceInstance && workspaceInstance.onUnLoad) {
					workspaceInstance.onUnLoad(self._loggedout);
				}
			});
		},
		
		getTabCounter: function() {
			return this.tabCounter;
		},
		
		getInitializeDeferredObj : function() {
			return this._$initializeDef;
		},
		
		onHelp: function(){
			var workspace = this.getActiveWorkspace();
			var helpId = workspace.getHelpId();
			infa.help.HelpUtils.instance().launchHelp(helpId);
		},
		
		getWorkspaceMap: function() {
			return this._workspaceMap;
		},
		
		getWorkspaceTab: function(workspaceId) {
			return infaw.workspace.WorkspaceStrategy.instance().getWorkspaceTab(workspaceId);
		}
	}
);

$.Class('infaw.workspace.AbstractWorkspace', {
	
	_instanceId: undefined,
	_readOnly: undefined,
	_isConfigurable: false,
	_isMultiObj: false,
	_eventMgr: null,
	
	/**
	 * Parameters:
	 *  - blockElementId: the id of the DOM element where the workspace content is to be added
	 *  - instanceId: It is a unique namespaced identifier for a workspace which is currently the workspaceId
	 *                e.g. 'startPageWS'
	 *                
	 */
	initialize: function(blockElementId, instanceId) {
		this._blockElementId = blockElementId;
		this._instanceId = instanceId;
		this._$workspaceTab = $(infaw.workspace.WorkspaceManager.instance().getWorkspaceTab(instanceId));
	},
	
	/**
	 * Call this method to determine when a workspace is done being loaded
	 */
	onLoaded: function() {
		$('#' + this._blockElementId).trigger('onWorkspaceLoaded');
	},
	
	getElementId: function() {
		return this._blockElementId;
	},
	
	getInstanceId: function() {
		return this._instanceId;
	},

	setReadOnly: function(readOnly) {
		if (this._readOnly !== readOnly) {
			this._readOnly = readOnly;
			this.readOnlyChanged();
		}
	},
	
	isReadOnly: function() {
		return this._readOnly;
	},

	/**
	 * Subclasses can override this to handle the change of state
	 */
	readOnlyChanged: function() {
	},
	
	/**
	 * sets the boolean configurable property of the workspace
	 */
	setConfigurable: function(configurable){
		this._isConfigurable = configurable;
	},

	/**
	 * Sets the workspace as multiObj
	 */
	setMultiObj: function(isMultiObj) {
		this._isMultiObj = isMultiObj;
	},

	/**
	 * Abstract workspaces do not support multiObj
	 */
	isMultiObj: function() {
		return false;
	},
	
	/**
	 * gets the boolean configurable property of the workspace
	 */
	isConfigurable: function(){
		return this._isConfigurable;
	},

	getEventManager: function() {
		if (this._eventMgr === null) {
			this._eventMgr = new infaw.page.EventManager();
		}
		return this._eventMgr;
	},
	
	/**
	 * Triggered when workspace is selected
	 */
	onWorkspaceSelect : function() {
		
	},
	
	/**
	 * Triggered when workspace is left
	 */
	onWorkspaceLeave : function() {
		
	},
	
	/**
	 * Triggered when workspace is removed
	 */
	onWorkspaceRemove: function() {
		
	},
	
	/**
	 * Triggered when Logout called. 
	 * Added this method to help iframed workspaces to call logout on its instances. 
	 */
	onLogout : function() {
	
	},
	
	/**
	 * Triggered when page unload event happens 
	 *  
	 */
	onUnLoad: function(){
		
	},
	
	/**
	 * return the help id for the workspace 
	 *  
	 */
	getHelpId: function(){
		return null;
	},
	
	/**
	 * Called when browser history state changed (HTML5 History/State API)
	 * back & forward button - 'onpopstate' event) 
	 * Can be deferred;
	 */
	onPopState: function(stateObj, oldStateObj) {
		var self = this;
		return $.when(this.processStateURL(stateObj)).then(function() {

			var eventMgr = self.getEventManager();
			eventMgr.sendEvent('onPopState', [stateObj, oldStateObj]);
		});
	},
	
	/**
	 * update the state URL
	 */
	pushStateURL: function(stateObj) {
		$('#' + this._blockElementId).trigger('onWsStateChange', stateObj);
	},
	
	/**
	 * This is called when initializing the workspace
	 * or onPopState should also call this.
	 */
	processStateURL: function(stateObj) {
		
	}
});

$.Class('infaw.workspace.WorkspaceStrategy',
{
	STRATEGY: 'vertical',
	
	ICONIZE: true,
	
	_instance : undefined,
	
	instance : function(){
		if (infaw.workspace.WorkspaceStrategy._instance === undefined) {
			if (infaw.workspace.WorkspaceStrategy.STRATEGY === 'vertical') {
				infaw.workspace.WorkspaceStrategy._instance = new infaw.workspace.VerticalWorkspaceStrategy();
			}
		}				         
		return infaw.workspace.WorkspaceStrategy._instance;
	} 
},
{
	// key is workspaceId, value contains the following properties:
	// - tab: the tab in the infaTab widget that represents the workspace, 
	// - hoverMenu: if supported by the workspace
	_wsIdState: [],
	
	init: function() {
		this._wsMgr = infaw.workspace.WorkspaceManager.instance();
	},
	
	initialize: function($elem) {
		this._$elem = $elem;
		
		var tabId = $.htmlId('wktabs'),
			self = this;
		this._$infaTabs = $('<div id="' + tabId + '"></div>')
			.appendTo($elem)
			.infaWSTabs({
				orientation: infaw.workspace.WorkspaceStrategy.STRATEGY,
				onLeave: function(ui) {
					return self.onTabLeave(ui);
				}, 
				onRemove: function(ui) {
					return self.onTabRemove(ui);
				},
				iconize: infaw.workspace.WorkspaceStrategy.ICONIZE,
				alwaysShowTabs: true		// Hides tabs if only 1 initially
			});
		this._infaTabs = $.getWidget(this._$infaTabs, 'infaWSTabs');	

		this._registerEvents();
	},
	
	createMultiObjControl: function(blockElementId) {
		
	},
	
	initializeObjectEditorHandler: function(workspace) {
	},
	
	addInstance: function(workspace, instance) {
		var state = this._wsIdState[workspace.getInstanceId()];
		this.addInstanceImpl(workspace, instance, $(state.tab))
	},
	
	addInstanceImpl: function(workspace, instance, $tab) {
		var instanceId = instance.options.instanceId + '',
			tabId = $tab.attr('id'),
			newDivID = tabId + instanceId,
			isMultiObj = workspace.isMultiObj();
		
		if(isMultiObj) {
			this.addMultiObjInstance(workspace, instance, $tab);
		} else {
			$tab.find('div.activeInstance').removeClass('activeInstance').hide();
			$('<div id="'+ instance.divId +'" class="activeInstance wsInstContent"></div>').appendTo($tab).height($tab.height());
			
			workspace._formatAndPushState(instance);
			
			//Remove first div if it exceeds 15 
			if (workspace.objInstances.length > 15) {
				workspace.objInstancesMap[instanceId] = null;
				var removedInst = workspace.objInstances.shift(); // Remove First item.
				$tab.find('#' + removedInst.divId).remove();
			}
		}
	},
	
	addMultiObjInstance: function(workspace, instance, $tab, newDivID) {
	},
	
	removeInstance: function(workspace, instanceId) {
		if(workspace.isMultiObj()) {
			this.removeMultiObjInstance(workspace, instanceId)
		} else { // Single Object Workspace
			var $wsTab= workspace._$workspaceTab,
				newDivID = workspace.objInstancesMap[instanceId].divId;
			
			var $removedInstance = $wsTab.find('#' + newDivID).remove();
			if($removedInstance.hasClass('activeInstance')) {
				$wsTab.children().eq(0).addClass('activeInstance').show();
				var stateObj = workspace.getWorkspaceStateObj();
				if(stateObj.$obj) {
					delete stateObj.$obj;
				}
				workspace.pushStateURL(stateObj);	
			}
		}
	},
	
	removeMultiObjInstance: function(workspace, instanceId) {
	},
	
	onInstanceRemoved: function(workspace) {
	},
	
	updateInstanceName: function (workspace, instanceId, name) {
	},
	
	getWorkspaceStateObj : function(workspaceId) {		
		return this._wsMgr.getWorkspaceStateObj(workspaceId);
	},
	
	/**
	 * Helper function to select object instances
	 */
	selectObjInstance: function(workspace, instance) {
		workspace._formatAndPushState(instance);
	},
	
	selectHomeInstance: function(workspace) {
		
	},
	
	canSelectInstance: function(workspace, instanceId) {
		return true;
	},
	
	canAddInstance: function(workspace) {
		return true;
	},
	
	getWorkspaceTab: function(workspaceId) {
		var state = this._wsIdState[workspaceId];
		if (state) {
			return state.tab;
		}
	},
	
	addWorkspace: function(extension, permanent) {
		if(permanent){
			var tab = this._infaTabs.add(extension, !permanent);								
			this.initTabItem(tab, extension);
		}
	},
	
	/**
	 * Called after the workspaces are added to the page (the workspaces' content may not have been
	 * initialized). 
	 */
	onWorkspacesAdded: function() {
		var workspaces = this._wsMgr.getWorkspaceMap();
		/*if (Object.keys(workspaces).length === 1) {
			var tab = this._infaTabs.getTabByIndex(0);
			this._infaTabs.hideLabel(tab);
		}*/
	},
	
	onTabSelect: function(ui) {
		if(!this._workspaceSelected) {
			this._tabSelected = true;
			this._wsMgr.selectWorkspace(this._getWorkspaceId(ui.tab), true);
			this._tabSelected = false;
		}
	},
	
	onTabSelected: function(ui) {
		var workspaceId = this._getWorkspaceId(ui.tab);
		if(!workspaceId) {
			this._infaTabs.clearFirstTimeEvent(ui.tab);		
			return;
		}

		var self = this,
			workspace = self._wsMgr.getWorkspaceMap()[workspaceId],
			$selDeferred = workspace.$selDeferred,
			blockElemId = self._$elem.attr('id'),
			accessMgr = infaw.access.AccessManager.instance();

		accessMgr.isReadOnly(workspaceId, 'workspace', blockElemId).fail(function(resp){
			$selDeferred.reject(resp);
		}).always(function(readOnly) {
			if (ui.firstTime) {
				self._populateContent(workspaceId).always(function() {
					self._resizeTab();
					var workspaceInst = workspace.workspaceInst,
						$deferred;
					if(workspaceInst) {
						workspaceInst.setReadOnly(readOnly.value);
						if(ui.modes) {
							if(ui.selectHome && workspaceInst.onWorkspaceHomeSelect) {
								$deferred = workspaceInst.onWorkspaceHomeSelect(ui.modes);
							}
						} else {
							if(workspaceInst.processStateURL) {
								$deferred = workspaceInst.processStateURL(self.getWorkspaceStateObj(workspaceId));
							}
						}
					}

					$.when($deferred).then(function() {
						$selDeferred.resolve(workspaceInst);
					});
				});
			} else {
				self._resizeTab();
				var workspaceInst = workspace.workspaceInst;
				if(workspaceInst) {
					workspaceInst.onWorkspaceSelect(ui.modes);
					workspaceInst.setReadOnly(readOnly.value);
				}		
				$selDeferred.resolve(workspaceInst);
			}	
		});
		
		self._wsMgr.pushState(workspace.workspaceStateObj);
	},
	
	initTabItem: function(tab, extension) {
		$(tab).height(this._calculateWorkspaceHeight())
			.data('workspaceId', extension.$workspaceId);	
		
		if (!this._wsIdState[extension.$workspaceId]) {
			this._wsIdState[extension.$workspaceId] = {};
		}
		this._wsIdState[extension.$workspaceId].tab = tab;
	},
	
	getActiveWorkspaceId: function() {
		return this._getWorkspaceId(this._infaTabs.getSelected());			
	},
	
	selectWorkspace: function(workspaceId, selectHome, modes) {
		var state = this._wsIdState[workspaceId];
		if (!state || !state.tab) {
			var extension = this._wsMgr.getWorkspaceMap()[workspaceId].extension;
			var tab = this._infaTabs.add(extension, false, true);					
			this.initTabItem(tab, extension);
		}
		if(!this._tabSelected) {
			this._workspaceSelected = true;
			this._infaTabs.selectTab(this._wsIdState[workspaceId].tab, selectHome, modes);
			this._workspaceSelected = false;
		}
	},
	
	removeWorkspace: function(workspaceId) {
		var wsTab = this.getWorkspaceTab(workspaceId);
		if(wsTab) {
			var tabHeader = this._infaTabs.getTabHeader(wsTab);
			this._infaTabs.remove(tabHeader);
			this._wsIdState[workspaceId].tab = null;
		}
	},
	
	onPageResize: function() {
		this._resizeTab();
	},
	
	onTabLeave: function(ui) {
		var workspaceId = this._getWorkspaceId(ui.tab);
		if(workspaceId){
			var workspaceInst = this._wsMgr.getWorkspace(workspaceId);
			if( workspaceInst ) {
				return workspaceInst.onWorkspaceLeave();
			}
		}
		return true;
	},	
	
	onTabRemove: function(ui) {
		var workspaceId = this._getWorkspaceId(ui.tab);

		if(workspaceId){
			var workspaceInst = this._wsMgr.getWorkspace(workspaceId);
			if( workspaceInst && workspaceInst.onWorkspaceRemove ) {
				return workspaceInst.onWorkspaceRemove();
			}
		}
		return true;
	},
	
	onTabRemoved: function(ui) {
	},
	
	getActiveInstance: function(workspace) {
		if(workspace.isMultiObj()) {
			return this.getActiveMultiObjInstance(workspace);
		} 
		var activeInstance;
		$.each(workspace.objInstances, function(index, instance){
			if($('#'+ instance.divId).hasClass('activeInstance')){
				//this is the active instance
				activeInstance = instance;
			}
		});
		return activeInstance;
	},
	
	getActiveMultiObjInstance: function(workspace) {
	},
	
	getWorkspace: function(tab) {
		return this._wsMgr.getWorkspace(this._getWorkspaceId(tab));
	},
	
	_getWorkspaceId: function(tab) {
		return $(tab).data('workspaceId');
	},
	
	/**
	 * Force workspaceHeaders to show
	 */
	showWorkspaceHeaders: function() {
		this._infaTabs.show();
	},
	
	_registerEvents: function() {
		this._registerWsTabSelectEvents();
		this._registerWsTabRemoveEvent();
	},
	
	_registerWsTabSelectEvents: function() {
		var self = this;
		this._$infaTabs.on('onSelect onSelected', function(event, ui) {
			switch (event.type) {
			case 'onSelect':
				if (event.currentTarget === event.target) {
					self.onTabSelect(ui);
				}
				break;
			case 'onSelected':
				if (event.currentTarget === event.target) {
					self.onTabSelected(ui);
				}		
				break;
			}
		});	
	},
	
	_registerWsTabRemoveEvent: function() {
		var self = this;
		this._$infaTabs.on('onRemove', function(event, ui) {
			if (event.currentTarget === event.target) {
				self.onTabRemoved(ui);
			}
		});
	},
	
	_populateContent: function(workspaceId) {
		var that = this, 
			id = this._wsIdState[workspaceId].tab.id,
			mainWSId='wsfd-'+id,
			newHeight=this._calculateWorkspaceHeight(),
			$wsElem = $(this._wsIdState[workspaceId].tab).height(newHeight);
		
		$('<div id="'+mainWSId+'" class="activeInstance"></div>').height(newHeight).appendTo($wsElem);
		
		return this._wsMgr._populateWSContent(workspaceId, mainWSId);
	},
	
	_calculateWorkspaceHeight: function() {
		return Math.floor(this._$elem.height() - this._infaTabs.ongletHeight()) - 40;
	},
	
	_resizeTab: function(){
		var h = this._calculateWorkspaceHeight(),
			$selTab = $(this._infaTabs.getSelected());
		$selTab.height(h).children('div').height(h);	
		
		// Let the workspace know that it is getting resized so it can do extra processing
		this._$elem.trigger('workspaceResize', h);
		var activeWorkspace = this._wsMgr.getActiveWorkspace();
		if(activeWorkspace) {
			activeWorkspace.getEventManager().sendEvent('onWorkspaceResize');	
		}
		
		$selTab.find(':infaFloatPanel').infaFloatPanel('refresh');
	},
	
	isWorkspaceUrlable: function(workspaceId) {
		return true;
	}
	
});
infaw.workspace.WorkspaceStrategy.extend('infaw.workspace.VerticalWorkspaceStrategy', {
	
	// key is instanceId, value contains the following properties:
	// - tab: tab corresponding to the instance
	_instanceIdState: {},
	
	// key is the tab id, value is the instance
	_tabInstanceMap: {},
	
	addInstance: function(workspace, instance) {
		var $tab = $(this.getWorkspaceTab(workspace.getInstanceId()));
		this.addInstanceImpl(workspace, instance, $tab);
	},
	
	addMultiObjInstance: function(workspace, instance, $tab, newDivID) {
		var instanceId = instance.options.instanceId,
			tab = this._infaTabs.addGroupItem({
				id: 'th-' + instance.divId,
				label: instance.options.instanceName,
				icon: instance.options.icon,
				removable: true,
				groupId: instance.options.groupId ? instance.options.groupId : 'default',	// GroupId that this instance should be added to
				groupLabel: instance.options.groupLabel ? instance.options.groupLabel : 'Open Assets' // Label of the group that this instance is in
		});
		$tab = $(tab);
		this._initMultiInstanceTabItem(tab, workspace, instance);
		$('<div id="'+ instance.divId +'" class="activeInstance wsInstContent"></div>').appendTo($tab).height($tab.height());
//		this.formatAndPushState(workspace, instance);
		workspace.selectInstance(instanceId);
	},
	
	removeMultiObjInstance: function(workspace, instanceId) {
		var state = this._instanceIdState[instanceId];
		if (!state.tabRemoved) {
			var	tab = this._getTabByInstanceId(instanceId),
				tabInHeader = this._infaTabs.getTabHeader(tab);
			if( tabInHeader ) {
				state.instanceRemoved = true;
				this._infaTabs.remove( tabInHeader );
				state.instanceRemoved = false;
			}
		}
	},
	
	_initMultiInstanceTabItem: function(tab, workspace, instance) {
		var instanceId = instance.options.instanceId;
		$(tab).height(this._calculateWorkspaceHeight())
			.data('workspaceId', workspace.getInstanceId())
			.data('instanceId', instanceId);	
		
		if (!this._instanceIdState[instanceId]) {
			this._instanceIdState[instanceId] = {};
		}
		this._instanceIdState[instanceId].tab = tab;
		this._tabInstanceMap[tab.id] = instance;
	},

	/**
	 * Helper function to select object instances
	 */
	selectObjInstance: function(workspace, instance) {
		if(workspace.isMultiObj()) {
			if(!this._instanceSelected) {
				this._instanceSelected = true;
				this._infaTabs.selectTab(this._getTabByInstanceId(instance.options.instanceId));
				this._instanceSelected = false;
			}
//			
//			// Currently the placeholder is active
//			if( workspace._$workspaceComposite.hasClass('activePlaceholder') ) {
//				state.multiObjTabs.element.show();
//				this._$workspaceComposite.hide().removeClass('activePlaceholder');
//			}
			
		} else {
			$(this.getWorkspaceTab(workspace.getInstanceId())).find('div.activeInstance').removeClass('activeInstance').hide();
			$('#' + instance.divId).addClass('activeInstance').show();
		}
		this._super(workspace, instance);
		
		this._resizeTab();
	},
	
	selectWorkspace: function(workspaceId, selectHome, modes) {
		var self = this,
			workspace = self._wsMgr.getWorkspaceMap()[workspaceId];
		if (workspace.extension.$multiTabs === 'true') {
			var $selDeferred = workspace.$selDeferred,
				blockElemId = self._$elem.attr('id'),
				accessMgr = infaw.access.AccessManager.instance();
	
			accessMgr.isReadOnly(workspaceId, 'workspace', blockElemId).fail(function(resp){
				$selDeferred.reject(resp);
			}).always(function(readOnly) {
				if (!workspace.workspaceInst) {
					var wsDivId = '__dummy_' + workspaceId;
					self._$elem.append('<div id="' + wsDivId + '" class="infaWSContents"></div>');
					self._wsMgr._populateWSContent(workspaceId, wsDivId).always(function() {
//						self._resizeTab();
						var workspaceInst = workspace.workspaceInst,
							$deferred;
						if(workspaceInst) {
							workspaceInst.setReadOnly(readOnly.value);
							if(modes) {
								if(selectHome && workspaceInst.onWorkspaceHomeSelect) {
									$deferred = workspaceInst.onWorkspaceHomeSelect();
								}
							} else {
								if(workspaceInst.processStateURL) {
									$deferred = workspaceInst.processStateURL(self.getWorkspaceStateObj(workspaceId));
								}
							}
						}
		
						$.when($deferred).then(function() {
							$selDeferred.resolve(workspaceInst);
						});
					});
				} else {
					self._resizeTab();
					var workspaceInst = workspace.workspaceInst;
					if(workspaceInst) {
						workspaceInst.onWorkspaceSelect(modes);
						workspaceInst.setReadOnly(readOnly.value);
					}		
					$selDeferred.resolve(workspaceInst);
				}	
			});
		} else {
			this._super(workspaceId, selectHome, modes);
		}
	},
	
	onTabSelect: function(ui) {
		if(this._instanceSelected) {
			// The tab is programmatically selected. Someone is calling selectInstance.
		} else {
			var instanceId = $(ui.tab).data('instanceId');
			if (instanceId) {
				// This is a multi-instance tab selected by the end-user
				var state = this._instanceIdState[instanceId],
					instance = state.instance;
//				self._tabSelected = true;
				
				// fromRemove is a flag to prevent calling onInstanceLeave twice on the tab that is being removed
				if( !state.fromRemove ) {
					var tab = this._infaTabs.getSelected(),
						objToLeave = this._getInstanceByTab(tab);
					if(objToLeave) {
						var ws = this.getWorkspace(tab);
						$.when(ws.onInstanceLeave(objToLeave.options.instanceView)).then(function() {
							ws.selectInstance(instanceId);
						});	
					} else {
						var ws = this.getWorkspace(ui.tab);
						ws.selectInstance(instanceId);
					}
				} else {
					state.fromRemove = false;
					var ws = this.getWorkspace(ui.tab);
					ws.selectInstance(instanceId);
				}
//				self._tabSelected = false;
			} else {
				// a workspace tab is selected
				this._super(ui);
			}
		}
	},
	
	onTabSelected: function(ui) {
		var instanceId = $(ui.tab).data('instanceId');
		if (instanceId) {
			this._infaTabs.clearFirstTimeEvent(ui.tab);		
		} else {
			this._super(ui);
		} 
	},
	
	onTabLeave: function(ui) {
		// we can add more logic here in the future, if we have a use case of blocking the user from 
		// leaving a tab
		return this._super(ui);
	},
	
	onTabRemove: function(ui) {
		// we can add more logic here in the future, if we have a use case of blocking the user from 
		// removing a tab
		return true;
	},
	
	onTabRemoved: function(ui) {
		var tab = this._infaTabs.getTabByIndex(ui.index),
			instanceId = $(tab).data('instanceId');
		if (instanceId) {
			var state = this._instanceIdState[instanceId];
			if( !state.instanceRemoved ) {
				var ws = this.getWorkspace(tab);
				state.tabRemoved = true;
				ws.removeInstance(instanceId, true);
				state.tabRemoved = false;
			}
			
			// This helps keep prevent calling onInstanceLeave when removing
			state.fromRemove = true;
		}
	},
	
	getActiveMultiObjInstance: function(workspace) {
		return this._getInstanceByTab(this._infaTabs.getSelected());
	},
	
	isWorkspaceUrlable: function(stateObjFromURL) {
		if (!stateObjFromURL.$obj) {
			var ws = this._wsMgr.getWorkspaceMap()[stateObjFromURL.$ws];
			if (ws && ws.extension.$multiTabs === 'true') {
				return false;
			}
		}
		return this._super(stateObjFromURL);
	},
	
	_getInstanceByTab: function(tab) {
		if (tab) {
			return this._tabInstanceMap[tab.id];
		}
	},

	_getTabByInstanceId: function(instanceId) {
		return this._instanceIdState[instanceId].tab;
	}
});

infaw.workspace.WorkspaceStrategy.extend('infaw.workspace.HorizontalWorkspaceStrategy', {

	createMultiObjControl: function(workspace, hasHome) {
		var self = this, 
			wsId = workspace.getInstanceId(),
			wsColor = this._wsMgr.getWorkspaceColor(wsId);

		workspace._$workspaceComposite.removeClass('activeInstance');
		
		var $workspaceTab = $(this.getWorkspaceTab(wsId)),
		 	$multiObjTabs = $('<div></div>').appendTo($workspaceTab).hide();
		
		$multiObjTabs.infaWSObjTabs({
			wsColor: wsColor,
			beforeRemove: function( tab ) {
				return workspace.showActiveInstanceExitDialog();
			}
		});
		var multiObjTabs = $.getWidget($multiObjTabs, 'infaWSObjTabs');
		if (!this._wsIdState[wsId]) {
			this._wsIdState[wsId] = {};
		}
		
		// For workspaces without a homeTab we want to delay selection
		// multiObjTabs will fire onSelect when the first addInstance tab is added
		// We want to delay this event until the the tab is done being added by multiObjTabs
		if(!hasHome) {
			this._wsIdState[wsId].delaySelect = true;
			// Class helps keep track if placeholder is active or not
			workspace._$workspaceComposite.addClass('activePlaceholder');
		}
		
		this._initializeMultiObjEventHandlers(workspace, multiObjTabs);
		this._wsIdState[wsId].multiObjTabs = multiObjTabs;
	},
	
	initializeObjectEditorHandler: function(workspace) {
		var multiObjTabs = this._getMultiObjTabs(workspace);
		return new infaw.workspace.ObjectEditorHandler(this, multiObjTabs);
	},
	
	_initializeMultiObjEventHandlers: function(workspace, multiObjTabs) {
		var self = this;
		var $multiObjTabs = multiObjTabs.element;
		
		var state = self._wsIdState[workspace.getInstanceId()];
		$multiObjTabs.on('onSelect', function(e, ui) {
			if( e.target === e.currentTarget ) {
				if( !state.delaySelect && !self.instanceSelected ) {
					var instance = multiObjTabs.getInstanceByTab(ui.tab), 
						instanceId;
					if(instance) {
						instanceId = instance.id;
					}
					state.tabSelected = true;
					
					// _fromRemove is a flag to prevent calling onInstanceLeave twice on the tab that is being removed
					if( !state.fromRemove ) {
						var objToLeave = multiObjTabs.getInstanceByTab(multiObjTabs.getSelected());
						if(objToLeave) {
							$.when(workspace.onInstanceLeave(objToLeave.options.instanceView)).then(function() {
								workspace.selectInstance(instanceId);
							});	
						} else {
							workspace.selectInstance(instanceId);
						}
					} else {
						state.fromRemove = false;
						workspace.selectInstance(instanceId);
					}
					state.tabSelected = false;
				}
			}
		})
		.on('onInstanceRemove', function(e, tabsToRemove) {
			if(tabsToRemove.length >= 0) {
				// Closing multiple tabs
				var instanceIds = [];
				for(var i = 0, len = tabsToRemove.length; i < len; i++) {
					instanceIds.push(multiObjTabs.getInstanceByTab(tabsToRemove[i]).id);
				}
				workspace.removeInstances(instanceIds);
			} else {
				// Closing only 1 tab
				$.when(workspace.showActiveInstanceExitDialog()).then(function(){
					multiObjTabs.remove(tabsToRemove);
				});
			}
		})
		.on('onRemove', function(e, ui) {
			if( e.target === e.currentTarget ) {
				if( !state.instanceRemoved ) {
					$.each(workspace.objInstances, function(index, instance) {
						if(instance.tab === ui.tab) {
							state.tabRemoved = true;
							workspace.removeInstance(instance.id, true);
							state.tabRemoved = false;
							
							return false;
						}
					});
				}
				
				// This helps keep prevent calling onInstanceLeave when removing
				state.fromRemove = true;
			}
		});
		
		var tabHeight = Math.round($multiObjTabs.children('.ui-tabs-nav').outerHeight(true));
		// Whenever workspace resizes we should also resize the tabs
		this._$elem.on('workspaceResize', function(evt, h) {
			$multiObjTabs.trigger('resize');
			$multiObjTabs.children('.ui-tabs-panel').children('div').height(h - tabHeight);
		});
	},
	
	addMultiObjInstance: function(workspace, instance, $tab, newDivID) {
		var instanceId = instance.options.instanceId,
			state = this._wsIdState[workspace.getInstanceId()],
			newTab = state.multiObjTabs.add( instance ),
			$newDiv = $('<div id="'+newDivID+'" class="wsInstContent"></div>').appendTo($(newTab));
	
		instance.tab = newTab;
		state.multiObjTabs.select( newTab );
		if(state.delaySelect) {
			workspace.selectInstance(instanceId);
			state.delaySelect = false;
		}
		
		var tabHeight = Math.ceil(state.multiObjTabs.element.children('.ui-tabs-nav').outerHeight(true));
		$newDiv.height($tab.height() - tabHeight);
	},
	
	removeMultiObjInstance: function(workspace, instanceId) {
		var state = this._wsIdState[workspace.getInstanceId()];
		if(!state.tabRemoved) {
			var tab = state.multiObjTabs.getTabByInstanceId( instanceId );
			if( tab ) {
				state.instanceRemoved = true;
				state.multiObjTabs.remove( tab );
				state.instanceRemoved = false;
			}	
		}
	},
	
	onInstanceRemoved: function(workspace) {
		// Display the placeholder when there are no instances
		// There is no homeTab for paneledWorkspace
		var state = this._wsIdState[workspace.getInstanceId()];
		if( state.multiObjTabs && workspace.objInstances.length === 0 && !state.multiObjTabs.getHomeTab()) {
			state.multiObjTabs.element.hide();
			$('#' + workspace.getElementId()).show().addClass('activePlaceholder');
			var stateObj = {
					$ws : this._instanceId																																	
			}
			workspace.pushStateURL(stateObj);
			state.delaySelect = true;
		}
	},
	
	updateInstanceName: function (workspace, instanceId, name) {
		var state = this._wsIdState[workspace.getInstanceId()];
		if(state.multiObjTabs) {
			state.multiObjTabs.setLabel(state.multiObjTabs.getTabByInstanceId(instanceId), name);
		}
	},
	
	_getMultiObjTabs: function(workspace) {
		var state = this._wsIdState[workspace.getInstanceId()];
		if (state) {
			return state.multiObjTabs;
		}
	},
	
	/**
	 * Helper function to select object instances
	 */
	selectObjInstance: function(workspace, instance) {
		var state = this._wsIdState[workspace.getInstanceId()];
		if(state && state.multiObjTabs) {
			if(!state.tabSelected) {
				state.instanceSelected = true;
				state.multiObjTabs.select(instance.tab);
				state.instanceSelected = false;
			}
			
			// Currently the placeholder is active
			if( workspace._$workspaceComposite.hasClass('activePlaceholder') ) {
				state.multiObjTabs.element.show();
				this._$workspaceComposite.hide().removeClass('activePlaceholder');
			}
		} else {
			$(state.tab).find('div.activeInstance').removeClass('activeInstance').hide();
			$('#' + instance.divId).addClass('activeInstance').show();
		}
		this._super(workspace, instance);
	},
	
	selectHomeInstance: function(workspace) {
		var state = this._wsIdState[workspace.getInstanceId()];
		if(state && state.multiObjTabs) {
			if(!state.tabSelected) {
				state.instanceSelected = true;
				state.multiObjTabs.select(state.multiObjTabs.getHomeTab());
				state.instanceSelected = false;
			}
		} else {
			var $wsTab = $(state.tab);
			// unselect the previously selected instance
			$wsTab.find('div.activeInstance').removeClass('activeInstance').hide();
			$wsTab.children().eq(0).addClass('activeInstance').show();
		}
	},
	
	canSelectInstance: function(workspace, instanceId) {
		if(workspace.isMultiObj()) {
			if(instanceId !== undefined) {
				return true;
			}
		} else if(instanceId !== undefined) {
			if(instanceId !== workspace.getActiveInstanceId()) {
				return $.when(workspace.showActiveInstanceExitDialog()).then(
					function() {
						return true;
					},
					function() {
						return false;
					}
				);
			}
			return true;
		}
		return false;
	},
	
	canAddInstance: function(workspace) {
		if(this._isMultiObj) {
			return true;
		}
		return $.when(workspace.showActiveInstanceExitDialog()).then(
			function() {
				return true;	
			},
			function() {
				return false;
			}
		);
	},
	
	initTabItem: function(tab, extension) {
		this._super(tab, extension);
		
		var isWSConfigurable = (extension.$isConfigurable === 'true');
		
		if(this._wsMgr._menuProviderMap[extension.$workspaceId] || isWSConfigurable) {
			this._infaTabs.addWSMenu(tab,  extension); //mobile
			var hoverMenu = this._infaTabs.addHoverMenu(tab, extension, this._wsMgr._isHomeMenuMap[extension.$workspaceId]);	//desktop
			this._wsIdState[extension.$workspaceId].hoverMenu = hoverMenu;
		}
	},
	
	getHoverMenu: function(workspaceId) {
		if (this._wsIdState[workspaceId]) {
			return this._wsIdState[workspaceId].hoverMenu;
		}
	},
	
	onTabSelect: function(ui) {
		// hide hover menu when selection changes
		for (var currWSId in this._wsIdState) {
			var state = this._wsIdState[currWSId];
			if (state.hoverMenu && state.hoverMenu.isShown()) {
				state.hoverMenu.hide();
				this._infaTabs.currHoverWS = undefined;
				break;
			}
		}	
		this._super(ui);
	},
	
	onTabRemoved: function(ui) {
		var tab = this._infaTabs.getTabByIndex(ui.index);
		var workspaceId = this._getWorkspaceId(tab);
		if(workspaceId){
			var workspace = this._wsMgr.getWorkspaceMap()[workspaceId],
				hoverMenu = this._wsIdState[workspaceId].hoverMenu;
			if (hoverMenu && hoverMenu.isShown()) {
				hoverMenu.hide();
				$(document).off('mousemove.extensibleWSHoverMenu');
			}
			if (this._infaTabs.currHoverWS && this._infaTabs.currHoverWS.hoverMenu === hoverMenu) {
				this._infaTabs.currHoverWS = undefined;
			}
			delete this._wsIdState[workspaceId].hoverMenu;
		}
	},
	
	getActiveMultiObjInstance: function(workspace) {
		var state = this._wsIdState[workspace.getInstanceId()];
		if (state && state.multiObjTabs) {
			var activeTab = state.multiObjTabs.getActive();
			if(activeTab) {
				return state.multiObjTabs.getInstanceByTab( activeTab );
			}
		}
	}
	
});
/**
 * @author clam
 * 
 * A workspace that supports panels and contextual panel.
 * 
 */
infaw.workspace.AbstractWorkspace.extend('infaw.workspace.PaneledWorkspace', {

	_bundle: infaw.workspace.I18nResources,
	_$workspaceComposite: null,
	_portletContainer: undefined,
	_queryResultSets: [],
	
	init: function() {
		this._objectCacheMgr = new infaw.workspace.ObjectCacheManager();
		this.$header = infaw.page.PageManager.instance().getHeader();
	},

	/**
	 * @param {string} blockElementId The id of the DOM element where the workspace content is to be added
	 * @param {string} instanceId It is a unique namespaced identifier for a workspace which is currently the workspaceId
	 *                e.g. 'startPageWS'
	 */
	initialize: function(blockElementId, instanceId, noPortletInit) {
		this._super(blockElementId, instanceId);
		this._$workspaceComposite =  $('#' + blockElementId);
		this._workspaceMgr = infaw.workspace.WorkspaceManager.instance();
		if(this.isMultiObj()) {
			infaw.workspace.WorkspaceStrategy.instance().createMultiObjControl(this);
		}
		
		this._objEditorHandler = this.initializeObjectEditorHandler();

		this.registerEvents();
		if(!noPortletInit && !this.isMultiObj()) {
			return this.initializePortletContainer();		
		}
	},	
	
	initializePortletContainer: function() {
		this._$workspaceComposite.infaFloatPanelComposite({
			panelOptions : this.getFloatPanelOptions()
		});

		var self = this,
		$mainElement = this._getMainElement().portletContainer(this.getPortletContainerOptions());

		this._portletContainer = $.getWidget($mainElement, 'portletContainer');	
		
		return $.when(this._portletContainer.createPortlets()).done(function() {
			self.onLoaded();
		});
	},
	
	initializeObjectEditorHandler: function() {
		return infaw.workspace.WorkspaceStrategy.instance().initializeObjectEditorHandler(this);
	},
	
	isMultiObj: function() {
		return this._isMultiObj;
	},
	
	/**
	 * Called when initializing workspace and also when onPopState
	 */
	processStateURL: function(stateObj) {
		var object = stateObj.$obj;
		if(object) {
			var lwObject = this.getLwObjectFromState(object);
			if(lwObject) {
				var instanceId = lwObject.$$IID;
				
				if(this.isInstanceExists(instanceId)) {
					this.selectInstance(instanceId);
				} else if( !this.isTempObject(instanceId) ) {
					
					$.blockElem();
					return $.when(this.openObject(lwObject, 'read')).always(function() {
						$.unblockElem();
					});
				} else {
					// TODO: Display 404 Page?
					delete this.getWorkspaceStateObj().$obj;
					this.selectInstance();
				}
			}
		} else {
			// Select Home
			return this.selectInstance();
		}
	},

	setReadOnly: function(readOnly) {
		this._super(readOnly);
		if(this._portletContainer) {
			var $portlets = this._portletContainer.getPortlets();
			for (var i = 0; i < $portlets.length; i++) {
				var portlet = this._portletContainer.getPortletInstance($portlets[i]);
				if (portlet) {
					portlet.setReadOnly(readOnly);
				}
			}			
		}
	},

	onWorkspaceSelect : function(modes) {
		if(this._portletContainer) {
			this._getMainElement().trigger('resizePortletContainer');	
		}		
		// If addInstance is true, that means the instance is in the process of being initialized.
		// onReenter is not needed in such case.
		if (!modes || !modes.addInstance && !modes.selectHome && !modes.selectInstance) {
			var activeInst = this.getActiveInstance();
			if(activeInst) {
				this.onInstanceReenter(this.getActiveInstanceId(), activeInst);
			}
		}
	},
	
	onInstanceReenter: function(instanceId, instance) {
		if (instance && instance.onReenter) {
			instance.onReenter();
		}
	},
	
	/**
	 * Called when Save Button clicked on Workspace Toolbar
	 */
	onWorkspaceSave : function()  {
		this._portletContainer.saveAndCommit();
		this.saveEditSet().fail(function(resp) {
			infaw.shell.common.Utils.showErrorFromResponse(resp);
		});
		
	},
	
	onWorkspaceLeave: function(beforeunload) {
		if(this._portletContainer) {
			this._portletContainer.saveAndCommit();	
		}
		
		if(!beforeunload){
			return this.onInstanceLeave(this.getActiveInstance());
		} else if(this._isMultiObj) {
			// We are reloading or exiting the page so we want to check if all instances are saved
			return this._showAllInstanceExitDialog(beforeunload);
		} else {
			return this.showActiveInstanceExitDialog(beforeunload);
		}
	},
	
	beforeLogout: function() {
		if(this._isMultiObj) {
			var objInstances = this.objInstances;
			if(objInstances) {
				var instanceIds = [];
				for(var i = 0, len = objInstances.length; i < len; i++) {
					instanceIds.push(objInstances[i].id);
				}
				
				var instances = this._getSavableAndUnsavableInstances(instanceIds);
				instances.workspaceId = this._instanceId;
				return instances;
			}
		} else {
			var instanceId = this.getActiveInstanceId();
			if(instanceId) {
				var instances = this._getSavableAndUnsavableInstances([instanceId]);
				instances.workspaceId = this._instanceId;
				return instances;
			}
		}
	},
	
	onWorkspaceRemove: function() {
		if(this._isMultiObj) {
			var objInstances = this.objInstances;
			if(objInstances) {
				var instanceIds = [];
				for(var i = 0, len = objInstances.length; i < len; i++) {
					instanceIds.push(objInstances[i].id);
				}
				return this.removeInstances(instanceIds);		
			}
		} else {
			return this.showActiveInstanceExitDialog();	
		}
	},
	
	getWorkspaceStateObj : function() {		
		return this._workspaceMgr.getWorkspaceStateObj(this._instanceId);
	},
	
	getFloatPanelOptions : function() {
		var options = {
			width : this.getFloatPanelDefaultWidth()
		};
		return options;
	},

	getFloatPanelDefaultWidth : function(){
		return '200px';
	},	
	
	
	getPortletContainerOptions: function() {
		var self = this,
			portletContainerOptions = { 
				parentId: this.getInstanceId(),
				columns: this.getColumnCount(),
				rowHeight: function(){ 
					return self.getRowHeight();
				},
				movable: this.isPortletMovable(),
				resizable: this.isPortletResizable(),
				data: [{key: 'workspace', value: this}],
				lazy: true
			};
		
		return portletContainerOptions;
	},

	getColumnCount: function() {
		return 3;
	},	

	getObjectInstanceId: function(object) {
		return object.$$IID || object.$$OID || object.$$ID;
	},
	
	/*
	 * Default row height is max height. 
	 */
	getRowHeight: function() {
		return this._$workspaceComposite.height();
	},

	isPortletMovable: function() {
		return false;
	},

	isPortletResizable: function() {
		return false;
	},

	openObject: function(){
		// needs to be implemented by subclasses
	},

	registerEvents: function() {
		var self= this,
		eventMgr = this.getEventManager();

		eventMgr.registerEvents({
			'onSelectChange' :  function(event, selectedObj) {
				self.onSelectChangeCallback(selectedObj); 
			},
			'clearSelection' : function(event, data) {
				self.getFloatPanel().hide();
			},
			'onWorkspaceResize': function(){
				if(self._portletContainer)
					self._portletContainer.element.trigger('resizePortletContainer');
			}
		});
	},	

	onSelectChangeCallback : function(selectedObj){
		var self = this;
		var $eMenus = this._$workspaceComposite.find(':extensibleMenu');
		if ($eMenus.length > 0) {
			for (var i = 0; i < $eMenus.length; i++) {
				var $eMenu = $eMenus.eq(i);
				var eMenu = $.getWidget($eMenu, 'extensibleMenu');
				eMenu.setContextObject(selectedObj);
				eMenu.refreshState();				
			}
		}						
	},

	getFloatPanel: function() {
		var workspaceComposite = $.getWidget(this._$workspaceComposite, 'infaFloatPanelComposite');
		var $floatPanel = workspaceComposite.getFloatPanel();
		return $.getWidget($floatPanel, 'infaFloatPanel');
	},
	
	getFloatPanelHeight: function() {
		var workspaceComposite = $.getWidget(this._$workspaceComposite, 'infaFloatPanelComposite');
		var $floatPanel = workspaceComposite.getFloatPanel();
		return $floatPanel.height();
	},

	isFloatPanelVisible : function(){
		var workspaceComposite = $.getWidget(this._$workspaceComposite, 'infaFloatPanelComposite');
		var $floatPanel = workspaceComposite.getFloatPanel();
		return $floatPanel.is(':visible');
	},

	getSelection: function() {
		var portletContainer = $.getWidget(this._getMainElement(), 'portletContainer');
		// TODO for now just get the selection from the first portlet
		var portlets = portletContainer.getPortlets();
		if (portlets.length > 0) {
			return portletContainer.getSelection(portlets[0]);
		}
	},

	_getMainElement: function() {
		var workspaceComposite = $.getWidget(this._$workspaceComposite, 'infaFloatPanelComposite');
		return workspaceComposite.getMainElement();
	},	

	updateFloatPanelContent: function(selectedObj, storage, panelInstanceId) {
		var self = this, 
		$readOnlyDeferred = $.Deferred();  // contains the readOnly value
		if (storage) {
			var id; 
			var idForm;
			if ('$$IID' in selectedObj) {
				id = selectedObj.$$IID;
				idForm = 1;
			} else if ('$$OID' in selectedObj) {
				id = selectedObj.$$OID;
				idForm = 2;
			} else {
				id = selectedObj.$$ID;
			}	
			// Un-comment after the contextual panel no longer updates based on selection changes in
			// the panel.
//			infa.model.access.ObjectAccessManager.instance().isReadOnly(id, selectedObj.$$class, storage, idForm).done(function(result) {
//				window.console.log(result.value);
//				$readOnlyDeferred.resolve(result.value);
//			});
			$readOnlyDeferred.resolve(false);
		} else {
			$readOnlyDeferred.resolve(false);
		}

		$readOnlyDeferred.done(function(result) {
			var floatPanel = self.getFloatPanel().showPanel(),
				$floatPanelContent = floatPanel.getContentElement(),				
				propfwkInst = infaw.propertiesFramework.PropertiesFrameworkManager.instance(),
				floatPanelPos = floatPanel.options.attachment,
				tabsPos = (floatPanelPos && floatPanelPos === 'bottom') ? 'left' : 'top';
			
			if(selectedObj.name) {			
				floatPanel.setTitle(selectedObj.name);
			}
			//set the object context and ui context
			floatPanel.setUIContext(panelInstanceId);
			floatPanel.setObjectContext(selectedObj);
			
			propfwkInst.createUI({
				$propertiesDiv: $floatPanelContent, 
				selectedObj: selectedObj, 
				tabsPosition: tabsPos,
				isReadOnly: result
			});
		});
	},


	/**
	 * Create iterative result set
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		type			: 'browse' | 'query'  (By default 'browse')
	 *		data			: {},	
	 * }
	 * 
	 * @return promise 
	 */	
	createIterativeResult: function(options) {
		return infa.model.ObjectUtil.instance().createIterativeResult(options);
	},
	
	/**
	 * Delete iterative result set
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''
	 * }
	 * 
	 * @return promise 
	 */	
	removeIterativeResult: function(options) {
		return infa.model.ObjectUtil.instance().removeIterativeResult(options);
	},	


	/**
	 * Get iterative results count
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''	
	 * }
	 * 
	 * @param {{storage, resultSetName}} options
	 * @return promise
	 */	
	getIterativeResultCount: function(options) {
		return infa.model.ObjectUtil.instance().getIterativeResultCount(options);
	},

	/**
	 * Fetch the lwObjects from iterative results.
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''	
	 *		startIndex		: '',
	 *		endIndex		: '',
	 *		typeName		: qualified|logical (qualified with output as ids with a map on what the ids mean. Logical outputs simple registered names)
	 *		idForm			: 1 | 2 | 3 (objectid, identity, generated), 
	 *		flat			: true | false,
	 *		verbose			: true | false,
	 * }
	 * 
	 * @param {{storage, resultSetName, startIndex, endIndex, flat, verbose, idForm}} options
	 * @return promise which returns array of lwObjects when promise is resolved
	 */
	getLwObjectsFromIterativeResults : function(options){
		return infa.model.ObjectUtil.instance().getLwObjectsFromIterativeResults(options,this._objectCacheMgr);
	},
	
	/**
	 * Get iterative results facets
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''	
	 * }
	 * 
	 * @param {{storage, resultSetName}} options
	 * @return promise
	 */	
	getIterativeResultFacets: function(options) {
		return infa.model.ObjectUtil.instance().getIterativeResultFacets(options);
	},
	

	
	/**
	 * Get iterative result index
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		objId	: '',
	 *		metaClassId: ''
	 *		idForm	: 1 | 2 | 3 (objectid, identity, generated)
	 * }
	 * 
	 * @param {{storage, resultSetName, objId, metaClassId}} options
	 * @return promise
	 */	
	getIterativeResultIndex: function(options) {
		return infa.model.ObjectUtil.instance().getIterativeResultIndex(options);
	},
	
	/**
	 * Remove the item in the Result Set 
	 * 
	 * Use LightWeightProviderServlet
	 *  DELETE /lightweight/mrs1/result1/20	 removes item at index 20 from the resultset
	 *  DELETE /lightweight/mrs1/result1/20,35,42 removes items at index 20, 35 and 42 from the resultset
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		index			: number or Array of number
	 * }
	 * 
	 * @param {{storage, resultSetName, index}} options
	 * @return promise
	 */	
	removeIterativeResultItem: function(options) {
		return infa.model.ObjectUtil.instance().removeIterativeResultItem(options);
	},

	/**
	 * Add the item in the Result Set 
	 * 
	 * Use below REST URL
	 *     PUT /lightweight/mrs1/result1/10 - Adds these items starting at index 10.
	 *     [
	 *     		{
	 *            [$$OID|$$IID]: [10|U:w-f-V8evEeC9Iu4hf_YhEA]
	 *            [$$class|$$type]: [20|Mapping]
	 *          }
	 *          ...
	 *     ]
	 *     
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		index			: number or Array of number,
	 *		data			: []  e.g. [{$ID: 10, $$class: 20},..]
	 * }
	 * 
	 * @param {{storage, resultSetName, index}} options
	 * @return promise
	 */	
	addIterativeResultItem: function(options) {
		return infa.model.ObjectUtil.instance().addIterativeResultItem(options);
	},


	/**
	 * Updated the item in the Result Set 
	 * 
	 * Use below REST URL
	 *     POST /lightweight/mrs1/result1/10 
	 *     		{
	 *            [$$OID|$$IID]: [10|U:w-f-V8evEeC9Iu4hf_YhEA]
	 *            [$$class|$$type]: [20|Mapping]
	 *          }
	 *     
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		index			: number or Array of number,
	 *		data			: {}  e.g. {$ID: 10, $$class: 20}
	 * }
	 * 
	 * @param {{storage, resultSetName, index}} options
	 * @return promise
	 */	
	updateIterativeResultItem: function(options) {
		return infa.model.ObjectUtil.instance().updateIterativeResultItem(options);
	},
	
	getLwObjectsFailIfNone : function(options){
		var $deferred = $.Deferred(),
			$i18nAlias = infaw.workspace.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		this.getLwObjects(options).then(function(lwObjects) {
			if(lwObjects  && lwObjects.length && lwObjects.length > 0) {
				$deferred.resolve(lwObjects);
			} else {
				// format it this way because many callers expect json error message from server
				$deferred.reject({
					"responseText": '{"description": "' + 
						$textUtils.getText($i18nAlias.ERROR_OBJECT_DELETED_OR_MODIFIED) + '" }'
				});
			}
		});
		return $deferred.promise();
	},
	
	/**
	 * Fetch the lwObjects from server.
	 * 
	 * options - {
	 *		storage	: '', 
	 *		typeName: qualified|logical (qualified with output as ids with a map on what the ids mean. Logical outputs simple registered names)
	 *		flat	: true | false, 
	 *		verbose : true | false, 
	 *		idForm	: 1 | 2 | 3 (identity, objectid, generated), 
	 *		cached	: true/false,
	 *		lwObject: '',
	 *		what: self | children | descendants  (default is descendants)
	 * }
	 * 
	 * @param {{storage, flat, verbose, idForm, cached}} options
	 * 
	 * @return promise which returns array of lwObjects when promise is resolved
	 */
	getLwObjects : function(options){
		return infa.model.ObjectUtil.instance().getLwObjects(options,this._objectCacheMgr);
	},

	/**
	 * Fetch the object from server.
	 * 
	 * options - {
	 *		objId	: '',
	 *		metaClassId: '',
	 *		storage	: '', 
	 *		flat	: true/false, 
	 *		verbose : true/false, 
	 *		idForm	: 1/2/3, 
	 *		cached	: true/false, false if not specified
	 *		mode	: read/edit, read if not specified
	 *		force	: true/false
	 * }
	 * 
	 * If object is already fetched for mode = 'edit' - return the cached the object. 
	 * If object is already fetched for mode = 'read' - re fetch the object, update the cache & return the latest object.
	 * If object is already fetched for any mode (read or edit) and option cached is true - return the cached the object. 
	 * 
	 * @param {{objId, metaClassId, storage, idForm, dependencies, translateMetaClassId, cached, mode, force}} options
	 * 
	 * @return promise which returns object when promise is resolved.
	 */
	getObject: function(options) {
		var objId = options.objId, 
		metaClassId = options.metaClassId, 
		storage = options.storage, 
		idForm = options.idForm, 
		dependencies = (options.dependencies !== undefined ? options.dependencies : true), 
		translateMetaClassId = options.translateMetaClassId,
		cached = options.cached,
		mode = options.mode,
		force = options.force,
		self=this,
		$deferred = $.Deferred();

		var cachedObj = this._objectCacheMgr.retrieve(storage, objId);
		if(cachedObj) {
			var object = cachedObj.object;			
			if(object && !force &&  (cachedObj.mode === 'edit' || cached === true)) {
				return $deferred.resolve(object).promise();
			}
		}		

		if(mode === 'edit') {
			var objectEditSetInstance = infa.model.ObjectEditSet.instance();			
			$.when(this._getEditSet(storage, options.editSet)).then(function(editSet){									
				$.when(objectEditSetInstance.blockEditSetSelected(objId, metaClassId, storage, editSet)).then(function(){
					$.when(objectEditSetInstance.blockObjectGet(objId, metaClassId, storage, editSet, idForm, dependencies, translateMetaClassId)).done(function(object){			
						var cachedObject = self._objectCacheMgr.cacheObject(object, options);
						$deferred.resolve(cachedObject);
					}).fail(function(arg) {
						$deferred.reject(arg);
					});
				}).fail(function(arg) {
					$deferred.reject(arg);
				});			
			});
		} else {
			var objectGetterInstance = infa.model.ObjectGetter.instance();			
			$.when(objectGetterInstance.blockObjectGet(objId, metaClassId, storage, idForm, dependencies, translateMetaClassId)).done(function(object){					
				var cachedObject = self._objectCacheMgr.cacheObject(object, options);
				$deferred.resolve(cachedObject);
			}).fail(function(arg) {
				$deferred.reject(arg);
			});
		}

		return $deferred.promise();
	},	

	_getEditSet: function(storage, editSet) {
		if(!this._$createEditSetDef) {
			var self = this;
			var editSetName = editSet !== undefined ? editSet :this._$workspaceComposite.attr('id'); // Use blockElementId as editSet as it is unique ID
			this._editSetStorage = storage;
			this._$createEditSetDef = infa.model.ObjectEditSet.instance().blockEditSetCreate(storage, editSetName).then(function(){
				self._editSet = editSetName; 
				return self._editSet;
			});			
		}
		return this._$createEditSetDef;
	},

	saveEditSet: function(){
		if(this._editSet) {
			var self = this,
				objectEditSetInstance = infa.model.ObjectEditSet.instance();
			return objectEditSetInstance.blockEditSetSave(this._editSetStorage, this._editSet).then(function() {
				if (window.console){
					window.console.log('Workspace saved');
				}
				self._objectCacheMgr.clearDirtyFlag();
			});
		}
	},
	
	deleteEditSet: function(){
		if(this._editSet) {
			var self = this,
				objectEditSetInstance = infa.model.ObjectEditSet.instance();
			return objectEditSetInstance.blockEditSetDelete(this._editSetStorage, this._editSet).then(function() {
				delete self._$createEditSetDef;
				delete self._editSet;
			});
		}
	},
	

	objectEdited: function(object, storage, propagateChange, origin) {				
		if (propagateChange) {
			var self = this,
				idType = 3,
				idAttr = '$$ID',
				objectEditSetInstance = infa.model.ObjectEditSet.instance();

			if ('$$IID' in object) {
				idType = 1;
				idAttr = '$$IID'; 
			} else if ('$$OID' in object) {
				idType = 2;
				idAttr = '$$OID';
			} else if ('$$ID' in object) {
				idType = 3;	
				idAttr = '$$ID';
			}
			
			return $.when(this._getEditSet(storage)).then(function(editSet){									
				return objectEditSetInstance.blockEditSetUncommitted(object, storage, editSet, idType).then(function(propogatedObjects) {
					if (window.console){
						window.console.log('propogatedObjects:');
						window.console.log(propogatedObjects);
					}
					var editedObjects = [];
					editedObjects.push(object);
					if(propogatedObjects && $.isArray(propogatedObjects)) {					
						var $deferredArr = [];
						$.each(propogatedObjects, function(index, propogatedObject) {							
							var propogatedObjCache = self._objectCacheMgr.retrieve(storage, propogatedObject[idAttr]);
							if(propogatedObjCache && propogatedObjCache.object) {
								//Re Fetch all propogated objects										
								var $deferred = self.getObject({
									objId: propogatedObject[idAttr], 
									metaClassId: propogatedObject.$$class, 
									storage: storage, 
									idForm: idType,
									force: true,
									mode: 'edit'
								}).then(function(pObject) {									
									if(pObject[idAttr] != object[idAttr]) {
										self.objectEdited(pObject, storage, propagateChange, origin);	
									}									
									editedObjects.push(pObject);
									return;
								});
								$deferredArr.push($deferred);								
							}						
						});
						return $.when.apply($, $deferredArr).done(function() {
							self._triggerObjectEdit(editedObjects, storage, propogatedObjects.length > 0, origin);
						});
					} else {
						self._triggerObjectEdit(editedObjects, storage, origin);
					}						
				});

			});
		} else {
			this._triggerObjectEdit([object], storage, origin);
		}
	},


	_triggerObjectEdit : function(editedObjects, storage, hasPropogatedObjects, origin) {
		//Update Cache		
		var affectedObjects = this._objectCacheMgr.updateObjectCache(editedObjects, storage);

		if(affectedObjects && affectedObjects.length > 0) {
			editedObjects = editedObjects.concat(affectedObjects);
			this.removeDuplicates(editedObjects);
		}			

		this.getEventManager().sendEvent('onObjectEdit', [editedObjects, hasPropogatedObjects, origin]);
	},


	//Utility method move it to utility class later
	removeDuplicates: function(a) {
		for(var i=0; i<a.length; ++i) {
			for(var j=i+1; j<a.length; ++j) {
				if(a[i] === a[j]) {
					a.splice(j, 1);
				}					
			}
		}
	},

	addPanel: function(){
		this._portletContainer.addPanel();
	},
	
	getPortletContainer: function(){
		return this._portletContainer;
	},
	
	/**
	 * Add object instance into this workspace
	 * options - {
	 *		instanceId		:	'',
	 *		instanceName	:	'',
	 *		icon			:	'',
	 *		metaClassName	:	'',
	 * } 
	 */	
	addInstance: function(options) {	
		var self = this;
		
		return $.when(infaw.workspace.WorkspaceStrategy.instance().canAddInstance(this)).then(function(res) {
			if (res) {
				return self._addInstance(options);
			}
		});
	},
	
	_addInstance: function(options) {
		var that = this,
			instanceId = options.instanceId + '', 
			$tab = this._$workspaceTab,
			tabId = $tab.length ? $tab.attr('id') : 'ws-',
			// TODO: Need to add a test workspace to help test all the URLability
			jqueryID = $.htmlId(tabId + 'obj');
		
		$.blockElem();
		
		if(!this.objInstancesMap || !this.objInstancesMap[instanceId]) {
			if (!this.objInstances) {
				this.objInstances = [];
				this.objInstancesMap = {};
			}
			
			var instance = {
					id : instanceId,
					divId : jqueryID,
					options: options
			};
			this.objInstances.push(instance);
			this.objInstancesMap[instanceId] = instance;

			infaw.workspace.WorkspaceStrategy.instance().addInstance(this, instance);
		} else {
			this.selectInstance(instanceId);
		}
		
		$.unblockElem();
		return jqueryID;
	},
	
	updateInstanceName: function (instanceId, name) {
		if(this.objInstancesMap) {
			var instance = this.objInstancesMap[instanceId];
			if( instance ) {
				instance.options.instanceName = name;
			}
		}
		infaw.workspace.WorkspaceStrategy.instance().updateInstanceName(this, instanceId, name);
	},
	
	updateInstanceView: function(instanceId, instanceView) {
		if(this.objInstancesMap) {
			var instance = this.objInstancesMap[instanceId];
			if( instance ) {
				instance.options.instanceView = instanceView;
			}
		}
	},
	
	/**
	 * Remove the object instance from this workspace
	 */
	removeInstance: function(instanceId) {
		if( !instanceId || !this.objInstancesMap ) {
			return; //workspace instances is not supported for this workspace
		}
		infaw.workspace.WorkspaceStrategy.instance().removeInstance(this, instanceId);
		this._removeObjInstance(instanceId);
	},
	
	/**
	 * Helper function to help remove obj instances
	 */
	_removeObjInstance: function(instanceId) {
		this.onWorkspaceSelect();

		var objInstancesMap = this.objInstancesMap,
			objInstances = this.objInstances,
			instance = objInstancesMap[instanceId],
			index = objInstances.indexOf(instance);
		
		objInstances.splice(index, 1);
		objInstancesMap[instanceId] = null;
		
		infaw.workspace.WorkspaceStrategy.instance().onInstanceRemoved(this);
	},
	
	isInstanceExists: function(instanceId) {
		if( !instanceId || !this.objInstancesMap ) {
			return false; //workspace instances is not supported for this workspace
		}
		
		if(this.objInstancesMap[instanceId]) {
			return true;
		} else {
			return false;
		}
	},
	
	selectInstance: function(instanceId) {
		if( !this.objInstancesMap ) {
			return; //workspace instances is not supported for this workspace
		}

		var self = this;
		return $.when(infaw.workspace.WorkspaceStrategy.instance().canSelectInstance(this, instanceId)).then(function(res) {
			if (res) {
				return self._enterInstance(instanceId);
			}
		});
	},
	
	_enterInstance: function(instanceId) {
		var instance = this.objInstancesMap[instanceId];
		if(instance) {
			infaw.workspace.WorkspaceStrategy.instance().selectObjInstance(this, instance);
			var inst = instance.options.instanceView;
			if (inst) {
				this.onInstanceReenter(instanceId, inst);
			}
			return instance;
		}
	},
	
	getActiveInstance: function(){
		if(!this.objInstances) {
			return null; 
		}
		var instance = this._getActiveObjInstance();
		if(instance) {
			return instance.options.instanceView;
		}
		return null;
	},
	
	getActiveInstanceId: function() {
		if(!this.objInstances) {
			return null; 
		}
		var instance = this._getActiveObjInstance();
		if(instance) {
			var instanceView = instance.options.instanceView;
			if(instanceView){
				return instance.id;
			}
		}
		return null;
	},

	/**
	 * Helper function to grab instance object associated with the selected tab
	 */
	_getActiveObjInstance: function() {
		return infaw.workspace.WorkspaceStrategy.instance().getActiveInstance(this);
	},
	
	/**
	 * Opens a new object in an editor
	 */
	newObjectInEditor : function(lwObject, options) {
		return this._objEditorHandler.newObjectInEditor(lwObject, options);
	},
	
	openObjectInEditor: function(object, mode) {
		return this._objEditorHandler.openObjectInEditor(object, mode);
	},
	
    getMetaClassName: function(lwObject) {
    	if(lwObject) {
        	var $$class = lwObject.$$class;
        	if($.isNumeric($$class)) {
        		return infa.imf.IClassInfo.instance().iClassById($$class).then(function(iclassinfo){
        			return iclassinfo.name;
        		});
        	} else {
        		return $$class;
        	}
    	}
    	return undefined;
    },

    /**
     * This is called when we are closing a workspace or leaving a workspace
     * We want to make sure that it is okay to close all the instances
     */
	_showAllInstanceExitDialog: function(beforeunload) {
		// No instances so we can close
		if(!this.objInstances) {
			return true;
		}
		
		var self = this,
			canExit = true;
		
		$.each(this.objInstances, function(index, instance) {
			var instanceView = instance.options.instanceView;
			if(instanceView) {
				canExit = self._showExitDialog(instanceView, beforeunload);
				if(!canExit) {
					return false;
				}
			}
		});
		
		return canExit;
	},
	
	/**
	 * We are leaving the instance in single object mode 
	 * or we are closing the instance in multi object mode
	 * This helps check if it is ok to continue
	 */
	_showExitDialog: function(instanceView, beforeunload) {
		var self = this;
		if(instanceView && 'showExitDialog' in instanceView) {
			if(beforeunload) {
				return instanceView.showExitDialog(beforeunload) !== false;
			}

			var $exitDeferred = $.Deferred();
			$.when(instanceView.showExitDialog()).then(function(res){
				if(res !== false) {
					$exitDeferred.resolve();	
				} else {
					$exitDeferred.reject();
				}
			}, function() {
				$exitDeferred.reject();
			});
			return $exitDeferred.promise();
		}
	},
	
	onInstanceLeave: function(instanceView) {
		var self = this;
		if(instanceView && 'onLeave' in instanceView) {
			var $onLeaveDef = $.Deferred();
			return $.when(instanceView.onLeave()).always(function(res){
				$onLeaveDef.resolve();
			});
			return $onLeaveDef.promise();
		}
	},
	
	/**
	 * Calls the activeInstance's showExitDialog function 
	 * If beforeunload it will return either true or false if it is ok to exit.
	 * Else it will return a promise that will be rejected if we should not exit this instance
	 * or resolve if its ok to exit
	 */
	showActiveInstanceExitDialog: function(beforeunload) {
		var activeInstance = this.getActiveInstance();

		if(activeInstance) {
			return this._showExitDialog(activeInstance, beforeunload);
		} else if(beforeunload) {
			return true;
		}
	},
	
	_formatAndPushState: function(instance) {
		var instanceId = instance.id, 
			metaClassName = instance.options.metaClassName, 
			mixin = instance.options.mixin;
		
		var stateObj = this.getWorkspaceStateObj();
		stateObj.$obj = instanceId + '@' + metaClassName;
		if(mixin) {
			stateObj.$obj += '@' + mixin; 
		}
		
		this.pushStateURL(stateObj);
	},
	
	getLwObjectFromState: function(lwObjectStr) {
		var objArr = lwObjectStr.split('@');
		if(objArr && objArr.length >= 2) {
			var lwObject = {
					$$IID: objArr[0],
					$$class: objArr[1]
				};
				
			if( objArr.length >= 3) { 
				lwObject.$mixins = [objArr[2]];	
			}
			
			return lwObject;
		}
	},
	
	/**
	 * Remove the instances given in instanceIds
	 * 
	 * @param {Array.<string>} instanceIds - array of instanceId that needs to be closed
	 * @param {Array.<Object>} saveInstances - array of instances to save (Means that we can attempt to save and close these tabs)
	 * @returns - $promise that finishes when all the tabs are done being closed. Will reject if tabs cannot be saved and resolve if all tabs can be closed
	 */
	removeInstances: function(instanceIds, saveInstances) {
		var objInstancesMap = this.objInstancesMap;
		if(!objInstancesMap) {
			return; // ObjInstances not supported
		}
		
		if(saveInstances) {
			return this._saveAndRemoveInstances(instanceIds, saveInstances);
		}
		
		// Check all the tabs' instances if any of them are dirty
		var savableAndUnsavableInstances = this._getSavableAndUnsavableInstances(instanceIds),
			savableInstances = savableAndUnsavableInstances.savable,
			unsavableInstances = savableAndUnsavableInstances.unsavable;
		
		var self = this;
		return $.when(this._createCloseTabsDialog(savableInstances, unsavableInstances)).then(function(saveInstances) {
			return self._saveAndRemoveInstances(instanceIds, saveInstances);
		});
	},
	
	_getSavableAndUnsavableInstances: function(instanceIds) {
		var objInstancesMap = this.objInstancesMap;

		var unsavableInstances = [], savableInstances = [];
		// Find all the dirty instances and check which can be saved or not
		for(var i = 0, len = instanceIds.length; i < len; i ++) {
			var instance = objInstancesMap[instanceIds[i]];
			
			var activeInstance = instance.options.instanceView;
			if(activeInstance && activeInstance.isDirty && activeInstance.isDirty()) {
				if( activeInstance.canSave && activeInstance.canSave() ) {
					savableInstances.push(instance);
				} else {
					unsavableInstances.push(instance);
				}
			}
		}
		return {savable: savableInstances, unsavable: unsavableInstances};
	},
	
	/**
	 * Helper function to help save and remove the instances
	 * 
	 * @param {Array.<string>} instanceIds - array of instanceId that needs to be closed
	 * @param {Array.<Object>} saveInstances - array of instances that the user wants to save
	 */
	_saveAndRemoveInstances: function(instanceIds, saveInstances) {
		var self = this;
		var $promiseArr = [];
		var rejectFlag = false;

		var firstFailedInstance;
		if(saveInstances) {
			// Go through each of the instances that the user wants to save and save them
			$.each(saveInstances, function(index, instance) {
				var activeInstance = instance.options.instanceView;
				var $deferred = $.Deferred();
				$.when(activeInstance.save()).done(function() {
					// New objects automatically save themselves when they are saved 
					// so we want to remove them from instanceIds so we don't try to remove them again
					if( self.isTempObject(instance.id) ) {
						var index = instanceIds.indexOf(instance.id);
						instanceIds.splice(index, 1);
					}
				}).fail(function() {
					// We do not want to remove instances that fail so we remove it out of the instanceIds
					var index = instanceIds.indexOf(instance.id);
					instanceIds.splice(index, 1);
					if(!rejectFlag) {
						firstFailedInstance = instance.id;
						rejectFlag = true;
					}
				}).always(function() {
					// We always want to resolve so that we can attempt to save all the instances
					// If we reject once this means we won't even try to close other instances
					$deferred.resolve();
				});
				$promiseArr.push($deferred.promise());
			});
		}

		var $deferred = $.Deferred();
		// Remove all the instances in instanceIds
		$.when.apply($, $promiseArr).then(function() {
			for(var i = 0, len = instanceIds.length; i < len; i ++) {
				self.removeInstance( instanceIds[i] );
			}
			if(rejectFlag) {
				$deferred.reject(firstFailedInstance);
			} else {
				$deferred.resolve();
			}
		});
		
		return $deferred.promise();
	},
	
	/**
	 * Helper method that creates a dialog asking if user wants to save all the dirty tabs
	 * 
	 * @param {Array.<Object>} savableInstances - Array of instances that can be saved
	 * @param {Array.<Object>} unsavableInstances - Array of instances that cannot be saved
	 */
	_createCloseTabsDialog: function(savableInstances, unsavableInstances) {
		if( savableInstances.length === 0 && unsavableInstances.length === 0 ) {
			// No dirty instances so we don't need to create close dialog
			return;
		}
		
		var $deferred = $.Deferred();
		var $dialog = $('<div></div>');
		var $savableInstances = $('<div></div>');
		
		var saveSelected = function(e) {
			var instanceGrid = $.getWidget($savableInstances, 'infaGrid');
			var selectedRows = instanceGrid.getSelectedRow();
			
			var instanceArr = []; 
			for(var i = 0, len = selectedRows.length; i < len; i++) {
				instanceArr.push(instanceGrid.getRowDataObject(selectedRows[i]));
			}
			
			var dialog = $.getWidget($(this), 'infaDialog');
			dialog.destroy();
			
			$deferred.resolve(instanceArr);
		};
		
		$dialog.html($.getLocalizedText(this._bundle, 'UNSAVED_CLOSE_ALL_MSG'))
			.infaDialog({
				title: $.getLocalizedText(this._bundle, 'UNSAVED_CLOSE_ALL_TITLE'),
				buttonLabels: {
					OK : $.getLocalizedText(this._bundle, 'OK_LABEL'),
					CANCEL : $.getLocalizedText(this._bundle, 'CANCEL_LABEL')
				},
				buttons: {
					OK: saveSelected,
					CANCEL: function(e) {
						var dialog = $.getWidget($(this), 'infaDialog');
						dialog.destroy();		
						$deferred.reject();
					}
				},
				width:400,
				closeOnEscape: false,
				canClose: false
			});
		var dialog = $.getWidget($dialog, 'infaDialog');
		
		dialog.open(true);
		
		var gridModel = new infaw.workspace.CloseAllGridModel(savableInstances, unsavableInstances);
		$savableInstances.appendTo($dialog).infaGrid({
			rowModel: gridModel.rowModel,
			columnModel: gridModel.columnModel,
			sortname: 'name',
			columnInfo: [
			    {
			    	name : 'name',
			    	label : 'Name',
			    	showIcon: true
			    }
			],
			autowidth: true,
			height: '200',
			checkboxes: true
		});
		var instanceGrid = $.getWidget($savableInstances, 'infaGrid');

		return $deferred.promise();		
	},
	
	/**
	 * Determines if the object is a temporary object
	 */
	isTempObject: function( instanceId ) {
		return instanceId.indexOf('newObject') !== -1;
	},
	
	onLogout: function(){
		if(this._portletContainer) {
			var $deferred = $.Deferred();
			this._portletContainer.saveAndCommit().done(function(){
				$deferred.resolve();
			});
			return $deferred.promise();
		}
	},
	
	onUnLoad: function(logout){
		//Delete all Query Result Sets to clear the DB Cache
		if(!logout){
			infa.model.ObjectUtil.instance().onUnLoad();
		}

		if(this._portletContainer){
			this._portletContainer.saveAndCommit();
		}
	}

});

/**
 * @author Olivier 
 * infa WSTabs 
 * 
 */

(function ($) {

var tabsIdx = 0;
	
$.widget('infa.infaWSBaseTabs', { 

	options: {
		useShortCut: true,
		trackPrevSelection: true,
		onLeave: undefined,
		onRemove: undefined,
		orientation: 'horizontal',
		iconize: false
	},
	
	_restoreFocus: false,
	_selectedTabs: null,

	_create: function() {
		this._tabCounter = 0;
		this._selectionIdx = -1;
		this._tabCount=0;
		this._prefix = 'tab' + tabsIdx++ + 't';
		var that=this;
	
		this.initTabHeaders();		
		this.initWSContainer();		
		this.registerEvents();
		
		this._initializeNavigationMenu();
	}, 
	
	initTabHeaders: function(){
		
	},
	
	_initializeNavigationMenu: function() {
		
	},
	
	_removeFromDropdown: function(tab) {
		
	},
	
	initWSContainer: function(){
		
		this._content=$('<div></div>').appendTo(this.element);
		if (this.options.trackPrevSelection) {
			this._selectedTabs = [];
		}
	},
	
	registerEvents: function() {
		
	},
	
	
	addTabHeader: function(options){
		
	},

	add: function(extension, removable, hidden){
		return this.addItem({
			id: extension.$workspaceId,
			label: extension.$label,
			icon: extension.$icon,
			color: extension.$color,
			removable: removable,
			hidden: hidden
		});
	},

	addGroupItem: function(options) {
		return this.addItem(options);
	},

	addItem: function(options) {
		var id = options.id, 
			label = options.label,
			icon = options.icon,
			color = options.color,
			removable = options.removable,
			hidden = options.hidden,
			container = options.container,
			that = this,
			url=this._prefix+this._tabCounter++,
			header = this.addTabHeader({
				id: id,
				label: label,
				icon: icon,
				color: color,
				removable: removable,
				url: url,
				hidden: hidden,
				container: container
			}),
			headerIndex = this.getHeaderIndex(header),
			h=['<div id="',url,'" style="display:none" class="infaWSContents"></div>'], //class="ui-tabs-panel ui-widget-content" 
			newTab = $(h.join(''));
		
		if(headerIndex > 0) {
			newTab.insertAfter(this._content.children().eq(headerIndex - 1));	
		} else {
			this._content.append(newTab);				
		}
					
		if (color && color !== '') {
			newTab.data('bgColor', color);
		}
		this._updateTabCount();
		return newTab[0];
	},

	remove: function( tabHeader ){
		var $onRemoveDef;
		
		var onRemoveCallback = this.options.onRemove;
		var self = this;
		if(onRemoveCallback && $.isFunction(onRemoveCallback )) {
			$onRemoveDef = $.Deferred()
			var tab = self.getTabByHeader(tabHeader);
			$.when(onRemoveCallback.call( this.element[0], {tab: tab} ) ).then(function(res) {
				if(res != undefined && res === false) {
					$onRemoveDef.reject();
				} else {
					// When we are leaving a tab we need to remove the headerColor
					$onRemoveDef.resolve();
				}
			}, function(){
				$onRemoveDef.reject();
			});
		}

		var self = this;
		var idx=this.getHeaderIndex(tabHeader); 
		if(idx !== -1) {
			$.when($onRemoveDef).then(function(){
				self.element.trigger('onRemove', {index: idx, tab: tabHeader});

				self._removeFromDropdown(tabHeader);
				
				self._onglet.find('li').eq(idx).remove();
				self._content.children().eq(idx).remove();
				self._updateTabCount();
				if (self.options.trackPrevSelection) {
					var href = $(tabHeader).children('a').attr('href');
					self._removeSelectedTab(href);
					var prevHref = self._selectedTabs.pop();
					if (prevHref) {
						var header = self._onglet.find('a[href="' + prevHref + '"]').parent().get(0);
						// Pass true for skipIdxCheck. Reason: suppose tab at index 2 (tab2) and tab 
						// at index 3 (tab3) are closeable. tab3 is first selected followed by tab2.
						// When tab2 is closed, we want to select tab3. The previous selected index 
						// will be the same as the new selection index. We don't want selection 
						// change to be skipped in such case.
						self._selectbyIndex(self.getHeaderIndex(header), undefined, undefined, true);
						return;
					}
				}
				if(self._selectionIdx === idx){
					var lastIdx = self.count() - 1;
					var newIdx=(idx == lastIdx + 1) ? lastIdx : idx;
					self._selectbyIndex(newIdx);
				} else {
					self._selectionIdx = idx;
				}
				self._selectbyIndex(newIdx);
				
			});	
		}
	},

	selectTab: function(tab, selectHome, modes){
		var idx = this.getTabIndex(tab);
		this._selectbyIndex(idx, selectHome, modes);
	},

	selectHeader: function(header){
		var idx = this.getHeaderIndex(header);
		this._selectbyIndex(idx);
	},
	
	_selectbyIndex: function(idx, selectHome, modes, skipIdxCheck){
		var es=this._content.children();
		if(es.length === 0) {
			this._selectionIdx=-1;
		} else {
			var ctab = this.getTabByIndex( idx );
			
			// Only need to select if it is a different tab
			if(skipIdxCheck || this._selectionIdx !== idx) {
				this.element.trigger( 'onSelect', { index: idx, tab: ctab } );
				var $onLeaveDef;
				
				if(this._selectionIdx !== -1) {
					var tabToLeave = this.getTabByIndex(this._selectionIdx);
					if(tabToLeave) {
						var onLeaveCallback = this.options.onLeave;
						var self = this;
						if(onLeaveCallback && $.isFunction(onLeaveCallback )) {
							$onLeaveDef = $.Deferred()
							$.when(onLeaveCallback.call( this.element[0], {tab: tabToLeave})).then(function(res){
								if(res !== false) {
									// When we are leaving a tab we need to remove the headerColor
									self._clearHeaderColor($(tabToLeave));
									$onLeaveDef.resolve();
								} else {
									$onLeaveDef.reject();
								}
							}, function(){
								$onLeaveDef.reject();
							});
						}
					}
				}
				
				var self = this;
				$.when($onLeaveDef).then(function() {
					var $ctab=$(ctab),
					alreadySeen=$ctab.data('seen')===true;
					es.hide();
					self._setCurrentColor($ctab);
					if(!alreadySeen){
						$ctab.data('seen',true);
					}
					$ctab.show();
					es=self._onglet.find('li');
					es.removeClass('selTab');
					
					var $tabHeader = es.eq(idx),
						$overlay = $tabHeader.find('.wsTabBgOverlay');
					
					// Set width so it cannot be overriden
					$overlay.width($overlay.width());
					
					$elem = $tabHeader.addClass('selTab').children('a');

					$overlay.animate({'width': '100%'}, {
						duration: 400, 
						always: function() {
							$overlay.css('width', '');
						}
					});
					
					self._selectionIdx=idx;
					if (self.options.trackPrevSelection) {
						var href = $elem.attr('href');
						self._removeSelectedTab(href);
						self._selectedTabs.push(href);
					}
					
					self.element.trigger('onSelected', {index: idx, tab: ctab, firstTime: !alreadySeen, selectHome: selectHome, modes: modes} );			
				});
			}
		}
	},

	getTabByIndex: function(index){
		return this._content.children().get(index);
	},
	getTabIndex: function(tab){
		var $this=$(tab);
		return $this.parent().children().index($this);
	},
	
	getHeaderByIndex: function(index) {
		return this._onglet.find('li').get(index);
	},
	
	getHeaderIndex: function(header){
		var $this=$(header);
		return this._onglet.find('li').index($this);
	},
	
	getTabHeader: function(tab) {
		var $header = this._getTabHeader($(tab));
		if ($header.length) {
			return $header.get(0);
		}
	},
	
	_getTabHeader: function($tab) {
		var id = $tab.attr('id');
		var $header = this._onglet.find('a[href="#' + id + '"]').parent();
		return $header;
	},
	
	getTabByHeader: function(header) {
		var $tab = this._getTabByHeader($(header));
		if ($tab.length) {
			return $tab.get(0);
		}
	},
	
	_getTabByHeader: function($header) {
		var href = $header.find('a').attr('href');
		if (href) {
			var id = href.substring(1);
			return $('#' + id);
		}
	},

	empty: function(){
		this._onglet.empty();
		this._content.empty();
		this._tabCounter = 0;
		this._selectionIdx = -1;
		this._tabCount=0;
		if (this.options.trackPrevSelection) {
			this._selectedTabs.splice(0);
		}
	},

//	enableTab: function(tab){
//		return this.tabsWidget.enable( this.getIndex(tab)); 
//	},
//	disableTab: function(tab){
//		return this.tabsWidget.disable( this.getIndex(tab)); 
//	},

	getSelected: function(){
		if(this._selectionIdx !== -1) {
			return this.getTabByIndex(this._selectionIdx);
		}
	},    

	count: function(){
		return this._tabCount;
	}, 
	_updateTabCount: function(){
		
	}, 

	getLabel: function(tab){
		return this._getLabelElem(this.getTabIndex(tab)).html(); 
	},
	setLabel: function(tab, value){
		this._getLabelElem(this.getTabIndex(tab)).html(value); 
	},
	hideLabel: function(tab){
	
	},
	clearFirstTimeEvent: function(tab){
		$(tab).data('seen', false); 
	},
	ongletHeight: function(){
		
	},	
	_getLabelElem: function(index){
		
	},	

	getContent: function(tab){
		return $(tab).html(); 
	},
	setContent: function(tab, value){
		$(tab).html(value); 
	},

	val: function(){
		return this.getSelected(); 
	},

	destroy: function(){
		this._onglet.off();
		this.element.empty().removeClass('infaWsTabs');
	},
	
	_closeTab: function($tabHeader) {
		// another tab is being closed. Re-set the color of the selected tab if it was out of
		// focus.
		var $selTab = $(this.getSelected());
		this._setCurrentColor($selTab);
		
		this.remove($tabHeader);
	},
	
	_closeTabs: function($tabHeaders) {
		for( var i = 0, len = $tabHeaders.length; i < len; i++ ) {
			var $tabHeader = $tabHeaders.eq(i);
			
			// Can only remove removable tabs
			if($tabHeader.children().hasClass('wsRemovable')) {
				this._closeTab( $tabHeader );
			}
		}
	},
	
	_restoreOrigFocus: function(restoreFocus) {
		this._restoreFocus = restoreFocus;
	},
	
	_removeSelectedTab: function(href) {
		for (var i = 0; i < this._selectedTabs.length; i++) {
			if (this._selectedTabs[i] === href) {
				this._selectedTabs.splice(i, 1);
				break;
			}
		}
	},	
	
	
	_setCurrentColor: function($tab) {

	},
	
	_clearHeaderColor: function($tab) {

	},
		
	addWSMenu: function(tab, extension){
		
	},
	
	addHoverMenu: function(tab, extension, isHomeMenu) {
		
	},
	
	_isRemovable: function($header) {
		return $header.children().hasClass('wsRemovable');
	},
	
	_isHidden: function($header) {
		return $header.hasClass('hiddenTab');
	}
});

}(jQuery));

/**
 * @author Fei Du 
 * infa WSUI 
 * It inherits from the infaWSBaseUI class
 * User in desktop browsers 
 */

(function ($) {

var tabsIdx = 0;
	
$.widget('infa.infaWSTabs', $.infa.infaWSBaseTabs,{
	
	currHoverWS: undefined,
	
	_hoverMenuCB: null,
	
	_groupTabs: {},
	
	_create: function() {
		this._super();
		
		this._createActionMenu();
	},
	
	_initializeNavigationMenu: function() {
		// create menu holder
		var dropdownMenuId = this.prefix + 'dropdownMenu',
			$menu = $('<div id="wsDropdownMenu" class="infaDropdown_menu"></div>').prependTo(this.element);
		//this._tabCounter++;
		
		$menu.infaMenu({
			contextMenu: true,
			numItemsToDisplay: 15,
			showMenuOnMouseOver: true
		});
		this._dropdownMenu = $.getWidget($menu, 'infaMenu');
		// Hide so that it doesn't take room
		$menu.parent().hide();

		// Dropdown not created so create now
		this._createNavigationTab();
		
		var self = this;
		$(window).on('resize', function(e) {
			self._refreshUI();
			e.stopPropagation();
		});
		
		this.element.on('onSelect', function(e, arg){
			if (self._dropdownMenu && arg && arg.tab) {
				self._dropdownMenu.setSelected($(self.getTabHeader(arg.tab)).data('infa-tabDropdownItem'));
			}
		});
		
		this._minimized = false;
	},
	
	_createNavigationTab: function() {
		var $dropdownTab = $('<li class="infa-tabDropdown ui-state-default ui-corner-top"><a tabindex="0" class="tabNoIco"></a></li>').appendTo(this._onglet);
		var $svgDropdown = $('<div class="iconSVG infa-tabIcoDropdown"></div>').appendTo($dropdownTab.children());
		$svgDropdown.svg({
			loadURL: $.url('/images/infaTabs/down_arrow.svg'),
			onLoad: function() {
				$svgDropdown.children().attr('focusable', 'false');
			}
		});

		var self = this;
		// Keyboard accessibility to open the navigationMenu
		$dropdownTab.children().on('keydown', function(e) {
			if(e.keyCode !== $.ui.keyCode.ENTER) {
				return;
			}
			self._showDropdownMenu(self._dropdownMenu, e, $dropdownTab);
			e.stopPropagation();
		});
		
		$dropdownTab.on('click', function(e) {
			self._showDropdownMenu(self._dropdownMenu, e, $dropdownTab);
			e.stopPropagation();
		}).on('mouseenter', function(e){
			$(this).addClass('hTab');
		}).on('mouseleave', function(e) {
			$(this).removeClass('hTab');
		});
		
		this._$dropdownTab = $dropdownTab.hide();
	},
	
	/**
	 * Helper method to display the dropdown menu on tab
	 */
	_showDropdownMenu: function( menu, event, $dropdownTab ) {
		var docBottom = $(document).height();
		menu.show($dropdownTab.get(0));
		var $dropdown = menu.getDropdown();
		var height = $dropdown.outerHeight();
		var bottom = $dropdownTab.offset().top + $dropdownTab.height();
		var my;
		var at;
		if (bottom + height <= docBottom) {
			my = 'right top';
			at = 'right bottom';
		} else {
			my = 'right bottom';
			at = 'right top';
		}
		$dropdown.position({
			of: $dropdownTab,
			my: my,
			at: at,
			collision: 'flip none'
		});
	},
	
	/**
	 * This method helps refresh the UI so that it adds a dropdown if there are too many tab's
	 * to fit into the DOM element only works when responsive is enabled
	 * 
	 * User should be firing resize event on the element
	 */
	_refreshUI: function() {
		var maxLength, totalLength, tabLength,
			$dropdownTab = this._$dropdownTab,
			totalLength = this._calculateTotalLength();
		if (this.options.orientation === 'horizontal') {
			maxLength = this.element.find('.infaWsTabs-nav').width() -1; //this.element.width() - 1,	// -1 to account for border
			tabLength = $dropdownTab.data('width');
		} else {
			maxLength = this.element.height();
			tabLength = $dropdownTab.data('height');
		}
		totalLength = totalLength - tabLength;
			
		if(totalLength > maxLength) {
			this._hideTabs(maxLength, totalLength + tabLength);
		} else {
			$dropdownTab.hide();
		}
	},
	
	/**
	 * Hide the tabs starting on the right of the selected tab
	 * If not enough tabs on right of selected then 
	 * start hiding the tabs at the beginning. If orientation is vertical, start hiding the tabs at
	 * the beginning of the Open Assets section.
	 */
	_hideTabs: function(maxLength, currentLength) {
		var selectedIndex = this._selectionIdx;
		if (!selectedIndex) {
			selectedIndex = 0;
		}
		var $tabHeaders = this._onglet.find('li:not(.infa-tabDropdown)'),
			$tabHeader;
		
		// Hide elements to right of selected
		for(var i = this.count() - 1; currentLength > maxLength && i > selectedIndex; i--) {
			$tabHeader = $tabHeaders.eq(i).hide();
			currentLength -= (this.options.orientation === 'horizontal' ? 
				$tabHeader.data('width') : this._$dropdownTab.data('height'));
		}
		
		// Hide elements at beginning of the list. If orientation is vertical, start hiding the tabs 
		// at the beginning of the Open Assets section.
		for(var i = 0; currentLength > maxLength && i < selectedIndex; i++) {
			$tabHeader = $tabHeaders.eq(i);
			if ($tabHeader.find('.wsRemovable').length > 0) { // start hiding only if the tab is removable
				$tabHeader.hide();
				currentLength -= (this.options.orientation === 'horizontal' ? 
					$tabHeader.data('width') : this._$dropdownTab.data('height'));
			}
		}
	},
	
	_calculateTotalLength: function() {
		var $tabHeaders = this._onglet.find('li:not(.hiddenTab)').show().trigger('show'),
			totalLength = 0;
		if (this.options.orientation === 'horizontal') {
			for( var i = 0; i < $tabHeaders.length; i++ ) {
				var	$tabHeader = $tabHeaders.eq(i),
					width = $tabHeader.data('width');
				if(!width) {
					// Calculate width if no width 
					width = $tabHeader.outerWidth(true) + 1; // Account for border
					$tabHeader.data('width', width);
				}
				totalLength += width;
			}
		} else {
			var height = this._$dropdownTab.data('height'),
				$groupTab = this._onglet.find('.openAssetCnt'),
				groupHeight = $groupTab.length * $groupTab.outerHeight();
			if (!height) {
				height = this._$dropdownTab.outerHeight(true);
				this._$dropdownTab.data('height', height);
			}
			totalLength = $tabHeaders.length * height + groupHeight;
		}
		return totalLength;
	},
	
	initTabHeaders: function(){
		this.element.addClass('infaWsTabs');
		var $parent = $('<div class="infaOnglet"><ul class="infaWsTabs-nav"></ul></div>').appendTo(this.element);
		this._onglet = $parent.children().eq(0);
		$parent.addClass(this.options.orientation);
		
		if(this.options.iconize){
			$parent.addClass('floating').addClass('iconize');
			
			$('<div class="infaOnglet vertical iconize widthControl" style="background-color: transparent;"></div>').appendTo(this.element);
			this._initExpandButton();
		}
	},
	
	_initExpandButton: function($parent) {
		var self = this;

		$("<div class='wsTabsExpandButton'><div class='assetsArrow arrow-left'></div></div>")
			.click(function(evt){
				var collapsed = 'collapsed',
				$ong = $('.infaOnglet.iconize'),
				$overlay = $('.infaOnglet.iconize.floating'),
				$widthControl = $('.infaOnglet.widthControl'),
				min = $ong.hasClass('collapsed'),
				$button = $('.wsTabsExpandButton'),
				$arrow = $button.find('.assetsArrow');
	
				if(min){
//					self._removeHoverEvents();
					//Only animate top div, not width control
					$widthControl.removeClass(collapsed);
					
					self._expandNavMenu($overlay, $button);
					$arrow.removeClass('arrow-right');
					$arrow.addClass('arrow-left');
				} else {
					self._closeNavMenu($overlay, $button)
					$ong.addClass(collapsed);
					
					$arrow.removeClass('arrow-left');
					$arrow.addClass('arrow-right');
//					self._addHoverEvents();
				}
				var activeWS = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
				if(activeWS) {
					activeWS.getEventManager().sendEvent('onWorkspaceResize');
				}
			}).prependTo(this.element);
	},
	
	registerEvents: function() {
		var that = this;

		this._onglet.on('click', 'li', function(e) {
			e.stopImmediatePropagation();
			e.preventDefault();

			that.selectHeader(this);
		}).on('mouseenter focusin', 'li', function(e){
			if (e.type !== 'focusin' || !that._restoreFocus) {
				var $this = $(e.target).closest('li'),
					idx = that._onglet.find('li').index($this),
					$tab = $(that.getTabByIndex(idx));
				
				if(e.type !== 'focusin') {
					$(this).addClass('hTab');
					that._setCurrentColor($tab);
				} else {
					$(this).addClass('fTab');
				}
			}
		}).on('mouseleave', 'li:not(.infaWsHover)', function(e) {
			var	$this=$(e.target).closest('li'),
				idx = that._onglet.find('li').index($this),
				tab = that.getTabByIndex(idx);
			
			that._unhover(tab);
		}).on('focusout', 'li', function(e) {
			$(this).removeClass('fTab');
		}).on('click keydown', '.wsIconClose', function(e){
			if (e.type === 'keydown' && e.which !== 13 /* enter*/) {
				return;
			}
			e.stopPropagation();
			e.preventDefault();
			that._closeTab($(this).closest('li'));
		});

		if(this.options.useShortCut){
			$(document).on('hotkey.workspace', function(evt, keycode){
				var numKey=keycode-48;
				if(numKey>-1 && numKey<that._tabCount){
					that._selectbyIndex(numKey);
				}
			});
			$(document).on('hotkey.workspaceClose', function(evt, keycode){
				var selTab = that.getSelected();
				var $tabHeader = that._getTabHeader($(selTab))
				if ( $tabHeader.find('.wsRemovable').length > 0 ) {
					that._closeTab($tabHeader);
				}
			});
		}
	},
	
	_addHoverEvents: function(){
		var self = this,
			$button = $('.wsTabsExpandButton'),
			$onglet = $('.infaOnglet.floating');
		$onglet.on('mouseenter.iconize', function(e){
			self._expandNavMenu($onglet, $button);
		}).on('mouseleave.iconize', function(e) {
			// We only want to close menu if we are hovering out but don't close if we hover to button
			if(!$(e.toElement).hasClass('wsTabsExpandButton')) {
				self._closeNavMenu($(this), $button);
			} else {
				$(e.toElement).one('mouseleave.iconize', function(e) {
					if(!$(e.toElement).is('.infaOnglet.floating')) {
						self._closeNavMenu($onglet, $button);
					}
				})
			}
		});
	},
	
	_expandNavMenu: function($onglet, $button) {
		var collapsed = 'collapsed',
			expWidth = "195px", 
			anim = 300,
			self = this;
		
		$onglet.find('.wsTabBgOverlay').stop();
		if($onglet.hasClass(collapsed)) {
			if(!$.infa.Validate.isIE()){
				$button.animate({left: expWidth}, anim);
				$onglet.animate({width: expWidth}, anim, function(){
					$onglet.removeClass(collapsed);
					self._setButtonExpanded();
				});
			} else {
				$onglet.removeClass(collapsed);
				self._setButtonExpanded();
			}
			
		}
	},
	
	_closeNavMenu: function($onglet, $button) {
		var collapsed = 'collapsed',
			col = "60px", 
			anim = 300;

		$onglet.find('.wsTabBgOverlay').stop();

		if(!$onglet.hasClass(collapsed)) {
			if(!$.infa.Validate.isIE()){
				$button.animate({left: col}, anim)
				$onglet.animate({width: col}, anim);
			}
			$onglet.addClass(collapsed);
			this._setButtonCollapsed();
		}
	},
	
	_setButtonCollapsed: function($t){
		$('.wsTabsExpandButton').addClass('collapsed');
	},
	
	_setButtonExpanded: function($t){
		$('.wsTabsExpandButton').removeClass('collapsed');
	},
	
	_removeHoverEvents: function(){
		$('.infaOnglet.floating').off('mouseenter.iconize').off('mouseleave.iconize');
		$('.wsTabsExpandButton').off('mouseleave.iconize');
	},
	
	addTabHeader: function(options) {
		var id = options.id,
			label = options.label,
			icon = options.icon,
			color = options.color,
			removable = options.removable,
			url = options.url,
			hidden = options.hidden,
			container = options.container,
			that = this,
			h=['<li id="', id, '"', (hidden ? 'class="hiddenTab"' : ''), '><a href="#', url, '"'];

		if(icon && icon!==''){
			h.push('><img src="', $.url(icon),'"/>');
		}else{
			h.push(' class="tabNoIco">');
		}
		h.push('<span class="wsLabel" title="' + label + '">', label,'</span></a>');
		h.push('</li>');
		var $header = $(h.join('')).appendTo(container ? container : this._onglet);
		
		if (removable) {
			var $svgIcon = $('<div tabindex="0" class="wsIconClose"/>').appendTo($header.children().addClass('wsRemovable'));
			$svgIcon.svg({
				loadURL: $.url('/images/common/close_small.svg'),
				onLoad: function() {
					$svgIcon.find('svg').attr('focusable', false);
				}
			});
		}
		
		$header.prepend('<div class="wsTabBgOverlay"></div>');
		
		// add item to dropdown menu and refresh
		if(that._dropdownMenu) {
    		var menuItem = that._dropdownMenu.add(-1, 'last', 'push', label);
    		if(icon) {
    			that._dropdownMenu.setIcon(menuItem, $.url(icon));
    		}
    		$header.data('infa-tabDropdownItem', menuItem);
    		$(menuItem).on('onSelect', function(e) {
    			that.selectHeader($header);
    			e.stopPropagation();
    			// show selected tab header
    			that._refreshUI();
    		});
    			
    		// Move dropdown to end
    		that._$dropdownTab.appendTo(this._onglet);
    		that._refreshUI();
    	}
		
		return $header;
	},
	
	_removeFromDropdown : function(tab) {
		if(this._dropdownMenu) {
			var menuItem = $(tab).data('infa-tabDropdownItem');
    		this._dropdownMenu.remove(menuItem);
    		this._refreshUI();
		}
	},	

	ongletHeight: function(){
		if (this.options.orientation === 'horizontal') {
			return Math.ceil(this._onglet.outerHeight());
		}
		return 0;
	},	
	
	hideLabel: function(tab){
		this._onglet.find('li').eq(this.getTabIndex(tab)).hide(); 
	},
	
	show: function() {
		this._onglet.show();
		this.element.find('.infaOnglet').show();
		if(this.options.iconize) {
			this.element.find('.wsTabsExpandButton').show();
		}

		var activeWs = infaw.workspace.WorkspaceManager.instance().getActiveWorkspace();
		if(activeWs) {
			activeWs.getEventManager().sendEvent('onWorkspaceResize');
		}
	},

	addGroupItem: function(options) {
		var id = options.id,
			label = options.label,
			icon = options.icon,
			color = options.color,
			removable = options.removable,
			hidden = options.hidden,
			groupId = options.groupId,
			groupLabel = options.groupLabel;

				if(!this._groupTabs[groupId]) {
			var $groupTab = $('<ul class="wsGrpTabs"></ul>').appendTo(this._onglet);
			$('<div class="openAssetCnt"></div>').appendTo($groupTab).data('label', groupLabel);

			var startIndex = 0,
				that = this,
				sortableOptions = {
				tolerance: "pointer",
				axis: "y",
				containment: "parent",
				items: "li",
				cursor: "move",
				delay: 150,
				placeholder: "ui-sortable-placeholder",
				forcePlaceholderSize: "true",
				start: function(evt, ui) {
					startIndex = that.getHeaderIndex(ui.item);
					that.selectHeader(ui.item);
				},
				update: function(evt, ui) {
					var endIndex = that._selectionIdx = that.getHeaderIndex(ui.item),
						tab = that.getTabByIndex( startIndex );

					if( startIndex < endIndex ) {
						 $( that.getTabByIndex( endIndex ) ).after( $( tab ) );
					} else {
						$( that.getTabByIndex( endIndex ) ).before( $( tab ) );
					}

					if(that._dropdownMenu) {
						var dropdownMenu = that._dropdownMenu,
							label = that._dropdownMenu.getLabel(ui.item.data('infa-tabDropdownItem')),
							icon = $(that.getTabHeader(tab)).find('img').attr('src');
		        		dropdownMenu.remove(ui.item.data('infa-tabDropdownItem'));

						var menuItem = dropdownMenu.add(-1, endIndex, 'push', label);
		        		if(icon) {
		        			dropdownMenu.setIcon(menuItem, icon);
		        		}
		        		dropdownMenu.setSelected(menuItem);

		        		$( ui.item ).data('infa-tabDropdownItem', menuItem);
		        		$(menuItem).on('onSelect', function(e) {
		        			that._selectbyIndex($(this).data('idx'));
		        			e.stopPropagation();
		        			that._refreshUI();
		        		}).data('idx', endIndex);
					}

		    		that._refreshUI();
				}
			}
			$groupTab.sortable(sortableOptions);

			this._groupTabs[groupId] = $groupTab;
		} else {
			var $groupTab = this._groupTabs[groupId].show();
		}
		return this.addItem({
            id: id,
            label: label,
            icon: icon,
            color: color,
            removable: removable,
            hidden: hidden,
            container: $groupTab
        });
	},

	remove: function( tabHeader ){
		var $groupTab = $(tabHeader).parent('.wsGrpTabs');

		this._super(tabHeader);

		// Check if this is a groupTab if so then we want to see if there are any tabs in this group if none then we should hide
		if($groupTab.children('li').length === 0) {
			$groupTab.hide();
		}
	},

	addItem: function(options) {
		// If there is only one tab then we can keep the tabs hidden
		// We start showing if there are more than one tab
		if(this.count() > 0 || this.options.alwaysShowTabs) {
			this.show();
		}
		return this._super(options);
	},

	_updateTabCount: function(){
		this._tabCount=this._onglet.find('li').length - 1; // last li is the dropdown

		if (this.options.orientation === 'vertical') {
			var $groupTabs = this._onglet.find('ul');
			for(var i = 0; i < $groupTabs.length; i++) {
				var $groupTab = $groupTabs.eq(i),
					$container = $groupTab.find('.openAssetCnt');
				$container.html('<b>' + $container.data('label') + '</b><div>&nbsp;(' + $groupTab.children('li').length + ')</div>');
			}
		}
	},

	/**
     * Creates an actionMenu
     *
     * @param {string} selector - elements based on selector to have actionMenu (i.e li:not(:first-child) or .class)
     */
    _createActionMenu: function() {
    	var that = this;

		// create menu holder
		var $menu = $('<div id="objCtxMenu" class="infaDropdown_menu"></div>').prependTo(this.element);
		this._IdxComp++;
		$menu.infaMenu({
			contextMenu: true,
		});
		// Hide so that it doesn't take room
		$menu.parent().hide();

		var actionMenu = this._actionMenu = $.getWidget($menu, 'infaMenu'),
			close = actionMenu.add( -1, 'last', 'push', 'Close' ),
			closeOther = actionMenu.add( -1, 'last', 'push', 'Close Others' ),
			closeAll = actionMenu.add( -1, 'last', 'push', 'Close All' );

		$( closeAll ).on( 'onSelect', function( evt ) {
			var $tabHeader = actionMenu.getContextObject();
			that._closeTabs( $tabHeader.siblings('li').addBack() );
		});

		$( closeOther ).on( 'onSelect', function( evt ) {
			var $tabHeader = actionMenu.getContextObject();
			that._closeTabs( $tabHeader.siblings('li') );
		});

		$( close ).on( 'onSelect', function( evt ) {
			var $tabHeader = actionMenu.getContextObject();
			that._closeTab( $tabHeader );
		});

		// prevent default browser right-click menu
		this._onglet.on("contextmenu", '.wsRemovable', function(e) {
			that._actionMenu.setContextObject($(e.currentTarget).closest('li'));
			that._showActionMenu(that._actionMenu, e);
			return false;
		});
    },

    /**
	 * Helper method to display the action menu on tab
	 */
	_showActionMenu: function( menu, event ) {
		var docBottom = $(document).height();
		menu.show();
		var $dropdown = menu.getDropdown();
		var height = $dropdown.outerHeight();
		var mousePosition = event.clientY;
		var my;
		var at;
		if (mousePosition + height <= docBottom) {
			my = 'left top';
			at = 'left bottom';
		} else {
			my = 'left bottom';
			at = 'left top';
		}
		$dropdown.position({
			of: event,
			my: my,
			at: at,
			collision: 'flip none'
		});
	},
	
	_getLabelElem: function(index){
		return this._onglet.find('li').eq(index).find('a span'); 
	},	
	

	addWSMenu: function(tab,  extension){		
//		var self = this;
//		var header = this.getTabHeader(tab),
//		$header = $(header);	
//		
//		var $dropdownIcon = $("<span><img class=\"dropdownIcon\" src=\"/web.workspace/images/dropdown.png\"></span>");
//		
//		$dropdownIcon.appendTo($header.find("a"));
//		
//		var $wsMenu = $('<div></div>').appendTo($header).infaMenu({contextMenu: true});
//		var wsMenu = $.getWidget($wsMenu, 'infaMenu');
//		
//		
//		
//		infaw.workspace.NewActionManager.instance().getAllowedContributions(extension.$workspaceId).done(function(contributions) {
//					    
//    		var cmdMgr = infa.common.CommandManager.instance();   	
//    		
//    		for (var i = 0; i < contributions.length; i++) {  	  			
//    		
//    			var contribution = contributions[i];  			
//    			var item = wsMenu.add(-1, 'last', 'push', contributions[i].name);    		
//    			wsMenu.setIcon(item, $.url(contribution.icon));   
//    			var $item = $(item);
//    			
//    			$.data(item, "commandId", contribution.id);
//    			    		
//    			$item.on('click', function(event) {
//    				wsMenu.hide();
//    				var commandId = $.data(this, "commandId");
//    				cmdMgr.executeCommand(commandId);
//
//    			});	      			
//    		}
//
//    		
//    	});
//		
//
//		$dropdownIcon.on('click', function(event) {
//			event.stopPropagation();
//			self._showMenu(event, $header, wsMenu);
//		});
//		
//		
//		
//		var keyboard = false;
//		$header.on('keydown focusout', function(event) {
//			switch (event.type) {
//			
//			case 'keydown':
//				if (event.which == 40) { // arrow down
//					// set the flag so that the focusout event handling code below will
//					// not make the tab header look "out of focus" when the hover menu is 
//					// open using keyboard
//					keyboard = true; 
//					self._showWSMenu(event, $header, wsMenu);
//					keyboard = false;
//				}
//				break;
//			case 'focusout':
//				if (!keyboard) {
//					// the focus is now somewhere outside this tab and its hover menu
////					self._unhover(tab);
//				}
//				break;
//			}
//		});
	},
	
	_showMenu: function(event, $header, wsMenu) {
        wsMenu.show();
        var $dropdown = wsMenu.getDropdown();
        $dropdown.position({
            of: $header,
            my: 'left top',
            at: 'left bottom',
            collision: 'flip none'
        });
    },
    
	_contains: function($elem, event) {
		var offset = $elem.offset();
		if (offset.left > event.clientX) {
			return false;
		}
		if (offset.top > event.clientY) {
			return false;
		}
		var width = $elem.outerWidth();
		if (offset.left + width < event.clientX) {
			return false;
		}
		var height = $elem.outerHeight();
		if (offset.top + height < event.clientY) {
			return false;
		}
		return true;
	},
    
	_checkHoverMenuClose: function(tab, $header, hoverMenu) {
		var self = this;
		$(document).on('mousemove.extensibleWSHoverMenu', function(event) {
			// the event handler is removed when the hover menu is closed (menuClosed callback
			// is invoked)
			var $dropdown = hoverMenu.getDropdown();
			if( !$header.is(':hover') && 
					!self._contains($header, event) && (!$dropdown.length || !self._contains($dropdown, event))) {
				hoverMenu.hide();
				self.currHoverWS = undefined;
			}
		});
	},
	
    _openSelected: function(workspaceId, tab) {
		this._unhover(tab);
		var commandMgr = infa.common.CommandManager.instance();	
		commandMgr.executeCommand('infaw.openAssetsDialogCommandID');						
	},
	
	_getHoverMenuCB: function() {
		var self = this;
		if (!self._hoverMenuCB) {
			self._hoverMenuCB = {
				menuClosed: function() {
					if(self.currHoverWS) {
						self._unhover(self.currHoverWS.tab);
					}
					$(document).off('mousemove.extensibleWSHoverMenu');
				},
				preFocusOnClose: function() {
					self._restoreOrigFocus(true);
				},
				postFocusOnClose: function() {
					self._restoreOrigFocus(false);
				}
			};
		}
		return self._hoverMenuCB;
	},

	addHoverMenu: function(tab, extension, isHomeMenu) {
		var self = this;
		var $tab = $(tab),
			$header = $(this.getTabHeader(tab)),
			wsManager = infaw.workspace.WorkspaceManager.instance();

		$header.addClass('infaWsHover');
		var isWSConfigurable = (extension.$isConfigurable === 'true');
		var hideFirstColumn = (extension.$permanent === 'false'),
			homeLabel = '';
		if (!hideFirstColumn) {
			homeLabel = extension.$homeLabel;
		}
		var $hoverMenu = $('<div tabindex=-1></div>').appendTo($header)
			.extensibleWSHoverMenu({
				workspaceId: extension.$workspaceId, 
				hideFirstColumn: hideFirstColumn,
				isHomeMenu: isHomeMenu,
				isWSConfigurable: isWSConfigurable,
				homeLabel: homeLabel,
				homeIcon: $.url('/web.workspace/images/home.svg'),
				homeHandler: function() {
					wsManager.selectHome(this.workspaceId);								
				},
				openHandler: function() {
					var wsId = this.workspaceId;
					self._openSelected(wsId, tab);
				},
				addPanelHandler: function() {
					wsManager.addPanelSelected(this.workspaceId);
				}
			});

		var hoverMenu = $.getWidget($hoverMenu, 'extensibleWSHoverMenu'),
			workspace = wsManager.getWorkspaceMap()[extension.$workspaceId];
		hoverMenu._setCB(self._getHoverMenuCB());

		this._initializeHoverMenuEventHandlers(workspace, $header, $hoverMenu, wsManager);
		return hoverMenu;
	},

	_initializeHoverMenuEventHandlers: function(workspace, $header, $hoverMenu, wsManager) {
		var self = this, 
			keyboard = false, 
			workspaceId = workspace.extension.$workspaceId,
			hoverMenu = workspace.hoverMenu,
			tab = workspace.tab;

		var keyboard = false;
		$header.on('mouseenter mousedown keydown focusout', function(event) {
			switch (event.type) {
			case 'mouseenter':
				if (self.currHoverWS && self.currHoverWS.hoverMenu != hoverMenu) {
					self.currHoverWS.hoverMenu.hide();
					self._unhover(self.currHoverWS.tab);
				} 
				self._showMenu(event, $header, hoverMenu);
				self._checkHoverMenuClose(tab, $header, hoverMenu);
				self.currHoverWS = workspace;
				break;
			case 'keydown':
				if (event.which == 40) { // arrow down
					// set the flag so that the focusout event handling code below will
					// not make the tab header look "out of focus" when the hover menu is 
					// open using keyboard
					keyboard = true; 
					// wsTabsFocus helps display a border around the workspace 
					// where menu was opened by the keyboard
					$header.addClass('wsTabsFocus');
					self._showMenu(event, $header, hoverMenu);
					keyboard = false;
				}
				break;
			case 'focusout':
				if (!keyboard) {
					// the focus is now somewhere outside this tab and its hover menu
					// self._infaTabs._unhover(tab);
					self._unhover(tab);
					$header.removeClass('wsTabsFocus');
				}
				break;
			}
		});

		$hoverMenu.on('onSelect', function(e) {
			var $menu = $(e.target),
				lwObject = $menu.data('lwObject');		
			if(!lwObject) {
				return;
			}
			
			var workspaceInst = wsManager.getWorkspace(workspaceId);
			if(workspaceInst) {
				if(workspaceInst.isInstanceExists(lwObject.$$IID)) {
					wsManager.selectInstance(workspaceId, lwObject.$$IID);	
				} else {
					wsManager.openObject(lwObject);	
				}
			}
		});
	},
	
	_unhover: function(tab) {
		var $tab = $(tab),
			$header = this._getTabHeader($tab);
		$header.removeClass('hTab');
		var selTab = this.getSelected();
		if (this._selectionIdx >= 0 && selTab !== tab) {
			this._clearHeaderColor($tab);
			var $selTab = $(selTab);
			this._setCurrentColor($selTab);
		}
	},
	
	_setCurrentColor: function($tab) {
		var bg = $tab.data('bgColor');
		var $ong = this.element.find('.' + 'infaWSTabs');
		if (bg) {
			this._getTabHeader($tab).css('background-color', bg);
		} else {
			this._getTabHeader($tab).css('background-color', '');
		}
	},
	
	_clearHeaderColor: function($tab) {
		var bg = $tab.data('bgColor');
		if (bg) {
			this._getTabHeader($tab).css('background-color', '');
		}
	},
	
	_setMinimized: function(minimized) {
		if (this._minimized !== minimized) {
			var $labels = this._onglet.find('li > a > span');
			if (minimized) {
				$labels.hide();
			} else {
				$labels.show();
			}
			this._minimized = minimized;
		}
	}
});

}(jQuery));

/**
 * @author ktruong 
 * infa workspace object tabs 
 * This helps keep track of the objects that are being edited
 * 
 * This class wraps around infaTabs and adds its own css styles
 * to make it look the way we want it to
 */

(function ($) {

var tabsIdx = 0;
	
$.widget( 'infa.infaWSObjTabs', {

	options: {
		wsColor: '#333',
		homeLabel: 'Home',
		maxHeaderWidth: '125'
	},

	_create: function() {
		this._tabCounter = 0;
		this._prefix = 'wobjtab' + tabsIdx++ + 't';
		
		this.element.addClass( 'infaWsObjTabs' );
		var self = this;
		this.element = this.element.infaTabs({
			padding: false,
			disableDefaultEvents: true,
			iconColor: {
				active: this.options.wsColor,
				inactive: '#CCC'
			},
			alwaysShowClose: false,
			showNavigationMenu: true,
			reorderable: true, 
			reorderableOptions: {
				items: '.infa-tabRemovable',
				start: function(evt, ui) {
					$(ui.item).height('35px')
						.children('.objTabSeparator').hide();
					$(ui.placeholder).append('<div class="objTabSeparator"></div>');
				},
				stop: function(evt, ui) {
					$(ui.item).children('.objTabSeparator').show();
				}
			},
			beforeRemove: function( tab ) {
				self.select( tab );
				return self.options.beforeRemove( tab );
			},
			actionMenu: {
				useMenu: true,
				selector: ".infa-tabRemovable",
			}
		});
		this._infaTabs = $.getWidget( this.element, 'infaTabs' );

		this._tabInstanceMap = {};
		this._instanceIdTabMap = {};
		
		this._nav = this.element.children('ul').addClass('infaWsObjTabsNav');
		// Add a separator when it adds a dropdown
		var $dropdown = this._nav.children('.infa-tabDropdown');
		$dropdown.append('<div class="objTabSeparator"></div>');
		 
		this._createActionMenu();
		this._initializeEventHandlers();
	}, 
	
	/**
	 * Add tab. If instance is undefined this means that we are adding the home tab
	 * 
	 * @param {Object} instance - the object instance this tab represents
	 */
	add: function( instance ) {
		if( instance ) {
			return this._addObjInstanceTab( instance );
		} else {
			return this._addHomeTab();
		}
	},
	
	_addHomeTab: function() {
		this._hasHomeTab = true;
		var tab = this._infaTabs.add( '', $.url('/images/workspace/home.svg') );

		// Home instance was added so we want to remove the tabindex added from jquery.ui.tab
		// Currently jquery.ui.tab adds a tabindex on the list element 
		// We don't want this because infaTabs already has its own focus element
		var $homeHeader = this._nav.children()
			.eq(0).addClass('infaWsHomeTab')
			.append( '<div class="objTabSeparator"></div>' ).attr( 'tabindex', '-1' );
		
		// Currently the navigationMenu does not have a label for home so we add it now
		var dropdownMenu = this._infaTabs.getNavigationMenu();
		var menuItem = dropdownMenu.getChildren( -1,  0 )[ 0 ]; 
		dropdownMenu.setLabel( menuItem, this.options.homeLabel );

		return tab;
	},
	
	_addObjInstanceTab: function( instance ) {
		var options = instance.options; 
		
		
		var label = $.infa.Formats.escapeComprehensive(options.instanceName),
			version = options.version;
		
		if( version ) {
			label = '<span class="versionIdentifier">V' + version + '</span>' + label;
		}
		
		var tab = this._infaTabs.add( label, options.icon, true );
		
		// Link tab and instance to each other
		this._tabInstanceMap[ tab.id ] = instance;
		this._instanceIdTabMap[ instance.id ] = tab;

		// Add a divider at end of each the added tab
		var $tabHeader = this._infaTabs.getTabHeader(tab);
		$tabHeader.append( '<div class="objTabSeparator"></div>' );
		
		this._setWidth( tab );
		return tab;
	},
	
	select: function( tab ) {
		return this._infaTabs.select( tab );
	},
	
	getSelected: function() {
		return this._infaTabs.getSelected();
	},
	
	getActive: function() {
		return this._infaTabs.getActive();
	},
	
	getHomeTab: function() {
		if(this._hasHomeTab) {
			return this._infaTabs.getTabByIndex( 0 );
		}
	},

	getTabByInstanceId: function( instanceId ) {
		return this._instanceIdTabMap[ instanceId ];
	},
	
	getInstanceByTab: function( tab ) {
		if(tab) {
			return this._tabInstanceMap[ tab.id ];	
		}
	},
	
	remove: function( tab ) {
		if(tab) {
			this._tabInstanceMap[ tab.id ] = null;
			return this._infaTabs.remove( tab );
		}
	},
		
	setLabel: function( tab, label ) {
		if(tab) {
			label = $.infa.Formats.escapeComprehensive(label);
			var instance = this.getInstanceByTab(tab),
				version = instance.options.version;
			if(version) {
				label = '<span class="versionIdentifier">V' + version + '</span>' + label;
			}
			
			var temp = this._infaTabs.setLabel( tab, label);
			this._setWidth( tab );
			return temp;
		}
	},
	
	count: function() {
		return this._infaTabs.count();
	},
	
	/**
	 * To prevent tabs from jumping when it gets bolded 
	 * we want to set the width of the tabLabel to its bolded state even when it 
	 * isn't bolded
	 */
	_setWidth: function( tab ) {
		var $tabHeader = this._infaTabs.getTabHeader(tab);
		var $label = this._infaTabs.getLabelHolder(tab);
		$label.attr( 'title', $label.text());
		
		if( !$tabHeader.is(':visible') ) {
			var self = this;
			$tabHeader.one('show', function() {
				self._setLabelWidth( $tabHeader, $label );
			});
		} else {
			this._setLabelWidth( $tabHeader, $label );	
		}
	},
	
	_setLabelWidth: function( $tabHeader, $label ) {
		$label.css( 'width', '' ).css( 'font-weight', 'bold' );
		
		var width = $label.width() + 5;	// +5 to account for dirty mark
		if(width > this.options.maxHeaderWidth) {
			width = this.options.maxHeaderWidth;
		}
		$label.css('width', width).css('font-weight', '');
		
		// Reset the width for navigation menu
		width = $tabHeader.outerWidth(true);
		$tabHeader.data('width', width);
	},
	
	_initializeEventHandlers: function() {
		var self = this;
		// We want to clean up the instance/tab maps when tabs are removed
		this.element.on( 'onRemove', function( e, ui ) {
			if( e.target === e.currentTarget ) {
				var instanceId = self._tabInstanceMap[ ui.tab.id ];
				self._instanceIdTabMap[ instanceId ] = null;
				self._tabInstanceMap[ ui.tab.id ] = null;
			}
		})
		// Do not want events to propagate to parent 
		.on('onLeave onRemove onSelect', function( e ){
			if( e.target === e.currentTarget ) {
				e.stopPropagation();
			}
		});
	},
	
	/**
	 * Create an action menu to close the tabs
	 */
	_createActionMenu: function() {
		var actionMenu = this._infaTabs.getActionMenu();

		this._initializeCloseActionEventHandler(actionMenu);
		this._initializeCloseOthersActionEventHandler(actionMenu);
		this._initializeCloseAllActionEventHandler(actionMenu);
	},
	
	_initializeCloseActionEventHandler: function(actionMenu) {
		var self = this;
		var close = actionMenu.add( -1, 'last', 'push', 'Close' );
		
		$( close ).on( 'onSelect', function( evt ) {
			var tabHeader = actionMenu.getContextObject();
			var tabToRemove = self._infaTabs.getTabByHeader( tabHeader );
			
			self.select( tabToRemove );
			self.element.trigger('onInstanceRemove', tabToRemove);
		});
	},
	
	_initializeCloseOthersActionEventHandler: function(actionMenu) {
		var self = this;
		var closeOther = actionMenu.add( -1, 'last', 'push', 'Close Others' );
		
		$( closeOther ).on( 'onSelect', function( evt ) {
			var tabHeader = actionMenu.getContextObject();
			var $tabHeaders = $( tabHeader ).siblings( '.infa-tabRemovable' );
			self._closeTabs( $tabHeaders );
		});
	},
	
	_initializeCloseAllActionEventHandler: function(actionMenu) {
		var self = this;
		var closeAll = actionMenu.add( -1, 'last', 'push', 'Close All' );

		$( closeAll ).on( 'onSelect', function( evt ) {
			var $tabHeaders = self._nav.children('.infa-tabRemovable');
			self._closeTabs( $tabHeaders );
		});
	},

	/**
	 * Closes the tabs specified in $tabHeaders
	 * 
	 * @param {Object} $tabHeaders - the tabs to close
	 */
	_closeTabs: function( $tabHeaders ) {
		var tabsToRemove = [];
		
		for( var i = 0, len = $tabHeaders.length; i < len; i++ ) {
			var tabToRemove = this._infaTabs.getTabByHeader( $tabHeaders.get(i) );
			tabsToRemove.push( tabToRemove );
		}

		this.element.trigger('onInstanceRemove', [ tabsToRemove ] );
	},
	
	setHomeLabel: function( homeLabel ) {
		this.options.homeLabel = homeLabel;
	},
	
	setInstanceDirty: function( instanceId, isDirty ) {
		var tab = this.getTabByInstanceId( instanceId );
		if( tab ) {
			var label = this._infaTabs.getLabel( tab );
			var dirtyLabel = '*';
			if( isDirty ) {
				label = dirtyLabel + label;
			} else if( label.indexOf(dirtyLabel) === 0 ) {
				label = label.substring(dirtyLabel.length);
			}
			this._infaTabs.setLabel(tab, label);
		}
	},
	
	destroy: function(){
		this.element.empty().removeClass('infaWsObjTabs');
	},
});

}(jQuery));

$.Class("infaw.workspace.CloseAllGridModel", {
	init: function( savableInstances, unsavableInstances ) {
		this.rowModel._savableInstances = savableInstances;	// Contains the instances that is not saved
		this.columnModel._savableInstances = savableInstances;	// Contains the instances that is not saved
		this.rowModel._unsavableInstances = unsavableInstances;	// Contains the instances that is not saved
	},
	
	rowModel: {
		getRowCount: function(options) {
			return this._savableInstances.length + this._unsavableInstances.length;
		},
		
		getRootObjects : function(options) {
			return this._savableInstances.concat(this._unsavableInstances);
		},
		
		isRowChecked: function(rowObj) {
            if( this._savableInstances.indexOf(rowObj) === -1 ) { 
                return false; 
            } 
            return true; 
		},

        getEnabled: function(rowObj) { 
            if( this._savableInstances.indexOf(rowObj) === -1 ) { 
                return false; 
            } 
            return true; 
        } 
	},
	
	columnModel: {
		_imgManager: infaw.shell.common.ImageManager.instance(),
		
		getData : function(rowObj, columnName) {
			var currentObject = rowObj.options.instanceView.currentObject;
			return currentObject.name;
		},
		
		getIcon: function(rowObj, columnName) {
			var currentObject = rowObj.options.instanceView.currentObject;
			return this._imgManager.getObjectImage(currentObject.$$class, currentObject.$mixins, true);
		},
		
		getIconColor: function(rowObj, columnName) {
			var currentObject = rowObj.options.instanceView.currentObject;
			return this._imgManager.getObjectImageColor(currentObject.$$class, currentObject.$mixins, 'activeOOFColor', true);
		},
		
		getStyle: function(rowObj, columnName) {
            if( this._savableInstances.indexOf(rowObj) === -1 ) {
				return 'style = "color: #CCC;"';
            }
		},
	}
});
/**
 * @author Madhu
 * CacheManager provides a basic caching mechanism for storing key/value pairs in local JavaScript memory.
 * 
 * 
 * Cache Structure
 * _objectCache = {
 *	"storage1" : {
 *			id1: {
 *				lwObject : {},
 *				object	: {},
 *				idForm	: 1/2/3
 *				mode	: read/edit
 *			},
 *			id2: {
 *
 * 
 *			}
 *			.....
 * 
 *		}
 *		"storage2" : {
 *			id1: {
 * 
 * 
 *			},
 *			id2: {
 * 
 * 
 *			}
 * 
 *		}
 *		......
 *		
 * }
 * 
 * Test Cached object in browser console 
 *	> infaw.workspace.WorkspaceManager.instance().getActiveWorkspace()._objectCacheMgr._objectCache
 * 
 *  > $.map(infaw.workspace.WorkspaceManager.instance().getActiveWorkspace()._objectCacheMgr._objectCache['tasks'], function (value, key) { return value.lwObject; });
 */

$.Class("infaw.workspace.ObjectCacheManager", {	
	init: function(editSet) {
		this.editSet = editSet;
		this._objectCache = {};
	},	

	getStorageCache: function(storage) {
		if(this._objectCache[storage] === undefined) {			
			this._objectCache[storage] = {}; 
		}		
		return this._objectCache[storage];		
	},

	/**
	 * Returns cached object for the given storage and key
	 * If key is undefined, it returns array of all cached objects for the given storage.
	 */
	retrieve: function(storage, key) {
		var storageCache = this.getStorageCache(storage);
		if(!key) {
			return $.map(storageCache, 
					function (value, key) { 
				return value.lwObject; 
			}
			);
		}				
		return storageCache[key] || undefined;
	},

	cacheObject : function(object, options) {
		var idType = '',			
		cacheKey = object.$$ID,
		storage = options.storage, 
		idForm = options.idForm,
		mode = options.mode,
		storageCache = this.getStorageCache(storage);

		if ('$$IID' in object) {
			cacheKey = object.$$IID;
			idType = '$$IID';
		} else if ('$$OID' in object) {
			cacheKey = object.$$OID;
			idType = '$$OID';
		} else {
			//If no ID what is the key for cache? 
			return object;
		}	

		var cachedObj = storageCache[cacheKey];
		if(cachedObj === undefined) {
			cachedObj = {};
			cachedObj.idForm = idForm;
			cachedObj.mode = mode;
			storageCache[cacheKey] = cachedObj;	
		}

		if(cachedObj.object === undefined) {
			cachedObj.object = object;
			cachedObj.mode = mode;
		} else {
			//If object already exists in cache, merge the newly fetched object with old cached object
			/*$.each(cachedObj.object, function(property) {
				delete cachedObj.object[property];
			});
			$.extend(cachedObj.object, object); */
			
			infa.imf.Deserializer.instance().refreshObject(object, cachedObj.object, false);

			cachedObj.mode = mode;
		}


		//If lightweight object exist, replace it with full object
		if(cachedObj.lwObject !== undefined) {
			var jQueryObj;

			$.each(cachedObj.lwObject, function(property) {
				if (!(typeof cachedObj.lwObject[property] === "object"  && property.indexOf('jQuery') === 0)) {					
					delete cachedObj.lwObject[property];
				}
			});

			$.each(cachedObj.object, function(property) {
				if (!(typeof cachedObj.object[property] === "object"  && property.indexOf('jQuery') === 0)) {					
					cachedObj.lwObject[property] = cachedObj.object[property];
				}
			});

			$.extend(cachedObj.lwObject, cachedObj.object);		
		}

		//Update all the object internals in cache
		var self = this;
		$.each(storageCache, function(index, cObj) {
			if(cObj.object && cObj.object !== cachedObj.object) {
				self.updateCachedObjectsInternal(cObj.object, cObj.object, cachedObj.object, idType);
			}
		});


		return cachedObj.object;
	},	

	updateCachedObjectsInternal : function(topLevelCacheObject, object, internalObject, idType){
		var self = this;
		$.each(object, function(property, value){
			if (value === null) {
				return;
			}				

			if (property === "$$fcParent" || property === "##agg") {
				return; //don't loop..
			}

			if ($.isArray(value)){
				for (var index = 0; index < value.length; index++){					  
					var innerValue = value[index];					

					if (typeof innerValue === 'object' && idType in innerValue && innerValue[idType] === internalObject[idType]){
						object[index] = internalObject;

						//TODO: Trigger only once and only if it is modified
						//$(topLevelCacheObject).trigger('change');					  
					} else {
						if(property.charAt(0) !== '_' && property.charAt(0) !== '$' && typeof innerValue === 'object') {
							self.updateCachedObjectsInternal(topLevelCacheObject, innerValue, internalObject, idType);
						}							
					}

				}
			} else if (typeof value === 'object'){
				if (idType in value && value[idType] === internalObject[idType]){
					object[property] = internalObject;

					//TODO: Trigger only once and only if it is modified
					//$(topLevelCacheObject).trigger('change');					  
				} else {
					if(property.charAt(0) !== '_' && property.charAt(0) !== '$' && typeof value === 'object') {
						self.updateCachedObjectsInternal(topLevelCacheObject, value, internalObject, idType);
					}						
				}
			}

		});//END walk all the properties
	},


	cacheLwObject : function(lwObjects, storage, idForm) {
		var self= this,
		newlwObjects = [],
		storageCache = this.getStorageCache(storage);		

		$.each(lwObjects, function(index, lwObject) {
			var cacheKey = lwObject.$$ID;
			if (idForm === 1) {
				cacheKey = lwObject.$$IID;				
			} else if (idForm === 2) {
				cacheKey = lwObject.$$OID;
			}					

			if (cacheKey) {
				var cachedObj = storageCache[cacheKey];
				if(cachedObj === undefined) {
					cachedObj = {};
					cachedObj.idForm = idForm;
					storageCache[cacheKey] = cachedObj;
				}

				if(cachedObj.lwObject === undefined) {
					cachedObj.lwObject = lwObject;
				} else {
					//If object already exists in cache, merge the newly fetched object with old cached object
					$.each(cachedObj.lwObject, function(property) {
						if (!(typeof cachedObj.lwObject[property] === "object"  && property.indexOf('jQuery') === 0)) {					
							delete cachedObj.lwObject[property];
						}
					});

					$.each(lwObject, function(property) {
						if (!(typeof lwObject[property] === "object"  && property.indexOf('jQuery') === 0)) {					
							cachedObj.lwObject[property] = lwObject[property];
						}
					});						
				}

				newlwObjects.push(cachedObj.lwObject);	
			} else {
				newlwObjects.push(lwObject);	
			}
		});			

		return newlwObjects;
	},


	updateObjectCache : function(objects, storage) {
		var self = this,
		affectedObjects = [],
		storageCache = this.getStorageCache(storage);

		$.each(objects, function(i, object) {
			//$(object).data('dirty', true);

			var idType = '';
			var cacheKey = object.$$ID;
			if ('$$IID' in object) {
				cacheKey = object.$$IID;
				idType = '$$IID';
			} else if ('$$OID' in object) {
				cacheKey = object.$$OID;
				idType = '$$OID';
			}

			var cachedObj = storageCache[cacheKey];
			if(cachedObj === undefined) {
				return;
			}				

			if(cachedObj.object) {
				//$(cachedObj.object).trigger('change');
			}					

			var lwObject = cachedObj.lwObject;
			if(lwObject) {
				$.each(cachedObj.lwObject, function(property) {
					if (!(typeof cachedObj.lwObject[property] === "object"  && property.indexOf('jQuery') === 0)) {					
						delete cachedObj.lwObject[property];
					}
				});

				$.each(cachedObj.object, function(property) {
					if (!(typeof cachedObj.object[property] === "object"  && property.indexOf('jQuery') === 0)) {					
						cachedObj.lwObject[property] = cachedObj.object[property];
					}
				});				

				//$(lwObject).data('dirty', true);			
				//$(lwObject).trigger('change');
			}


			//Trigger all cached objects if it contains internal object as modified object		
			$.each(storageCache, function(index, cObj) {
				if(cObj.object && cObj.object !== cachedObj.object) {
					if(self.isAncestorObject(cObj.object, cachedObj.object, idType)) {
						//Trigger change event for both light weight & full object
						if(cObj.object) {
							//$(cObj.object).trigger('change');
						}
						if(cObj.lwObject) {
							//$(cObj.lwObject).trigger('change');
						}							
						affectedObjects.push(cObj.object);
					}					
				}
			});
		});

		return affectedObjects;

	},

	isAncestorObject : function(object, internalObject, idType){
		var self = this;
		var isAncestor = false;
		$.each(object, function(property, value){
			if (value === null) {
				return;
			}				

			if (property === "$$fcParent" || property === "##agg") {
				return; //don't loop..
			}				

			if ($.isArray(value)){
				for (var index = 0; index < value.length; index++){					  
					var innerValue = value[index];					  
					if (typeof innerValue === 'object' && idType in innerValue && innerValue[idType] === internalObject[idType]){
						isAncestor = true;
						return false; // To break the each
					} else {
						if(property.charAt(0) !== '_' && property.charAt(0) !== '$') {
							if(self.isAncestorObject(innerValue, internalObject, idType)) {
								isAncestor = true;
								return false;
							}
						}
					}					  
				}
			} else if (typeof value === 'object'){
				if (idType in value && value[idType] === internalObject[idType]){
					isAncestor = true;
					return false; // To break the each
				} else {
					if(property.charAt(0) !== '_' && property.charAt(0) !== '$') {
						if(self.isAncestorObject(value, internalObject, idType)) {
							isAncestor = true;
							return false;
						}
					}						  
				}
			}
		});//END walk all the properties

		return isAncestor;
	},
	
	clearDirtyFlag : function() {
		var self = this;
		/*$.each(this._objectCache, function(storage, cachedObjects) {
			$.each(cachedObjects, function(i, cachedObj) {				
				if(cachedObj.object && $(cachedObj.object).data('dirty')) {
					$(cachedObj.object).data('dirty', false).trigger('change');
				}
				if(cachedObj.lwObject && $(cachedObj.lwObject).data('dirty')) {
					$(cachedObj.lwObject).data('dirty', false).trigger('change');
				}									
			});			
		});*/
	}

});
/**
 * This manager class is responsible for reading extensible workspaces extension point. 
 * Both WorkspaceConfigurationProvider and WorkspaceManager can call the APIs in this class to get extensions
 * corresponding to a workspace. The extensions are read once at the time of startup and are cached for later use.
 * 
 */

$.Class("infaw.workspace.WorkspaceExtensionManager", 
{
	_instance : undefined,

	instance : function(){
		if (infaw.workspace.WorkspaceExtensionManager._instance === undefined) {
			infaw.workspace.WorkspaceExtensionManager._instance = new infaw.workspace.WorkspaceExtensionManager();
		}			         
		return infaw.workspace.WorkspaceExtensionManager._instance;
	}  

},
{
	intialized: false,
	
	_workspaceIdToExtensionMap: {},
	
	_workspaceContextIdToActiveWorkspaceId: {},
	
	_workspaceContextIdToWorkspaceExtensions: {},
	
	_workspaceIdToSupportedObjExtns: {},
	
	_workspaceIdToNewActionProviderExtns: {},
	
	_workspaceIdToActionProviderExtns: {},
	
	_workspaceContextIdToAllowedWorkspaceExtensions: {},

	_initialize : function() {
		if(!this.$initializedDef) {
			var self = this,
				reader = infa.extensibility.ExtensionReader.instance();
			this.$initializedDef = $.Deferred();
			reader.read("com.informatica.tools.web.shell.extensibleWorkspaces").then(	
				/**
				 * @param {Array.<({$configElem, $contextId, $workspaceId, $label, $icon, $position, $jsClass, $packageId, supportedObject: Array.<{$$metaClass, $condition, $exclueCondition, $visibleCondition}>,
				 *				   $activeWorkspaceId})>} 
				 *		  extensions
				 */
					function(extensions) {
						
						var dynamicWorkspaceProviderExtensions = [],
							dynamicNewActionProviderExtensions = [],
							dynamicResourceDeferreds = [],
							dynamicSupportedObjExtns = [];
						
						for(var index in extensions) {
							var extension = extensions[index];
							if(extension.$configElem === 'workspaceProvider'){
								self._handleWorkspaceProvider(extension);
							} else if(extension.$configElem === 'initialState'){
								self._workspaceContextIdToActiveWorkspaceId[extension.$contextId] = extension.$activeWorkspaceId;
							} else if(extension.$configElem === 'supportedObject') {
								self._handleSupportedObject(extension);
							} else if(extension.$configElem === 'newActionProvider'){
								self._handleNewActionProvider(extension);
							} else if(extension.$configElem === 'actionProvider'){
								var extnsArr = self._workspaceIdToActionProviderExtns[extension.$workspaceId];
								if(extnsArr) {
									extnsArr.push(extension);
								} else {
									extnsArr = [];
									extnsArr.push(extension);
									self._workspaceIdToActionProviderExtns[extension.$workspaceId] = extnsArr;
								}
							} else if(extension.$configElem === 'dynamicWorkspaceProvider') {
								dynamicWorkspaceProviderExtensions.push(extension);
								dynamicResourceDeferreds.push(infa.extensibility.ResourceInclude.blockRequireResource(extension));
							} else if(extension.$configElem === 'dynamicNewActionProvider') {
								dynamicNewActionProviderExtensions.push(extension);
								dynamicResourceDeferreds.push(infa.extensibility.ResourceInclude.blockRequireResource(extension));
							} else if (extension.$configElem === 'dynamicSupportedObject') {
								dynamicSupportedObjExtns.push(extension);
								dynamicResourceDeferreds.push(infa.extensibility.ResourceInclude.blockRequireResource(extension));
							}
						}
						
						$.when.apply($, dynamicResourceDeferreds).done(function(data) {
							$.when(self._handleDynamicWorkspaceProviders(dynamicWorkspaceProviderExtensions),
								   self._handleDynamicNewActionProviders(dynamicNewActionProviderExtensions)/*,
								   self._handleDynamicSupportedObjects(dynamicSupportedObjExtns)*/).always(function() {

								self.intialized = true;
								// populate the allowed workspace extensions
								var workspaces = [], workspaceIdToContextId = {}, contextId, i;
								for (contextId in self._workspaceContextIdToWorkspaceExtensions){
									var extensions = self._workspaceContextIdToWorkspaceExtensions[contextId];
									for (i = 0; i < extensions.length; i++) {
										var extension = extensions[i];
										workspaces.push({id: extension.$workspaceId, type: 'workspace'});
										workspaceIdToContextId[extension.$workspaceId] = contextId;
									}
								}
								infaw.access.AccessManager.instance().getState(workspaces, {visible: true}, -1).done(function (states) {
									for (var i = 0; i < states.length; i++){
										var result = states[i];
										if (result.state.visible.value){
											// make map of workspaceId to contextId?
											// get result.id (workspaceId)
											// get contextId from map
											// get extension from workspaceIdToExtensionMap
											// insert into allowed map
											var workspaceId = result.id, 
												contextId = workspaceIdToContextId[workspaceId],
												extension = self._workspaceIdToExtensionMap[workspaceId],
												extnsArr = self._workspaceContextIdToAllowedWorkspaceExtensions[contextId];
											if(extnsArr) {
												extnsArr.push(extension);
											} else {
												extnsArr = [];
												extnsArr.push(extension);
												self._workspaceContextIdToAllowedWorkspaceExtensions[contextId] = extnsArr;
											}
										}
									}
									self.$initializedDef.resolve();
								}).fail(function(resp){
									self.$initializedDef.reject(resp);
								});
							});
						});
					}
			);				
		}
		return this.$initializedDef.promise();
	},
	
	_handleWorkspaceProvider: function(extension) {
		
		var self = this;
		self._workspaceIdToExtensionMap[extension.$workspaceId] = extension;
		var extnsArr = self._workspaceContextIdToWorkspaceExtensions[extension.$contextId];
		if(extnsArr) {
			extnsArr.push(extension);
		} else {
			extnsArr = [];
			extnsArr.push(extension);
			self._workspaceContextIdToWorkspaceExtensions[extension.$contextId] = extnsArr;
		}
	},
	
	_handleNewActionProvider: function(extension) {
		
		var self = this;
		var extnsArr = self._workspaceIdToNewActionProviderExtns[extension.$workspaceId];
		if(extnsArr) {
			extnsArr.push(extension);
		} else {
			extnsArr = [];
			extnsArr.push(extension);
			self._workspaceIdToNewActionProviderExtns[extension.$workspaceId] = extnsArr;
		}
	},
	
	_handleDynamicWorkspaceProviders: function(dynamicWorkspaceProviderExtensions) {

		var self = this,
			$deferred = $.Deferred(),
			dynamicWorkspaces = [],
			$allWsExtDeferreds = [];
		for (var i = 0; i < dynamicWorkspaceProviderExtensions.length; i++) {
			var extension = dynamicWorkspaceProviderExtensions[i];
			var jsClass = $.toFunction(extension.$jsClass);
			if (jsClass) {
				var dynamicWorkspaceProvider = new jsClass(),
					$wsDeferred;
				$wsDeferred = dynamicWorkspaceProvider.getWorkspaces();
				$allWsExtDeferreds.push($wsDeferred);
				$wsDeferred.done(function(workspaceExtensions) {

					if (!$.isArray(workspaceExtensions)) {
						workspaceExtensions = [workspaceExtensions];
					}
					
					// Specify the default context ID if not specified
					var $contextId = "infaPage.indexPage.workspaceContextID";
					if (dynamicWorkspaceProvider.getContextId) {
						var $providedContextId = dynamicWorkspaceProvider.getContextId();
						if ($providedContextId) {
							$contextId = $providedContextId;
						}												
					}
					
					for (var index = 0; index < workspaceExtensions.length; index++) {
						
						var workspaceExtension = {
							$contextId: $contextId
						}
						
						var refWorkspaceExtension = workspaceExtensions[index];
						for (var property in refWorkspaceExtension) {
							workspaceExtension["$" + property] = refWorkspaceExtension[property];
						}

						// Specify additional properties needed to replicate a "workspaceProvider" object
						workspaceExtension.$configElem = "workspaceProvider";
						dynamicWorkspaces.push(workspaceExtension);
					}
				}).fail(function() {
					$deferred.reject('Failed to get workspaces from dynamic workspace provider');
				});
			} else {
				return $deferred.reject('jsClass not found');
			}
		}
		
		$.when.apply($, $allWsExtDeferreds).done(function() {
			var pckgUtils = infa.extensibility.PackageUtils.instance();
			$.when(pckgUtils.getExtensionPackages(dynamicWorkspaces)).done(function(wkspcExtns) {
				for (var i = 0; i < wkspcExtns.length; i++) {
					self._handleWorkspaceProvider(wkspcExtns[i]);
				}
				$deferred.resolve();
			})
		});
		
		return $deferred.promise();
	},
	
	_handleDynamicNewActionProviders: function(dynamicNewActionProviderExtensions) {
		var self = this,
			$deferred = $.Deferred(),
			newActionProviders = [],
			$allActionExtDeferreds = [];
			
		for ( var i = 0; i < dynamicNewActionProviderExtensions.length; i++ ) {
			var extension = dynamicNewActionProviderExtensions[ i ],
				jsClass = $.toFunction( extension.$jsClass );
			
			if ( jsClass ) {
				var dynamicNewActionProvider = new jsClass(),
					$deferredAction = dynamicNewActionProvider.getNewActionProviders();
					
				$allActionExtDeferreds.push($deferredAction);
				
				$deferredAction.done(function( newActionExtensions ) {
					if ( !$.isArray( newActionExtensions ) ) {
						newActionExtensions = [ newActionExtensions ];
					}
					for ( var index = 0; index < newActionExtensions.length; index++ ) {
						var newActionProvider = self._formatNewActionProvider( newActionExtensions[ index ] );
						newActionProviders.push( newActionProvider );
					}
				});
			} else {
				return $deferred.reject('jsClass not found');
			}
		}

		$.when.apply( $, $allActionExtDeferreds ).done(function(){
			for( var i = 0, len = newActionProviders.length; i < len; i++ ) {
				self._handleNewActionProvider( newActionProviders[i] );
			}
			$deferred.resolve();
		});
		
		return $deferred.promise();
	},
	
	_formatNewActionProvider: function ( refNewActionProvider ) {
		var self = this;
		// Specify additional properties needed to replicate a "newActionProvider" object
		var newActionProvider = {
			$configElem: "newActionProvider",
		}
		
		for (var property in refNewActionProvider) {
			if( property === "newAction" ) {
				newActionProvider[ "newAction" ] = self._formatNewActionProperty( refNewActionProvider.newAction );
			} else if ( property === "locationURI" ) {
				newActionProvider[ "$locationURI" ] = self._formatLocationURI( refNewActionProvider[ property ] );
			} else {
				newActionProvider["$" + property] = refNewActionProvider[ property ];
			}
		}
		return newActionProvider;
	},
	
    /**
     * Format the locationString into the expected $locationURI object
     */
    _formatLocationURI: function ( locationURI ) {
    	var $locationURI = { };
		var placement = null;
		var refId = null;
		if ( locationURI === "endof" ) { 
			placement = "after"; 
			refId = locationURI;
		} else {
			var query = locationURI.split( "=" ); 
			if ( query.length == 2 ) {
				placement = query[ 0 ];
				refId = query[ 1 ];
			}
		}
		if ( placement != null && refId != null ) {
			$locationURI[ "placement" ] = placement; 
			$locationURI[ "refId" ] = refId; 
		}
		
		return $locationURI;
    },
    
	_formatNewActionProperty: function ( newActions ) {
		if ( !$.isArray( newActions ) ) {
			newActions = [ newActions ];
		}
		
		var convertedNewActions = [];
		for ( var i = 0; i < newActions.length; i++ ) {

			var newAction = {
				$configElem: "newAction"
			}
		
			for ( var property in newActions[ i ] ) {
				newAction[ "$" + property ] = newActions[ i ][ property ];
			}
			
			convertedNewActions.push( newAction );
		}
		return convertedNewActions;
	},
	
	
	_handleSupportedObject: function(extension) {
		var extnsArr = this._workspaceIdToSupportedObjExtns[extension.$workspaceId];
		if(extnsArr) {
			extnsArr.push(extension);
		} else {
			extnsArr = [];
			extnsArr.push(extension);
			this._workspaceIdToSupportedObjExtns[extension.$workspaceId] = extnsArr;
		}
	},
	
	// get the supported object contributions provided by dynamicSupportedObjectProviders
	_handleDynamicSupportedObjects: function(dynamicSupportedObjExtns) {
		var self = this,
			$deferred = $.Deferred(),
			$deferreds = [],
			dynamicSupportedObjProviders = [];
		for (var i = 0; i < dynamicSupportedObjExtns.length; i++) {
			var extension = dynamicSupportedObjExtns[i];
			var jsClass = $.toFunction(extension.$jsClass);
			if (jsClass) {
				var dynamicSupportedObjProvider = new jsClass();
				dynamicSupportedObjProviders.push(dynamicSupportedObjProvider);
				$deferreds.push(dynamicSupportedObjProvider.getSupportedObjects());
			}
		}
		
		$.when.apply($, $deferreds).always(function(res) {
			var metaClassNames = [], // a list of metaClassNames whose ids need to be obtained
				metaClassNameToSupportedObj = {},
				contextId,
				supportedObjs,
				supportedObj,
				newSupportedObj,
				metaClassName;
			for (var i = 0; i < arguments.length; i++) {
				supportedObjs = arguments[i];
				dynamicSupportedObjProvider = dynamicSupportedObjProviders[i];
				if (dynamicSupportedObjProvider.getContextId && $.isFunction(dynamicSupportedObjProvider.getContextId)) {
					contextId = dynamicSupportedObjProvider.getContextId();
				} else {
					contextId = 'infaPage.indexPage.workspaceContextID';
				}
				
				if (!$.isArray(supportedObjs)) {
					supportedObjs = [supportedObjs];
				}
				for (var j = 0; j < supportedObjs.length; j++) {
					supportedObj = supportedObjs[j];
					newSupportedObj = { $contextId: contextId };
					for (var prop in supportedObj) {
						if (prop === 'metaClass') {
							// The current browseObj extension contains $$metaClass as an id, so 
							// the metaClassName needs to be translated into metaClassId.
							metaClassName = supportedObj[prop];
							metaClassNames.push(metaClassName);
							metaClassNameToSupportedObj[metaClassName] = newSupportedObj;
						} else {
							newSupportedObj['$' + prop] = supportedObj[prop];
						}
					}
					self._handleSupportedObject(newSupportedObj);
				}
			}
			
			// get the metaClassId. Set it back to the cached extension object.
			var iClassInfo;
			infa.imf.IClassInfo.instance().iClassByName(metaClassNames).then(function(iClassInfos) {
				for (var i = 0; i < iClassInfos.length; i++) {
					iClassInfo = iClassInfos[i];
					supportedObj = metaClassNameToSupportedObj[iClassInfo.name];
					supportedObj.$$metaClass = iClassInfo.id;
				}
				$deferred.resolve();
			});
		});
		
		return $deferred.promise();
	},
	
	getWorkspaceExtension: function(workspaceId, immediate){
		if(immediate) {
			return this._workspaceIdToExtensionMap[workspaceId];
		} else {
			var self = this;
			return this._initialize().then(function() {
				return self._workspaceIdToExtensionMap[workspaceId];
			});			
		}
	},
	
	getActiveWorkspaceId: function(workspaceContextId){
		var self = this;
		return this._initialize().then(function() {
			return self._workspaceContextIdToActiveWorkspaceId[workspaceContextId];
		});
	},
	
	getAllWorkspaceExtensions: function(workspaceContextId, immediate){
		if(immediate) {
			return this._workspaceContextIdToWorkspaceExtensions[workspaceContextId];
		} else {
			var self = this;
			return this._initialize().then(function() {
				return self._workspaceContextIdToWorkspaceExtensions[workspaceContextId];
			});			
		}
	},
	
	getAllAllowedWorkspaceExtensions: function(workspaceContextId, immediate){
		if(immediate) {
			return this._workspaceContextIdToAllowedWorkspaceExtensions[workspaceContextId];
		} else {
			var self = this;
			return this._initialize().then(function() {
				return self._workspaceContextIdToAllowedWorkspaceExtensions[workspaceContextId];
			});			
		}
	},	
	
	isWorkspaceAllowed: function(workspaceContextId, workspaceId) {
		var allowedWSExtns = this._workspaceContextIdToAllowedWorkspaceExtensions[workspaceContextId],
			self = this,
			allowed = false;
		
		$.each(allowedWSExtns, function(i, wsExtn){
			if(wsExtn.$workspaceId == workspaceId) {
				allowed = true;
				return false;
			}
		});
		
		return allowed;
	},
	
	getWorkspaceSupportedObjExtns: function(workspaceId, immediate){
		if(immediate) {
			return this._workspaceIdToSupportedObjExtns[workspaceId];
		} else {
			var self = this;
			return this._initialize().then(function() {
				return self._workspaceIdToSupportedObjExtns[workspaceId];
			});				
		}
	},
	
	getNewActionProviderExtns: function(workspaceId) {
		var self = this;
		return this._initialize().then(function() {			
			return self._workspaceIdToNewActionProviderExtns[workspaceId];
		});			
	},
	
	getNewActionProviderExtnsMap: function() {
		var self = this;
		return this._initialize().then(function() {			
			return self._workspaceIdToNewActionProviderExtns;
		});			
	},
	
	getActionProviderExtns: function(workspaceId) {
		var self = this;
		return this._initialize().then(function() {			
			return self._workspaceIdToActionProviderExtns[workspaceId];
		});			
	},
	
	getActionProviderExtnsMap: function() {
		var self = this;
		return this._initialize().then(function() {			
			return self._workspaceIdToActionProviderExtns;
		});			
	},
	
	getSupportedObjectWorkspaceId: function(metaClassId, $mixins, immediate) {
		if(immediate) {
			return this._getSupportedObjectWorkspaceId(metaClassId, $mixins);
		} else {
			var self = this;
			return this._initialize().then(function() {
				return self._getSupportedObjectWorkspaceId(metaClassId, $mixins); 
			});
		}		
	},
	
	_getSupportedObjectWorkspaceId: function(metaClassId, $mixins) {
		var $mixin,
			self = this;
		
		if($mixins && $mixins.length)  {
			$mixin = $mixins[0];			
			if($.isNumeric($mixin)) {
				var clsInfoInst = infa.imf.IClassInfo.instance(),
					clsInfo = clsInfoInst.iClassById($mixin, true);	
				$mixin = clsInfo.name;
			}
		}		
		
		if(!$.isNumeric(metaClassId)) {
			var clsInfoInst = infa.imf.IClassInfo.instance(),
				clsInfo = clsInfoInst.iClassByName(metaClassId, true);	
			metaClassId = clsInfo.id;			
		}
		
		var suppportedWorkspaceId;
		$.each(self._workspaceIdToExtensionMap, function(workspaceId, extension){
			var supportedObjExtns = self._workspaceIdToSupportedObjExtns[workspaceId];
			if(supportedObjExtns && supportedObjExtns.length) {
				$.each(supportedObjExtns, function(i, extn){
					if(extn.$$metaClass == metaClassId && extn.$mixin == $mixin) {
						suppportedWorkspaceId = workspaceId;
						return false;
					};
				});
				
				if(suppportedWorkspaceId) {
					return false;
				}
			}
		});	
		
		return suppportedWorkspaceId;		
	},	
	
	getWorkspaceLabelToSupportedObjMap: function() {
		var self = this;
		return this._initialize().then(function() {
			return self._getWorkspaceLabelToSupportedObjMap();
		});
	},
	
	_getWorkspaceLabelToSupportedObjMap: function() {
		var wsToObjMap = {},
			self = this;
		$.each(this._workspaceIdToExtensionMap, function(workspaceId, extension){
			var supportedObjExtns = self._workspaceIdToSupportedObjExtns[workspaceId];
			if(supportedObjExtns && supportedObjExtns.length) {
				var classArr = [];
				$.each(supportedObjExtns, function(i, extn){
					classArr.push(extn.$$metaClass);
				});
				wsToObjMap[extension.$label] = classArr;
			}
		});
		
		return wsToObjMap;
	},
	
	getAllWorkspaceLabels: function(workspaceContextId){
		var wsExtensions = this._workspaceContextIdToWorkspaceExtensions[workspaceContextId];
		// sort the extensions based on the preferred position specified in extension contributions
		wsExtensions.sort(function(ext1, ext2) {
			var pos1 = ext1.$position;
			var pos2 = ext2.$position;
			if (pos1 === pos2) {
				return 0;
			}
			if (!pos1) {
				return 1;
			}
			if (!pos2) {
				return -1;
			}
			return pos1 - pos2;
		});
		
		var labels =[];
		$.each(wsExtensions, function(index, wsExtn){
			labels.push(wsExtn.$label);
		});
		
		return labels;
	},
	
	getSupportedObjectClauses : function(workspaceId, immediate) {
		if(immediate) {
			return this._getSupportedObjectClauses(workspaceId);
		} else {
			var self = this;
			return this.initialize().then(function(){
				return self._getSupportedObjectClauses(workspaceId);
			});	
		}
	},
	
	_getSupportedObjectClauses :function(workspaceId){
		var clauses = [],
			extns = this._workspaceIdToSupportedObjExtns[workspaceId];
		
		$.each(extns, function(i, extn){
			var clause = {
					$$classes: [extn.$$metaClass]
			};

			if(extn.$mixin) {									
				clause.where = '$mixins = ' + extn.$mixin;
			}							

			clauses.push(clause);
		});		

		return clauses;
	},
	
	getWorkspaceLabel: function(workspaceId) {
		var extn = this._workspaceIdToExtensionMap[workspaceId];
		if(extn) {
			return extn.$label;
		}
		return '';
	},
	
	getWorkspaceColor: function(workspaceId) {
		var extn = this._workspaceIdToExtensionMap[workspaceId];
		if(extn) {
			return extn.$color;
		}
		return '';
	}
	
});
$.Class('infaw.workspace.ObjectEditorHandler', {

	init: function(workspaceInst, multiObjTabs) {
		this._workspaceInst = workspaceInst;
		this._multiObjTabs = multiObjTabs;
	},
	
	/**
	 * Opens a new object in an editor
	 */
	newObjectInEditor : function(lwObject, options) {
		var workspaceInst = this._workspaceInst,
			self = this;
		return $.when(infaw.shell.common.ObjectNewWizardManager.instance().getObjectNewWizard(lwObject.$$class, lwObject.$mixins),
				infa.imf.IClassInfo.instance().iClassById(lwObject.$$class),
				infaw.shell.common.ImageManager.instance().getObjectImage(lwObject.$$class, lwObject.$mixins))
				.then(function(objNewWizardExtn, clsInfo, icon){

					if(objNewWizardExtn && objNewWizardExtn.$wizardJSClass) {	
						return $.when(infa.extensibility.ResourceInclude.blockRequireResource(objNewWizardExtn)).then(function(){
							var objectEditorInstanceId = self._createTempId();
							return $.when(workspaceInst.addInstance({
								instanceType: 'object',
								instanceId : objectEditorInstanceId, 
								metaClassName: clsInfo.name,									
								instanceName: lwObject.name, 
								icon: icon
							})).then(function(instanceDivId) {
								var objectNewWizardJSClass = $.toFunction(objNewWizardExtn.$wizardJSClass);
								if(objectNewWizardJSClass) {
									$.blockElem(instanceDivId);
									self._initNewObjEventHandlers( $('#' + instanceDivId), objectEditorInstanceId );
									var objectNewWizardInstance = new objectNewWizardJSClass(lwObject, options);
									//update the instance view
									workspaceInst.updateInstanceView(objectEditorInstanceId, objectNewWizardInstance);

									return $.when(objectNewWizardInstance.createUI(instanceDivId)).then(function(){		
										$.unblockElem(instanceDivId);
										return instanceDivId;
									});
								}
							});		
						});
					}
				});
	},
	
	/**
	 * Help remove the objects when they are closed or saved.
	 */
	_initNewObjEventHandlers: function($objectNewWizard, objectEditorInstanceId) {
		var workspaceInst = this._workspaceInst;
		var self = this;
		$objectNewWizard.on({
			'objectNewWizardClose' : function(e, skipHomeSelect) {
				workspaceInst.removeInstance(objectEditorInstanceId, skipHomeSelect);
			},
			'objectNewWizardSave' : function(e, skipHomeSelect) {
				workspaceInst.removeInstance(objectEditorInstanceId, skipHomeSelect); 
			},
			'objectNewWizardDirty' : function(e, isDirty) {
				if(self._multiObjTabs) {
					self._multiObjTabs.setInstanceDirty(objectEditorInstanceId, isDirty);
				}
			},
		});			
	},

	openObjectInEditor: function(object, mode) {
		var clsInfoInst = infa.imf.IClassInfo.instance(),
			workspaceInst = this._workspaceInst,
			self = this;

		return $.when(infaw.shell.common.ObjectEditorAssociationManager.instance().getObjectEditor(object.$$class, object.$mixins),
				clsInfoInst.iClassById(object.$$class),
				infaw.shell.common.ImageManager.instance().getObjectImage(object.$$class, object.$mixins))
				.then(function(objEditorAssExtn, clsInfo, icon){
					var $mixin;

					if(object.$mixins && object.$mixins.length) {
						$mixin = object.$mixins[0];						
						if($.isNumeric($mixin)) {
							var mixinClsInfo = clsInfoInst.iClassById($mixin, true);	
							$mixin = mixinClsInfo.name;
						}
					}

					if(objEditorAssExtn && objEditorAssExtn.$jsClass) {		
						return $.when(infa.extensibility.ResourceInclude.blockRequireResource(objEditorAssExtn)).then(function(){
							var objectEditorInstanceId = self.getObjectEditorId(object);

							if(workspaceInst.isInstanceExists(objectEditorInstanceId)) {								
								return $.when(workspaceInst.selectInstance(objectEditorInstanceId)).then(function(instanceObj) {
									if(instanceObj && instanceObj.divId) {
										var $editor = $('#' + instanceObj.divId),
										viewInst = $editor.data('editorInstance');
										if(viewInst && viewInst.updateUI) {
											viewInst.updateUI(mode);
										}
										return instanceObj;
									}
								});
							} else {
								var options = self.getObjectEditorOptions(objectEditorInstanceId, object, clsInfo, icon, $mixin);
								return $.when(workspaceInst.addInstance(options)).then(function(editorDivId) {
									var jsClass = $.toFunction(objEditorAssExtn.$jsClass);
									if(jsClass) {
										$.blockElem(editorDivId);
										
										var $editor = $('#' + editorDivId);
										self._initObjEventHandlers( $editor, objectEditorInstanceId );
										var viewInstance = new jsClass(object, objEditorAssExtn.$id);
										//update the instance view 
										workspaceInst.updateInstanceView(objectEditorInstanceId, viewInstance);

										$editor.data('editorInstance', viewInstance);
										return $.when(viewInstance.createUI(editorDivId, mode)).then(function(){											
											$.unblockElem(editorDivId);
											return editorDivId;
										});
									}
								});		
							}
						});
					}
				});
	},

	getObjectEditorId: function(object) {
		var instanceId = this._workspaceInst.getObjectInstanceId(object);
		if(instanceId) {
			return instanceId;
		} else {
			return this._createTempId();
		}
	},

	getObjectEditorOptions: function(instanceId, object, clsInfo, icon, $mixin) {
		return 	{
			instanceType: 'object',
			instanceId : instanceId, 
			metaClassName: clsInfo.name,
			mixin: $mixin,
			instanceName: object.name, 
			icon: icon
		};
	},
	
	_createTempId: function() {
		return 'newObject' + $.getUniqueID();
	},
	
	/**
	 * Help remove the instance when object is closed or saved
	 */
	_initObjEventHandlers: function($editor, objectEditorInstanceId) {
		var workspaceInst = this._workspaceInst,
			self = this;
		$editor.on({
			'objectEditorClose' : function(e) {
				workspaceInst.removeInstance(objectEditorInstanceId);
			},
			'objectEditorSave' : function(e) {
				workspaceInst.removeInstance(objectEditorInstanceId);
			},
			'objectEditorDirty' : function(e, isDirty) {
				if(self._multiObjTabs) {
					self._multiObjTabs.setInstanceDirty(objectEditorInstanceId, isDirty);
				}
			}
		});		
	},
});
(function ($) {

var homeClass = 'home',
	sHeadClass = 'sHead',
	sepClass = 'separator',
	disabledClass = 'disabled',
	selectedClass = 'menuSelected',
	hoverClass = 'mHover',  // used in keyboard scenario
	openIcon = $.url('/images/workspace/open.svg'),
	blankIcon = $.url('/images/workspace/blank.png'),
	tmpl = 
		'<table style="width:100%">' + 
			'<tr>' + 
				'<td><div class="sHead" itemId="rOpen"></div></td>' + 
			'</tr>' + 
		'</table>',
	firstCol = 
		'<td>' + 
			'<a class="home"></a>' + 
			'<div class="separator"></div>' +
			'<div class="sHead" itemId="new"></div>' + 
			'<div class="separator" itemId="newsep"></div>' +
			'<a itemId="open"><span class="openLabel" style="float:left"/></div><div class="iconSVG" style="margin-left:10px"></div></a>' +
		'</td>',
	actions = 
		'<table style="width:100%">' + 
			'<tr>' + 
				'<td><div class="sHead" itemId="actions"></div></td>' + 
			'</tr>' + 
		'</table>';		

var currNavElem = null,
	isKeyDown = false;

$.widget('infa.extensibleWSHoverMenu', { 

	_currentId: 0,
	
	_nextID: function(){
		return this._currentId++;
	},
	
	_$menu: null,
	
	_cb: null,

	options: {
		/**
		 * The id of the workspace that owns this menu
		 */
		workspaceId: '',
		/**
		 * If true, hide the first column including the home, new and open sections
		 */
		hideFirstColumn: false,
		/**
		 * To indicate whether Hover Menu is Home Menu or not
		 * If true, hover menu will contain HOME,NEW,Recently Opened
		 * If false, hover menu will contain ACTIONS
		 */
		isHomeMenu: true,		
		/**
		 * If true, ACTIONS menu will contain Add a Panel, Change the Layout by default
		 */
		isWSConfigurable: false,			
		/**
		 * The label of the "home" item
		 */
		homeLabel: '',
		/**
		 * The icon of the "home" item
		 */
		homeIcon: '',
		/**
		 * The function invoked when the "home" item is selected
		 */
		homeHandler: null,
		/**
		 * The function invoked when "Open" is selected
		 */
		openHandler: null,
		/**
		 * The function invoked when "Add a Panel" is selected
		 */		
		addPanelHandler: null		
	},

	_create: function() {
		var $elem = $('<div></div>').appendTo(this.element).infaMenu({contextMenu: true, showMenuOnMouseOver:true});
		this._$menu = $elem.parent().find('.mbmenu').addClass('boxMenu');
		
		var	i18nAlias = infaw.workspace.I18nResources,
			textUtils = infa.i18n.TextUtils.instance(),
			wsColor = infaw.workspace.WorkspaceExtensionManager.instance().getWorkspaceColor(this.options.workspaceId);
		
		//If workspace menu is not home menu or if workspace configurable
		//Draw the ACTIONS hover menu
		if(this.options.isHomeMenu == false || this.options.isWSConfigurable) {
			var $actionsElement = $(actions).appendTo(this._$menu);
			this._getCategory('actions').html(textUtils.getText(i18nAlias.ACTIONS));
			this._getMenuWidget()._setBoxMenuCB(this._createBoxMenuCB());
			
			if(this.options.isWSConfigurable) {
		    	var $refItem = this._getCategory('actions'),
	    		pos = 'first';
		    	
		    	var addPanelId = this.options.workspaceId + "_addPanel";
    	    	var $addPanelItem = this._add(addPanelId, $refItem, pos, i18nAlias.ADD_PANEL);

				$addPanelItem.on('click',$.proxy(this._onAddPanelSelect, this));
	    		
				//TODO: Change Layout action should be added
			}
			
			this._processActionExtensions();
		} else {
			var $tmpl = $(tmpl).appendTo(this._$menu);
			
			if (!this.options.hideFirstColumn) {
				$tmpl.find('tr').prepend(firstCol);
				
				var $openLabel = $tmpl.find('.openLabel');	
				$openLabel.html(textUtils.getText(i18nAlias.OPEN));
				
				var $openIcon = $tmpl.find('.iconSVG');			
				$openIcon.svg({
					loadURL: openIcon,
					onLoad: function() {							
						$openIcon.find('path, polygon, circle, rect').css({
							fill: wsColor
						});							
					}
				});										
				
				var homeLabel = this.options.homeLabel === '' ? textUtils.getText(i18nAlias.HOME) : this.options.homeLabel;
				var $home = $tmpl.find('.' + homeClass).html(homeLabel);
				if (this.options.homeIcon && this.options.homeIcon !== '') {
					var homeIcon = this.options.homeIcon;
					if(homeIcon && /.svg/i.test(homeIcon)) {
						var $homeIcon = $('<div class="iconSVG"></div>').prependTo($home);				
						$homeIcon.svg({
							loadURL: homeIcon,
							onLoad: function() {							
								$homeIcon.find('path, polygon, circle, rect').css({
									fill: wsColor
								});							
							}
						});						
					} else {
						var imgHtml = '<img src="' + homeIcon + '">';								
						$(imgHtml).prependTo($home);					
					}				
				}
				this._getCategory('new').html(textUtils.getText(i18nAlias.NEW));
				//this._getItem('open').append(textUtils.getText(i18nAlias.OPEN));
				$home.on('click', $.proxy(this._onHomeSelect, this));
				$tmpl.find('a[itemId="open"]').on('click', $.proxy(this._onOpenSelect, this));
			}
			this._getCategory('rOpen').html(textUtils.getText(i18nAlias.RECENTLY_OPENED));
			this._getMenuWidget()._setBoxMenuCB(this._createBoxMenuCB());
			this._processExtensions();
		} 
	}, 
    
    // the options that are supplied to create the mbMenu
    _menuOptions: function() {
    	var that=this;
    	var mbMenuOptions = {
    		template: '',
			menuWidth: 150,
			iconPath: '',
			fadeOutTime: 50,
//			onBeforeMenuOpened: this._onBeforeMenuOpened,
//			onMbOpen: function(e){that._onMbOpen(e)},
//			onMbClosed: this._onMbClosed,
//			onMbSelect: function(e){that._onMbSelect(e)}
    	};
    	return mbMenuOptions;
	}, 

	destroy: function(){
		this.element.empty();
		$.Widget.prototype.destroy.call(this);
	},
	
	show: function(domElem) {
		var menu = this._getMenuWidget();
		menu.show(domElem);
		return this;
	},
	
	hide: function() {
		var menu = this._getMenuWidget();
		menu.hide();
		return this;
	},
	
	isShown: function() {
		var menu = this._getMenuWidget();
		return menu.isShown();
	},
	
	getDropdown: function() {
		var menu = this._getMenuWidget();
		return menu.getDropdown();
	},
	
	_onHomeSelect: function() {
		this.hide();
		this.options.homeHandler();
	},

	_onAddPanelSelect: function() {
		this.hide();
		this.options.addPanelHandler();
	},
	
	_onOpenSelect: function() {
		this.hide();
		this.options.openHandler();
	},

	add: function(id, refId, position, label, icon, iconColor, location) {
		var $refItem = (refId === 'rOpen') ? this._getCategory(refId) : this._getItem(refId);
		label = $.infa.Formats.escapeComprehensive(label);
		var $item = this._add(id, $refItem, position, label, icon, iconColor, location);
		var that = this;
		$item.on('click', function(event) {
    		that.hide();
			var $realElem = that._$getRealElement(event.currentTarget);
			that.select($realElem.get(0));
			$realElem.trigger('onSelect');
    	});
		return $item.get(0);
	},
	
	_add: function(id, $refItem, position, label, icon, iconColor, location) {
		var locHtml = location ? '<span> / ' + location + '</span>' : '';
		var newItemHtml = '<a>' + label + locHtml + '</a>';
		var $newItem;
		if (this._isSectionHeader($refItem)) {
			// if the reference item is a section header, only allow inserting as the first child or
			// last child to that section.
			if (position === 'first') {
				$newItem = $(newItemHtml).insertAfter($refItem);
			} else {
				var $sep;
				var $curr = $refItem;
				while ($curr.length) {
					if ($curr.hasClass(sepClass)) {
						$sep = $curr;
						break;
					}
					$curr = $curr.next();
				}
				$newItem = $(newItemHtml).insertBefore($sep);
			}
		} else {
			// support inserting before or after a regular item
			if (position === 'before') {
				$newItem = $(newItemHtml).insertBefore($refItem);
			} else {
				$newItem = $(newItemHtml).insertAfter($refItem);
			}
		}
		$newItem.attr('id', this._nextID());
		if (id) {
			$newItem.attr('itemId', id);
		}
		
		if(!icon) {
			icon = blankIcon;
		}
		
		if(icon && /.svg/i.test(icon)) {
			var $svgicon = $('<div class="iconSVG" />').prependTo($newItem),
				wsColor = infaw.workspace.WorkspaceExtensionManager.instance().getWorkspaceColor(this.options.workspaceId);
			
			$svgicon.svg({
				loadURL: icon,
				onLoad: function() {							
					$svgicon.find('path, polygon, rect, circle').css({
						fill: iconColor || wsColor
					});							
				}
			});				
		} else {
			var imgHtml = '<img src="' + (icon ? icon : blankIcon) + '">';
			$(imgHtml).prependTo($newItem);			
		}
		
		
		
		return $newItem;
	},
	
	remove: function(item) {
		$(item).remove();
		return this;
	},
	
	setLabel: function(item, label) {
		var children = item.childNodes;
		for (var i = 0; i < children.length; i++) {
			var child = children[i];
			if (child.nodeType === 3) { // TEXT_NODE
				child.textContent = label;
				break;
			}
		}
		return item;
	},
	
	// Give the item a "selected" look
	select: function(item) {
		var $item = $(item);
		$item.siblings().removeClass(selectedClass);
		$item.addClass(selectedClass);
		return item;
	},
	
	unselect: function(item) {
		var $item = $(item); 
		$item.removeClass(selectedClass);
		return item;
	},
	
	isSelected: function(item) {
		return $(item).hasClass(selectedClass);
	},
	
	getSelected: function() {
		var $selected = this.element.find('.' + selectedClass);
		if ($selected.length) {
			return $selected.get(0);
		}
	},
	
	_getCategory: function(id) {
		return this._$menu.find('div[itemId="' + id + '"]');
	},
	
	getMenuItemById: function(id) {
		return this._getItem(id);
	},	
	
	_getItem: function(id) {
		return this._$menu.find('a[itemId="' + id + '"]');
	},
	
	_isSectionHeader: function($elem) {
		return $elem.hasClass(sHeadClass);
	},
	
	_setItemEnabled: function(item, enabled) {
		var isEnabled = this._isItemEnabled(item); 
		if (enabled !== isEnabled) {
			if (enabled) {
				$(item).removeClass(disabledClass);
			} else {
				$(item).addClass(disabledClass);
			}
		}
	},
	
	_isItemEnabled: function(item) {
		return !$(item).hasClass(disabledClass);
	},
	
	_processExtensions: function() {
    	var that = this;
    	infaw.workspace.NewActionManager.instance().getAllowedContributions(that.options.workspaceId).done(function(contributions) {
    		
    		if(contributions===undefined || contributions.length===0){
    			var $nItem = that._getCategory('new');
    			that.remove($nItem);
    			var $nSepItem = that._getCategory('newsep');
    			that.remove($nSepItem);
    		}
    		else{
	    		var cmdMgr = infa.common.CommandManager.instance();
		    	var $refItem = that._getCategory('new'),
		    		pos = 'first';
	    		for (var i = 0; i < contributions.length; i++) {
	    			var contribution = contributions[i];
	    	    	var $newItem = that._add(contributions[i].id, $refItem, pos, contributions[i].name, $.url(contributions[i].icon));
	    			cmdMgr.isEnabled(contributions[i].id).then(function(retValue, id) {
	    				var $item = that._getItem(id);
			    		that._setItemEnabled($item.get(0), retValue);
		    			$item.on('click', function(event) {
		    	    		if (that._isItemEnabled(event.target)) {
		    		        	that.hide();
		    		    		var id = $(event.target).attr('itemId');
		    		    		infa.common.CommandManager.instance().executeCommand(id);
		    	    		}
		    	    	});
	    			});
	    			$refItem = $newItem;
	    			pos = 'after';
	    		}
    		}	
    		that.element.trigger('onProcessExtensions');
    	});
    },
    
	_processActionExtensions: function() {
    	var that = this;
    	infaw.workspace.ActionManager.instance().getAllowedContributions(that.options.workspaceId).done(function(contributions) {
    		//If there are no contributions to actionProvider
    		if(contributions===undefined || contributions.length===0){
    			//If the workspace is not configurable
    			if(!that.options.isWSConfigurable) {
    				//Remove action item
    				var $actionItem = that._getCategory('actions');
    				that.remove($actionItem);
    			}
    		}
    		else{
	    		var cmdMgr = infa.common.CommandManager.instance();
		    	var $refItem = that._getCategory('actions'),
		    		pos = 'first';
	    		for (var i = 0; i < contributions.length; i++) {
	    			var contribution = contributions[i];
	    	    	var $newItem = that._add(contributions[i].id, $refItem, pos, contributions[i].name, $.url(contributions[i].icon));
	    			cmdMgr.isEnabled(contributions[i].id).then(function(retValue, id) {
	    				var $item = that._getItem(id);
			    		that._setItemEnabled($item.get(0), retValue);
		    			$item.on('click', function(event) {
		    	    		if (that._isItemEnabled(event.target)) {
		    		        	that.hide();
		    		    		var id = $(event.target).attr('itemId');
		    		    		infa.common.CommandManager.instance().executeCommand(id);
		    	    		}
		    	    	});
	    			});
	    			$refItem = $newItem;
	    			pos = 'after';
	    		}
    		}	
    		that.element.trigger('onProcessExtensions');
    	});
    },
    
    _$getRealElement: function(element) {
    	var id = $(element).attr('id');
    	var $item = this._getCategory('rOpen');
		var $curr = $item;
		while ($curr.length) {
			if ($curr.attr('id') === id) {
				return $curr;
			}
			$curr = $curr.next();
		}
    },
    
    _getMenuWidget: function() {
    	return $.getWidget(this._$menu, 'infaMenu');
    },
    
    _setFocusOnHide: function(elem) {
		var menu = this._getMenuWidget();
    	menu._setFocusOnHide(elem);
    },
    
    _createBoxMenuCB: function() {
    	var self = this;
    	return {
    		menuOpened: function(elem) {
    			currNavElem = elem;
    			isKeyDown = false;
    			$(document).on('keydown.extensibleWSHoverMenu keyup.extensibleWSHoverMenu', $.proxy(self._handleEventOnMenuOpen, self));
    		},
    		menuClosed: function() {
    			$(document).off('keydown.extensibleWSHoverMenu keyup.extensibleWSHoverMenu');
    			if (self._cb) {
    				self._cb.menuClosed();
    			}
    		},
    		preFocusOnClose: function() {
    			if (self._cb) {
    				self._cb.preFocusOnClose();
    			}
    		},
    		postFocusOnClose: function() {
    			if (self._cb) {
    				self._cb.postFocusOnClose();
    			}
    		}
    	};
    },
    
    _handleEventOnMenuOpen: function(event) {
    	// ignore the event if it happens outside the menu container
    	var $menuContainer = $(event.target).closest('.boxMenuContainer');
    	if ($menuContainer.length) {
			switch (event.type) {
			case 'keydown':
				this._onKeyDown(event);
				break;
			case 'keyup':
				isKeyDown = false;
				break;
			}
    	}
	},
	
	_onKeyDown: function(event) {
		if (!isKeyDown/*event.currentTarget === event.target*/) {
			isKeyDown = true;
			switch (event.which) {
			case 13: // enter
				if (this._isItemEnabled(currNavElem)) {
					// When enter is pressed on a menu item, the menu will be closed, and 
					// _onMbClosed will set the focus back to origFocus (the element that took 
					// focus before the menu was open). If origFocus is an <a>, a click event 
					// will also be triggered on the <a>, which is not desirable. 
					// preventDefault() prevents the click event from happening on the <a>.
					event.preventDefault();
					
					// select the item
					this._select(currNavElem);
				}
				return;
			case 27: // esc
				// close the menu
				this.hide();
				return;
			case 37: // arrow left
				// close the cascading menu
				this._navigateLeft();
				return;
			case 38: // arrow up
				// navigate one item up
				this._navigateVertically(true);
				return;
			case 39: // arrow right
				this._navigateRight();
				return;
			case 40: // arrow down
				// navigate one item down
				this._navigateVertically(false);
				return;
			}
		}
		event.preventDefault();
	},
	
	_select: function(elem) {
		var $elem = $(elem);
		$elem.trigger('mousedown');
		$elem.trigger('mouseup');
	
		var event = jQuery.Event('click');
		$elem.trigger(event);
	},
	
	_navigateVertically: function(up) {
		var elem = undefined;
		if (currNavElem) {
			if ($(currNavElem).hasClass('boxMenuContainer')) {
				elem = up ? this._getLastEnabled(currNavElem) : this._getFirstEnabled(currNavElem);
			} else {
				// navigate to the neighboring sibling
				elem = up ? this._getPrevEnabled(currNavElem) : this._getNextEnabled(currNavElem);
			}
		}
		if (elem) {
			this._navigateTo(elem);
		}
	},
	
	_navigateLeft: function() {
		if (currNavElem) {
			var $currNavElem = $(currNavElem);
			if (this._isNavigable($currNavElem)) {
				var $td = $currNavElem.parent(),
					$tds = $td.parent().children(),
					idx = $tds.index($td);
				for (var i = idx - 1; i >= 0; i--) {
					var item = this._getFirstEnabledInTd($tds.eq(i));
					if (item) {
						this._navigateTo(item);
						break;
					}
				}
			}
		}
	},
	
	_navigateRight: function() {
		if (currNavElem) {
			var $currNavElem = $(currNavElem);
			if (this._isNavigable($currNavElem)) {
				var $td = $currNavElem.parent(),
					$tds = $td.parent().children(),
					idx = $tds.index($td);
				for (var i = idx + 1; i < $tds.length; i++) {
					var item = this._getFirstEnabledInTd($tds.eq(i));
					if (item) {
						this._navigateTo(item);
						return;
					}
				}
			}
		}
	},

	_navigateTo: function(elem) {
		$(currNavElem).removeClass(hoverClass);
		currNavElem = elem;
		$(elem).addClass(hoverClass);
	},
	
	_getFirstEnabled: function(menuContainer) {
		var $tds = $(menuContainer).find('td');
		for (var i = 0; i < $tds.length; i++) {
			var item = this._getFirstEnabledInTd($tds.eq(i));
			if (item) {
				return item;
			}
		}
	},
	
	_getLastEnabled: function(menuContainer) {
		var $tds = $(menuContainer).find('td');
		for (var i = $tds.length - 1; i >= 0; i--) {
			var item = this._getLastEnabledInTd($tds.eq(i));
			if (item) {
				return item;
			}
		}
	},
	
	_getNextEnabled: function(elem) {
		var $elem = $(elem);
		var $curr = $elem.next();
		while ($curr.length) {
			if (this._isNavigable($curr) && this._isItemEnabled($curr.get(0))) {
				return $curr.get(0);
			}
			$curr = $curr.next();
		}
//		var $td = $elem.parent(),
//			$tds = $td.parent().children(),
//			idx = $tds.index($td);
//		for (var i = idx + 1; i < $tds.length; i++) {
//			var item = this._getFirstEnabledInTd($tds.eq(i));
//			if (item) {
//				return item;
//			}
//		}
	},
	
	_getPrevEnabled: function(elem) {
		var $elem = $(elem);
		var $curr = $elem.prev();
		while ($curr.length) {
			if (this._isNavigable($curr) && this._isItemEnabled($curr.get(0))) {
				return $curr.get(0);
			}
			$curr = $curr.prev();
		}
//		var $td = $elem.parent(),
//			$tds = $td.parent().children(),
//			idx = $tds.index($td);
//		for (var i = idx - 1; i >= 0; i--) {
//			var item = this._getLastEnabledInTd($tds.eq(i));
//			if (item) {
//				return item;
//			}
//		}
	},
	
	_getFirstEnabledInTd: function($td) {
		var $children = $td.children();
		for (var i = 0; i < $children.length; i++) {
			var $child = $children.eq(i);
			if (this._isNavigable($child)) {
				var child = $child.get(0);
				if (this._isItemEnabled(child)) {
					return child;
				}
			}
		}
	},
	
	_getLastEnabledInTd: function($td) {
		var $children = $td.children();
		for (var i = $children.length - 1; i >= 0; i--) {
			var $child = $children.eq(i);
			if (this._isNavigable($child)) {
				var child = $child.get(0);
				if (this._isItemEnabled(child)) {
					return child;
				}
			}
		}
	},
	
	_isNavigable: function($elem) {
		return $elem.is('a');
	},
	
	_setCB: function(cb) {
		this._cb = cb;
	}
	
});

}(jQuery));

/**
 * @author sdonthul
 * 
 * Base class file used to read through extensions
 */
$.Class('infaw.workspace.BaseActionManager', 
{
},
{
	/**
	 * reads the extension contributions, parse the locationURI attribute in the extension, 
	 * and determines whether an action should go before or after another.
	 */	
	readExtensions: function(actionExtensions) {
		var refItemIdToExtMap = new Object();
		$.each(actionExtensions, function(index, extension) {															
			var locationURI = extension.$locationURI;
			if (locationURI) {
				var refItemId = locationURI.refId;
				var ext = refItemIdToExtMap[refItemId];
				if (!ext) {
					refItemIdToExtMap[refItemId] = new Object();
					ext = refItemIdToExtMap[refItemId];
				}
				var bucket;
				if (locationURI.placement == 'before') {
					bucket = ext.before;
					if (!bucket) {
						ext.before = new Array();
						bucket = ext.before;
					}
				} else {
					bucket = ext.after;
					if (!bucket) {
						ext.after = new Array();
						bucket = ext.after;
					}
				}
				bucket.push(extension);
			}								
		});

		return refItemIdToExtMap;
	},
	
	/**
	 * returns the action contributions for a workspace
	 */	
	buildEndof: function(refItemIdToExtMap, idToCommandMap) {
		var contributions = [];
		
    	if (refItemIdToExtMap) {
    		var ext = refItemIdToExtMap['endof'];
    		if (ext) {
    			var bucket = ext.after;
    			if (bucket) {
    		    	for (var i = 0; i < bucket.length; i++) {
    					var extension = bucket[i];
    					if (extension.newAction) {
    						if (extension.newAction.length) {
    							for (var j = 0; j < extension.newAction.length; j++) {
    								this._addContributionCommand(refItemIdToExtMap, extension.newAction[j], idToCommandMap, contributions, true);
    							}
    						} else {
    							this._addContributionCommand(refItemIdToExtMap, extension.newAction, idToCommandMap, contributions, true);
    						}
    					} else if (extension.action) {
    						if (extension.action.length) {
    							for (var j = 0; j < extension.action.length; j++) {
    								this._addContributionCommand(refItemIdToExtMap, extension.action[j], idToCommandMap, contributions, false);
    							}
    						} else {
    							this._addContributionCommand(refItemIdToExtMap, extension.action, idToCommandMap, contributions, false);
    						}
    					}
    				}
    	    	}
    		}
    	}
    	
    	return contributions;
    },
    
    _addContributionCommand: function(refItemIdToExtMap, extCommand, idToCommandMap, contributions, isNewAction) {
    	var ext;
    	if (refItemIdToExtMap && extCommand.$id) {
    		ext = refItemIdToExtMap[extCommand.$id];
    	}
		if (ext && ext.before) {
			for (var i = 0; i < ext.before.length; i++) {
				if(isNewAction)
					this._addContributionCommand(refItemIdToExtMap, ext.before[i].newAction, idToCommandMap, contributions, isNewAction);
				else
					this._addContributionCommand(refItemIdToExtMap, ext.before[i].action, idToCommandMap, contributions, isNewAction);
			}
		}

		if (extCommand && extCommand.length) {
			for (var i = 0; i < extCommand.length; i++) {
				this._addContributionCommand(refItemIdToExtMap, extCommand[i], idToCommandMap, contributions, isNewAction);
			}
		} else {
			var command = idToCommandMap[extCommand.$commandId];
			contributions.push({id: command.$id, name: command.$name, icon: extCommand.$icon});
		}
		
		if (ext && ext.after) {
			for (var i = 0; i < ext.after.length; i++) {
				if(isNewAction)
					this._addContributionCommand(refItemIdToExtMap, ext.after[i].newAction, idToCommandMap, contributions, isNewAction);
				else
					this._addContributionCommand(refItemIdToExtMap, ext.after[i].action, idToCommandMap, contributions, isNewAction);
			}
		}
    },
   
	/**
	 * returns allowed action contributions by checking the states returned by access manager.
	 */	
    getAllowedActions: function(cmdExtns, wsIdToActionProviderExtns) {
    	var $deferred = $.Deferred(),
    	idToCommandMap = {},
    	wsIdToContributions = {},
    	self=this;
    	
		if ($.isArray(cmdExtns[0])){
			cmdExtns = cmdExtns[0];
		}
		$.each(cmdExtns, function(index, extension) {
			idToCommandMap[extension.$id] = extension;
		});																			

		//get contributions
		$.each(wsIdToActionProviderExtns, function(workspaceId, actionMgrExtns) {
			var refItemIdToExtMap = self.readExtensions(actionMgrExtns);
			var contributions = self.buildEndof(refItemIdToExtMap, idToCommandMap);	
			wsIdToContributions[workspaceId] = contributions;
		});	
  	
    	
    	var contributionIdToWorkspaceId = {}, 
		contributionIdToContribution = {}, 
		allowedContributions = [],
    	wsIdToAllowedContributions = {};
    	
		for (var workspaceId in wsIdToContributions){
			for (var j = 0; j < wsIdToContributions[workspaceId].length; j++){
				var contribution = wsIdToContributions[workspaceId][j];
				contributionIdToWorkspaceId[contribution.id] = workspaceId;
				allowedContributions.push({id: contribution.id, type: 'allowed'});
				contributionIdToContribution[contribution.id] = contribution;
			}
		}
		
		//populate allowed contributions
		infaw.access.AccessManager.instance().getState(allowedContributions, {allowed:true}, -1).done(function(states){
			for (var id in contributionIdToContribution){
				for (var i = 0; i < states.length; i++){
					var result = states[i];
					if (result.id == id){
						if (result.state.allowed.value){
							var workspaceId = contributionIdToWorkspaceId[id],
							allowedWorkspaceActions = wsIdToAllowedContributions[workspaceId];
							if (!allowedWorkspaceActions){
								// first time seeing workspace
								allowedWorkspaceActions = [];
								wsIdToAllowedContributions[workspaceId] = allowedWorkspaceActions;
							}
							allowedWorkspaceActions.push(contributionIdToContribution[id]);
						}
						break;
					}
				}
			}
			
			$deferred.resolve(wsIdToAllowedContributions);
		}).fail(function (resp) {
			$deferred.reject(resp);
		});
		
		return $deferred.promise();
    }

});
/**
 * @author clam
 * 
 * Manages new actions contributed to each workspace.
 */
infaw.workspace.BaseActionManager.extend('infaw.workspace.NewActionManager', 
{
	_instance : undefined,

	instance : function(){
		if (infaw.workspace.NewActionManager._instance === undefined) {
			infaw.workspace.NewActionManager._instance = new infaw.workspace.NewActionManager();
		}			         
		return infaw.workspace.NewActionManager._instance;
	}  

},
{
	// a map with workspaceId as the key and an array of allowed new action commands as the value
	_wsIdToAllowedContributions: undefined,
	
	initialize: function() {
		if(!this._$initializedDef) {
			var self = this,			
				wsExtnMgr = infaw.workspace.WorkspaceExtensionManager.instance();
			
			this._wsIdToAllowedContributions = {};			
			this._$initializedDef = $.Deferred();
				$.when(
					infa.common.CommandManager.instance().readCommands(), 
					wsExtnMgr.getNewActionProviderExtnsMap())
					.then(function(cmdExtns, wsIdToNewActionProviderExtns){
						// get the allowed action contributions
						self.getAllowedActions(cmdExtns, wsIdToNewActionProviderExtns).done(function(wsIdToAllowedContributions) {
							self._wsIdToAllowedContributions = wsIdToAllowedContributions;
							self._$initializedDef.resolve();
						}).fail(function(resp) {
							self._$initializedDef.reject(resp);
						});
					});
		}		
		return this._$initializedDef.promise();
	},
	
	getAllowedContributions: function (workspaceId, immediate) {
		if (immediate) {
			return this._wsIdToAllowedContributions[workspaceId] || [];
		} else {
			var self = this;
			return this.initialize().then(function() {
				return self._wsIdToAllowedContributions[workspaceId] || [];
			});
		}
	}
});
/**
 * @author sdonthul
 * 
 * Manages ACTIONS contributed to each workspace.
 */
infaw.workspace.BaseActionManager.extend('infaw.workspace.ActionManager', 
{
	_instance : undefined,

	instance : function(){
		if (infaw.workspace.ActionManager._instance === undefined) {
			infaw.workspace.ActionManager._instance = new infaw.workspace.ActionManager();
		}			         
		return infaw.workspace.ActionManager._instance;
	}  

},
{
	// a map with workspaceId as the key and an array of allowed action commands as the value
	_wsIdToAllowedContributions: undefined,
	
	initialize: function() {
		if(!this._$initializedDef) {
			var self = this,			
				wsExtnMgr = infaw.workspace.WorkspaceExtensionManager.instance();
			
			this._wsIdToAllowedContributions = {};
			this._$initializedDef = $.Deferred();
				$.when(
					infa.common.CommandManager.instance().readCommands(), 
					wsExtnMgr.getActionProviderExtnsMap())
					.then(function(cmdExtns, wsIdToActionProviderExtns){
						// get the allowed action contributions
						self.getAllowedActions(cmdExtns, wsIdToActionProviderExtns).done(function(wsIdToAllowedContributions) {
							self._wsIdToAllowedContributions = wsIdToAllowedContributions;
							self._$initializedDef.resolve();
						}).fail(function(resp) {
							self._$initializedDef.reject(resp);
						});
					});
		}		
		return this._$initializedDef.promise();
	},
	
	getAllowedContributions: function (workspaceId, immediate) {
		if (immediate) {
			return this._wsIdToAllowedContributions[workspaceId] || [];
		} else {
			var self = this;
			return this.initialize().then(function() {
				return self._wsIdToAllowedContributions[workspaceId] || [];
			});
		}
	}
});
(function ($) {
	
$.widget('infa.newAssetsTable', {
	
	options : {
		separators: true,
		workspaceId: '' // required
	}, 
	
	_create : function () {
		var opts=this.options, 
			that = this;
		this.element.addClass("wsAssets");
		var contributions = infaw.workspace.NewActionManager.instance().getAllowedContributions(opts.workspaceId).done(function(assets) {
			var $table = that._createAssetsTable(assets);
			if($table) {
				$table.appendTo(that.element);	
			}			
		});
	}, 
	
	_createAssetsTable : function (assets) {
		if (assets.length != 0){
    		var cmdMgr = infa.common.CommandManager.instance(), 
    			$div = $('<div class="tablePadding"></div>'), 
    			$table = $('<table class="table">').appendTo($div),
    			that = this;
			$.each(assets, function(i,asset){
				var $row = that._createAssetRow($table, asset);
				cmdMgr.isEnabled(asset.id).then(function (result, id){
					if (!result){
						// command should not be enabled
						$row.find('td').removeClass("row");
						$row.find('td').addClass("disabled-row");
						$row.find('span').attr('tabindex','-1');
					} else {
						$row.on('click keydown', function(event){
							if (event.type === 'keydown' && event.which !== 13){
								return;
							}
							cmdMgr.executeCommand($(event.currentTarget).data('id'));
						});
					}
				});

			});
			return $div;
		}
	},
	
	_createAssetRow : function ($table, asset) {
		var $row = $('<tr></tr>').appendTo($table),
			$data = $('<td class="row"></td>').appendTo($row), 
			sepOption = this.options.separator, 
			icon = $.url(asset.icon);
		
		if(icon && /.svg/i.test(icon)) {
			var $svgicon = $('<div class="iconSVG" />').appendTo($data),
				wsColor = infaw.workspace.WorkspaceExtensionManager.instance().getWorkspaceColor(this.options.workspaceId);
			
			$svgicon.svg({
				loadURL: icon,
				onLoad: function() {							
					$svgicon.find('path, polygon, rect, circle').css({
						fill: wsColor
					});							
				}
			});	
			
			$data.append('<span tabindex="0" class="label-text">'+asset.name+'</span>');
			
		} else {
			$data.append((typeof icon === 'undefined' ? '<div class="icon-buffer">' : '<img src="' + icon + '" class="icon">')
					+ '<span tabindex="0" class="label-text">'+asset.name+'</span>'
					+ (typeof icon === 'undefined'?'</div>' : ''));
			
		}
		
		if (sepOption){
			$data.addClass("separator");
		}
		$row.data('id', asset.id);
		return $row;
	},
	
});
}(jQuery));

(function ($) {
	$.infaWSNotify = function (message, title, type) {
		var wkMgr = infaw.workspace.WorkspaceManager.instance(),
		activeWSInstance = wkMgr.getActiveWorkspace(),		
		elementId = $(wkMgr.getWorkspaceTab(wkMgr.getActiveWorkspaceId())).attr('id');
		$.infaNotify(message, title, {type: type, element: '#' + elementId, offset: {y: 12}});
	};
	
}(jQuery));
$.infaNamespace('infaw.page');
(function( $ ){
infaw.page.I18nResources = {
  MESSAGE : 'Message',
  SESSION_EXPIRED_REDIRECT_MESSAGE : 'Your session has expired. You will now be redirected to the log in page where you can enter your user name and password.',
  SESSION_EXPIRED_REDIRECT_MESSAGE_FOR_KERBEROS : 'Your session has expired. Your page will now be refreshed.',
  GLOBAL_PANEL : 'Global Panel'
  
}}(jQuery));

/**
 * @author Madhu 
 * Base Page Manager
 * This manager class is responsible for rendering a page given a pageId. 
 * It calls PageExtensionManager for reading page information from extension points like header/footer etc. It can call ConfigurationManager
 * to read/set any preferences for the page using the key '<pageId>'.
 */
$.Class("infaw.page.BasePageManager", 
{
	_instance : undefined,

	instance : function(){
		if (infaw.page.PageManager._instance === undefined) {
			infaw.page.PageManager._instance = new infaw.page.PageManager();  
		}
		return infaw.page.PageManager._instance;
	}  

},
{
	pageExtension: undefined,
	
	pageId: undefined,
	
	/**
	 * options - {
	 * 	pageId : '', 
	 *  pageURL : '', 
	 *  serverIdleTime : '',
	 *  logo: '',
	 *  infaToken:'',
	 *  locale:''
	 * }
	 */
	
	load : function(options) {	

		this.pageId = options.pageId;
		this.pageURL = options.pageURL;
		this.$body = $('body');		
		infa.utils.Utils.instance()._setToken(options.infaToken);
		infa.utils.Utils.instance().setLocale(options.locale);

		$(document).on('ajaxSend', function(event, request, settings) {
			if (!settings.crossDomain) {
				request.setRequestHeader("infaToken", infa.utils.Utils.instance().getToken());
			}
		});		

		var	pageExtnManagerInst = infaw.page.PageExtensionManager.instance(),
		self = this;


		this._$initializeDef = pageExtnManagerInst.getPageExtension(this.pageId)
		.then(function(object){
			self.pageExtension= object;				
			return infa.extensibility.ResourceInclude.blockRequireResource(self.pageExtension);
		})	
		.then(function(){
			return self._initMainPageComponents(options);
			
		})			
		.then(
				function(){
					self._initPageViewHandler();					
					self._registerEvents();
					self._initTimeoutStrategy(options.pageId, options.serverIdleTime);
					$(document).trigger('onInfaPageLoad');
				}, 
				function(message){
					self.$body.append(message);
					self._refresh();				
				}
		)
		.then(function(){
			return self.getServerTimeDifference();
		})
		
		return this._$initializeDef;
	},	
	
	
	_registerEvents: function() {
		var self = this,
			$i18nAlias = infaw.page.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		
		this._wHeight = this._wWidth = -1;
		$(window).on('resize', function() {
			self._resize();
		});
		
	
		infaw.page.HotKeys.bindKeys();
		
		$(document).on('ajaxComplete',function(event,request,settings){
		    if (request.getResponseHeader('REDIRECT_TO_LOGIN_PAGE') === 'true' ||
		    		request.status == 401){
		    	var $dialog = $('<div />').infaDialog({
		    		closeOnEscape: false,
					buttons: {
						OK: function(e) {
							window.location.reload();
						}
					}, 
					modal: true,
					resizable: false,
					draggable: false
				}),
				dialog = $.getWidget($dialog, 'infaDialog');
				
		    	dialog.setTitle($textUtils.getText($i18nAlias.MESSAGE));
		    	var isKerberosEnabled = $.cookie('isKerberosEnabled');
				if(isKerberosEnabled && isKerberosEnabled === 'true') {
					dialog.setContent($textUtils.getText($i18nAlias.SESSION_EXPIRED_REDIRECT_MESSAGE_FOR_KERBEROS));
				}else{
					dialog.setContent($textUtils.getText($i18nAlias.SESSION_EXPIRED_REDIRECT_MESSAGE));
				}
				dialog.open();
		    };
		});
	},
	
	
	_initMainPageComponents: function(options) {
		
	},
	
	_refresh:function(){
		
		if(this.$globalHolder) {
			var wHeight = $(window).height(),
				headerHeight=0,
				footerHeight=0;
			
			// assumes minimum heights for header=37px and footer=24px
			if(this.$header){
				headerHeight=this.$header.height();
				if(headerHeight<37) {
					headerHeight=50;
				}
			}
			if(this.$footer){
				footerHeight=this.$footer.height();
				if(footerHeight<24){
					footerHeight=24; 
				}
			}			
			wHeight=Math.round(wHeight - headerHeight - footerHeight);
		
			this.$globalHolder.height(wHeight);
			this.$globalPanel.infaFloatPanel('refresh');		
		}
		$(window).trigger('pageresize');
	

	},	
	
	_resize:function(){
		var w = $(window),
			wHeight = w.height(),
			wWidth = w.width();

		
		if(wHeight !== this._wHeight || wWidth !== this._wWidth){
			this._wHeight = wHeight;
			this._wWidth = wWidth;	
			this._refresh();
		}	
	},
	
	_insertPageHeader: function(header) {
		
	
	},
	
	_initPageHeader: function(options) {	
		if(!this.pageExtension.pageHeader){
			return;	
		}

		var headerID = $.htmlId('ipg');
		this.$header = $('<header id="' + headerID + '"> </header>');
		
		this._insertPageHeader(this.$header);
		//this.$body.append(this.$header);		

		return infaw.pageHeader.PageHeaderManager.instance().load(this.pageExtension.pageHeader.$headerId, this.$header, options.logo);

	},
	
	
	 _insertWorkspace: function(workspaceSection) {
		 
		 
    },
	

	_initWorkspace: function() {
		var self=this,
		$i18nAlias = infaw.page.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();


		if(!this.pageExtension.workspaceProvider){
			return;
		}
		
		

		this.$workspaceSection = $('<section id="' + $.htmlId('ipg') + '" role="workspaces"></section>');
		
		this._insertWorkspace(this.$workspaceSection);
		//.appendTo(this.$body);		

		this.$globalHolder = $('<div></div>').appendTo(this.$workspaceSection)
		.infaFloatPanelComposite({
			panelOptions: { 
				title:$textUtils.getText($i18nAlias.GLOBAL_PANEL),
				attachment:'bottom', // possible values: top, bottom, left, right
				height:'380px', 
				global:true
			} 
		});
		var workspaceComposite = $.getWidget(this.$globalHolder, 'infaFloatPanelComposite');
		var $workspaceDiv = workspaceComposite.getMainElement();
		this.$globalPanel = workspaceComposite.getFloatPanel()
		.on('dock manualresize', function(){
			self._refresh();
		});
		this.globalPanelWidget = $.getWidget(this.$globalPanel, 'infaFloatPanel');

		this._refresh();

		var workspaceManager = infaw.workspace.WorkspaceManager.instance(),
			$deferred = workspaceManager.initialize(this.pageExtension.workspaceProvider.$workspaceContextId, 
				$workspaceDiv, 
				this.pageURL),
			strategy = infaw.workspace.WorkspaceStrategy.instance();
		strategy.initialize($workspaceDiv);
		return $deferred;
	},
	
	_initPageFooter: function() {	
		if(!this.pageExtension.pageFooter) {
			return;
		}

		var footerID = $.htmlId('ipg');
		this.$footer = $('<footer id="' + footerID + '"> </footer>');
		this.$body.append(this.$footer);		
				
		return infaw.pageFooter.PageFooterManager.instance().load(this.pageExtension.pageFooter.$footerId, this.$footer);
	},
	
	_initPageViewHandler: function() {
		if(!this.pageExtension.$jsCallback) {
			return;
		}

		var pageSectionID = $.htmlId('ipg');
		this.$pageSection = $('<section id="' + pageSectionID + '" role="pagesection"></section>');
		this.$body.append(this.$pageSection);					

		var pageViewHandler = $.toFunction(this.pageExtension.$jsCallback);
		if(pageViewHandler) {
			pageViewHandler(pageSectionID);
		}

	},
	
	_initTimeoutStrategy: function(pageId, serverIdleTime) {
		var reader = infa.extensibility.ExtensionReader.instance(),
		blockRequireResource = infa.extensibility.ResourceInclude.blockRequireResource;
		reader.read("com.informatica.tools.web.shell.timeoutStrategy").done(function(extensions) {			
			$.each(extensions, function(index, extension) {
				if(extension.$pageId === pageId && extension.$jsClass){						
					blockRequireResource(extension).done(function(){
						var jsClass = $.toFunction(extension.$jsClass);
						if(jsClass) {
							var timeoutStrategy = new jsClass();
							timeoutStrategy.initialize(serverIdleTime);							
						}						
					});
					return false;
				}					
			});									
		});	
	},	
	
	getGlobalPanelWidget: function() {
		return this.globalPanelWidget;
	},
	
	getHeader: function() {
		return this.$header;
	},
	
	getPageURL: function() {
		return this.pageURL;
	},
	
	getInitializeDeferredObj : function() {
		return this._$initializeDef;
	},
	
	getWorkspaceContextId: function() {
		return this.pageExtension.workspaceProvider.$workspaceContextId;
	},
	
	
	/**
	 * Page Event Manager - Event Manager to communicate across workspaces
	 */
	getEventManager: function() {
		if (!this._eventMgr) {
			this._eventMgr = new infaw.page.EventManager();
		}
		return this._eventMgr;
	},	
	
	getServerTimeDifference: function() {
		return infa.utils.Utils.instance().getServerTimeDifference();
	},
	
	getWorkspaceHolderDiv: function() {
		var workspaceComposite = $.getWidget(this.$globalHolder, 'infaFloatPanelComposite');
		if (workspaceComposite) {
			return workspaceComposite.getMainElement();
		}
	}
	
});
/**
 * @author Fei Du 
 * Page Manager
 * This manager class inherits from the basePageManager class
 * It is responsible for rendering a page in desktop browsers
 */

infaw.page.BasePageManager("infaw.page.PageManager", 
{},
{
	
	_initMainPageComponents: function(options) {		

		var self = this;
		self._initPageHeader(options)		
		.then(function(){
			return self._initPageFooter();
		})	
		.then(function(){
			return self._initWorkspace();
		})		

	},


	_insertPageHeader: function(header) {

		this.$body.append(header);
	},

	_insertWorkspace: function(workspaceSection) {

		workspaceSection.appendTo(this.$body);
	},

}
);
/**
 * @author clam
 * 
 * Event manager responsible for sending events and allowing consumers to listen to events. 
 */
$.Class('infaw.page.EventManager',
{
	_$eventNode: null,

	init: function() {
		this._$eventNode = $({}); //Updated $('<div></div>') (Dom based jQuery object) to $({}) to improve performance 
	},
	
	registerEvents: function(eventTypes, func) {
		var $event = this._$getEventElem();
		if ($event) {			
			// eventTypes can be a map of types/handlers
			if ( typeof eventTypes === "object" ) {
				$event.on(eventTypes);
			} else {
				$event.on(eventTypes, func);	
			}
		}
	},
	
	unregisterEvents: function(eventTypes, func) {
		var $event = this._$getEventElem();
		if ($event) {
			// eventTypes can be a map of types/handlers
			if ( typeof eventTypes === "object" ) {
				$event.off(eventTypes);
			} else {
				$event.off(eventTypes, func);
			}
		}
	},
	
	sendEvent: function(eventType, eventData) {
		var event = jQuery.Event(eventType);
		this._$eventNode.trigger(event, eventData);
	},
	
	_$getEventElem: function() {
		return this._$eventNode;
	}
});
// Stores menu contribution information
$.Class('infaw.page.SelectionManager',
// static methods 
{  
	_instance : undefined,
  
	instance : function(){
		if (!infaw.page.SelectionManager._instance) {
			infaw.page.SelectionManager._instance = new infaw.page.SelectionManager();
		}
		return infaw.page.SelectionManager._instance;
	}        
},
// prototype methods
{

	setSelection: function($elem, selection) {
		var $selection = this._$getSelection($elem);
		if ($selection) {
			$selection.data('selection', selection);
		}
	},
	
	getSelection: function($elem) {
		var $selection = this._$getSelection($elem);
		if ($selection) {
			return $selection.data('selection');
		}
	},
	
	_$getSelection: function($elem) {
		var $parent = $elem;
		while ($parent.length === 1 && $parent.data('selection') === undefined) {
			$parent = $parent.parent();
		}
		if ($parent.length === 1) {
			// $parent has attr 'data-selection'
			return $parent;
		}
	}
}
);
/**
 * This manager class is responsible for reading extensible page extension point. 
 * Both PageConfigurationProvider and PageManager can call the APIs in this class to get extensions
 * corresponding to a page. The extension are read once at the time of startup and are cached for later use.
 * 
 */


$.Class("infaw.page.PageExtensionManager", 
{
	_instance : undefined,
	
	_pageIdToExtensionMap: {},
	
	instance : function(){
		if (infaw.page.PageExtensionManager._instance === undefined) {
			infaw.page.PageExtensionManager._instance = new infaw.page.PageExtensionManager(); 
		}
		return infaw.page.PageExtensionManager._instance;
	}  

},
{
	intialized: false,
	
	_initialize : function() {
		var $deferred = $.Deferred();				
		var that = this;
		var reader = infa.extensibility.ExtensionReader.instance();
		reader.read("com.informatica.tools.web.shell.extensiblePage").done(	
			/**
			 * @param {Array.<{$configElem, $pageId, $packageId, $title, $jsCallback, pageHeader, workspaceProvider, pageFooter}>} extensions
			 */
			function(extensions) {			
				$.each(extensions, function(index, extension) {
					if(extension.$configElem === 'pageDescriptor'){
						infaw.page.PageExtensionManager._pageIdToExtensionMap[extension.$pageId] = extension;
					}
				});
				that.intialized = true;
				$deferred.resolve();
			}
		);	
		
		return $deferred.promise();
	},
	
	getPageExtension: function(pageId){
		var $deferred = $.Deferred();
		var self = this;
		if(!this.intialized) {
			var $initDeferred = this._initialize();
			$initDeferred.done(function() {
				$deferred.resolve(infaw.page.PageExtensionManager._pageIdToExtensionMap[pageId]);
			});									  	
		} else {
			$deferred.resolve(infaw.page.PageExtensionManager._pageIdToExtensionMap[pageId]);
		}
		
		return $deferred.promise();
	}
	
});


$.Class("infaw.page.HotKeys", {
	keyCodes:{
		search: 83,			// s + Ctrl + Shift
		contextPanel:67,	// c + Alt
		globalPanel:71,		// g + Alt
		closeWS: 88			// x + Ctrl + Shift
	},
	bindKeys: function(){
		$(document).on('keyup.page', function(evt){
			var keycode=evt.keyCode,
			codes=infaw.page.HotKeys.keyCodes;
			if(evt.ctrlKey && evt.shiftKey){
				if(keycode===codes.search){
					$(document).trigger('hotkey.search');
				}else if(keycode>47 && keycode<58){ // 0 to 9
					$(document).trigger('hotkey.workspace', keycode);
				} else if (keycode === codes.closeWS){
					$(document).trigger('hotkey.workspaceClose', keycode);
				}
			}else if(evt.altKey){
				switch(keycode){
				case codes.contextPanel:
					$(document).trigger('hotkey.contextPanel');
					break;
				case codes.globalPanel:
					$(document).trigger('hotkey.globalPanel');
					break;
				}
			}				
		});	
	}
},{});

/*infaSidebar is only for mobile version*/
/*sidebarManager is only for mobile version*/
$.infaNamespace('infaw.search');
(function( $ ){
infaw.search.I18nResources = {
  SEARCH_ALL : 'Search All',
  ALL : 'All',
  SEARCH_WORKSPACE : 'Search {0}',
  SEARCH_BY : 'Search by'
  
}}(jQuery));

$.Class('infaw.search.GlobalSearchManager', 
{  
	_instance : undefined,
  
	instance : function(){
		if (!infaw.search.GlobalSearchManager._instance) {
			infaw.search.GlobalSearchManager._instance = new infaw.search.GlobalSearchManager();
		}
		return infaw.search.GlobalSearchManager._instance;
	}        
},		
{	
	_optionCustomizerExtn: undefined,
	
	_init: function() {
		var self = this,
			reader = infa.extensibility.ExtensionReader.instance();
		if(!this.$initializedDef) {
			this.$initializedDef = $.Deferred();
			reader.read("com.informatica.tools.web.shell.globalSearch").done(function(extns) {
				var extn;
				self._searchHandlerExtnArr = [];
				for (var i = 0; i < extns.length; i++) {
					extn = extns[i];
					if (!self._optionCustomizerExtn && extn.$configElem === 'searchByCustomizer') {
						// only one contribution is supported
						self._optionCustomizerExtn = extn;
					} else if (extn.$configElem === 'searchHandler') {
						self._searchHandlerExtnArr.push(extn);
					}
				}
				self.$initializedDef.resolve();
			});
		}
		return this.$initializedDef.promise();
	},
	
	getSearchTypeOptions: function() {
		var self = this,
			$deferred = $.Deferred();
		this._init().done(function() {
			if (self._optionCustomizerExtn) {
				infa.extensibility.ResourceInclude.blockRequireResource(self._optionCustomizerExtn).done(function() {
					var jsClass = $.toFunction(self._optionCustomizerExtn.$jsClass);
					if (jsClass) {
						var customizer = new jsClass();
						customizer.getOptions().done(function(options) {
							$deferred.resolve(options);
						}).fail(function() {
							$deferred.reject();
						});
					} else {
						$deferred.reject();
					}
				}).fail(function() {
					$deferred.reject();
				});
			} else {
				$deferred.resolve();
			}
		}).fail(function() {
			$deferred.reject();
		});
		return $deferred.promise();
	},
	
	doWorkspaceSearch: function(searchText, curSearchCriteria, objTypeId, context) {
		var self = this;
		this._init().done(function() {
			if (self._searchHandlerExtnArr.length>0) {
				var searchHandlerExtn = undefined;
				if(context){ // If context is defined then pick up the searchHandler with matching context
					$.each(self._searchHandlerExtnArr, function(index, searchHandler){
						if(searchHandler.$context===context) {
							searchHandlerExtn = searchHandler;
							return false;
						}
					});
				}else {	// If context is not defined then pick up the first searchHandler that does not have context			
					$.each(self._searchHandlerExtnArr, function(index, searchHandler){
						if(!searchHandler.$context) {
							searchHandlerExtn = searchHandler;
							return false;
						}
					});
				}
				if(searchHandlerExtn){
					infa.extensibility.ResourceInclude.blockRequireResource(searchHandlerExtn).done(function() {
						var jsClass = $.toFunction(searchHandlerExtn.$jsClass);
						if (jsClass) {
							self.searchCallback = new jsClass();
							self.searchCallback.doWorkspaceSearch(searchText, curSearchCriteria, objTypeId);
						}
					});
				}
			} else{
				if (window.console) {
					window.console.log('No global search handler registered');
				}
			}
		});
	},
	
	getWSSearchStatus: function() {
		if(this.searchCallback)
			return this.searchCallback.getSearchStatus();
		
		return false;
	},
	
	resetWSSearchStatus: function() {
		if(this.searchCallback)
			this.searchCallback.resetSearchStatus();
	}
});	
/**
 * @author Olivier 
 * infaSearchBox
 * 
 */

(function ($) {
	
$.widget('infa.infaSearchBox', { 
	options: { 
		placeHolder: '', // will be populated in _create()
		clearAfterSubmit: false,
		autoResize: false,
		value: '',
		list: [],
		listValue: null,
		useShortCut: false, // ctrl-shift-s will open search
		searchIcon: $.url('/images/search/search.svg')
	},
	
	_create: function() {		
		var self = this,
			pageMgr = infaw.page.PageManager.instance();
		this._workspaceExtnMgr = infaw.workspace.WorkspaceExtensionManager.instance();
		$.when(this._workspaceExtnMgr.getAllAllowedWorkspaceExtensions(pageMgr.getWorkspaceContextId())).then(function(wsExtns){
			self._wsExtns = wsExtns || [];
			self._createUI();
		});
	},
	
	_createUI: function() {
		var opts=this.options,
			items=this.options.list,
			h=[],
			self = this;

		this.i18nAlias = infaw.search.I18nResources;
		this.textUtils = infa.i18n.TextUtils.instance();
		
		if(!opts.placeHolder) {
			opts.placeHolder = this.textUtils.getText(this.i18nAlias.SEARCH_ALL);	
		}
		
		h.push('<input type="text" class="infaSearchField" placeholder="', opts.placeHolder, '" ' );
		if(opts.value) {
			h.push('value="',  opts.value, '"');
		}
		h.push(' />');
		
		h.push('<span class="iconBuffer" />');
		h.push('<div class="infaSearchActivationButton" />');
		h.push('<div class="infaSearchMenu" />')
		
		this.element.html(h.join(''));

		this.$searchField = this.element.find('.infaSearchField');
		this.$searchField.placeholder();
		this.$searchFieldIcon = this.element.find('.iconBuffer')
								.prepend('<img src="' + $.url('/images/search/dropdown.png') + '" />');
		
		this.$searchActivationButton = this.element.find('.infaSearchActivationButton')
										.infaButton({
											shape: 'iconic', 
											icon: opts.searchIcon,
											width: 16,
											height: 16,
											activeOOFColor: '#CCCCCC',
											activeIFColor: '#3399FF'
										});
		
		
		this.$searchMenu = this.element.find('.infaSearchMenu')
							.infaMenu({
								contextMenu: true,
								showSelection: true
							});
		this.searchMenu = $.getWidget(this.$searchMenu, 'infaMenu');
		
		var searchByItem = this.searchMenu.add(-1, 'last', 'noIcon', this.textUtils.getText(this.i18nAlias.SEARCH_BY));
		this.searchMenu.disableItem(searchByItem);
		this.searchMenu.setItemStyle(searchByItem, 'color:#999999;');
		
		infaw.search.GlobalSearchManager.instance().getSearchTypeOptions().done(function(options) {
			if (options) {
				$.each(options, function(index, option){
					var menuItem = self.searchMenu.add(-1, 'last', 'radio', option.label, 'headerSearchGroupID');	
					$(menuItem).data('objTypeId', option.objTypeId);
				});
			} else {
				$.each(self._wsExtns, function(index, wsExtn){
					if (wsExtn.$permanent !== 'false' &&  
						wsExtn.$workspaceId !== 'startPageWS') {
						var supportedObjExtns = self._workspaceExtnMgr.getWorkspaceSupportedObjExtns(wsExtn.$workspaceId, true);
						if(supportedObjExtns && supportedObjExtns.length) {
							var menuItem = self.searchMenu.add(-1, 'last', 'radio', wsExtn.$label, 'headerSearchGroupID');	
							$(menuItem).data('workspaceId', wsExtn.$workspaceId);
						}
					}
				});
			}
		
			self.searchMenu.add(-1, 'last', 'separator');

			var allItem = self.searchMenu.add(-1, 'last', 'radio', self.textUtils.getText(self.i18nAlias.ALL), 'headerSearchGroupID');
			self.searchMenu.setChecked(allItem, true);
			self._selectedWorkspaceId = undefined;
			self._selectedObjTypeId = undefined;
		
			self._initializeEvents();
		});
	},

	_initializeEvents: function() {
		var self = this;
		
		this.$searchField.keydown(
			function(e) {
				if(e.which == 40) { // "Down"
					self._showMenu();
				}
			}
		).focus(
			function() {
				var menu = self.searchMenu;
				if (menu.isShown()) {
					menu.hide();
			}
		});
		
		this.$searchFieldIcon.on({
			'click' : function() {
				var menu = self.searchMenu;
				if (menu.isShown()) {
					menu.hide();
				} else {
					self._showMenu();
					
				}
			}
		});
		
		this.element.on('onSelect', '.infaMenuItem', function(event, ui) {
			var menuItem = event.target,
				$menuItem = $(menuItem),
				menuItemLabel = self.searchMenu.getLabel(menuItem);
			self.$searchField.prop('placeholder', self.textUtils.formatMessage(self.i18nAlias.SEARCH_WORKSPACE, [menuItemLabel]));
			self._selectedWorkspaceId = $menuItem.data('workspaceId');
			self._selectedObjTypeId = $menuItem.data('objTypeId');
		});
		
		this.$searchField.on('keyup',function(evt){
			if(evt.which==13){
				self._submit();
			}
		});
		
		this.$searchActivationButton.on('onSelect', function(evt){
			self._submit();
		});
	},
	
	_showMenu: function() {
		var self = this;
		var menu = self.searchMenu;
		
		menu.show(self.$searchField.get(0));
		var dropdown = menu.getDropdown().position({
			of: self.$searchField,
			my: 'left top',
			at: 'left bottom',
			collision: 'flip none'
		});
		
		dropdown.width('241px');

		// This closes the menu on "up" when we are at the top of the menu
		dropdown.keydown(
			function(event){
				if(event.which == 38) { // Up key
					// Get top element ignoring the disabled element
					var $topElement = $(this).children().eq(1); 
					if($topElement.hasClass("selected") == true) {
						self.focus();
					}
				}
			}
		);
	},
	
    _submit: function(v) {
    	this.element.trigger('onSearch', this.getValue());
    	var opts=this.options;
		if(opts.clearAfterSubmit){
			this.clear();
		}
		return this;
    },    
    
    getValue: function(){
    	var v={ searchText:this.$searchField.val().trim()};
    	v.workspaceId = this._selectedWorkspaceId;
    	v.objTypeId = this._selectedObjTypeId;
    	return v;
    },
    setValue: function( value){
    	this.$searchField.val(value.text);
    	if(this._dropdown){
    		this._dropdown.val(value.type);
    	}
    	return this;
    },
    clear: function(){
    	this.$searchField.val('');
    	if(this._dropdown){
    		this._dropdown.eq(0).listIndex=-1;
    	}
    },

    focus: function(){
    	this.$searchField.focus();
    	return this;
    },
    
	destroy: function(){
		this.element.empty();
		$.Widget.prototype.destroy.call( this );		
	}
	
});

}(jQuery));


/**
 * LDM Index header
 */
$.Class("infaw.indexPage.IndexHeader",
    {
        // static variables
        _searchBoxAccessId : "infaw.indexPage.indexHeader.searchBox",
        _headerMenuId: 'infaw.indexPage.Header'
    },
    {
        initialize : function(headerId, options) {
			var self = this;
			this.$header = $('#' + headerId);

			//this.i18nAlias = infaw.page.indexPage.I18nResources;
			/*this.textUtils = infa.i18n.TextUtils.instance();*/


			var label = options.label;


			return $.blockRequireTemplate({"tmpl/indexPage/ldmHeader.htm": "indexHeaderTmpl"}).then(function () {
				self.$header.html($.tmpl("indexHeaderTmpl", {logo: label}));


				var $deferred = $.Deferred();
				/*$.blockPostJSON('/web.access/access/start', null, null, -1).always(function () {*/
					var $defArr = [];

					if (options.search) {
						$defArr.push(self._initializeSearchBox(options.search));
					}
					if (options.setting) {
						$defArr.push(self._initializeMenu('ConfigMenu', 'images/indexPage/configure.svg', options.setting));
					}
					if (options.user) {
						$defArr.push(self._initializeMenu('UserMenu', 'images/indexPage/user.svg', options.user));
					}
					if (options.help){
						$defArr.push(self._initializeMenu('HelpMenu', 'images/indexPage/help_global.svg', options.help));
					}

					if (options.switcher) {
						$defArr.push(self._initializeSwitcher(options.switcher));
					}
					$.when.apply($, $defArr).done(function () {
						$deferred.resolve();
					}).fail(function () {
						$deferred.reject();
					})/*.always(function () {
						$.blockPostJSON('/web.access/access/end', null, null, -1);
					})*/;
				/*});*/
				return $deferred.promise();
			});
		},

		_initializeSwitcher: function(options) {
			var switcher = this.$header.find("[data-id='SwitchMenu']").infaButton({
				shape: 'iconic',
				icon: $.url('images/indexPage/dropdown.png'),
				width: 16,
				height: 16,
				activeOOFColor: '#CCCCCC',
				activeIFColor: '#3399FF'
			});
			switcher.bind('onSelect', function(){
				new infaw.ProductSwitchDialog(options);
			});

			$('.indexHeaderProductName')
					.css('cursor', 'pointer')
					.click(function() {
						new infaw.ProductSwitchDialog(options);
					});;
		},

        _initializeSearchBox: function(options) {
			this.$header.find("[data-id='SearchField']").children()
				.append('<div class="ldmSearchActivationButton"/>')
				.append('<input type="text" class="ldmSearchField" />');
			this.$header.find('.ldmSearchActivationButton')
				.infaButton({
					shape: 'iconic',
					icon: $.url('images/indexPage/search.svg'),
					width: 16,
					height: 16,
					activeOOFColor: '#000',
					activeIFColor: '#3399FF',
					hoverColor: '#3399FF'
				});
			this._createSearch(options);

			this.$header.find('.ldmSearchField').keydown(function(e) {
				if(e.which == 13) { // "Enter"
					$(e.currentTarget).blur();
				}
			});
        },

		_createSearch: function(options){
			this.$header.find('.ldmSearchField').autocomplete({
				source: function (request, response) {
                    if (options.jsClass) {
                        var cls = $.toFunction(options.jsClass);
                        if(cls) {
                            var searchCls = new cls();
							if (searchCls.onAutoComplete) {
								return searchCls.onAutoComplete(request.term, response);
							}
                        }
                    }
				},
				change: function (event, ui) {
					if(!ui.item)
						return;

					var item = ui.item.object;
					if (options.jsClass) {
                        var cls = $.toFunction(options.jsClass);
                        if(cls) {
                            var searchCls = new cls();
							if (searchCls.onSearch) {
								searchCls.onSearch(item);
							}
                        }

                    }
				},
				minLength: 1
			});
		},

        _initializeMenu: function(id, icon, options) {
            var $dropdown = this.$header.find("[data-id='" + id + "']").infaDropdown({
                menuId: infaw.indexPage.IndexHeader._headerMenuId + id,
                buttonOptions: {
                	icon: $.url(icon),
                	shape: 'iconic', 
                	height: 16,
                	width: 16,
                	hoverColor: '#FFF',
                	activeOOF: '#FFF',
                	activeIFColor: '#FFF',
                	animated: true
                },
                animated: true
            });

            var dropdown = $.getWidget($dropdown, 'infaDropdown'),
            	menu = dropdown.getMenuWidget();

			if (options.jsClass) {
				var cls = $.toFunction(options.jsClass);
				if (cls) {
					var settingCls = new cls();
					if (settingCls.getItems) {
						dropdown.disable();
						settingCls.getItems().done(function (items) {
							items.forEach(function (item) {
								var el = menu.add(-1, 'last', 'push', item.label);
								$(el).click(item.onClick);
							});


							if (items.length > 0) {
								dropdown.enable();
							}

						})
					}
				}
			}

			return;
        }
    }
);


$.Class('infaw.ProductSwitchDialog', {
	init: function(options) {
		var $dialog;
		
		var renderProduct = function(item, curCell) {
			var target = item.openNewWin? "_blank" : "_self";
			var tooltipMkup = '';
			if (item.tooltip) {
				tooltipMkup = ' title="' + item.tooltip + '"';
			}
			$('<div class="name"' + tooltipMkup +'><a target="' + target + '" href="' + item.url + '"><img class="prodimage" src="' + item.icon + '">' + item.label+'</a></div>').appendTo(curCell);
		};
		
		var createUI = function(items) {
			var catCount = 0, curCatName, curRow, curCell;
			var container = $('<div class="container-fluid"/>').appendTo($dialog);
			curRow = $('<div class="row" />').appendTo(container);

			items.forEach(function(item){
				
				if (curCatName == item.category) {
					renderProduct(item, curCell);
				} else {
					curCatName = item.category;
					catCount++;
					curCell = $('<div class="col-sm-3"><div class="category">' + curCatName + '</div></div>').appendTo(curRow);
					renderProduct(item, curCell);
					if (catCount%3 === 0) {
						$('<hr>').appendTo(container);
						curRow = $('<div class="row" />').appendTo(container);
					}
				}

				
			});
			
			$('.productSwitcher-title').append('<img style="padding:5px 0 0 10px;" src="' + options.icon + '">');

		};
		
		var createDialog = function(items) {
			$dialog = $('<div id="'+$.htmlId()+'"></div>').infaDialog({
				title: "",
				canClose: true,
				closeOnEscape: true,
				close: function() {
					$(this).infaDialog('destroy').remove();
				},
				position: {my:'bottom', at:'center', collision:'fit'}, 
				draggable: true,
				width: 800, 
				autoOpen: true,
				titleClass: 'productSwitcher-title',
				contentClass: 'productSwitcher-content'
			});
			
			createUI(items);
		};
		
		if (options.jsClass) {
			var cls = $.toFunction(options.jsClass);
			if(cls) {
				var switchCls = new cls();
				if (switchCls.getItems) {
					switchCls.getItems().done(function (json) {
						createDialog(json);
					});
				}
			}
			/*$.blockGetJSON(options.url).
	        	done(function(json) {
	        		if (!json || !json.products) {
	        			return;
	        		}
	        		createDialog(json.products);
	        	});*/
		}
		
		
	}

});
/**
 * @author Madhu 
 * A properties section defines an id, display name, and
 * ui portion for a section of the properties framework.
 */

$.Class("infaw.propertiesFramework.AbstractPropertiesSection", 
{

},
{
	currentObject:  undefined,
	_readOnly: undefined,
	
	init: function(obj) {
		this.currentObject = obj;
	},
	
	/**
	 * Get the unique id of this properties section
	 */
	getId: function(){
	},
	
	
	/**
	 * Get the UI portion of this section which has methods to 
	 * create a UI control as well as handle updates to the UI.
	 */
	createUI: function(blockElementId) {
		
	},
	
	/**
	 * return false if commit fails
	 */
	commit: function(){
		return true;
	},
	
	/**
	 * Called when the user switches to the property section 
	 */
	onSelect: function() {
		
	},
	
	/**
	 * Called before the section is removed to do the cleanup.
	 * 
	 */
	destroyUI: function() {
		
	},		
	
	setReadOnly: function(readOnly) {
		if (this._readOnly !== readOnly) {
			this._readOnly = readOnly;
			this.readOnlyChanged();
		}
	},
	
	isReadOnly: function() {
		return this._readOnly;
	},
	
	/**
	 * Subclasses can override this to handle the change of state
	 */
	readOnlyChanged: function() {
		
	}
	
});

infaw.propertiesFramework.AbstractPropertiesSection.extend('infaw.propertiesFramework.EmptyPropertiesSection', 
{
	
	options: {
		message: 'No properties to display'
	},
	
	init: function(options) {
		$.extend(this.options, options);
	},
	
	createUI: function(blockElementId) {
		var $sectionDiv = $('#'+ blockElementId).html(''),
		$messageDiv = $('<div class="infaEmptySectionMessage"></div>').appendTo($sectionDiv); 
		$messageDiv.append($.infa.UI.htmlMessage($.htmlId('im'),0, null, this.options.message));
	},
	
	destroyUI: function() {
		
	}		
	
});
/**
 * @author Madhu
 * 
 * Abstract Properties Section Provider
 */
$.Class('infaw.propertiesFramework.AbstractPropertiesSectionProvider', {
	getDefaultSectionId: function(){
		
	},
	
	getSectionDescriptors: function(){
		
	}
});
/**
 * @author Madhu
 * 
 * Composite Addition Section Provider
 */
infaw.propertiesFramework.AbstractPropertiesSectionProvider.extend('infaw.propertiesFramework.CompositeAdditionSectionProvider', {
	mainProvider: undefined,
	additionProviderList: undefined,
	combinedSections: undefined,
	CHOICE_FIRST : "first",
	CHOICE_START : "start",
	CHOICE_END : "end",
	CHOICE_LAST : "last",
	CHOICE_BEFORE : "before",
	CHOICE_AFTER : "after",
	
	init: function(mainProvider, additions) {
		this.mainProvider = mainProvider;
		this.additionProviderList = additions;
		this.combinedSections = undefined;
	},
	
	getDefaultSectionId: function(){
		if (this.mainProvider.getDefaultSectionId()) {
			return this.mainProvider.getDefaultSectionId();
		}
		// add addition sections with the order
		for (var i = 0; i < this.additionProviderList.length; i++) {
			if (this.additionProviderList[i].getDefaultSectionId()) {
				return this.additionProviderList[i].getDefaultSectionId();
			}
		}
		return undefined;
	},

	getSectionDescriptors: function(){
		if(this.combinedSections === undefined) {
			this.combinedSections = [];			
			//add all sections in mainProvider
			$.merge(this.combinedSections, this.mainProvider.getSectionDescriptors());			
			
			//add addition sections with the order
			for(var i = 0; i< this.additionProviderList.length; i++) {
				var addition = this.additionProviderList[i],
				prePosition = addition.getAdditionsPrePosition(),
				refSectionId = addition.getReferenceSectionId();
				
				//this is logic to add the 2nd PropertiesSectionProvider's sections
				if(this.CHOICE_START === prePosition || 
						this.CHOICE_FIRST === prePosition) {
					this.combinedSections = $.merge( $.merge([], addition.getSectionDescriptors()), this.combinedSections);					
				} else if((this.CHOICE_BEFORE === prePosition ||
						 this.CHOICE_AFTER === prePosition) && 
						 refSectionId !== undefined) {
					var referenceSection = this.findReferenceSectionIndex(this.combinedSections, refSectionId);
					
					if(referenceSection !== -1) {
						if(this.CHOICE_AFTER === prePosition) {
							referenceSection++;
						}						
						Array.prototype.splice.apply(this.combinedSections, [referenceSection, 0].concat(addition.getSectionDescriptors()));
					}
					else {	//add those to the last
						$.merge(this.combinedSections, addition.getSectionDescriptors());
					}
				} else {
					$.merge(this.combinedSections, addition.getSectionDescriptors());					
				}
			}
		}
		
		return this.combinedSections;
	},
	
	
	findReferenceSectionIndex : function(sections, refSectionId) {
		var refIndex = -1;
		for(var i = 0; i < sections.length; i++) {
			var section = sections[i];
			if(refSectionId === section.$id) {
				refIndex = i;
				break;
			}		
		}
		return refIndex;
	}
	
	
}) ;
/**
 * @author Madhu
 * 
 * Property Section Provider
 */
infaw.propertiesFramework.AbstractPropertiesSectionProvider.extend('infaw.propertiesFramework.CompositeSectionProvider', {
	provider1: undefined,
	provider2: undefined,
	
	init: function(first, second) {
		this.provider1 = first;
		this.provider2 = second;
	},
	
	getDefaultSectionId: function(){
		return (this.provider1.getDefaultSectionId()) ? this.provider1.getDefaultSectionId() : this.provider2.getDefaultSectionId();
	},

	getSectionDescriptors: function(){
		return $.merge( $.merge([], this.provider1.getSectionDescriptors()), this.provider2.getSectionDescriptors());
	}
});
/**
 * @author Madhu
 * 
 * Property Section Provider
 */
infaw.propertiesFramework.AbstractPropertiesSectionProvider.extend('infaw.propertiesFramework.PropertiesSectionProvider', {
	configElement : undefined,
	metaClass: undefined,
	
	init: function(configElement, metaClass) {
		this.configElement = configElement;
		this.metaClass = metaClass;
	},
	
	getDefaultSectionId: function() {
		return this.configElement.$defaultSectionId;
	},

	getSectionDescriptors: function() {
		var sectionDescriptors =[], 
			sections = this.configElement.section,
			propfwkInst = infaw.propertiesFramework.PropertiesFrameworkManager.instance();
		
		if(!$.isArray(sections)) {
			sections = [sections];
		}		
		
		$.each(sections, function(index, section) {
			var sectionDescriptor = propfwkInst.getSectionDescriptor(section.$id);
			sectionDescriptors.push(sectionDescriptor);
		});
			
		return sectionDescriptors;
	}
});
/**
 * @author Madhu
 * 
 * Section Additions
 */
infaw.propertiesFramework.PropertiesSectionProvider.extend('infaw.propertiesFramework.SectionAdditions', {
	configElement : undefined,
	metaClass: undefined,
	
	init: function(configElement, metaClass) {
		this.configElement = configElement;
		this.metaClass = metaClass;
	},

	getAdditionsPrePosition: function(){
		return this.configElement.$relativePosition;
	},
	
	getReferenceSectionId: function(){
		return this.configElement.$sectionId;
	}
});
/**
 * @author Madhu 
 * Properties Framework Manager
 */

$.Class("infaw.propertiesFramework.PropertiesFrameworkManager", 
{
	_instance : undefined,

	instance : function(){
		var propertiesFrameworkManager = infaw.propertiesFramework.PropertiesFrameworkManager;
		if (propertiesFrameworkManager._instance !== undefined) {
			return propertiesFrameworkManager._instance;
		}			
		propertiesFrameworkManager._instance = new infaw.propertiesFramework.PropertiesFrameworkManager();	  
		return propertiesFrameworkManager._instance;
	}
},
{	 
	propertiesSectionProviders: {},
	propertiesSections: {},
	propertiesSectionAdditions: {},
	CHOICE_FIRST : "first",
	CHOICE_START : "start",
	CHOICE_END : "end",
	CHOICE_LAST : "last",
	CHOICE_BEFORE : "before",
	CHOICE_AFTER : "after",

	initialize: function(){
		if(!this.$intializedDef) {
			var self = this,
			reader = infa.extensibility.ExtensionReader.instance();		
			this.$intializedDef = reader.read("com.informatica.tools.web.propertiesFramework.propertiesFramework").pipe(	
					/**
					 * @param {Array.<({$configElem, $defaultSectionId, $$metaClass, section: {$id}} |
					 *                 {$configElem, $id, $propertiesSectionJSClass, $name, $packageId})>} 
					 *        extensions array containing propertiesSectionProviders or propertiesSections
					 */
					function(extensions) {			
						$.each(extensions, function(index, extension){
							if(extension.$configElem === 'propertiesSectionProvider') {
								self._readPropertiesSectionProviders(extension);
							} else if(extension.$configElem === 'propertiesSection') {
								self._readPropertiesSections(extension);
							} else if(extension.$configElem === 'propertiesSectionAddition') {
								self._readPropertiesSectionAdditions(extension);
							}							
						});
	
						self.intialized = true;
						return;
					}
			);
		}
		return this.$intializedDef.promise();		
	},
	
	
	_readPropertiesSectionProviders: function(extension) {
		var metaClass = extension.$$metaClass;
		var providers = this.propertiesSectionProviders[metaClass];
		if(providers === undefined) {
			providers = [];
			this.propertiesSectionProviders[metaClass] = providers;
		}
		
		var propertiesSectionProvider = new infaw.propertiesFramework.PropertiesSectionProvider(extension, metaClass);
		
		providers.push(propertiesSectionProvider);
	},
	
	_readPropertiesSections: function(extension) {
		var id = extension.$id;
		//Ignore duplicate PropertiesSection Registered
		if(this.propertiesSections[id] === undefined) {
			this.propertiesSections[id] = extension;
		}
	},
	
	_readPropertiesSectionAdditions: function(extension) {
		var metaClass = extension.$$metaClass;
		var additions = this.propertiesSectionAdditions[metaClass];
		if(additions === undefined) {
			additions = [];
			this.propertiesSectionAdditions[metaClass] = additions;
		}
		
		var propertiesSectionProvider = new infaw.propertiesFramework.SectionAdditions(extension, metaClass);
		additions.push(propertiesSectionProvider);
	},
	
	
	/** 
	 * We need to see if this object has an main providers
	 * if not we need to find one in its super classes
	 * we also need to see if any one is adding any sections
	 * to this object using additions and we also need to
	 * add the additions of the super classes of this object
	 */
	getSectionProvider: function(obj) {		
		var self= this,
			$deferred = $.Deferred(),
			iClsInst = infa.imf.IClassInfo.instance();
		
		if(obj === undefined || obj.$$class === undefined) {			
			return $deferred.reject('Object is undefined or metaClass not found').promise();
		}				
		
		$.when(iClsInst.iClassById(obj.$$class), self.initialize()).always(function(classInfo){			
			var mainProvider = self.getProvider(self.propertiesSectionProviders[obj.$$class], obj);
			if(mainProvider === undefined) {
				var info = classInfo.superClass;
				while(info) {
					var superClassProvider = self.getProvider(self.propertiesSectionProviders[info.id], obj);
					if(superClassProvider) {
						mainProvider = superClassProvider;
						break;
					}
					info = info.superClass;
				}
			}
			
			var additionProviderList = self.buildSectionAdditionsList(obj, classInfo);			
			
			if(mainProvider && additionProviderList.length === 0) {
				$deferred.resolve(mainProvider);
			} else if(additionProviderList.length > 0) {
				var provider = new infaw.propertiesFramework.CompositeAdditionSectionProvider(mainProvider, additionProviderList);
				$deferred.resolve(provider);
			} else {
				$deferred.resolve();
			}
			
		});				
		
		return $deferred.promise();
	},
	
	
	buildSectionAdditionsList: function(obj, classInfo) {
		var additionProviderList = [],
		firstAddition,
		lastAddition,
		additionList = this.propertiesSectionAdditions[obj.$$class];
		
		var info = classInfo.superClass;
		while(info) {
			var superClassAdditionList = this.propertiesSectionAdditions[info.id];
			if(superClassAdditionList) {
				for(var k = 0; k < superClassAdditionList.length; k++) {
					var superClassAddition = superClassAdditionList[k];
					
					if(this.CHOICE_FIRST === superClassAddition.getAdditionsPrePosition()) {
						if (firstAddition !== undefined) {
							additionProviderList.push(firstAddition);	
						} 
						firstAddition = superClassAddition;
					} 
					else if (this.CHOICE_LAST === superClassAddition.getAdditionsPrePosition()) {
						if(lastAddition !== undefined) {
							additionProviderList.push(lastAddition);
						}
						lastAddition = superClassAddition;
					} 
					else {
						additionProviderList.push(superClassAddition);
					}
				}
			}
			
			info = info.superClass;
		}
		
		//continue to build additionProviderList
		if(additionList) {
			for(var m = 0;  m < additionList.length; m++) {
				var addition = additionList[m];

				if(this.CHOICE_FIRST === addition.getAdditionsPrePosition()) {
					if (firstAddition !== undefined) {
						additionProviderList.push(firstAddition);	
					} 
					firstAddition = addition;
				} 
				else if (this.CHOICE_LAST === addition.getAdditionsPrePosition()) {
					if(lastAddition !== undefined) {
						additionProviderList.push(lastAddition);
					}
					lastAddition = addition;
				} 
				else {
					additionProviderList.push(addition);
				}
			}
		}
		
		//put first/last addition in place, it will overwrite the previous first/last
		if(firstAddition !== undefined) {
			additionProviderList.push(firstAddition);
		}		
		if(lastAddition !== undefined) {
			additionProviderList.push(lastAddition);
		}
		
		return additionProviderList;
	},
	
	
	getProvider: function(providers, obj) {
		if(providers === undefined) {
			return undefined;
		}
		
		var defaultMatch;		
		for (var i=0;i<providers.length;i++) {
			var descriptor = providers[i];
			if(!defaultMatch) {
				defaultMatch = descriptor;
			} else {
				defaultMatch = new infaw.propertiesFramework.CompositeSectionProvider(defaultMatch, descriptor);	
			}
			
		}		
		
		return defaultMatch;
	},
		
	/**
	 * @return {{$id, $propertiesSectionJSClass, $name, $packageId}}
	 */
	getSectionDescriptor: function(id){
		return this.propertiesSections[id];
	},
	
	
	/**
	 * options - {
	 *  $propertiesDiv : '',
	 *  selectedObj : {},
	 *  tabsPosition : left | top
	 *  isReadOnly : true | false
	 * }
	 */
	createUI: function(options) {
		var self = this, 
			$propertiesDiv = options.$propertiesDiv, 
			selectedObj = options.selectedObj, 
			tabsPosition = options.tabsPosition,
			isReadOnly = options.isReadOnly,
			psOptions = options.psOptions,
			blockRequireResource = infa.extensibility.ResourceInclude.blockRequireResource,
			propfwkInst = infaw.propertiesFramework.PropertiesFrameworkManager.instance(),
			preserveTab = $propertiesDiv.data('objectContext') == selectedObj,
			selectedTabIndex = 0;
				
		if(preserveTab){
			var $oldTabs = $propertiesDiv.find('.ui-tabs');
			if($oldTabs){
				var tabs = $.getWidget($oldTabs, 'infaTabs');
				if(tabs){
					selectedTabIndex = tabs.getIndex(tabs.getSelected());
				}
			}
		}
		
		$propertiesDiv.data('objectContext', selectedObj);
		$propertiesDiv.data('psInstance', null);
		
		if(!tabsPosition) {
			tabsPosition = 'left';
		}
		
		$.blockElem($propertiesDiv.attr('id'));

		var propertySectionContext =[];
		if(psOptions){
			$.when(self.destroyUI($propertiesDiv)).done(function(){
				var jsClassName = psOptions.jsClass? psOptions.jsClass: 'infaw.propertiesFramework.EmptyPropertiesSection';
				var psJSClass = $.toFunction(jsClassName);
				if (psJSClass) {									
					var psInstance = new psJSClass(psOptions);
					psInstance.setReadOnly(isReadOnly);
					psInstance.createUI($propertiesDiv[0].id);									
					propertySectionContext.push(psInstance);
					$.unblockElem($propertiesDiv.attr('id'));
				}
				
				$propertiesDiv.data('propertySectionContext', propertySectionContext);	
			});
		}else{
		$.when(propfwkInst.getSectionProvider(selectedObj), self.destroyUI($propertiesDiv)).done(function(propertiesSectionProvider){
				var $defArr = [];
			if(propertiesSectionProvider !== undefined) {										
				var sectionDescriptors = propertiesSectionProvider.getSectionDescriptors();					
				if(sectionDescriptors) {
					if(sectionDescriptors.length === 1) {							
						var sectionDescriptor = sectionDescriptors[0];
						var $def = blockRequireResource(sectionDescriptor, -1).then(function() {
							var psJSClass = $.toFunction(sectionDescriptor.$propertiesSectionJSClass);
							if (psJSClass) {									
								var psInstance = new psJSClass(selectedObj);	
								psInstance.setReadOnly(isReadOnly);
								psInstance.createUI($propertiesDiv[0].id);	
								$propertiesDiv.data('psInstance', psInstance);
								propertySectionContext.push(psInstance);
								$.unblockElem($propertiesDiv.attr('id'));
							}
						});
						$defArr.push($def);
					} else {
						var $tabs = $('<div id="' + $.htmlId('t') + '"></div>')
									.appendTo($propertiesDiv)
									.infaTabs({
											position: tabsPosition,
											beforeActivate: function(event, ui){
												var psInstance = $(ui.tab).data('psInstance');
												if(psInstance && options.beforeActivate) {
													return options.beforeActivate(psInstance);
												}
												return true;
											}
									}).on('onSelect', function(event, ui) {								
										if (event.currentTarget === event.target) {		
											var psInstance = $(ui.tab).data('psInstance');
											if (ui.firstTime) {						
												if(psInstance) {
													psInstance.createUI(ui.tab.id);
												}
											}
											if (psInstance && psInstance.onSelect) { 
												psInstance.onSelect();
											}
										}
									}),
							tabs = $.getWidget($tabs, 'infaTabs');

						$.each(sectionDescriptors, function(index, sectionDescriptor) {								
							var $def = blockRequireResource(sectionDescriptor, -1).then(function() {
								var psJSClass = $.toFunction(sectionDescriptor.$propertiesSectionJSClass);
								if (psJSClass) {
									var sectionTab = tabs.add(sectionDescriptor.$name),
										psInstance = new psJSClass(selectedObj);	
									psInstance.setReadOnly(isReadOnly);										
									if(index === selectedTabIndex) {
										tabs.select(sectionTab);
										psInstance.createUI(sectionTab.id);	
									}										
									propertySectionContext.push(psInstance);
									$(sectionTab).data('psInstance', psInstance);
									$(sectionTab).css("overflow", "auto");
									$.unblockElem($propertiesDiv.attr('id'));
								}
							});
							$defArr.push($def);
						});
					}										
				}
			} else {
				$.unblockElem($propertiesDiv.attr('id'));
			}
			
			$.when.apply($, $defArr).always(function(){
				$propertiesDiv.data('propertySectionContext', propertySectionContext);	
			});				
		});
		}
	},
	
	getSelectedSection: function($propertiesDiv){
		var psInstance = $propertiesDiv.data('psInstance');
		if(psInstance) return psInstance;
		var $tabs = $propertiesDiv.find('.ui-tabs');
		if($tabs){
			var tabs = $.getWidget($tabs, 'infaTabs');
			if(tabs){
				return $(tabs.getSelected()).data('psInstance');
			}
		}
	},
	
	destroyUI: function($propertiesDiv) {
		var $defArr = [],			
			propertySectionContext = $propertiesDiv.data('propertySectionContext') || [];
		
		$.each(propertySectionContext, function(index, psInstance){
			if(psInstance.destroyUI) {
				$defArr.push(psInstance.destroyUI());
			}
		});
		
		return $.when.apply($, $defArr).then(function(){
			$propertiesDiv.children().remove();
		});
	}
});

$.infaNamespace('infaw.workspaceHome');
(function( $ ){
infaw.workspaceHome.I18nResources = {
  DEFAULT_HOME : 'Home',
  QUICKSTART_VIDEOS : 'Getting Started',
  NEW_ASSETS : 'New Assets',
  RECENTLY_OPENED : 'Recently Opened'
  
}}(jQuery));

infaw.workspace.PaneledWorkspace.extend('infaw.workspaceHome.WSHomeTemplate', {

	options: {
		overviewPanel : {
			visible: true,
			colSpan: 2
		}, 
		assetsPanel: {
			visible: true,
			colSpan: 1
		}, 
		recentlyOpenedPanel: {
			visible: true,
			colSpan: 1
		},
		videosPanel: {
			visible: true,
			colSpan: 2
		}
	},

	initialize: function(blockElementId, instanceId) {
		this._super(blockElementId, instanceId, true);
		this._configMgr = infaw.configuration.ConfigurationManager.instance();
		this._imgMgr = infaw.shell.common.ImageManager.instance();
		
		var strategy = infaw.workspace.WorkspaceStrategy.instance();;
		if (strategy.getHoverMenu && $.isFunction(strategy.getHoverMenu)) {
			this._hoverMenuInst = strategy.getHoverMenu(instanceId);
		}
		
		this._mruConfigKey = 'MRU-' + instanceId;
		this._registerMRUEvents();
	},

	onWorkspaceHomeSelect: function() {
		if(!this._skipHomeSelect && !this._isHomeInitialized && 
				this.isWorkspaceHomeActive()) {
			this._isHomeInitialized = true;
			return this._initializeHomePage(this._instanceId);			
		}
	},

	isWorkspaceHomeActive: function() {
		var multiObjTabs = this._multiObjTabs;
		if( multiObjTabs ) {
			return multiObjTabs.getHomeTab() === multiObjTabs.getActive();
		} else {
			return this._$workspaceTab.children().eq(0).hasClass('activeInstance');
		}
	},

	_initializeHomePage: function(instanceId) {
		// check the new action manager in case assets panel should be hidden
		var self = this;
		return infaw.workspace.NewActionManager.instance().getAllowedContributions(instanceId).then(function(assets){
			if (assets.length == 0){
				self.options.assetsPanel.visible = false;
				self.options.recentlyOpenedPanel.colSpan = 2;
			}
			// create config elements that mimic extension point contributions
			var extensions = new Array(),
				portletProvider = self._createPortletProvider(extensions, instanceId), 
				overviewInstanceId = self.options.overviewPanel.visible ? self._addOverviewPanel(extensions, portletProvider, instanceId) : -1, 
				videoInstanceId = self.options.videosPanel.visible ? self._addVideosPanel(extensions, portletProvider, instanceId) : -1, 
				assetsInstanceId = self.options.assetsPanel.visible ? self._addAssetsPanel(extensions, portletProvider, instanceId) : -1, 
				recentlyOpenedInstanceId = self._recentlyOpenedInstanceId = self.options.recentlyOpenedPanel ? self._addRecentlyOpenedPanel(extensions, portletProvider, instanceId) : -1; 			

			infaw.portlet.PortletExtensionManager.instance().addExtensions(extensions);
			
			//Handle Recently Opened Objects					
			return self.initializePortletContainer().then(function() {
				self._refreshMRUList();
			});		
		}, function(resp){
			infaw.shell.common.Utils.showErrorFromResponse(resp);
		});		
	},
	
	getRecentlyOpenedPortlet: function() {
		if(this._portletContainer){
			return this._portletContainer.getPortletInstanceById(this._recentlyOpenedInstanceId);
		}
		return null;
	},
	
	getPortletContainerOptions: function() {
		var portletContainerOptions = this._super();
		portletContainerOptions.masonry = true;
		return portletContainerOptions;
	},
	
	getColumnCount: function() {
		return 4;
	},
	
	getRowHeight: function(){
		return (this._$workspaceComposite.height())/2;
	},
	
	isPortletMovable: function() {
		return false;
	},

	isPortletResizable: function() {
		return false;
	},
	
	getWorkspaceName: function() {
		return this._workspaceMgr.getWorkspaceName(this.getInstanceId());
	},
	
	getWorkspaceColor: function(){
		var color = this._workspaceMgr.getWorkspaceColor(this.getInstanceId());
		if (color) {
			return color;
		}
		return '#333333';
	},
	
	/**
	 * Subclasses should override this to set the Text and style in the overview section of home page
	 */
	getOverviewText: function($overview) {
		
	},
	
	/**
	 * Subclasses can override this to set the videos in the Quickstart Videos Panel
	 * The overriding function should return an Array of objects of the following type: 
	 * 		title: 'How to create a reusable rule in Analyst Tool',
			creator: 'Informatica Support',
			postDate: '6/26/2013',
			description: 'Description',
			videourl: '//www.youtube.com/embed/gGRMx1k93TY',
	 */
	getVideos: function() {
		return [];
	},
	
	getOverviewColor: function(){
		return this._shadeColor(this.getWorkspaceColor(), 0.9);
	},
	
	_shadeColor : function (color, whiteRatio) {   
	    var num = parseInt(color.slice(1),16),
	    	origR = (num >> 16), 
	    	origG = (num >> 8 & 0x00FF), 
	    	origB = (num >> 2 & 0x0000FF), 
	    	white=255,
	    	diffR = Math.round((white-origR)*whiteRatio), 
	    	diffG = Math.round((white-origG)*whiteRatio), 
	    	diffB = Math.round((white-origB)*whiteRatio),
	    	fnlR = origR+diffR, 
	    	fnlG = origG+diffG, 
	    	fnlB = origB+diffB; 
	    return "#" + (0x1000000 + (fnlR<255?fnlR<1?0:fnlR:255)*0x10000 + (fnlG<255?fnlG<1?0:fnlG:255)*0x100 + (fnlB<255?fnlB<1?0:fnlB:255)).toString(16).slice(1);
	},
	
	addOpenedInstance : function (item) {		
		var lwObject = this._getLwObjectFromOptions(item),
			lwObjectStr = this._getLwObjectStrFromOptions(item);
		
		if(this._mruList) {
			var pos = $.inArray(lwObjectStr, this._mruList);
			if(pos != -1) {
				if(this._hoverMenuInst) {
					var mItem = this._hoverMenuInst.getMenuItemById(item.id);
					if(mItem) {
						this._hoverMenuInst.select(mItem);	
					}
				}
				
				//Move to last & save MRU
				this._mruList.splice(pos, 1);			
				this._mruList.push(lwObjectStr);
				this._configMgr.updateConfigs([{
					key: this._mruConfigKey, 
					value: this._mruList
				}]);
				return;
			}			
		}

		if(this._hoverMenuInst) {
			//Update Hover Menu
			var menuItem = this._updateMenuWithNewItem(lwObject),
				$menuSiblings = $(menuItem).siblings();	
			
			this._hoverMenuInst.select(menuItem);

			//If count is greater than 15 remove last menu item
			if($menuSiblings && $menuSiblings.length > 15) {
				var lastMenuItem = $menuSiblings[$menuSiblings.length - 1];
				this._hoverMenuInst.remove(lastMenuItem);
			}
		}

		//If MRU list not yet loaded - in the case of object using history state store the lwObject & update MRU list once it is completely loaded.
		if(!this._mruList) {
			if(!this.isTempObject(item.id)) {
				if(this._historyLwObjectStr) {
					this._historyLwObjectStr.push(lwObjectStr);	
				} else {
					this._historyLwObjectStr = [lwObjectStr];
				}
			} else {
				if(this._historyNewObjs) {
					this._historyNewObjs.push(lwObject);
				} else {
					this._historyNewObjs = [lwObject];
				}
			}

			return;
		}		
		
		//Update Portlet		
		var recentlyOpenedPortlet= this.getRecentlyOpenedPortlet();
		if(recentlyOpenedPortlet) {
			recentlyOpenedPortlet.addROpenItem(lwObject, this._instanceId);
		}
		
		if( !this.isTempObject(item.id) ) {
			if(this._mruList.length === 15) {
				this._mruList.shift(); // Remove First item.
			}
			
			this._mruList.push(lwObjectStr);
						
			this._configMgr.updateConfigs([{
				key: this._mruConfigKey, 
				value: this._mruList
			}]);			
		}
	},
	
	_getLwObjectFromOptions: function(options) {
		var lwObject = {
				$$IID: options.id,
				$$class: options.metaClassName,
				name: options.name,
				location: options.location
			};
		
		if(options.mixin) {
			lwObject.$mixins = [options.mixin];
		}
		
		return lwObject;
	},
	
	_getLwObjectStrFromOptions: function(options) {
		var lwObjectStr = options.id + '@' + options.metaClassName;
		
		if(options.mixin) {
			lwObjectStr += '@' + options.mixin; 
		}
		
		return lwObjectStr;
	},
	
	removeOpenedInstance : function (instanceId) {
		if(this._hoverMenuInst) {
			var $menuItem = this._hoverMenuInst.getMenuItemById(instanceId);
			if($menuItem && $menuItem[0]) {
				this._hoverMenuInst.remove($menuItem[0]);
			}
		}
		
		var recentlyOpenedPortlet= this.getRecentlyOpenedPortlet();
		if(recentlyOpenedPortlet) {
			recentlyOpenedPortlet.removeROpenItem(instanceId);
		}
		
		if(!this._mruList) {
			var self = this;
			if(  !this.isTempObject(instanceId) && 
					this._historyLwObjectStr && this._historyLwObjectStr.length) {
				$.each(this._historyLwObjectStr, function(i, lwStr){
					var lwObject = self.getLwObjectFromState(lwStr);
					if(lwObject) {				
						if(lwObject.$$IID == instanceId ) {
							self._historyLwObjectStr.splice(i, 1);
							return false;
						}
					}
				});
			} else if(this._historyNewObjs && this._historyNewObjs.length) {
				$.each(this._historyNewObjs, function(i, newLwObj) {
					if(newLwObj.$$IID == instanceId ) {
						self._historyNewObjs.splice(i, 1);
						return false;
					}
				});
			}
			return;
		}		
	},

	updateInstanceName: function (instanceId, name) {
		this._super(instanceId, name);

		var hoverMenu = this._hoverMenuInst;
		if(hoverMenu) {
			var $menuItem = hoverMenu.getMenuItemById(instanceId);
			if($menuItem && $menuItem[0]) {
				hoverMenu.setLabel($menuItem[0], name);
			}
		}
		
		var recentlyOpenedPortlet= this.getRecentlyOpenedPortlet();
		if(recentlyOpenedPortlet) {
			recentlyOpenedPortlet.updateROpenItemName(instanceId, name);
		}
	},

	/**
	 * Create portlet provider for workspace that each portlet instance can be added to
	 */
	_createPortletProvider : function (extensions, workspaceId) {
		var portletProviderConfig = {
			$configElem : 'portletProvider', 
			$workspaceId : workspaceId,
			portletInstance : new Array()
		}
		
		extensions.push(portletProviderConfig);
		return portletProviderConfig;
	},
	
	/**
	 * Create the config elements for the Overview Panel
	 */
	_addOverviewPanel : function (extensions, portletProvider, workspaceId) {
		var instanceId = workspaceId + '.wsHome.overview.instance', 
			homeLabel = this._workspaceMgr.getWorkspaceHomeLabel(workspaceId);
			
		if (!homeLabel || homeLabel === ''){
			var $i18nAlias = infaw.workspaceHome.I18nResources,
				$textUtils = infa.i18n.TextUtils.instance();
				homeLabel = $textUtils.getText($i18nAlias.DEFAULT_HOME);
		}
		// portletProvider portletInstance
		portletProvider.portletInstance.push(
				{
					$configElem: 'portletInstance',
					$configId: workspaceId + '.wsHome.overview.config',
					$instanceId: instanceId,
					$label: homeLabel
				}
		);
		
		// portletDescriptor
		var portletDescriptor = {
			$columnSpan: this.options.overviewPanel.colSpan,
			$configElem: 'portletDescriptor',
			$defaultPortletConfig: workspaceId + '.wsHome.overview.config',
			$hasDropdown: 'false',
			$jsClass: 'infaw.workspaceHome.WSHomeOverviewPanel',
			$label: 'Workspace Overview Portlet',
			$package: {
			},
			$portletId: 'wsHome.overview',
			$rowSpan: '1',
			$minWidth: 300
		},
		
		portletConfigDescriptor = {
			$closable: 'false',
			$configElem: 'portletConfigDescriptor',
			$configId: workspaceId + '.wsHome.overview.config',
			$label: 'Workspace Overview Config',
			$portletDescriptorId: 'wsHome.overview'
		};
		extensions.push(portletDescriptor);
		extensions.push(portletConfigDescriptor);
		
		return instanceId;
	},
	
	/**
	 * Create the config elements for the Quickstart Videos panel
	 */
	_addVideosPanel: function (extensions, portletProvider, workspaceId) {
		// portletProvider portletInstance 
		var $i18nAlias = infaw.workspaceHome.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance(), 
			instanceId = workspaceId + '.wsHome.videos.instance';
		portletProvider.portletInstance.push(
				{
					$configElem: 'portletInstance',
					$configId: workspaceId + '.wsHome.videos.config',
					$instanceId: instanceId,
					$label: $textUtils.getText($i18nAlias.QUICKSTART_VIDEOS),
				}
		);

		// portletDescriptor
		var portletDescriptor = {
			$columnSpan: this.options.videosPanel.colSpan,
			$configElem: 'portletDescriptor',
			$defaultPortletConfig: workspaceId + '.wsHome.videos.config',
			$hasDropdown: 'false',
			$jsClass: 'infaw.workspaceHome.WSHomeVideosPanel',
			$label: 'Quickstart Videos',
			$package: {
			},
			$portletId: 'wsHome.videos',
			$rowSpan: '2',
			$minWidth: 300
		},
		
		portletConfigDescriptor = {
			$closable: 'false',
			$configElem: 'portletConfigDescriptor',
			$configId: workspaceId + '.wsHome.videos.config',
			$label: 'Workspace Overview',
			$portletDescriptorId: 'wsHome.videos'
		};
		
		extensions.push(portletDescriptor);
		extensions.push(portletConfigDescriptor);
		
		return instanceId;
	}, 
	
	/**
	 * Create the config elements for the New Assets panel
	 */
	_addAssetsPanel : function (extensions, portletProvider, workspaceId) {
		var $i18nAlias = infaw.workspaceHome.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance(), 
			instanceId = workspaceId + '.wsHome.assets.instance';
		// portletProvider portletInstance
		portletProvider.portletInstance.push(
				{
					$configElem: 'portletInstance',
					$configId: workspaceId + '.wsHome.assets.config',
					$instanceId: instanceId,
					$label: $textUtils.getText($i18nAlias.NEW_ASSETS),
				}
		);
		
		// portletDescriptor
		var portletDescriptor = {
			$columnSpan: this.options.assetsPanel.colSpan,
			$configElem: 'portletDescriptor',
			$defaultPortletConfig: 'wsHome.assets.config',
			$hasDropdown: 'false',
			$jsClass: 'infaw.workspaceHome.WSHomeAssetsPanel',
			$label: 'New Assets',
			$package: {
			},
			$portletId: 'wsHome.assets',
			$rowSpan: '1',
			$minWidth: 150
		},
		
		portletConfigDescriptor = {
			$closable: 'false',
			$configElem: 'portletConfigDescriptor',
			$configId: workspaceId + '.wsHome.assets.config',
			$label: 'New Assets',
			$portletDescriptorId: 'wsHome.assets'
		};
		
		extensions.push(portletDescriptor);
		extensions.push(portletConfigDescriptor);
		
		return instanceId;
	}, 
	
	/**
	 * Create the config elements for the Recently Opened panel
	 */
	_addRecentlyOpenedPanel : function (extensions, portletProvider, workspaceId) {
		var $i18nAlias = infaw.workspaceHome.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance(), 
			instanceId = workspaceId + '.wsHome.recentlyOpened.instance';
		// portletProvider portletInstance
		portletProvider.portletInstance.push(
				{
					$configElem: 'portletInstance',
					$configId: workspaceId + '.wsHome.recentlyOpened.config',
					$instanceId: instanceId,
					$label: $textUtils.getText($i18nAlias.RECENTLY_OPENED),
				}
		);
		
		// portletDescriptor
		var portletDescriptor = {
			$columnSpan: this.options.recentlyOpenedPanel.colSpan,
			$configElem: 'portletDescriptor',
			$defaultPortletConfig: workspaceId + '.wsHome.recentlyOpened.config',
			$hasDropdown: 'false',
			$jsClass: 'infaw.workspaceHome.WSHomeRecentlyOpenedPanel',
			$label: 'Recently Opened',
			$package: {
			},
			$portletId: 'wsHome.recentlyOpened',
			$rowSpan: '1',
			$minWidth: 150
		},
		
		portletConfigDescriptor = {
			$closable: 'false',
			$configElem: 'portletConfigDescriptor',
			$configId: workspaceId + '.wsHome.recentlyOpened.config',
			$label: 'Recently Opened',
			$portletDescriptorId: 'wsHome.recentlyOpened'
		};
		
		extensions.push(portletDescriptor);
		extensions.push(portletConfigDescriptor);
		
		return instanceId;
	},
	
	getStorageName: function() {
		return 'browse';
	},
	
	getConfigMRUList: function() {
		return this._mrulwObjects;
	},
	
	
	_refreshMRUList: function() {
		var rOpenPortletInst = this.getRecentlyOpenedPortlet(),
			self = this;

		this._mruList = [];
		this._mrulwObjects = [];
		
		rOpenPortletInst.showLoading();
		$.when(self._configMgr.getConfigs([self._mruConfigKey])).then(function(configs){	
			var mruConfig = (configs && configs.length) ? configs[0] : {value: []},
				mruListChange = false,
				$defArr = [];				

			self._mruList = mruConfig.value;	

			if(self._historyLwObjectStr && self._historyLwObjectStr.length) {
				$.each(self._historyLwObjectStr, function(i, lwStr){
					var hp = $.inArray(lwStr, self._mruList);
					if(hp == -1)  {												
						if(self._mruList.length === 15) {
							self._mruList.shift(); // Remove First item.
						}						
						self._mruList.push(lwStr);									
						mruListChange = true;	
					} else {						
						//If exists move to last
						var hmru = self._mruList.splice(hp, 1);
						if(hmru && hmru.length) {
							self._mruList.push(hmru[0]);	
						}										
					}	
					
					if(self._hoverMenuInst) {
						var obAr = lwStr.split('@');
						if(obAr && obAr.length >= 2) {	
							var $meItem = self._hoverMenuInst.getMenuItemById(obAr[0]);
							if($meItem && $meItem[0]) {
								self._hoverMenuInst.remove($meItem[0]);
							}
						}
					}
				});
			}


			$.each(self._mruList, function(index, lwObjectStr){		
				var lwObject = self.getLwObjectFromState(lwObjectStr);
				if(lwObject) {
					self._mrulwObjects.push(lwObject);

					var $def = self.getLwObjects({                                    
						storage: self.getStorageName(), 
						idForm: 1, 
						what: 'self',
						lwObject: lwObject                                     
					}).then(
							function(objects) {
								if(objects && objects.length === 2) {
									var object = objects[0];
									lwObject.name = object.name;
									lwObject.$$class = object.$$class;
								} else {
									lwObject.deleted = true;
									//remove the instance if object is deleted
									if(self.isInstanceExists(lwObject.$$IID)){
										self.removeInstance(lwObject.$$IID);
									}
									var ax = $.inArray(lwObjectStr, self._mruList);
									if(ax != -1) {
										self._mruList.splice(ax, 1);
										mruListChange = true;
									}
								}
							}, 
							function() {
								lwObject.deleted = true;
								//remove the instance if object is deleted
								if(self.isInstanceExists(lwObject.$$IID)){
									self.removeInstance(lwObject.$$IID);
								}
								var ax = $.inArray(lwObjectStr, self._mruList);
								if(ax != -1) {
									self._mruList.splice(ax, 1);
									mruListChange = true;
								}
							}
					);
					$defArr.push($def);								
				}
			});

			$defArr.push(self._imgMgr.initialize());

            //INFA436665
            //deferreds need to be wrapped so rejected defer will not impact the execution of then function
            var lastResolved = 0;
            var wrappedDeferreds = [];
            for (var i = 0; i < $defArr.length; i++) {
                wrappedDeferreds.push(jQuery.Deferred());
                $defArr[i].always(function() {
                    wrappedDeferreds[lastResolved++].resolve(arguments);
                });
            }

			return $.when.apply($, wrappedDeferreds).then(function() {
				$.each(self._mrulwObjects, function(index, lwObject) {			
					if(lwObject.deleted) {
						return;
					}														
					rOpenPortletInst.addROpenItem(lwObject, self._instanceId);
					if(self._hoverMenuInst) {
						self._updateMenuWithNewItem(lwObject);
					}
				});

				if(self._historyNewObjs && self._historyNewObjs.length) {
					$.each(self._historyNewObjs, function(index, lwObject) {																	
						rOpenPortletInst.addROpenItem(lwObject, self._instanceId);
						
						if(self._hoverMenuInst) {
							var $newObjmenuItem = self._hoverMenuInst.getMenuItemById(lwObject.$$IID);
							if($newObjmenuItem && $newObjmenuItem[0]) {
								self._hoverMenuInst.remove($newObjmenuItem[0]);
							}

							self._updateMenuWithNewItem(lwObject);
						}
					});
				}

				self._historyLwObjectStr = undefined;
				self._historyNewObjs = undefined;

				if(mruListChange && self._mrulwObjects.length) {
					self._configMgr.updateConfigs([{
						key: self._mruConfigKey, 
						value: self._mruList
					}]);	
				}

				rOpenPortletInst.hideLoading();
			});

		}, function(resp) {
			rOpenPortletInst.hideLoading();
			infaw.shell.common.Utils.showErrorFromResponse(resp);			
		});			

	},
	
	_registerMRUEvents: function() {
		var _pageEventMgr = infaw.page.PageManager.instance().getEventManager(),
		   _wsExtnMger = infaw.workspace.WorkspaceExtensionManager.instance(),
			self = this;
		if (_pageEventMgr) {
			_pageEventMgr.registerEvents({				
				'onSave': function(event, savedObject){
					if(!savedObject) {
						return;
					}
					
					$.when(self._getObjectIdentity(savedObject)).then(function(identity) {
						if(identity) {
							if(self.objInstancesMap && self.objInstancesMap[identity]) {
								self.updateInstanceName(identity, savedObject.name);	
							}
						}
					});	
				},
				'onDelete': function(event, deletedObject) {
					if(!deletedObject || !deletedObject.$$class) {
						return;
					}
					
					if(self._isContainerMetaClass(deletedObject.$$class)){
						self._handleDelete();
					}else{
						$.when(_wsExtnMger.getSupportedObjectWorkspaceId(deletedObject.$$class, deletedObject.$mixins)).then(function(workspaceId){
							if(workspaceId && self._instanceId == workspaceId) {
								self._handleDelete();
							}
						});
					}
					
				}
			});						
		}		
	},	
	
	_getObjectIdentity: function(object) {
		if(object.$$IID) {
			return object.$$IID;
		} else if(object.$$OID) {
			var self = this
			return this.getLwObjects({                                    
                storage: self.getStorageName(), 
                idForm: 1, 
                what: 'self',
                lwObject: object                                     
			}).then(
				function(objects) {
                    if(objects && objects.length === 2) {
                    	var lwObject = objects[0];
                    	return lwObject.$$IID;
                    }                    
                    return undefined;
				}, 
				function() {
					return undefined;
				}
			);
		}
		
		return undefined;
	},
	
	_handleDelete: function() {
		var self = this;
		if(self._mruList) {
			$.each(self._mruList, function(index, lwObjectStr) {
				var lwObject = self.getLwObjectFromState(lwObjectStr);
				if(lwObject) {
					self.removeOpenedInstance(lwObject.$$IID);
				}
			});
			self._refreshMRUList();
		} else {
			//this means ws home is not initialized yet
			self._cleanUpHistory();
		}
	},
	
	_cleanUpHistory: function() {
		var self = this;
		//this means ws home is not initialized yet
		if(self._historyLwObjectStr && self._historyLwObjectStr.length) {
			//first make copy of the array
			var tempArr = self._historyLwObjectStr.slice(0);
			$.each(tempArr, function(i, lwObjectStr){
				if(lwObjectStr){
					var lwObject = self.getLwObjectFromState(lwObjectStr);
					if(lwObject) {		
						
						var $def = self.getLwObjects({                                    
							storage: self.getStorageName(), 
							idForm: 1, 
							what: 'self',
							lwObject: lwObject                                     
						}).then(
								function(objects) {
									if(!objects || objects.length !== 2) {
										//remove the instance if object is deleted
										//this will remove it from hover menu and history object
										if(self.isInstanceExists(lwObject.$$IID)){
											self.removeInstance(lwObject.$$IID, true);
										}
										
									} 
								}, 
								function() {
									//remove the instance if object is deleted
									//this will remove it from hover menu and history object
									if(self.isInstanceExists(lwObject.$$IID)){
										self.removeInstance(lwObject.$$IID, true);
									}
								}
						);

					}
				}
			});
		}
	},
	
	_isContainerMetaClass: function(metaClassId){
		var containerMetaClasses = this.getContainerMetaClasses();
		
		if(containerMetaClasses == null){
			return false;
		}
		
		if($.isArray(containerMetaClasses) && containerMetaClasses.length > 0){
		    var clsInfo = $.isNumeric(metaClassId) ? infa.imf.IClassInfo.instance().iClassById(metaClassId, true) : {name: metaClassId};
			if(clsInfo && clsInfo.hasOwnProperty('name'))
				return $.inArray(clsInfo.name, containerMetaClasses) > -1;
		}
		
		return false;
	},
	
	getContainerMetaClasses: function(){
		return null;
	},
	
	addInstance: function(options) {
		var self = this;
		
		return $.when(this._super(options)).then(function(newDivID) {
			$.blockElem();
			var instanceId = options.instanceId + '', 
				instanceName = options.instanceName, 
				icon = options.icon, 
				metaClassName = options.metaClassName,
				mixin = options.mixin,
				location = options.location;
			
			// update home page!
			self.addOpenedInstance({
				name: instanceName,
				icon: icon,
				location: location,
				id: instanceId,
				metaClassName: metaClassName,
				mixin: mixin
			});

			$.unblockElem();
			return newDivID;
		});
	},

	selectInstance: function(instanceId) {
		var self = this,
			instanceObj;
		
		if(instanceId === undefined) {
			if(this.isMultiObj()) {
				return this._selectHomeInstance();
			} else {
				return $.when(this.showActiveInstanceExitDialog()).then(function() {
					return self._selectHomeInstance();
				});	
			}
		} else {
			return $.when(this._super(instanceId)).then(function(instanceObj) {
				if(self._hoverMenuInst) {
					self._updateHoverMenuSelection(instanceId);
				}
				return instanceObj;
			});
		}
	},
	
	/**
	 * Helper function to select the home instance
	 */
	_selectHomeInstance: function() {
		infaw.workspace.WorkspaceStrategy.instance().selectHomeInstance(this);

		if(this._hoverMenuInst) {
			this._updateHoverMenuSelection();
		}

		var stateObj = {
			$ws : this._instanceId																																	
		}
		
		this.pushStateURL(stateObj);
		return $.when(this.onWorkspaceHomeSelect()).then(function() {
			// Return undefined because this is selecting home and has no instance
			return;	
		});
	},
	
	removeInstance: function(instanceId, skipHomeSelect) {
		if( !instanceId || !this.objInstancesMap ) {
			return; //workspace instances is not supported for this workspace
		}
		this._super(instanceId);
		
		if(!skipHomeSelect) {
			this.onWorkspaceHomeSelect();
		} else {
			// Need to initialize HomePage if not initialized
			if(!this._isHomeInitialized && 
					this.isWorkspaceHomeActive()) {
				this._isHomeInitialized = true;
				return this._initializeHomePage(this._instanceId);			
			}
		}
		
		if( this.isTempObject(instanceId) ) {
			// remove from home page
			this.removeOpenedInstance(instanceId);	
		}
	},
	
	/**
	 * This helps update the hoverMenu by adding the new item
	 */
	_updateMenuWithNewItem: function(lwObject) {
		var icon = this._imgMgr.getObjectImage(lwObject.$$class, lwObject.$mixins, true),
			iconColor = this._imgMgr.getObjectImageColor(lwObject.$$class, lwObject.$mixins, 'activeOOFColor', true),
			menuItem = this._hoverMenuInst.add(lwObject.$$IID, 'rOpen', 'first', lwObject.name, icon, iconColor, lwObject.location);
			$(menuItem).data('lwObject', lwObject);	
		return menuItem;
	},
	
	/**
	 * Update the hover menu with new selection
	 */
	_updateHoverMenuSelection: function(instanceId) {
		if(instanceId) {
			var menuItem = this._hoverMenuInst.getMenuItemById(instanceId);
			if(menuItem) {
				this._hoverMenuInst.select(menuItem);
			} else {
				// Selection was not found
				this._removeHoverMenuSelection();
			}
		} else {
			// Home Menu selected
			this._removeHoverMenuSelection();
		}
	},
	
	_removeHoverMenuSelection: function() {
		var selected = this._hoverMenuInst.getSelected();
		if (selected) {
			this._hoverMenuInst.unselect(selected);
		}
	},
	
	/**
	 * Add Home Tab
	 */
	_createMultiObjTabs: function(blockElementId) {
		// Create multiObjTabs using _super
		var multiObjTabs = this._super(blockElementId, true);
		multiObjTabs.element.show();
		multiObjTabs.setHomeLabel(this._workspaceMgr.getWorkspaceHomeLabel(this._instanceId));
		
		// Add Home Tab (Tab will be resized after populateContent finishes)
		this._skipHomeSelect = true;
		var homeTab = multiObjTabs.add();
		this._skipHomeSelect = false;
		
		// Move homeInstance into homeTab
		this._$workspaceComposite.appendTo( $(homeTab) );
		
		return multiObjTabs;
	}
});
infaw.portlet.AbstractPortlet.extend('infaw.workspaceHome.WSHomeAssetsPanel', 
{
	init: function(blockElementId, instanceId) {
		this._super(blockElementId, instanceId);
		this.createUI();
	},
	
	createUI : function() {
		var workspaceInst = this._getWorkspaceInst();
		var that = this;
		this.$assets = $('<div id="' + $.htmlId('assetsId') + '" class="grid-section"></div>').appendTo(this.getPortletElem());
		this.$assets.newAssetsTable({
			separator: true,
			workspaceId: workspaceInst.getInstanceId()
		});
	},
	
	_getWorkspaceInst: function() {
		return infaw.portlet.PortletUtils.instance().getWorkspace(this.getPortletElem());
	}
});
infaw.portlet.AbstractPortlet.extend('infaw.workspaceHome.WSHomeOverviewPanel', 
{
	init: function(blockElementId, instanceId) {
		this._super(blockElementId, instanceId);
		this.createUI();
	},
	
	createUI : function(){
		var workspace = this._getWorkspaceInst();
		this.$overviewText = $('<div id="' + $.htmlId('homePageOverviewText') + '" class="overview"></div>').appendTo(this.getPortletElem());
		workspace.getOverviewText(this.$overviewText);
	},
	
	getBackground: function() {
		return this._getWorkspaceInst().getOverviewColor();
	},
	
	_getWorkspaceInst: function() {
		return infaw.portlet.PortletUtils.instance().getWorkspace(this.getPortletElem());
	}
});
infaw.portlet.AbstractPortlet.extend('infaw.workspaceHome.WSHomeRecentlyOpenedPanel', 
{
	init: function(blockElementId, instanceId) {
		this._super(blockElementId, instanceId);		
		this.$portlet = this.getPortletElem();
		this._workspaceInst = infaw.portlet.PortletUtils.instance().getWorkspace(this.$portlet);		
		this.$initDef = this.createUI();
	},
	
	createUI : function() {
		this.$recentlyOpened = $('<div id="' + $.htmlId('recentlyOpenedId') + '" class="grid-section"></div>').appendTo(this.getPortletElem());
		var $parentDiv = this._createROpenTable();
		$parentDiv.appendTo(this.$recentlyOpened);		
	},
		
	_createROpenTable : function() {
		var $parentDiv = $('<div class="tablePadding"></div>')
		this.$table = $('<table style="width:100%; border-spacing: 0px">').appendTo($parentDiv);
		return $parentDiv;
	},	
	
	addROpenItem : function(lwObject, workspaceId) {		
		// assume item has id, name, icon, location		
		var currentRows = this.$table.find('tr'),
			imgMgr = infaw.shell.common.ImageManager.instance(),
			$row, 
			$data,
			self = this;
		
		// only want 10 items! if this will push over, remove oldest child
		// TODO ask Victoria what to do!
		if (currentRows.length == 15){
			$(currentRows[currentRows.length-1]).remove();
		}
		
		$row = $('<tr></tr>').prependTo(this.$table);
		$data = $('<td class="wsHomeRow"></td>').appendTo($row);
		
		
		var iconSrc = imgMgr.getObjectImage(lwObject.$$class, lwObject.$mixins, true);
		
		if(iconSrc && /.svg/i.test(iconSrc)) {
			var $svgicon = $('<div class="iconSVG" />').appendTo($data),
				wsColor = infaw.workspace.WorkspaceExtensionManager.instance().getWorkspaceColor(workspaceId);
			
			$svgicon.svg({
				loadURL: iconSrc,
				onLoad: function() {							
					$svgicon.find('path, polygon, rect, circle').css({
						fill: wsColor
					});							
				}
			});	
			
		} else {
			$data.append('<img src="' + iconSrc + '" class="icon">');			
		}
		
		
		
		var label = $.infa.Formats.escapeComprehensive(lwObject.name),
			version = lwObject.$version;
		if(version) {
			label = '<span class="versionIdentifier">V' + version + '</span>' + label;
		}
			
		$data.append('<span tabindex="0" class="label-text">' + label + '</span>'
				+ (lwObject.location ? '<span class="path-text">' + ' / ' + lwObject.location + '</span>' : ''));	
		
		$row.data('lwObject', lwObject);
				
		$row.on('click keydown', function(event){
			
			if (event.type === 'keydown' && event.which !== 13){
				return;
			}
			
			var lwObject = $(event.currentTarget).data('lwObject');
			
			if(lwObject) {
				if(self._workspaceInst.isInstanceExists(lwObject.$$IID)) {
					self._workspaceInst.selectInstance(lwObject.$$IID);	
				} else if(lwObject.$$IID.indexOf('newObject') == -1) {
					$.blockElem();
					if(lwObject.$$IID){
						lwObject.$$IID = self.getOriginalId(lwObject.$$IID);
					}
					$.when(self._workspaceInst.openObject(lwObject)).always(function() {
						$.unblockElem();
					});
				}
			}			
		});
	},
	
	getOriginalId: function(instanceId) {
		if(instanceId) {
			if(instanceId.split) {
				return instanceId.split('INFAv')[0];	
			} else {
				return instanceId;
			}
		}
	},
		
	removeROpenItem : function (instanceId) {
		var currentRows = this.$table.find('tr'), $row, lwObject;
		for (var i = 0; i < currentRows.length; i++){
			$row = $(currentRows[i]);
			lwObject = $row.data('lwObject');
			if (lwObject && lwObject.$$IID == instanceId){
				$row.remove();
			}
		}
	},
	
	updateROpenItemName : function (instanceId, name) {
		var currentRows = this.$table.find('tr'), i, $row, lwObject;
		for (i = 0; i < currentRows.length; i++){
			$row = $(currentRows[i]);
			lwObject = $row.data('lwObject');
			if (lwObject && lwObject.$$IID == instanceId){
				$row.find('.label-text').text(name);
			}
		}
	},
	
	removeAllROpen: function() {
		this.$table.find('tr').remove();
	},
	
	showLoading: function() {
		$.blockElem(this.$portlet.attr('id'));
	},
	
	hideLoading: function() {
		$.unblockElem(this.$portlet.attr('id'));
	}
});
infaw.portlet.AbstractPortlet.extend('infaw.workspaceHome.WSHomeVideosPanel', 
{
	init: function(blockElementId, instanceId) {
		this._super(blockElementId, instanceId);
		this.createUI();
	},
	
	createUI : function(){
		var workspace = this._getWorkspaceInst();
		this.$videos = $('<div id="' + $.htmlId('videosId') + '" class="grid-section video">').appendTo(this.getPortletElem());
		var videos = workspace.getVideos();
		var $table = this._createVideosTable(videos);
		$table.appendTo(this.$videos);
	},

	_createVideosTable : function(videos) {
		var $table = $('<table style="width:100%; border-collapse:collapse">'), i;
		for (i=0; i < videos.length; i++){
			this._createVideoRow($table, videos[i]);
		}
		return $table;
	},
	
	_createVideoRow : function($table, video){
		var $row = $('<tr class="wsHomeRow"></tr>').appendTo($table),
			$dataVideo = $('<td class="screenshot"></td>').appendTo($row);

		// First check if the youtube website is accessible. Just see if we can access http://www.youtube.com/favicon.ico. 
		
		var image = new Image();
		image.onload = function(){    
			
		   $dataVideo.append('<iframe class = "player" src="'+video.videourl+'&wmode=transparent" frameborder="0" allowfullscreen wmode="Opaque"></iframe>');		
			
			// if we can access the youtube website, then see if video or playlist is accessible. Only embedded videos and playlist links are supported
/*			var lastIndex  = video.videourl.lastIndexOf("=");
			var playlistVideoID = "";
			var gDataURL = "";
			var wmode = "&";  //wmode transparent is required for IE Menu to show on top of iframe. & is used to connect playlist and ? is used for videos
			
			if(lastIndex !== -1)
			{	
				playlistVideoID = video.videourl.substring(lastIndex+1);
				gDataURL = 'https://gdata.youtube.com/feeds/api/playlists/'+playlistVideoID+'?v=2&alt=jsonc';
			}
			else
			{
				lastIndex = video.videourl.lastIndexOf("/");
				if(lastIndex !== -1)
				{
					wmode = "?";
					playlistVideoID = video.videourl.substring(lastIndex+1);
					gDataURL = 'https://gdata.youtube.com/feeds/api/videos/'+playlistVideoID+'?v=2&alt=jsonc';
				}
			}
			
			// calling Google Youtube API to see if the video is accessible. 
			
			$.ajax({
				   type: 'GET',
				   crossDomain: true,
				   url: gDataURL,
				   dataType: 'JSONP',
				   success: function(data, textStatus, request){ // video is accessible
					   if(data.data !== undefined && data.data.id !== undefined && data.data.id == playlistVideoID)
						   $dataVideo.append('<iframe class = "player" src="'+video.videourl+wmode+'wmode=transparent" frameborder="0" allowfullscreen wmode="Opaque"></iframe>');
					   else
						   $dataVideo.append('<img src=\'/web.workspaceHome/images/cannotconnectyoutube.png\'>');
				   },
				   error: function (request, textStatus, errorThrown) { // video is not accessible
						$dataVideo.append('<img src=\'/web.workspaceHome/images/cannotconnectyoutube.png\'>');
				   }
			});   */
		};
		image.onerror = function(){ // youtube website is not accessible
			$dataVideo.append('<img src='+$.url('/images/workspaceHome/cannotconnectyoutube.png')+'>');
		};
		image.src = "http://www.youtube.com/favicon.ico";

	},
	
	_createVideoDetailsColumn : function ($row, video){
		var $detailsVideo = $('<td class="text"></td>').appendTo($row),
			today = new Date(), 
			date = today.getDate(), 
			month = today.getMonth()+1,
			year=today.getFullYear(),
			postDate = video.postDate.split('/'),
			age;
		$detailsVideo.append('<div class="title">'+video.title+'</div>');
		$detailsVideo.append('<div class="details">' + 'by ' + video.creator + '</div>');

		if (postDate[2] == year){
			if (postDate[0] == month){
				if (postDate[1] == date){
					age = 'Today';
				} else {
					age = date-postDate[1]+ ' ' + ((date-postDate[1]== 1) ? 'day' :  'days') + ' ago';
				}
			} else {
				age = month-postDate[0] + ' ' + ((month-postDate[0]== 1) ? 'month' :  'months') + ' ago';
			}
		} else {
			age = year-postDate[2] + ' ' + ((year-postDate[2] == 1) ? 'year' :  'years') + ' ago';
		}
//		$detailsVideo.append('<div class="details">' + age + ' | ' + video.views + ' views </div>');
		$detailsVideo.append('<div class="details">' + age + ' </div>');
		$detailsVideo.append('<div class="description">'+ video.description + '</div>')
	},
	
	_getWorkspaceInst: function() {
		return infaw.portlet.PortletUtils.instance().getWorkspace(this.getPortletElem());
	}
});
infaw.portlet.AbstractPortlet.extend('infaw.workspaceHome.HelpPanel', 
{
	init: function(blockElementId, instanceId, config) {
		this._super(blockElementId, instanceId, config);
				
//		var $elem = $('#' + blockElementId),
		var $elem = $('<div style="margin-top: 10px; margin-left: 15px"></div>').appendTo($('#' + blockElementId)),
		$text = $('<div></div>');
		
		/*now have to append the text to the parent, which is elem) */
		
		$text.appendTo($elem);
		

		this.getDescription($text) ;
		
		var $newTable = $('<div></div>');
		

		var $table = $newTable.newAssetsTable({
			separator: false,
			workspaceId: this.getCorrespondingWSId()
		});
		
		$newTable.appendTo($elem); 
		
		$table.addClass('helpTable');
		
		$elem.addClass('helpContent');
	},

	getDescription : function($elem){

	}, 
	
	getCorrespondingWSId : function(){
		
	},
	


}); 