$.Class("infa.imf.IClassInfo",
//Singleton...		
{  
  _instance : undefined,
  
  instance : function(){
	  var iclassInfo = infa.imf.IClassInfo;
	  if (iclassInfo._instance != undefined)
		  return iclassInfo._instance;
	  iclassInfo._instance = new infa.imf.IClassInfo();	  
	  return iclassInfo._instance;
  }
},		
{
  id_iclassMap : null ,
  name_iclassMap : null ,
  
  isInited: function(){
	  return this.name_iclassMap != null;
  },
  
  init: function(){
	  var that = this;
	  if(!this.$intializedDef) {
		  this.$intializedDef = $.blockGetJSON('/w3.imf/iclass/?' + infa.utils.Utils.instance().getTokenParam()).pipe( 
					function(iClasses){
			  			//Fixing
						that.id_iclassMap = iClasses;
						that.fixInheritance();	
						return iClasses;
					}
				);	  
	  }	  
	  return this.$intializedDef;	  
  },
  
  /**
   * Passing immediate returns the classinfo and not a deferred
   * metaClassId - single metaClassId or array of metaClassId
   * 
   * Eg: infa.imf.IClassInfo.instance().iClassById(12);   => return iClassInfo	
   *     infa.imf.IClassInfo.instance().iClassById([12, 5, 19]);  => returns array of iClassInfo
   */
  iClassById : function(metaClassId, immediate){	  
	  var that = this;
	  if (!this.isInited()){	  
		  return this.init().pipe(function(){	
			  if($.isArray(metaClassId)) {
				  var iClassArr =[];
				  $.each(metaClassId, function(i, id){
					  iClassArr.push(that.id_iclassMap[id])
				  });
				  return iClassArr;
			  } else {
				  return metaClassId != 0? that.id_iclassMap[metaClassId]:null; 
			  }	
		  });
	  }else{		  		  		  
		  var classInfo;
		  if($.isArray(metaClassId)) {
			  classInfo =[];
			  $.each(metaClassId, function(i, id){
				  classInfo.push(that.id_iclassMap[id])
			  });			  
		  } else {
			  classInfo = this.id_iclassMap[metaClassId];			  
		  }		  
		  return immediate?classInfo:$.Deferred().resolve(classInfo).promise();
	  }	  	  
  },
  
  fetchMoreInfo : function(metaClassIds){	  
	  var requiresFetch = false;
	  for (var i = 0; i < metaClassIds.length; i++){
		  var classInfo = this.id_iclassMap[metaClassIds[i]];
		  if (!('redefines' in classInfo) && !('mixin' in classInfo)){
			  requiresFetch = true;
		  }
		  else
			  metaClassIds[i] = 0;
	  }
	  
	  if (!requiresFetch)
		  return $.Deferred().resolve().promise();	  
	  else{ //We need to reverse fetch
		  var query = null;
		  for (var i = 0; i < metaClassIds.length; i++){
			  if (metaClassIds[i] == 0)
				  continue;
			  if (query == null)
				  query = metaClassIds[i].toString();
			  else
				  query += '.' + metaClassIds[i].toString();
		  }
		  var that = this; //closure ok..
		  return $.blockGetJSON('/w3.imf/iclass/' + query + '?' + infa.utils.Utils.instance().getTokenParam() + '&recurse=true').pipe( 
				function(classInfos){
		  			$.each(classInfos, function(metaClassId, fetchClassInfo){
		  				if (!(metaClassId in that.id_iclassMap))
		  					return;
		  				var saveClassInfo = that.id_iclassMap[metaClassId];
		  				if ('redefines' in saveClassInfo)
		  					return;
		  				
		  				saveClassInfo.redefines = fetchClassInfo.redefines; //copy things over
		  				delete fetchClassInfo.redefines; //hopefully no closures here
		  			});		  			
				}
			);
	  }
  },
  

  /**
   * Passing immediate returns the classinfo and not a deferred
   * metaClassId - single metaClassName or array of metaClassName
   * 
   * Eg: infa.imf.IClassInfo.instance().iClassByName('com.informatica.metadata.common.humantask.HumanTask');  
   * 		=> returns iClassInfo
   *     infa.imf.IClassInfo.instance().iClassByName(['com.informatica.metadata.common.humantask.HumanTask', 'com.informatica.metadata.design.humantask.UserCharacteristic']); 
   *     	=> returns array of iClassInfo 
   */
  iClassByName : function(metaClassName, immediate){
	  var that = this;
	  if (this.name_iclassMap == null){
		  return this.init().pipe(function(){			  
			  if($.isArray(metaClassName)) {
				  var iClassArr =[];
				  $.each(metaClassName, function(i, className){
					  iClassArr.push(that.name_iclassMap[className])
				  });
				  return iClassArr;
			  } else {
				  return that.name_iclassMap[metaClassName];  
			  }			  
		  });
	  }
	  else{
		  var classInfo;
		  if($.isArray(metaClassName)) {
			  classInfo =[];
			  $.each(metaClassName, function(i, className){
				  classInfo.push(that.name_iclassMap[className])
			  });			 
		  } else {
			  classInfo = this.name_iclassMap[metaClassName];  
		  }		  
		  return immediate?classInfo:$.Deferred().resolve(classInfo).promise();		  		  
	  }
  },
  
  fixInheritance: function(){	  
	  this.name_iclassMap = {};
	  var that = this;
	  $.each(this.id_iclassMap, function(metaClassId, metaClassInfo){
		  if (metaClassInfo.superClass != 0)//Id to object!
			  metaClassInfo.superClass = that.id_iclassMap[metaClassInfo.superClass];
		  else
			  metaClassInfo.superClass = null;
		  that.name_iclassMap[metaClassInfo.name] = metaClassInfo;
	  });
  },
  
  // Checks if parentMetaClassName is a superclass of metaClassId.
  isSelfOrSuperClass: function(metaClassId, parentMetaClassName) {
	  var instance = infa.imf.IClassInfo.instance();
	  var $master = $.Deferred();
	  var $deferred1 = instance.iClassByName(parentMetaClassName);
	  $deferred1.done(function(baseClassInfo) {
		  var baseClassId = baseClassInfo.id;
		  var $deferred2 = instance.iClassById(metaClassId);
		  $deferred2.done(function(classInfo) {
			  var info = classInfo;
			  var result = false;
			  while (info) {
				  if (info.id == baseClassId) {
					  result = true;
					  break;
				  }
				  info = info.superClass;
			  }
			  $master.resolve(result);
		  });
	  });
	  return $master.promise();
  }
  
});
$.Class("infa.imf.Deserializer",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var deserializer = infa.imf.Deserializer;
	  if (deserializer._instance != undefined)
		  return deserializer._instance;
	  deserializer._instance = new infa.imf.Deserializer();	  
	  return deserializer._instance;
  }
},
{ 
  deserializeObject : function(object){
		var objects = [object];
		var marker = {};
		objects[1] = marker;
		if ('$$dependencies' in object){
			marker.$$dependencies = object.$$dependencies;
			delete object.$$dependencies;
		}
		
		if ('$$classInfo' in object){
			marker.$$classInfo = object.$$classInfo;
			delete object.$$classInfo;
		}
		this.deserializeObjects(objects);
   },
  //Should be able to deserialize multifaceted objects.
  //Either identity driven or object id driven or internal id driven
  //Done by testing the type of id used...Remember no id means internal id with
  //no reason to id
  deserializeObjects : function(objects){ 	 
	  var info = objects.splice(objects.length - 1, 1);
	  if ('$$dependencies' in info[0]){
			objects = objects.concat(info[0].$$dependencies);//get the depends
	  }
	  
	  //sense what type we are talking about
	  //We need to grab the identifiable objects and second class objects
	  var autoDetect = objects[0];
	  var idType = 3;
	  if ('$$IID' in autoDetect)
		  idType = 1;
	  else if ('$$OID' in autoDetect)
		  idType = 2;
	  else if ('$$ID' in autoDetect)
		  idType = 3;	  
	  
	  var idMap = {};
	  var IDMap = {};
	  for (var i = 0; i < objects.length; i++)
		  this.hash(objects[i], IDMap, idMap, idType); //No parent for these guys...	  
	  
	  for (var i = 0; i < objects.length; i++)
		  this.resolve(objects[i], idMap, IDMap, idType); //No parent for these guys...	  
	   	  
  },
  
  hash: function(object, IDMap, idMap, idType, fcParent){
	  var that = this; //closure
	  
	  var fcContainer;
	  
	  var iclassInfo = infa.imf.IClassInfo.instance();
	  
	  if (idType == 1 && '$$IID' in object)
		  IDMap[object.$$IID] = object;		  		  		  
	  else if (idType == 2 && '$$OID' in object)
		  IDMap[object.$$OID] = object;
	  else if (idType == 3 && '$$ID' in object){
		  IDMap[object.$$ID] = object;
		  delete object.$$ID;
	  }	  
	  else if ('$$id' in object){
		  idMap[object.$$id] = object;
		  delete object.$$id;
	  }
	  
	  var iclass = ('$$class' in object)?iclassInfo.iClassById(object.$$class, true):undefined;
	  //Assuming we have iclass
	  if (iclass && fcParent && iclass.referencible)
		  object.$$fcParent = fcParent;
	  
	  if (iclass && iclass.firstClass)
		  fcContainer = object; //New FC container...	  
	  
	  $.each(object, function(property, value){	
		  if (typeof property === "string"){
			  var subs = property.substring(0, 2);
			  if (subs == '$$' || subs == '##')
				  return;
		  }
		 
		  if (typeof value === 'object')
			  that.hash(value, IDMap, idMap, idType, fcContainer?fcContainer:fcParent);
	  });
  },
  
  resolve: function(object, idMap, IDMap, idType){
	  var that = this; //closure...we should try to convert to function call version (function(that){})(this)	  	 	  	  
		  
	  $.each(object, function(property, value){	
		  if (typeof property === "string"){
			  var subs = property.substring(0, 2);
			  if ((subs == '$$' || subs == '##') && property != "$$aggParent" && property != "$$param")
				  return;
		  }
		  
		  if (typeof value == 'object'){
			  
			  if ('##id' in value){
				  var scId = value['##id'];
				  if (scId in idMap)
					  object[property] = idMap[scId];
				  else{
					  if ($.isArray(object))
						  object.slice(property, property + 1);
					  else
						  delete object[property]; //blow this guy. Does not belong here...Problem with array is we got to remove which should work with index
				  }
			  }//END internal object
			  
			  var id;
			  if (idType == 1 && '##IID' in value)
				  id = value['##IID'];				 			  
			  else if (idType == 2 && '##OID' in value)
				  id = value['##OID'];				  			  
			  else if (idType == 3 && '##ID' in value)
				  id = value['##ID'];				  
			  			  
			  if (id){ //Are we talking about something here...
				  if (id in IDMap)
					  object[property] = IDMap[id];
				  else{
					  if ($.isArray(object))
						  object.slice(property, property + 1);
					  else
						  delete object[property]; //blow this guy. Does not belong here...Problem with array is we got to remove which should work with index
				  }
			  }//END if this is ID property...
			  else {
				  if ($.isArray(value))
					  that.resolve(value, idMap, IDMap, idType);				  
				  else if (typeof property === "string") {
					  if((property.charAt(0) != '_' && property.charAt(0) != '$') 
							  || '##id' in value)
						  that.resolve(value, idMap, IDMap, idType);
				  } else 
					  that.resolve(value, idMap, IDMap, idType);
			  }		  			  
				  
		  }//END if this is a object...
	  });
  },
  
  //Prepares the fetched object with IDs if not available
  prepare : function(object, counter){
	  //Unfortunately no way to deal with second class internal references?	  
	  var that = this;
	  $.each(object, function(property, value){	
		  if (value == null)
			  return;
		  
		  if (property == '$$fcParent')
			  return; //don't loop..
		  
		  if (property == '$$param' || (property.charAt(0) == '$' && property.charAt(1) != '$')){
			  if ($.isArray(value)){
				  for (var index = 0; index < value.length; index++){	
					  var innerValue = value[index];
					  if ('##SID' in innerValue) //We don't care about the top level objects
						  continue;
					  if (typeof innerValue == 'object' && (!'$$IID' in innerValue && !'$$OID' in innerValue)){
						  innerValue.$$ID = counter.id++;
					  }	
				  }
			  }
			  else if (typeof value == 'object' && (!'$$IID' in value && !'$$OID' in value)){
				  if ('##SID' in value) //We don't care about the top level objects
					  return;
				  value.$$ID = counter.id++;
			  }			  
		  }//END if this is external reference..reference...
		  else if (property.charAt(0) == '_'){
			  if ($.isArray(value)){
				  for (var index = 0; index < value.length; index++){	
					  var innerValue = value[index];
					  if (typeof innerValue == 'object'){
						  innerValue.$$id = counter.id++;
					  }
				  }
			  }
			  else if (typeof value == 'object'){
				  value.$$id = counter.id++;
			  }				  
		  }//END if this is internal reference 	
		  else if ($.isArray(value)){
			  for (var index = 0; index < value.length; index++){	
				  var innerValue = value[index];
				  if (typeof innerValue == 'object'){
					  that.prepare(innerValue, counter);
				  }			 
			  }
		  }
		  else if (typeof value == 'object'){
			  that.prepare(value, counter);
		  }
	  });
  },
  
  refreshObject: function(object, originalObject, needsDeserialization){
	  if(needsDeserialization !== false)
		  this.deserializeObject(object);
	  var IDMap = {};
	  var idMap = {};
	  var counter = {id : 1};
	  var topLevelObjects = [originalObject]; //add the original as the first one...							
	  this.prepare(object, counter);
	  this.record(originalObject, topLevelObjects, IDMap);
	
	  topLevelObjects = [object]; //add the fetched as the first one...
	  this.merge(object, originalObject, originalObject, object, topLevelObjects, IDMap, idMap);
  },
  
  //All contained Objects with identities are recorded. Top level references are recursively walked...
  record : function(originalObject, topLevelObjects, IDMap){
	  if ("$$OID" in originalObject)
		  IDMap[originalObject.$$OID] = originalObject;
	  else if ("$$IID" in originalObject)
		  IDMap[originalObject.$$IID] = originalObject;
	  
	  //Unfortunately no way to deal with second class internal references?	  
	  var that = this;
	  $.each(originalObject, function(property, value){	
		  if (value == null)
			  return;
		  
		  if (property == '$$fcParent')
			  return; //don't loop..
		  
		  if ((property.charAt(0) == '$' && property.charAt(1) != '$') || property == '$$param'){	
			  if ($.isArray(value)){
				  for (var index = 0; index < value.length; index++){	
					  var innerValue = value[index];
					  if (typeof innerValue == 'object'){
						  var topLevelObject = that.topLevelObject(innerValue);
						  if ($.inArray(topLevelObject, topLevelObjects) < 0){ //keep recursing...
							  topLevelObjects.push(topLevelObject);
							  that.record(topLevelObject, topLevelObjects, IDMap);
						  }						  
					  }
				  }
			  }//END dealing with arrays
			  else{
				  var topLevelObject = that.topLevelObject(value);
				  if ($.inArray(topLevelObject, topLevelObjects) < 0){ //keep recursing...
					  topLevelObjects.push(topLevelObject);
					  that.record(topLevelObject, topLevelObjects, IDMap);
				  }
			  }
		  }//END if this is external reference..reference...
		  else if (property.charAt(0) == '_'){			  
		  }//END if this is internal reference 	
		  else if ($.isArray(value)){
			  for (var index = 0; index < value.length; index++){	
				  var innerValue = value[index];
				  if (typeof innerValue == 'object'){
					  that.record(innerValue, topLevelObjects, IDMap);
				  }			 
			  }
		  }
		  else if (typeof value == 'object'){
			  that.record(value, topLevelObjects, IDMap);
		  }
	  });
  },
  
  topLevelObject: function(object){
	  var topLevel = object;
	  while ('$$fcParent' in topLevel){
		  topLevel = topLevel['$$fcParent'];		  
	  }
	  
	  return topLevel;
  },
  
  //Merges the fetched object onto to the originalObject given the fetched toplevelobject and original's parent
  merge : function(object, originalObject, fcOriginalParent, topLevelObject, topLevelObjects, IDMap, idMap){
	  var that = this;
	  //We delete all properties in originalObject not in object and introduce new properties likewise...
	  $.each(object, function(property, value){		
		  var iclassInfo = infa.imf.IClassInfo.instance();
		  var fcContainer = null;
		  
		  if (property == '$$fcParent')
			  return; //don't loop..
		  if ($.isArray(value)){
			  var originalValue = undefined;
			  var originalCopy = undefined;
			  if (!(property in originalObject)){
				  originalValue = [];
				  originalObject[property] = originalValue;
			  }
			  else{
				  originalValue = originalObject[property];
				  originalCopy = originalValue.slice(); //Copy the array...
				  originalValue.length = 0; //we will be filling this up soon...
			  }
			  
			  for (var index = 0; index < value.length; index++){	
				  var innerValue = value[index];
				  if (typeof innerValue != 'object') {
					  originalValue[index] = innerValue;
					  continue; 
				  }
				  
				  var iclass = ('$$class' in innerValue)?iclassInfo.iClassById(innerValue.$$class, true):undefined;
				  		
				  //blindly reference that guy?
				  var dependency = (iclass && iclass.referencible && !iclass.seeded && that.topLevelObject(innerValue) !== topLevelObject);				  
				  //Assuming we have iclass				  
				  if (dependency){ //We have to do this for the top level object and prepare him or her
					  //Test if we need to test the dependency matrix
					  var thatTopLevelObj = that.topLevelObject(innerValue);
					  if ($.inArray(thatTopLevelObj, topLevelObjects) < 0){
						  topLevelObjects.push(thatTopLevelObj);
						  var origTopLevelObj = undefined;
						  if ("$$OID" in thatTopLevelObj){
							  if (thatTopLevelObj.$$OID in IDMap)
								 origTopLevelObj = IDMap[thatTopLevelObj.$$OID];	
							  else{
								  origTopLevelObj = {$$OID: thatTopLevelObj.$$OID};								  
								  IDMap[thatTopLevelObj.$$OID] = origTopLevelObj;
							  }
						  }
						  else if ("$$IID" in thatTopLevelObj){
							  if (thatTopLevelObj.$$IID in IDMap)
								 origTopLevelObj = IDMap[thatTopLevelObj.$$IID];
							  else{
								  origTopLevelObj = {$$IID: thatTopLevelObj.$$IID};	
								  IDMap[thatTopLevelObj.$$IID] = origTopLevelObj;
							  }
						  }
						  						  
						  that.merge(thatTopLevelObj, origTopLevelObj, origTopLevelObj, thatTopLevelObj, topLevelObjects, IDMap, idMap);						  
					  }					  
				  }//END handle the dependency so that copying can happen there...
				  
				  //We still need to set the property if it is a dependency...Only thing if it is a dependency and id not found, we just start pointing
				  //to the same object. Remember we don't recurse any further there on...
				  if ("$$OID" in innerValue){
					  if (innerValue.$$OID in IDMap)
						  originalValue[index] = IDMap[innerValue.$$OID];
					  else if (!dependency){
						  var newObj = {$$OID: innerValue.$$OID};
						  originalValue[index] = newObj;
						  IDMap[innerValue.$$OID] = newObj;
					  }
					  else{
						  originalValue[index] = innerValue;
						  continue;
					  }
				  }
				  else if ("$$IID" in innerValue){
					  if (innerValue.$$IID in IDMap)
						  originalValue[index] = IDMap[innerValue.$$IID];
					  else{
						  var newObj = {$$IID: innerValue.$$IID};
						  originalValue[index] = newObj;
						  IDMap[innerValue.$$IID] = newObj;
					  }
				  }
				  else if ("$$id" in innerValue){
					  if (innerValue.$$id in idMap)
						  originalValue[index] = idMap[innerValue.$$id];
					  else{
						  var newObj = {};
						  originalValue[index] = newObj;
						  idMap[innerValue.$$id] = newObj;
					  }
				  }
				  else{
					  //Lets try to reuse value objects if we can...They have to agree in class type to do this. If both original and fetched have same class(or no class)
					  //we will reuse the object...there is possibility with no index and it would be undefined?
					  var originalClass = (originalCopy && index in originalCopy && '$$class' in originalCopy[index])?originalCopy[index].$$class:undefined;
					  var innerClass = ('$$class' in innerValue)?innerValue.$$class:undefined;
					  var newObj = (originalClass === innerClass && originalCopy && index in originalCopy)?originalCopy[index]:{}; //use the one we have backed up!!!					  
					  originalValue[index] = newObj;
				  }
				  
				  if (dependency) ///The buck stops here...
					  continue;
				  		
				  var currentValue = originalValue[index];
				  if (iclass && fcOriginalParent && iclass.referencible)
					  currentValue.$$fcParent = fcOriginalParent;	  				  
				  
				  if (!(property.charAt(0) == '$' && property.charAt(1) != '$' && !iclass.seeded) && !(property.charAt(0) == '_'))				  
					  that.merge(innerValue, originalValue[index], (iclass && iclass.firstClass)?currentValue:fcOriginalParent, topLevelObject, topLevelObjects, IDMap, idMap);
				  
			  }//END iterating...
		  }//END if this is array reference...
		  else if (typeof value == 'object'){
			  var iclass = ('$$class' in value)?iclassInfo.iClassById(value.$$class, true):undefined;
			  
			//blindly reference that guy?
			  var dependency = (iclass && iclass.referencible && !iclass.seeded && that.topLevelObject(value) !== topLevelObject);				  
			  //Assuming we have iclass				  
			  if (dependency){ //We have to do this for the top level object and prepare him or her
				  //Test if we need to test the dependency matrix
				  var thatTopLevelObj = that.topLevelObject(value);
				  if ($.inArray(thatTopLevelObj, topLevelObjects) < 0){
					  topLevelObjects.push(thatTopLevelObj);
					  var origTopLevelObj = {};
					  if ("$$OID" in thatTopLevelObj){
						  if (thatTopLevelObj.$$OID in IDMap)
							 origTopLevelObj = IDMap[thatTopLevelObj.$$OID];	
						  else{
							  origTopLevelObj = {$$OID: thatTopLevelObj.$$OID};								  
							  IDMap[thatTopLevelObj.$$OID] = origTopLevelObj;
						  }
					  }
					  else if ("$$IID" in thatTopLevelObj){
						  if (thatTopLevelObj.$$IID in IDMap)
							 origTopLevelObj = IDMap[thatTopLevelObj.$$IID];
						  else{
							  origTopLevelObj = {$$IID: thatTopLevelObj.$$IID};	
							  IDMap[thatTopLevelObj.$$IID] = origTopLevelObj;
						  }
					  }
					  						  
					  that.merge(thatTopLevelObj, origTopLevelObj, origTopLevelObj, thatTopLevelObj, topLevelObjects, IDMap, idMap);
				  }
			  }//END handle the dependency so that copying can happen there...
			  
			  if ("$$OID" in value){
				  if (value.$$OID in IDMap)
					  originalObject[property] = IDMap[value.$$OID];
				  else if (!dependency){
					  var newObj = {$$OID: value.$$OID};
					  originalObject[property] = newObj;
					  IDMap[value.$$OID] = newObj;
				  }
				  else{
					  originalObject[property] = value;
					  return;
				  }
			  }
			  else if ("$$IID" in value){
				  if (value.$$IID in IDMap)
					  originalObject[property] = IDMap[value.$$IID];
				  else if (!dependency){
					  var newObj = {$$IID: value.$$IID};
					  originalObject[property] = newObj;
					  IDMap[value.$$IID] = newObj;
				  }
				  else{
					  originalObject[property] = value; //reuse....
					  return;
				  }
			  }
			  else if ("$$id" in value){
				  if (value.$$id in idMap)
					  originalObject[property] = idMap[value.$$id];
				  else{
					  var newObj = {};
					  originalObject[property] = newObj;
					  idMap[value.$$id] = newObj;
				  }
			  }
			  else{
				  //vanilla object...we deal it with this...
				  var originalClass = originalValue && ('$$class' in originalValue)?originalValue.$$class:undefined;
				  var innerClass = ('$$class' in value)?value.$$class:undefined;
				  if (originalClass !== innerClass || !(property in originalObject) ) //both are unequal or property itself does not exist create new one				  				  		  
					  originalObject[property] = {};			  	
			  }
			  
			  if (dependency) //As long as we are done assigning the property we have no more business to conduct here
				  return;
			  
			  var currentValue = originalObject[property];
			  if (iclass && fcOriginalParent && iclass.referencible)
				  currentValue.$$fcParent = fcOriginalParent;	
			  
			  if (!(property.charAt(0) == '$' && property.charAt(1) != '$' && iclass && !iclass.seeded) && (property.charAt(0) != '_') && property != '$$param')				  
				  that.merge(value, currentValue, (iclass && iclass.firstClass)?currentValue:fcOriginalParent, topLevelObject, topLevelObjects, IDMap, idMap);			  
		  
		  }//END if object....		  
		  else{
			  originalObject[property] = value; //just copy over..period...
		  }//END Vanilla property here...			  
	  });	  
	  
	  //At the end of this exercise..find all properties in the original that do not exist in the object and blow them..
	  $.each(originalObject, function(property, originalValue){		
		  if (!(property in object)){
			  //We need to mark the object in question as deleted if that happens...As make sure it does not exist in the IDMap
			  var value = originalObject[property];
			  if ($.isArray(value)){
				  for (var index = 0; index < value.length; index++){	
					  var innerValue = value[index];
					  if (typeof innerValue != 'object')
						 continue;
					  value.$$deleted = true;
				  }			  
			  }else if (typeof value == 'object')
				  value.$$deleted = true;
			  
			  delete originalObject[property]; //detach yourself from here now...
		  }
	  });
  }
}
);
$.Class("infa.imf.Serializer",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var objSaver = infa.imf.Serializer;
	  if (objSaver._instance != undefined)
		  return objSaver._instance;
	  objSaver._instance = new infa.imf.Serializer();	  
	  return objSaver._instance;
  }
},
{   
	/*
	 * A subsetter is function that returns 3 values.
	 * 1. false(ignore), 
	 * 2. undefined (no opinion - system can remove as deem necessary. only applicable for objects/arrays)
	 * 3. true(include)
	 * 
	 * Flags that are stored
	 */
  serializeObject : function(object, idType, dependencies, subsetter){	  
	  var serializedObjs = this.serializeObjectsInternal([object], idType, dependencies, subsetter);
	  if ('$$dependencies' in serializedObjs[1]){
		  serializedObjs[0].$$dependencies = serializedObjs[1].$$dependencies;
		  delete serializedObjs[1].$$dependencies;
	  }
	  return $.toJSON(serializedObjs[0]);
  },
  
  serializeObjects : function(objects, idType, serializeDependencies, subsetter){
	  var serialized = this.serializeObjectsInternal(objects, idType, serializeDependencies, subsetter);
	  serialized.splice((serialized.length-1), 1);
	  return $.toJSON(serialized);
  },
  
  serializeObjectsInternal : function(objects, idType, serializeDependencies, subsetter){
	  var infoObject = {};	  
	  
	  //We have to mark the object...record the objects so that they can be unmarked later...
	  //Remember we only need to mark the objects that are being referred not all objects...
	  //Also applies to sc internal. Look for all $ and _ references and if they show up id such objects
	  //You may not even need to id their parents...We still need to do this for SECOND CLASS INTERNAL(idform-1 & 2)
	  
	  var counter = {id: 1};
	  for (var i = 0; i < objects.length; i++){		  
		  objects[i].$$visited = true; //first start with this...we don't want to get through a dependency and repeat it...
	  }
	  for (var i = 0; i < objects.length; i++){				 
		  this.mark(objects[i], counter, idType);
	  }
	  
	  
	  for (var i = 0; i < objects.length; i++){		  
		  objects[i].$$copied = true; //first start with this...we don't want to get through a dependency and repeat it...
	  }
	  
	  var returnObjects = [];
	  for (var i = 0 ; i < objects.length; i++){
		  var newObject = {};
		  this.copy(objects[i], objects[i], newObject, idType, serializeDependencies, infoObject, subsetter);
		  returnObjects.push(newObject);
	  }
	  
	  for (var i = 0 ; i < returnObjects.length; i++){		  
		  this.cleanse(returnObjects[i]);		  
	  }
	  
	  if ('$$dependencies' in infoObject){
		  for (var i = 0 ; i < infoObject.$$dependencies.length; i++){		  
			  this.cleanse(infoObject.$$dependencies[i]);		  
		  }
	  }
	  
	  		  
	  for (var i = 0; i < objects.length; i++){	
		  delete objects[i].$$visited;
		  delete objects[i].$$copied;		  
		  this.unmark(objects[i]);
	  }	  
	  
	  returnObjects.push(infoObject);
	  return returnObjects;
  },
  
  mark: function(object, counter, idType){
	  var that = this;
	  $.each(object, function(property, value){
		  var isParamProperty = (property == '$$param');
		  
		  if (!isParamProperty && (property.substring(0,2) == "$$" || property.substring(0,2) == "##"))
			  return; //don't loop...
		  if (value == null)
			  return;
		  else if (isParamProperty || (property.charAt(0) == '$' && property.charAt(1) != '$')){ //Replace this guy by a new object..Some can be seeded and others not..			  			  
			  if ($.isArray(value)){				  
				  for (var index = 0; index < value.length; index++){					  
					  var innerValue = value[index];
 					  //Be more permissive to assign manufactured ones to missing entries
					  if ((idType == 1  && '$$IID' in innerValue) || (idType == 2 && '$$OID' in innerValue))
						  continue;
					  
					  if ('##SID' in innerValue)
					  	continue;
					   //We don't care about the top level objects
					  var otherTopObject = that.topLevelObject(innerValue);
					  if (otherTopObject != null && !('$$visited' in otherTopObject)){ //put a visited flag against top level objects
						  otherTopObject.$$visited = true;
						  that.mark(otherTopObject, counter);
					  }
					  
					  if ('$$ID' in innerValue)
						  continue;
					  innerValue.$$ID = counter.id++; 
				  }				  
			  }//END is array
			  else{
				  if ('##SID' in value) //We don't care about the top level objects
					  return;
				  
				  if ((idType == 1  && '$$IID' in value) || (idType == 2 && '$$OID' in value))
					  return;
				  
				  var otherTopObject = that.topLevelObject(value);
				  if (otherTopObject != null && !('$$visited' in otherTopObject)){ //put a visited flag against top level objects
					  otherTopObject.$$visited = true;
					  that.mark(otherTopObject, counter);				  
				  }
				  if ('$$ID' in value)
					  return;
				  value.$$ID = counter.id++;
			  }//END not an array		  
		  }//END if this is external reference
		  else if (property.charAt(0) == '_'){
			  if ($.isArray(value)){				  
				  for (var index = 0; index < value.length; index++){					  
					  var innerValue = value[index];
					  if ('$$id' in innerValue)
						  continue;
					  innerValue.$$id = counter.id++; 
				  }
			  }//END if array
			  else{
				  if ('$$id' in value)
					  return;
				  value.$$id = counter.id++;
			  }//END if not arary
		  }//END if this is internal reference
		  else if ($.isArray(value)){			 
			 for (var index = 0; index < value.length; index++){					  
				var innerValue = value[index];								
				if (typeof innerValue == 'object'){
					innerValue.$$container = [object, property]; //add the back reference
					that.mark(innerValue, counter, idType);
				}
			 }
		  }//END iterate and recurse
		  else if (typeof value == 'object'){
			  value.$$container = [object, property]; //add the back reference
			  that.mark(value, counter, idType);			  
		  }//END iterate and recurse for vanilla creme
	  });//END walk all the properties
  },
  
  unmark: function(object, idType){
	  var that = this;
	  $.each(object, function(property, value){
		  var isParamProperty = (property == '$$param');
		  
		  if (!isParamProperty && (property.substring(0,2) == "$$" || property.substring(0,2) == "##"))
			  return; //don't loop...
		  if (value == null)
			  return;
		  else if (isParamProperty || (property.charAt(0) == '$' && property.charAt(1) != '$')){ //Replace this guy by a new object..Some can be seeded and others not..
			  
			  if ($.isArray(value)){				  
				  for (var index = 0; index < value.length; index++){					  
					  var innerValue = value[index];
					//Be more permissive to assign manufactured ones to missing entries
					  if ((idType == 1  && '$$IID' in innerValue) || (idType == 2 && '$$OID' in innerValue))
						  continue;
					  
					  if ('##SID' in innerValue)
						  continue;
					  //We don't care about the top level objects
					  var otherTopObject = that.topLevelObject(innerValue);
					  if (otherTopObject != null && ('$$visited' in otherTopObject)){ //put a visited flag against top level objects
						  delete otherTopObject.$$visited;
						  delete otherTopObject.$$copied;
						  if (otherTopObject.$$container)
							  delete otherTopObject.$$container;
						  that.unmark(otherTopObject);					  
					  }
					  
					  if ('$$ID' in innerValue)
						  delete innerValue.$$ID; 
				  }				  
			  }//END if this is array value
			  else{
				  if ('##SID' in value)
				  	return;
				  if ((idType == 1  && '$$IID' in value) || (idType == 2 && '$$OID' in value))
					  return;
				  
				   //We don't care about the top level objects
				  var otherTopObject = that.topLevelObject(value);
				  if (otherTopObject != null && ('$$visited' in otherTopObject)){ //put a visited flag against top level objects
					  delete otherTopObject.$$visited;
					  delete otherTopObject.$$copied;
					  if (otherTopObject.$$container)
						  delete otherTopObject.$$container;
					  that.unmark(otherTopObject);				  
				  }//END if not seeded
				  if ('$$ID' in value)
					  delete value.$$ID;				  
			  }//END if non primitive		  
		  }//END if this is external reference
		  else if (property.charAt(0) == '_'){
			  if ($.isArray(value)){				  
				  for (var index = 0; index < value.length; index++){					  
					  var innerValue = value[index];
					  if ('$$id' in innerValue)						 
						  delete innerValue.$$id; 
				  }
			  }
			  else{
				  if ('$$id' in value)
					  delete value.$$id;
			  }
		  }//END if this is internal reference
		  else if ($.isArray(value)){			 
			 for (var index = 0; index < value.length; index++){					  
				var innerValue = value[index];	
				if (typeof innerValue == 'object'){
					if (innerValue.$$container)
						  delete innerValue.$$container;
					that.unmark(innerValue, idType);	
				}				
			 }
		  }//END iterate and recurse
		  else if (typeof value == 'object'){
			  if (value.$$container)
				  delete value.$$container;
			  that.unmark(value, idType);			  
		  }//END iterate and recurse for vanilla creme
	  });//END walk all the properties
  },
  
  topLevelObject: function(object){
	  var topLevel = object;
	  while ('$$fcParent' in topLevel){
		  topLevel = topLevel['$$fcParent'];		  
	  }
	  
	  return topLevel;
  },
  
  //Look at all the properties in the aggParent(only one level and check if aggregated exists anywhere)
  getAggProperty: function(aggParent, aggregated){
	  var aggInfo = undefined;
	  $.each(aggParent, function(property, value){
		  if (property.charAt(0) == '$')
			  return; //don't loop..contained properties have to be not with a $
		  if (value == null)
			  return;
		  if ($.isArray(value)){			  			 
			  for (var index = 0; index < value.length; index++){	
				  if (value[index] === aggregated){
					  aggInfo = {};
					  aggInfo.$$property = property;
					  aggInfo.$$collection = true;
					  return false;
				  }					  
			  }
		  }
		  else if (value == aggregated){
			  aggInfo = {};
			  aggInfo.$$property = property;
			  aggInfo.$$collection = false;
			  return false;
		  }
	  });//END of for each
	  
	  return aggInfo;
  },
  
  /*
   * Clean the object of spurious object that do not have properties...Unfortunately this works bottom up...You clean the bottommost properties
   * and rollup as you see more empty objects
   */
  cleanse: function(newObject){
	  var that = this;
	  $.each(newObject, function(property, value){
		  if ($.isArray(value)){		
			 var emptyArray = true;
			 for (var index = 0; index < value.length; index++){					  
				var innerValue = value[index];
				if (typeof innerValue == 'object'){
					if ('$$empty' in innerValue)
						newObject[property][index] = {}; //bootstrap this...
					else{
						that.cleanse(innerValue);
						emptyArray = false;
					}
				}	
				else
					emptyArray = false;
			 }
			 if (emptyArray)
				 delete newObject[property];
		  }
		  else if (typeof value == 'object'){
			  if ('$$empty' in value)
				 delete newObject[property];
			  else
				  that.cleanse(value);
		  }
	  });
	  
	  //remove self if marked
	  if ('$$empty' in newObject)
		  delete newObject.$$empty;
  },
  
  copy: function(topLevelObject, object, newObject, idType, serializeDependencies, infoObject, subsetter){
	  var that = this;
	  /**
	   * @param {({$$class, $$ID, $$IID, $$OID}|Array.<{$$class, $$ID, $$IID, $$OID}>)} value 
	   * represents an object with the specified properties, or an array of such objects 
	   */
	  $.each(object, function(property, value){		  
		  if (property == '$$fcParent' || property == '$$visited' || property == '$$copied' || property == '$$container')
			  return; //don't loop..
		  //Remember we need to learn to leave alone things if they are not real objects...!!!
		  //This applies to any kind of reference.. aggregator reference or external references. Someone could have fetched it that way
		  var isAggParentProperty = (property == '$$aggParent'); 
		  var isParamProperty = (property == '$$param');
		  
		  if (value == null)
			  return;
		  //Subset = true means include it.. If subsetter is missing then include it
		  var subsetOption = (subsetter === undefined || (topLevelObject === object && property.charAt(0) == '$' && property.charAt(1) == '$'))?true:subsetter(object, property);
		  if (subsetOption === false)
			  return;
		  if (isAggParentProperty || isParamProperty || (property.charAt(0) == '$' && property.charAt(1) != '$')){ //Replace this guy by a new object..Some can be seeded and others not..
			  if (subsetOption === undefined)
				  return; //no opinion...we don't write things...
			  
			  if ($.isArray(value)){
				  newObject[property] = new Array();				  
				  for (var index = 0; index < value.length; index++){					  
					  var innerValue = value[index];
					  if (serializeDependencies && !('##SID' in innerValue)){ //We don't care about the top level objects
						  var otherTopObject = that.topLevelObject(innerValue);
						  if (otherTopObject != null && !('$$copied' in otherTopObject)){
							  otherTopObject.$$copied = true;
							  var dependentObject = {};
							  that.copy(otherTopObject, otherTopObject, dependentObject, idType, serializeDependencies, infoObject, subsetter);							  
							  if (!('$$dependencies' in infoObject))
								  infoObject['$$dependencies'] = [];
							  infoObject['$$dependencies'].push(dependentObject);							  							  
						  }
					  }
					  					  
					  if (idType == 2 && '$$OID' in innerValue)
						  newObject[property][index] = serializeDependencies?{'##OID' : innerValue.$$OID}:{'##OID' : innerValue.$$OID, '$$class': innerValue.$$class}; //bootstrap this...
					  else if (idType == 1 && '$$IID' in innerValue)
						  newObject[property][index] = serializeDependencies?{'##IID' : innerValue.$$IID}:{'##IID' : innerValue.$$IID, '$$class': innerValue.$$class}; //bootstrap this...
					  else if ('$$ID' in innerValue) //actually we are permissive here..We will use OID/IID if available with the option...else if manufactured just use that
						  newObject[property][index] = serializeDependencies?{'##ID' : innerValue.$$ID}:{'##ID' : innerValue.$$ID, '$$class': innerValue.$$class}; //bootstrap this...
					  else{
						  var copyInner = {};
						  newObject[property][index] = copyInner; //bootstrap this...
						  that.copy(topLevelObject, innerValue, copyInner, idType, serializeDependencies, infoObject, subsetter);
					  }
					  
					  var aggInfo = undefined;						
					  if (isAggParentProperty)
						  aggInfo = that.getAggProperty(object, value);
					  if (aggInfo) //Should ONLY happen with first 3 ifs...you will never find a thing with a proxy reference as aggregator
						  $.extend(newObject[property][index], aggInfo);
				 }
			  }//END if this is a array
			  else {
				  if (serializeDependencies && !('##SID' in value)){ //We don't care about the top level objects
					  var otherTopObject = that.topLevelObject(value);
					  if (otherTopObject != null && !('$$copied' in otherTopObject)){
						  otherTopObject.$$copied = true;
						  var dependentObject = {};
						  that.copy(otherTopObject, otherTopObject, dependentObject, idType, serializeDependencies, infoObject, subsetter);
						  if (!('$$dependencies' in infoObject))
							  infoObject['$$dependencies'] = [];
						  infoObject['$$dependencies'].push(dependentObject);						  						  
					  }
				  }
				  
				  
				  if (idType == 2 && '$$OID' in value)
					  newObject[property] = serializeDependencies?{'##OID' : value.$$OID}:{'##OID' : value.$$OID, '$$class': value.$$class};
				  else if (idType == 1 && '$$IID' in value)
					  newObject[property] = serializeDependencies?{'##IID' : value.$$IID}:{'##IID' : value.$$IID, '$$class': value.$$class};
				  else if ('$$ID' in value)
					  newObject[property] = serializeDependencies?{'##ID' : value.$$ID}:{'##ID' : value.$$ID, '$$class': value.$$class};
				  else{ //for proxies who remain the same...
					  var copyInner = {};
					  newObject[property] = copyInner; //bootstrap this...
					  that.copy(topLevelObject, value, copyInner, idType, serializeDependencies, infoObject, subsetter);
				  }
				  
				  var aggInfo = undefined;						
				  if (isAggParentProperty)
					  aggInfo = that.getAggProperty(object, value);
				  if (aggInfo) //Should ONLY happen with first 3 ifs...you will never find a thing with a proxy reference as aggregator
					  $.extend(newObject[property], aggInfo);
			  }//END if this is singular
		  }//END if this is reference...
		  else if (property.charAt(0) == '_'){
			  if (subsetOption === undefined)
				  return; //no opinion...we don't write things...
			  
			  if ($.isArray(value)){
				  newObject[property] = new Array();
				  $.each(value, function(index, innerValue){
					  newObject[property][index] = {'##id' : value[index].$$id}; //bootstrap this... 
				 });
			  }
			  else 
				  newObject[property] = {'##id' : value.$$id, '$$class': value.$$class};
		  }//END if this is internal reference  
		  else if ($.isArray(value)){
			 newObject[property] = new Array();
			 for (var index = 0; index < value.length; index++){					  
				var innerValue = value[index];
				if (typeof innerValue == 'object'){
					var copyInner = {};
					newObject[property][index] = copyInner; //bootstrap this...
					that.copy(topLevelObject, innerValue, copyInner, idType, serializeDependencies, infoObject, subsetter);					
				} else {
					newObject[property][index] = innerValue;
				}								
			 }
		  }
		  else if (typeof value == 'object'){
			  var copyInner = {};
			  newObject[property] = copyInner;
			  that.copy(topLevelObject, value, copyInner, idType, serializeDependencies, infoObject, subsetter);		  
		  }
		  else
			  newObject[property] = value; //just copy primitive value over...		  		  
	  });	  
	  
	  var emptyChildren = true;
	  for (var property in newObject) {
		  var value = newObject[property];
		  if ($.isArray(value)){ //check each entry to find if empty exists...
			  for (var index = 0; index < value.length; index++){					  
				var innerValue = value[index];
				if (typeof innerValue != 'object' || (typeof innerValue == 'object' && !('$$empty' in innerValue))){
					emptyChildren = false;
					break;
				 }									
			  }
			  if (!emptyChildren)
				  break; //double point break!
		  }
		  else if (typeof value != 'object' || (typeof value == 'object' && !('$$empty' in value))){
			  emptyChildren = false;
			  break;
		  }	  
	  }
	  
	  if (emptyChildren) //rolled up...
		  newObject.$$empty = true;
  }  
}
);
$.Class('infa.imf.SeedManager',
{  
  _instance : undefined,
  
  instance : function(){
	  var seedMgr = infa.imf.SeedManager;
	  if (seedMgr._instance != undefined)
		  return seedMgr._instance;
	  seedMgr._instance = new infa.imf.SeedManager();	  
	  return seedMgr._instance;
  }
},		
{
  
  /**
   * If seed provider names are given, the method returns a map hashed by the seed provider names.
   * If seed identities are given, the method returns an array of seeded objects.
   * 
   * @param seeds a seed provider name, a seed identity, an array of seed provider names, or an 
   * array of seed identities 
   * @param metaClasses a metaClassId, a metaClass name, an array of metaClassIds, or an array of
   * metaClass names
   */
  getSeedObjects: function(seeds, metaClasses) {
	  var path;
	  if ($.isArray(seeds)) { // metaClasses has to be an array too
		  path = seeds[0] + '@' + metaClasses[0];
		  for (var i = 1; i < seeds.length; i++) {
			  path = path + ',' + seeds[i] + '@' + metaClasses[i];
		  }
	  } else {
		  path = seeds + '@' + metaClasses;
	  }
	  return $.blockGetJSON('/w3.imf/seed/' + path + '?' + infa.utils.Utils.instance().getTokenParam()).pipe(function(objects) {
		  return objects;
	  });
  }
  
});
$.Class("infa.model.ObjectGetter",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var objGetter = infa.model.ObjectGetter;
	  if (objGetter._instance != undefined)
		  return objGetter._instance;
	  objGetter._instance = new infa.model.ObjectGetter();	  
	  return objGetter._instance;
  }
},
{
  //Get the reader
  blockObjectGet : function(objId, metaClassId, storage, idForm, dependencies, translateMetaClassId){
	  var that = this;
	  return infa.imf.IClassInfo.instance().iClassById(0).pipe(function(){
		  var query = '/w3.model/object/' + storage + '/' + objId + '@' + metaClassId;
		  
		  if(translateMetaClassId != undefined) {
			  query += '@' + translateMetaClassId;
		  }
		  
		  query += '?' + infa.utils.Utils.instance().getTokenParam();
		  if (idForm != undefined && dependencies != undefined)
			  query = query + '&idForm=' + idForm + '&dependencies=' + dependencies;
		  else if (idForm)
			  query = query + '&idForm=' + idForm;
		  else if (dependencies)
			  query = query + '&dependencies=' + dependencies;
		  
		  return $.getJSON($.url(query)).pipe( 
					function(object){
							that.deserialize(object);
			  				return object;		  				
					}
	  )});	  
  },
  
  blockObjectRefresh : function(originalObject, objId, metaClassId, storage, idForm, dependencies, translateMetaClassId){
	  var that = this;
	  return infa.imf.IClassInfo.instance().iClassById(0).pipe(function(){
		  var query = '/w3.model/object/' + storage + '/' + objId + '@' + metaClassId;
		  
		  if(translateMetaClassId != undefined) {
			  query += '@' + translateMetaClassId;
		  }
		  
		  query += '?' + infa.utils.Utils.instance().getTokenParam();
		  if (idForm != undefined && dependencies != undefined)
			  query = query + '&idForm=' + idForm + '&dependencies=' + dependencies;
		  else if (idForm)
			  query = query + '&idForm=' + idForm;
		  else if (dependencies)
			  query = query + '&dependencies=' + dependencies;
		  
		  return $.getJSON($.url(query)).pipe( 
					function(object){
							that.refresh(object, originalObject);							
			  				return originalObject;		  				
					}
	  )});	  
  },   
  
  deserialize : function(object){	
	  infa.imf.Deserializer.instance().deserializeObject(object);	  	  	  
  },
  
  refresh : function(object, originalObject){	
	  infa.imf.Deserializer.instance().refreshObject(object, originalObject);	  	  	  
  } 
});
$.Class("infa.model.ObjectSaver",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var objSaver = infa.model.ObjectSaver;
	  if (objSaver._instance != undefined)
		  return objSaver._instance;
	  objSaver._instance = new infa.model.ObjectSaver();	  
	  return objSaver._instance;
  }
},
{
	/*
	 * A subsetter is function that returns 3 values.
	 * 1. false(ignore), 
	 * 2. undefined (no opinion - system can remove as deem necessary. only applicable for objects/arrays)
	 * 3. true(include)
	 * 
	 */
  blockObjectSave : function(object, storage, subsetter){
	  return $.blockPostJSON('/w3.model/object/' + storage + '?' + infa.utils.Utils.instance().getTokenParam(), 
			  this.serialize(object, subsetter));
	  
  },
  
  serialize : function(object, subsetter){
	  var isArray = $.isArray(object),
	      obj = isArray ? object[0] : object,
		  idType = 3;
	  if ('$$IID' in obj) {
		  idType = 1;
	  } else if ('$$OID' in obj) {
		  idType = 2;
	  } else if ('$$ID' in obj) {
		  idType = 3;	
	  }
	  return isArray ? infa.imf.Serializer.instance().serializeObjects(object, idType, false, subsetter) :
		  infa.imf.Serializer.instance().serializeObject(object, idType, false, subsetter);	  	  	 
  }
  
});
$.Class("infa.model.ObjectDelete",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var objDelete = infa.model.ObjectDelete;
	  if (objDelete._instance != undefined)
		  return objDelete._instance;
	  objDelete._instance = new infa.model.ObjectDelete();	  
	  return objDelete._instance;
  }
},
{
	

  blockObjectDelete : function(objId, metaClassId, storage){
	  var url = '/w3.model/object/' + storage + '/';
	  if ($.isArray(objId) && $.isArray(metaClassId)){
		  // multiple objects
		  // make sure arrays are of the same length
		  if (objId.length == metaClassId.length){
			  var tempId, tempMetaClass, i;
			  for (i = 0; i < objId.length; i++){
				  tempId = objId[i];
				  tempMetaClass = metaClassId[i];
				  url = url + tempId + '@' + tempMetaClass + ((i != objId.length-1) ? ',' : '');
			  }
			  return $.blockDeleteJSON(url + '?' + infa.utils.Utils.instance().getTokenParam());
		  }
	  } else {
		  return $.blockDeleteJSON(url + objId + '@' + metaClassId + '?' + infa.utils.Utils.instance().getTokenParam());
	  }
  }, 
  
  
  blockBulkObjectDelete: function(lwObjects, storage) {	  
	  var url = '/w3.model/object/' + storage + '/?' + infa.utils.Utils.instance().getTokenParam();	  
	  var postData = JSON.stringify(lwObjects, function(key, value){		  
		  if(!key || $.isNumeric(key) || key == '$$OID' || key == '$$IID' || key == '' || key == '$$class') {
			  return value;
		  }
		  return undefined;
	  });
	  
	  return $.blockPostJSON(url, postData);
  },
  
  serialize : function(object, subsetter){	 
	  var idType = 3;
	  if ('$$IID' in object) {
		  idType = 1;
	  } else if ('$$OID' in object) {
		  idType = 2;
	  } else if ('$$ID' in object) {
		  idType = 3;	
	  }
	  return infa.imf.Serializer.instance().serializeObject(object, idType, false, subsetter);	  	  	 
  }
 
}
);
$.Class("infa.model.ObjectEditSet",
// static methods 
{  
	_instance : undefined,

	instance : function(){
		var objEdit = infa.model.ObjectEditSet;
		if (objEdit._instance != undefined)
			return objEdit._instance;
		objEdit._instance = new infa.model.ObjectEditSet();	  
		return objEdit._instance;
	}
},
{
	blockEditSetCreate: function(storage, editSet) {
		return $.blockPutJSON('/w3.model/object/' + storage + '/' + editSet + '?' + infa.utils.Utils.instance().getTokenParam(), null, null, -1);
	},
	
	blockEditSetSelected: function(objId, metaClassId, storage, editSet){		
		return $.blockPutJSON('/w3.model/object/' + storage + '/' + editSet + '/selected/' + objId + '@' + metaClassId + '?' + infa.utils.Utils.instance().getTokenParam(), null, null, -1);
	},

	blockEditSetUncommitted: function(object,storage, editSet, idForm){
		var query = '/w3.model/object/' + storage + '/' + editSet + '/uncommitted/?' + infa.utils.Utils.instance().getTokenParam();		
		if(idForm) {
			query = query + '&idForm=' + idForm;
		}		
		return $.blockPostJSON(query, 
				this.serialize(object), null, -1);
	},
	
	blockEditSetSave: function(storage, editSet) {		
		return $.blockPostJSON('/w3.model/object/' + storage + '/' + editSet + '?' + infa.utils.Utils.instance().getTokenParam());	
	},
	
	serialize : function(object){	 
		var idType = 3;
		if ('$$IID' in object) {
			idType = 1;
		} else if ('$$OID' in object) {
			idType = 2;
		} else if ('$$ID' in object) {
			idType = 3;	
		}
		return infa.imf.Serializer.instance().serializeObject(object, idType, false);	  	  	 
	},
	
	blockObjectGet : function(objId, metaClassId, storage, editSet, idForm, dependencies, translateMetaClassId){
		var that = this;
		return infa.imf.IClassInfo.instance().iClassById(0).pipe(function(){
			var query = '/w3.model/object/' + storage + '/' + editSet + '/uncommitted/' + objId + '@' + metaClassId;

			if(translateMetaClassId != undefined) {
				query += '@' + translateMetaClassId;
			}
			 
			query += '?' + infa.utils.Utils.instance().getTokenParam();
			if (idForm != undefined && dependencies != undefined)
				query = query + '&idForm=' + idForm + '&dependencies=' + dependencies;
			else if (idForm)
				query = query + '&idForm=' + idForm;
			else if (dependencies)
				query = query + '&dependencies=' + dependencies;

			return $.getJSON($.url(query)).pipe( 
					function(object){
						that.deserialize(object);
						return object;		  				
					}
			)});	  
	},
	
	blockEditSetDelete: function(storage, editSet) {
		return $.blockDeleteJSON('/w3.model/object/' + storage + '/' + editSet);
	},

	deserialize : function(object){	
		infa.imf.Deserializer.instance().deserializeObject(object);	  	  	  
	}  	

});
$.Class("infa.model.ObjectIdSequencer",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var objIdSequencer = infa.model.ObjectIdSequencer;
	  if (objIdSequencer._instance != undefined)
		  return objIdSequencer._instance;
	  objIdSequencer._instance = new infa.model.ObjectIdSequencer();	  
	  return objIdSequencer._instance;
  }
},
{
  storage_idMap : {} ,	 
	  
  //Get the reader given the storage name.. Returns a deferred...
  //Immediate will return a long or -1 if the range is locked out
  next : function(storage, immediate){	  
	  
	  var range = undefined;
	  var that = this;
	  if (storage in this.storage_idMap){
		  range = this.storage_idMap[storage];
		  if (range[2]){ //If deferred in progress wait for it to complete and recurse yourself
			  return range[2].pipe(function(){
					return that.next(storage, immediate); 
			  });
		  }
		  if (range[0] < range[1]){
			  range[0] = range[0] + 1;
			  if (immediate)
				  return range[0];
			  var $deferred = $.Deferred();
			  $deferred.resolve(range[0]);//thats the new id
			  return $deferred;
		  }
	  }
	  else{
		  range = [-1,-1, undefined];
		  this.storage_idMap[storage] = range;
	  }
	  
	  if (immediate)
		  return -1;	  
	  
	  //Make the call and update the stuff
	  var that = this;
	  var query = '/w3.model/sequence/' + storage + '/1000' + //Get 1000 ids at a time
	  		'?' + infa.utils.Utils.instance().getTokenParam();
		  
	  range[2] =
		  $.getJSON($.url(query)).pipe( 
				function(object){
					range[1] = object.$$OID;// This will be the highest id
					range[0] = range[1] - 1000 + 1;//preincrement...Say 150...This would start at 51
					range[2] = undefined; //reset it. Should not affect too much since deferred will immediately return.
					return range[0];
				});	
	  return range[2];
  }
});
$.Class("infa.model.ObjectUtil",
// static methods 

{  
  _instance : undefined,
  
  instance : function(){
	  var objUtil = infa.model.ObjectUtil;
	  if (objUtil._instance != undefined)
		  return objUtil._instance;
	  objUtil._instance = new infa.model.ObjectUtil();	  
	  return objUtil._instance;
  }
},
{
	_queryResultSets: [],
	/**
	 * Create iterative result set
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		type			: 'browse' | 'query'  (By default 'browse')
	 *		data			: {},	
	 * }
	 * 
	 * @return promise 
	 */	
	createIterativeResult: function(options) {
		var type = options.type || 'browse',
			query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '/' + type + '?' + infa.utils.Utils.instance().getTokenParam(),
			self = this;
		
		if(type == 'query') {
			this._queryResultSets.push({
				storage: options.storage,
				resultSetName: options.resultSetName
			});
		}

		return $.ajax({
			type : 'PUT',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text",
			data: $.toJSON(options.data)
		});
	},
	
	/**
	 * Delete iterative result set
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''
	 * }
	 * 
	 * @return promise 
	 */	
	removeIterativeResult: function(options) {
		var type = options.type || 'browse',
			query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '?' + infa.utils.Utils.instance().getTokenParam();

		return $.ajax({
			type : 'DELETE',
			url: $.url(query)
		});
	},	


	/**
	 * Get iterative results count
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''	
	 * }
	 * 
	 * @param {{storage, resultSetName}} options
	 * @return promise
	 */	
	getIterativeResultCount: function(options) {
		var query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '/count?' + infa.utils.Utils.instance().getTokenParam();
		return $.ajax({
			type : 'GET',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text"
		});	
	},

	/**
	 * Fetch the lwObjects from iterative results.
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''	
	 *		startIndex		: '',
	 *		endIndex		: '',
	 *		typeName		: qualified|logical (qualified with output as ids with a map on what the ids mean. Logical outputs simple registered names)
	 *		idForm			: 1 | 2 | 3 (objectid, identity, generated), 
	 *		flat			: true | false,
	 *		verbose			: true | false,
	 * }
	 * 
	 * @param {{storage, resultSetName, startIndex, endIndex, flat, verbose, idForm}} options
	 * @param (optional parameter) objectCacheMgr
	 * @return promise which returns array of lwObjects when promise is resolved
	 */
	getLwObjectsFromIterativeResults : function(options, objectCacheMgr){
		var $deferred = $.Deferred(),
		storage = options.storage, 
		resultSetName = options.resultSetName,
		startIndex = options.startIndex,
		endIndex = options.endIndex,
		typeName = (options.typeName ? options.typeName : 'qualified'),
		flat = (options.flat ? options.flat : true), 
		verbose = options.verbose, 
		idForm = options.idForm,	
		query = '/w3.model/lightweight/' + storage + '/' + resultSetName + '/' + startIndex;
		
		if(endIndex) {
			query += '-' + endIndex;
		}
		
		query += '/?' + infa.utils.Utils.instance().getTokenParam() + '&typeName=' + typeName + '&flat=' + flat;	

		if (idForm) {
			query = query + '&idForm=' + idForm;
		}		

		if (verbose) {
			query = query + '&verbose=' + verbose;
		}
		$.ajax({
			type : 'GET',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text",
			success: function(lwObjects){
				if(objectCacheMgr) {
					lwObjects = objectCacheMgr.cacheLwObject(lwObjects, storage, idForm);
				}
				$deferred.resolve(lwObjects);
			},
			failure: function(data){
				$deferred.resolve([]);
			},
			error : function(jqXHR, textStatus, errorThrown) {				
				$deferred.reject(jqXHR, textStatus, errorThrown);
			}
		});	

		return $deferred.promise();
	},
	
	/**
	 * Get iterative results facets
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: ''	
	 * }
	 * 
	 * @param {{storage, resultSetName}} options
	 * @return promise
	 */	
	getIterativeResultFacets: function(options) {
		var query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '/facets?' + infa.utils.Utils.instance().getTokenParam();
		return $.ajax({
			type : 'GET',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text"
		});	
	},
	

	
	/**
	 * Get iterative result index
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		objId	: '',
	 *		metaClassId: ''
	 *		idForm	: 1 | 2 | 3 (objectid, identity, generated)
	 * }
	 * 
	 * @param {{storage, resultSetName, objId, metaClassId}} options
	 * @return promise
	 */	
	getIterativeResultIndex: function(options) {
		var query = '/w3.model/lightweight/' + options.storage + '/' + 
							options.resultSetName + '/index' + 
							'/' + options.objId + '@' + options.metaClassId + '?' + infa.utils.Utils.instance().getTokenParam();
		
		if (options.idForm) {
			query = query + '&idForm=' + options.idForm;
		}
		
		return $.ajax({
			type : 'GET',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text"
		});	
	},
	
	/**
	 * Remove the item in the Result Set 
	 * 
	 * Use LightWeightProviderServlet
	 *  DELETE /lightweight/mrs1/result1/20	 removes item at index 20 from the resultset
	 *  DELETE /lightweight/mrs1/result1/20,35,42 removes items at index 20, 35 and 42 from the resultset
	 * 
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		index			: number or Array of number
	 * }
	 * 
	 * @param {{storage, resultSetName, index}} options
	 * @return promise
	 */	
	removeIterativeResultItem: function(options) {
		var query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '/',
			indexValue;
		
		if($.isArray(options.index)) {
			$.each(options.index, function(i,ind) {
				if(typeof indexValue == "undefined") {
					indexValue =  ind;	
				} else {
					indexValue =  indexValue + ',' + ind;
				}				
			});
		} else {
			indexValue = options.index;
		}		
		
		query +=  indexValue + '/?' + infa.utils.Utils.instance().getTokenParam();
		return $.ajax({
			type : 'DELETE',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text"
		});	
	},

	/**
	 * Add the item in the Result Set 
	 * 
	 * Use below REST URL
	 *     PUT /lightweight/mrs1/result1/10 - Adds these items starting at index 10.
	 *     [
	 *     		{
	 *            [$$OID|$$IID]: [10|U:w-f-V8evEeC9Iu4hf_YhEA]
	 *            [$$class|$$type]: [20|Mapping]
	 *          }
	 *          ...
	 *     ]
	 *     
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		index			: number or Array of number,
	 *		data			: []  e.g. [{$ID: 10, $$class: 20},..]
	 * }
	 * 
	 * @param {{storage, resultSetName, index}} options
	 * @return promise
	 */	
	addIterativeResultItem: function(options) {
		var query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '/' + options.index + '?' + infa.utils.Utils.instance().getTokenParam();
				
		return $.ajax({
			type : 'PUT',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text",
			data: $.toJSON(options.data)
		});	
	},


	/**
	 * Updated the item in the Result Set 
	 * 
	 * Use below REST URL
	 *     POST /lightweight/mrs1/result1/10 
	 *     		{
	 *            [$$OID|$$IID]: [10|U:w-f-V8evEeC9Iu4hf_YhEA]
	 *            [$$class|$$type]: [20|Mapping]
	 *          }
	 *     
	 * options - {
	 *		storage			: '', 
	 *		resultSetName	: '',
	 *		index			: number or Array of number,
	 *		data			: {}  e.g. {$ID: 10, $$class: 20}
	 * }
	 * 
	 * @param {{storage, resultSetName, index}} options
	 * @return promise
	 */	
	updateIterativeResultItem: function(options) {
		var query = '/w3.model/lightweight/' + options.storage + '/' + options.resultSetName + '/' + options.index + '?' + infa.utils.Utils.instance().getTokenParam();
				
		return $.ajax({
			type : 'POST',
			url: $.url(query), 
			contentType: 'application/json',
			datatype: "text",
			data: $.toJSON(options.data)
		});	
	},
	
	/**
	 * Fetch the lwObjects from server.
	 * 
	 * options - {
	 *		storage	: '', 
	 *		typeName: qualified|logical (qualified with output as ids with a map on what the ids mean. Logical outputs simple registered names)
	 *		flat	: true | false, 
	 *		verbose : true | false, 
	 *		idForm	: 1 | 2 | 3 (objectid, identity, generated), 
	 *		cached	: true/false,
	 *		lwObject: '',
	 *		what: self | children | descendants  (default is descendants)
	 * }
	 * 
	 * @param {{storage, flat, verbose, idForm, cached}} options
	 * @param (optional parameter) objectCacheMgr
	 * @return promise which returns array of lwObjects when promise is resolved
	 */
	getLwObjects : function(options, objectCacheMgr){
		var self = this,
		storage = options.storage, 
		typeName = (options.typeName ? options.typeName : 'qualified'),
		flat = (options.flat ? options.flat : true), 
		verbose = options.verbose, 
		idForm = options.idForm,
		what = options.what,
		cached = options.cached,
		lwObject = options.lwObject,
		query = '/w3.model/lightweight/' + storage,
		$$classes = options.$$classes,
		$$types = options.$$types;

		if(objectCacheMgr && cached) {
			var cachedObjs = objectCacheMgr.retrieve(storage);
			if(cachedObjs && cachedObjs.length > 0) {
				return $.Deferred().resolve(cachedObjs).promise();
			}
		}		
		
		if(lwObject && lwObject.$$class) {
			var objId;
			if ('$$IID' in lwObject) {
				objId = lwObject.$$IID;
			} else if ('$$OID' in lwObject) {
				objId = lwObject.$$OID;
			} else if ('$$ID' in lwObject) {
				objId = lwObject.$$ID;	
			}			
			if(objId) {
				query = query + '/' + objId + '@' + lwObject.$$class;	
			}			
		}
		
		query = query + '/?' + infa.utils.Utils.instance().getTokenParam() + '&typeName=' + typeName + '&flat=' + flat;		

		if (idForm) {
			query = query + '&idForm=' + idForm;
		}		

		if (verbose) {
			query = query + '&verbose=' + verbose;
		}
		
		if(what) {
			query = query + '&what=' + what;
		}
		
		if($$classes){
			query = query + '&$$classes=' + $$classes;
		}
		if($$types){
			query = query + '&$$types=' + $$types;
		}
		

		return $.getJSON($.url(query)).then(function(lwObjects){
			if (objectCacheMgr) {
				return objectCacheMgr.cacheLwObject(lwObjects, storage, idForm);
			}
			return lwObjects;
		});	
	},

	/**
	 * Fetch the object from server.
	 * 
	 * options - {
	 *		objId	: '',
	 *		metaClassId: '',
	 *		storage	: '', 
	 *		flat	: true/false, 
	 *		verbose : true/false, 
	 *		idForm	: 1/2/3, 
	 *		cached	: true/false, 
	 *		force	: true/false
	 * }
	 * 
	 * @param {{objId, metaClassId, storage, idForm, dependencies, translateMetaClassId}} options
	 * @param (optional parameter) objectCacheMgr
	 * @return promise which returns object when promise is resolved.
	 */
	getObject: function(options, objectCacheMgr) {
		var objId = options.objId, 
		metaClassId = options.metaClassId, 
		storage = options.storage, 
		idForm = options.idForm, 
		dependencies = (options.dependencies !== undefined ? options.dependencies : true), 
		translateMetaClassId = options.translateMetaClassId,
		mode = options.mode,
		$deferred = $.Deferred();

		var objectGetterInstance = infa.model.ObjectGetter.instance();			
		$.when(objectGetterInstance.blockObjectGet(objId, metaClassId, storage, idForm, dependencies, translateMetaClassId)).done(function(object){					
			if(objectCacheMgr) {
				object = objectCacheMgr.cacheObject(object, options);
			}
			$deferred.resolve(object);
		}).fail(function(arg) {
			$deferred.reject(arg);
		});
		return $deferred.promise();
	},
	
	onUnLoad: function(){
		var self = this;
		//Delete all Query Result Sets to clear the DB Cache
		$.each(this._queryResultSets, function(index, resultSetOpts) {
			self.removeIterativeResult(resultSetOpts);
		});
	}
}
);
/**
 * @author clam
 * 
 * Query for the access state (e.g. readOnly, visible) of an object.
 */
$.Class('infa.model.access.ObjectAccessManager',
// static methods 
{  
	_instance : undefined,
  
	instance : function(){
		if (!infa.model.access.ObjectAccessManager._instance) {
			infa.model.access.ObjectAccessManager._instance = new infa.model.access.ObjectAccessManager();
		}
		return infa.model.access.ObjectAccessManager._instance;
	}        
},
// prototype methods
{
	/**
	 * @param id the id of the object
	 * @param metaClass the metaClass of the object
	 * @param storage the id of the storage associated with the object 
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the object is read only. A 
	 * message field is also present to provide more detail about why the object is read only.
	 */
	isReadOnly: function(id, metaClass, storage, idForm, elemID) {
		var $deferred = $.Deferred();
		var query = '/w3.model/object/' + storage + '/' + id + '@' + metaClass + '/access?' 
			+ infa.utils.Utils.instance().getTokenParam() + '&state=readOnly';
		if (idForm) {
			query = query + '&idForm=' + idForm;
		}
		$.blockGetJSON(query, null, null, elemID).done(function(objects) {
			if (objects.length == 1) {
				$deferred.resolve(objects[0].state.readOnly);
			} else {
				$deferred.reject();
			}
		});
		
		return $deferred.promise();
	},
	
	/**
	 * @param id the id of the object
	 * @param metaClass the metaClass of the object
	 * @param storage the id of the storage associated with the object 
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the object is visible.
	 */
	isVisible: function(id, metaClass, storage, idForm, elemID) {
		var $deferred = $.Deferred();
		var query = '/w3.model/object/' + storage + '/' + id + '@' + metaClass + '/access?'
		 	+ infa.utils.Utils.instance().getTokenParam() + '&state=visible';
		if (idForm) {
			query = query + '&idForm=' + idForm;
		}
		$.blockGetJSON(query, null, null, elemID).done(function(objects) {
			if (objects.length == 1) {
				$deferred.resolve(objects[0].state.visible);
			} else {
				$deferred.reject();
			}
		});
		return $deferred.promise();
	},

	/**
	 * @param id the id of the object
	 * @param metaClass the metaClass of the object
	 * @param storage the id of the storage associated with the object 
	 * @param actionId the action if to be queried
	 * @param elemID the element to block
	 * @return a deferred object with the value true indicates the object is allowed.
	 */
	isAllowed: function(id, metaClass, storage, actionId, idForm, elemID) {
		var $deferred = $.Deferred();
		var query = '/w3.model/object/' + storage + '/' + id + '@' + metaClass + '/access?'
		 	+ infa.utils.Utils.instance().getTokenParam() + '&state=' + actionId;
		if (idForm) {
			query = query + '&idForm=' + idForm;
		}
		$.blockGetJSON(query, null, null, elemID).done(function(objects) {
			if (objects.length == 1) {
				$deferred.resolve(objects[0].state[actionId]);
			} else {
				$deferred.reject();
			}
		});
		return $deferred.promise();
	}, 
	
	/**
	 * Based on the state(s) specified, return the value of the state(s) for each of the given
	 * objects.  If an object is not visible, and the readOnly state is also requested, the readOnly 
	 * state will not be returned as it is not applicable. Consumers should not request the allowed state with 
	 * any of the other states (visible, readOnly), as they compare different entities.
	 * 
	 * @param {Array.<{$$IID, $$OID, $$class}>} objects an array of objects, each having id and type
	 * @param {string} storage 
	 * @param {Object.<{visible, readOnly, actionIds}>} states: object with properties that map to booleans of whether or not the state is requested. If the state is not present, assumes false.
	 * 	the actionIds property can map to an array of action ids to request their allowed state  
	 * @param elemID the element to block
	 * @return a deferred object which represents an array of object states,. Each state object 
	 * has the properties id, type, readOnly or visible based on the corresponding values specified 
	 * or requested in the parameter. 
	 */
	getState: function(objects, storage, idForm, states, elemID) {
		
		var $deferred = $.Deferred();

		if (states.actionIds && (states.readOnly || states.visible)) {
			return $deferred.resolve(); // requested actionIds and readOnly or visible at the same time
		}
		
		var bulk = true, urlPath = '/';
		if (bulk) {
			urlPath = urlPath + '~';
		} else {
			var id = objects[0].$$IID ? objects[0].$$IID : objects[0].$$OID;
			urlPath = urlPath + this._getString(id, objects[0].$$class);
			for (var i = 1; i < objects.length; i++) {
				id = objects[i].$$IID ? objects[i].$$IID : objects[i].$$OID;
				urlPath = urlPath + ',' + this._getString(id, objects[i].$$class);
			}
		}
		
		var query = '?' + infa.utils.Utils.instance().getTokenParam() + '&state=';
		if (states.readOnly){
			query = query + 'readOnly,';
		} 
		if (states.visible){
			query = query + 'visible,';
		}
		if (states.actionIds){
			if ($.isArray(states.actionIds)){
				for (var i = 0; states.actionIds.length; i++){
					query = query + states.actionIds[i] + ',';
				}
			}
		}
		query = query.slice(0, query.length-1); // remove last comma
		
		if (idForm) {
			query = query + '&idForm=' + idForm;
		}
		
		var url = '/w3.model/object/' + storage + urlPath + '/access' + query,
		    data;
		if (bulk) {
			data = $.toJSON(objects);
		}
		
		$.ajax({
			type : bulk ? 'POST' : 'GET',
			url: $.url(url), 
			data: data,
  			contentType: 'application/json',
	  		datatype: "text"})
	  		.done(function(objects) {
	  			if (objects.length > 0) {
					$deferred.resolve(objects);
				} else {
					$deferred.reject();
				}
	  		})
	  		.always(function() {$.unblockElem(elemID)});
		return $deferred.promise();
	},
	
	_getString: function(id, type) {
		return id + '@' + type;
	}
}
);
/**
 * Query for the validity of an object.
 */
$.Class('infa.model.validation.ObjectValidationManager', 
// static methods
{
	_instance: undefined, 
	
	instance: function(){
		if (!infa.model.validation.ObjectValidationManager._instance){
			infa.model.validation.ObjectValidationManager._instance = new infa.model.validation.ObjectValidationManager();
		}
		return infa.model.validation.ObjectValidationManager._instance;
	}
	
}, 

// prototype methods
{
	/**
	 * @param id the id of the object, can be an array of ids
	 * @param metaClass the metaClass of the object, can be an array of metaClasses
	 * @param storage the id of the storage associated with the id/metaClass. One storage at a time.  
	 * @return a deferred object which represents the validation diagnostics. If a single id/metaclass was provided, the returned value will 
	 * be an array of all the diagnostics. If multiple id/metaclasses were passed, the returned value will be an array of an array of diagnostics
	 * where the first index is the array of the diagnostics for the first object, etc. 
	 */
	
	isValid: function(id, metaClass, storage){
		if (($.isArray(id) && $.isArray(metaClass)) && (id.length !== metaClass.length)){
			return;
		}
		var $deferred = $.Deferred(), 
			query = '/w3.model/object/' + storage + '/',  
			i, tempId, tempMetaClass, length = ($.isArray(id)) ? id.length : undefined;
		if (length){
			for (i = 0; i < id.length; i++){
				tempId = id[i];
				tempMetaClass = metaClass[i];
				query = query + tempId + '@' + tempMetaClass + ((i != id.length-1) ? ',' : '');
			}
		} else {
			query = query + id + '@' + metaClass;
		}
		query = query + '/validation?' + infa.utils.Utils.instance().getTokenParam();
		
		$.blockGetJSON(query, null, null, null).done(function(objects){ // json array from java side
			if (!length && objects.length == 1){
				$deferred.resolve(objects[0]); // give all diagnostics, since caller only gave 1 object
			} else if (objects.length == length){
				$deferred.resolve(objects) // give an array of all diagnostics (ie first index is list of all diagnostics for first object, etc)
			} else {
				$deferred.reject();
			}
		});
		return $deferred.promise();

	},

	/**
	 * @param objects either a singular object or an array of objects to be validated. These objects will not be fetched from the core model and 
	 *  	          will be validated as is. 
	 * @param storage the id of the storage associated with the objects. One storage at a time.  
	 * @return a deferred object which represents the validation diagnostics. If a single object was provided, the returned value will 
	 * be an array of all the diagnostics. If multiple objects were passed, the returned value will be an array of an array of diagnostics
	 * where the first index is the array of the diagnostics for the first object, etc. 
	 */
	isUnsavedValid: function (objects, storage){
		var $deferred = $.Deferred(), 
			query = '/w3.model/object/' + storage + '/~/validation?' + infa.utils.Utils.instance().getTokenParam(), 
			length = ($.isArray(objects)) ? objects.length : undefined,
			data = this.serializeObjects(objects); // serialize the objects before sending to ajax
		
		$.ajax({
			type: 'POST',
			url: $.url(query),
			data: data,
			contentType: 'application/json',
			datatype: 'text'
		}).done(function (diagnosticArray){
			if (!length && diagnosticArray.length == 1){
				$deferred.resolve(diagnosticArray[0]);
			} else if (diagnosticArray.length == length){
				$deferred.resolve(diagnosticArray)
			} else {
				$deferred.reject();
			}
		}).fail(function(){
			$deferred.reject();
		});
		return $deferred.promise();
	}, 
	
	serializeObjects : function(objects, subsetter){
		  if (!($.isArray(objects))){
			  objects = [objects];
		  }
		  var idType = 3;
		  if ('$$IID' in objects[0]) {
			  idType = 1;
		  } else if ('$$OID' in objects[0]) {
			  idType = 2;
		  } else if ('$$ID' in objects[0]) {
			  idType = 3;	
		  }
		  return infa.imf.Serializer.instance().serializeObjects(objects, idType, false, subsetter);	  	  	 

	  }
}) 

// util to parse failure object expression
$.Class('infa.model.validation.ValidationUtils', 
{
	_instance: undefined,
	_expressionDelimiter : '/',

	instance : function(){
		if (!infa.model.validation.ValidationUtils._instance) {
			infa.model.validation.ValidationUtils._instance = new infa.model.validation.ValidationUtils();
		}
		return infa.model.validation.ValidationUtils._instance;
	}

}, 
{
	getFailureObject : function (rootObject, failureExpression){
		if (failureExpression.length == 0){
			return rootObject; // empty expression means failureObject is the rootObject
		}
		var properties = failureExpression.split(infa.model.validation.ValidationUtils._expressionDelimiter), 
			currObject = rootObject, 
			propertyInfo = {
				property : '',
				index : -1
			}, 
			i, 
			property;
		
		for (i = 0; i < properties.length; i++){
			property = properties[i];
			this._getPropertyAndIndex(property, propertyInfo);
			if (propertyInfo.index != -1){
				currObject = currObject[propertyInfo.property][propertyInfo.index];
			} else {
				currObject = currObject[property];
			}
		}
		return currObject == rootObject ? undefined : currObject; // if currObject is still rootObject, something went wrong
	},
	
	_getPropertyAndIndex : function (propertyExpression, propertyInfo) {
		var splitArray = propertyExpression.split(/[\[\]]+/); // split around a potential propertyName[0] so that we are left with 'propertyName', '0'
		if (splitArray.length > 1){
			propertyInfo.property = splitArray[0]; 
			propertyInfo.index = splitArray[1];
		} else {
			propertyInfo.property = '';
			propertyInfo.index = -1;
		}
	}
	
})
	
