$.infaNamespace('infaw.dataPreview');
(function( $ ){
infaw.dataPreview.I18nResources = {
  PREVIEW_ERROR : 'Cannot preview the data because of an internal error. Contact an administrator to check the service logs for more information. ',
  DETAILS : 'Details'
  
}}(jQuery));

/**
 * Performs data preview of an object.
 */
$.Class('infa.preview.ObjectPreviewManager', 
// static methods
{
	_instance: undefined, 
	
	instance: function(){
		if (!infa.preview.ObjectPreviewManager._instance){
			infa.preview.ObjectPreviewManager._instance = new infa.preview.ObjectPreviewManager();
		}
		return infa.preview.ObjectPreviewManager._instance;
	}
	
}, 

// prototype methods
{
//	/**
//	 * @param id the id of the object, can be an array of ids
//	 * @param metaClass the metaClass of the object, can be an array of metaClasses
//	 * @param storage the id of the storage associated with the id/metaClass. One storage at a time.  
//	 * @return a deferred object which represents the validation diagnostics. If a single id/metaclass was provided, the returned value will 
//	 * be an array of all the diagnostics. If multiple id/metaclasses were passed, the returned value will be an array of an array of diagnostics
//	 * where the first index is the array of the diagnostics for the first object, etc. 
//	 */
//	
//	isValid: function(id, metaClass, storage){
//		if (($.isArray(id) && $.isArray(metaClass)) && (id.length !== metaClass.length)){
//			return;
//		}
//		var $deferred = $.Deferred(), 
//			query = '/w3.model/object/' + storage + '/',  
//			i, tempId, tempMetaClass, length = ($.isArray(id)) ? id.length : undefined;
//		if (length){
//			for (i = 0; i < id.length; i++){
//				tempId = id[i];
//				tempMetaClass = metaClass[i];
//				query = query + tempId + '@' + tempMetaClass + ((i != id.length-1) ? ',' : '');
//			}
//		} else {
//			query = query + id + '@' + metaClass;
//		}
//		query = query + '/validation?' + infa.utils.Utils.instance().getTokenParam();
//		
//		$.blockGetJSON(query, null, null, null).done(function(objects){ // json array from java side
//			if (!length && objects.length == 1){
//				$deferred.resolve(objects[0]); // give all diagnostics, since caller only gave 1 object
//			} else if (objects.length == length){
//				$deferred.resolve(objects) // give an array of all diagnostics (ie first index is list of all diagnostics for first object, etc)
//			} else {
//				$deferred.reject();
//			}
//		});
//		return $deferred.promise();
//
//	},

	/**
	 * @param objects either a singular object or an array of objects to be validated. These objects will not be fetched from the core model and 
	 *  	          will be validated as is. 
	 * @param storage the id of the storage associated with the objects. One storage at a time.  
	 * @param configuration the preview configuration object (e.g. {maxdisplayrows: 100})
	 * @return a deferred object which represents the validation diagnostics. If a single object was provided, the returned value will 
	 * be an array of all the diagnostics. If multiple objects were passed, the returned value will be an array of an array of diagnostics
	 * where the first index is the array of the diagnostics for the first object, etc. 
	 */
	previewUnsaved: function (object, storage, resultSetName, configuration){
		var self = this;
		return self._createPreviewResultSet(object, storage, resultSetName, configuration).then(function() {
			return self._getResult(storage, resultSetName);
		});
	}, 
	
	
	/**
	 * @param objects id or object identity
	 * @param meta class id 
	 * @param storage the id of the storage associated with the objects. One storage at a time.  
	 * @param configuration the preview configuration object (e.g. {maxdisplayrows: 100})
	 * @return a deferred object which represents the validation diagnostics. If a single object was provided, the returned value will 
	 * be an array of all the diagnostics. If multiple objects were passed, the returned value will be an array of an array of diagnostics
	 * where the first index is the array of the diagnostics for the first object, etc. 
	 */
	preview: function (Id, metaClass, storage, resultSetName, configuration){
		var self = this;
		return self._createPreviewResultSet2(Id, metaClass, storage, resultSetName, configuration).then(function() {
			return self._getResult(storage, resultSetName);
		});
	}, 
	
	
	cancelPreview: function(storage, resultSetName) {
		return $.ajax({
			type : 'DELETE',
			url: $.url('/w3.preview/object/' + storage + '/' + resultSetName)
		});
	},
	
	_createPreviewResultSet: function(object, storage, resultSetName, configuration) {
		var $deferred = $.Deferred(), 
			data = this._serializeObject(object); // serialize the objects before sending to ajax
		
		var objectJSONStr =  '{"object":' + data + '}';			
		var payLoad = $.extend(JSON.parse(objectJSONStr), {configuration: configuration});
	    var payLoadData = JSON.stringify(payLoad);

		$.ajax({
			type: 'PUT',
			url: $.url('/w3.preview/object/' + storage + '/' + resultSetName),
			data: payLoadData,
			contentType: 'application/json',
			datatype: 'text'
		}).done(function(data) {
			$deferred.resolve();
		}).fail(function(){
			$deferred.reject();
		});
		return $deferred.promise();
	},
	
	_createPreviewResultSet2: function(Id, metaClass, storage, resultSetName, configuration) {
		
		var payLoad = {configuration: configuration};
	    var payLoadData =  JSON.stringify(payLoad);
	    
		var $deferred = $.Deferred();
		$.ajax({
			type: 'PUT',
			url: $.url('/w3.preview/object/' + storage + '/' + Id + '@' + metaClass + '/' + resultSetName),
			data: payLoadData,
			contentType: 'application/json',
			datatype: 'text'
		}).done(function(data) {
			$deferred.resolve();
		}).fail(function(){
			$deferred.reject();
		});
		return $deferred.promise();
	},
	
	_getResult: function(storage, resultSetName) {
		return $.ajax({
			type : 'GET',
			url: $.url('/w3.preview/object/' + storage + '/' + resultSetName), 
			contentType: 'application/json',
			datatype: "text"
		});	
	},
	
	_serializeObject: function(object) {
		var idType = 3;
		if ('$$IID' in object) {
			idType = 1;
		} else if ('$$OID' in object) {
			idType = 2;
		} else if ('$$ID' in object) {
			idType = 3;	
		}
		return infa.imf.Serializer.instance().serializeObject(object, idType, false);	  	  	 
	}
}) 

(function ($) {

// Custom selector
$.extend($.expr[':'].infaDataPreview = function (obj){
	var widgetInst = $.getWidget($(obj), 'infaDataPreview');
	return widgetInst ? true : false;
});
	
$.widget('infa.infaDataPreview',  {	
    options: {   	
    	label: "Data Preview",
    	configuration: {maxdisplayrows: 1000},
    	refreshButton: true,
    	cancelButton: true,
    	lazy: false,
    	minimumColumnWidth: 0,
		storage: 'browse'
	},	
	
	_bundle: infaw.preview.I18nResources,
	
	_getNewID : function()	{
		return $.htmlId('idp');  //idp => Infa Data Preview
	},
	
    _create: function() {    
	
    	this.idForm = 1;
    	this.resultSetName = 'result';	
    			
		this.isCancelled = false;
		
		this.element.addClass('infaDataPreview');		
	
		var $topBarDiv = $('<div></div>').appendTo(this.element);
		$topBarDiv.addClass('dataPreviewTopbar');    
		var $labelDiv = $('<div>' + this.options.label + '</div>').appendTo($topBarDiv);        
		$labelDiv.addClass('dataPreviewLabel');     
				
		if(this.options.refreshButton === true){ //default: no refresh button
			var $refreshBtnDiv = $('<div></div>').appendTo($topBarDiv);	    
			$refreshBtnDiv.addClass('dataPreviewBtn')   	    
			var $refreshBtn =
				$refreshBtnDiv.infaButton({shape: 'iconic', icon:$.url('/web.preview/images/refresh.svg')});

			this.refreshBtn = $.getWidget($refreshBtn, 'infaButton');
			
			this.refreshBtn.setTooltip('refresh');

			var self = this;
			$refreshBtn.on('onSelect', function(event){     	
				if(!self.obj || self.columnNames.length===0)
				    return;		
				if(self.dataGrid)
					self.dataGrid.loadData();	
				else
					self._populateDataGrid();
			});
		}
		
		if (this.options.cancelButton === true){ //default: show cancel button
			var $cancelBtnDiv = $('<div></div>').appendTo($topBarDiv);	    
			$cancelBtnDiv.addClass('dataPreviewBtn')   	    
			var $cancelBtn =
				$cancelBtnDiv.infaButton({shape: 'iconic', icon:$.url('/web.preview/images/cancel.svg')});

			this.cancelBtn = $.getWidget($cancelBtn, 'infaButton');
			this.cancelBtn.setTooltip('cancel preview');
			this.cancelBtn.disable();

			var self = this;
			$cancelBtn.on('onSelect', function(event){ 
				
				self.isCancelled = true;
				infa.preview.ObjectPreviewManager.instance().cancelPreview(self.options.storage, self.resultSetName);
				if($.getWidget(self.$dataGrid, 'infaDataGrid')){
					self.$dataGrid.infaDataGrid('destroy');	
					self.dataGrid = null;
				}
				
			});
		}
		
		this.gridId = this._getNewID();
		this.$gridContainer = $('<div></div>').appendTo(this.element); 
		this.$dataGrid = $('<div></div>').appendTo(this.$gridContainer); 
		this.$dataGrid.addClass('dataPreviewDataGrid');
		this.$dataGrid.attr('id', this.gridId);
		this.dataGrid = null;
    	
    },
    
    
	previewObject: function(obj, columnNames){		
		this.obj = obj;
		this.columnNames = columnNames;
		this._populateDataGrid();
    },

    
    //this is actually a refresh: destroy the old data grid, create and populate a new data grid
    _populateDataGrid: function(){	
    	    	
    	this._resetGridDiv();
  
		if(!this.obj || this.columnNames.length===0)	
			return;
		
		var self = this;
		
		//prepare column info
		var width = this.$dataGrid.width() - 40;			
		var columnWidth = width/this.columnNames.length;
		if(columnWidth < this.options.minimumColumnWidth) {
			columnWidth = this.options.minimumColumnWidth;
		}
		var columnInfo = [];
		for (var i=0; i<this.columnNames.length; i++) {
			var columnName = this.columnNames[i];
			columnInfo.push({label: columnName, name: columnName, width: columnWidth});
		}

		//prepare row model		
		var rowModel = {
				getRowCount: function(options){					
					return 0;
				},

				getRootObjects: function(options) {
					if(self.options.refreshButton === true)
					    self.refreshBtn.disable();
					if(self.options.cancelButton === true)
						self.cancelBtn.enable();
					
					var $deferred = $.Deferred(),	
					rows = [];

					infa.preview.ObjectPreviewManager.instance().previewUnsaved(self.obj, self.options.storage, self.resultSetName, self.options.configuration).done(function(data) {
						//disable the cancel button
						if(self.options.cancelButton === true)
							self.cancelBtn.disable();

						if(self.isCancelled === true){
							self.isCancelled = false;
							//enable the refresh button
							if(self.options.refreshButton === true)
								self.refreshBtn.enable();					
							$deferred.resolve(rows);
						}

						if(!data){
							//enable the refresh button
							if(self.options.refreshButton === true)
								self.refreshBtn.enable();
							$deferred.resolve(rows);
						}

						for (var i=0; i<data.length; i++){
							var row = {};
							for(var j=0; j<columnInfo.length; j++){
								row[columnInfo[j].name] = $.infa.Validate.cleanXSSContent(data[i][j]);
							}
							rows.push(row);	
						}

						//enable the refresh button
						if(self.options.refreshButton === true)
							self.refreshBtn.enable();
						$deferred.resolve(rows);
						
					}).fail(function(resp){						


						self._resetGridDiv();						
						self.$dataGrid.html( $.getLocalizedText(self._bundle, 'PREVIEW_ERROR') + '<a class="details">' + $.getLocalizedText(self._bundle, 'DETAILS') + '</a>');
						$('.details').click(function(){
							infaw.shell.common.Utils.showMsg(infaw.shell.common.Utils.getErrorMessageFromResponse(resp), $.getLocalizedText(self._bundle, 'DETAILS'));
						});				

						//disable the cancel button
						if(self.options.cancelButton === true)
							self.cancelBtn.disable();

						if(self.isCancelled === true){
							self.isCancelled = false;
						}
						
						//enable the refresh button
						if(self.options.refreshButton === true)
							self.refreshBtn.enable();
						$deferred.resolve([]);
					});

					return $deferred.promise();					
				}
		};		

		//create a new data grid
		this.$dataGrid = $('#' + this.gridId);
		this.$dataGrid.infaDataGrid({
			height: self.$dataGrid.parent().parent().parent().height() - 35,
			width: '100%',
			columnInfo: columnInfo,
			rowModel: rowModel,
			cellEdit: false,
			lazy: self.options.lazy
		});	
		
		this.dataGrid = $.getWidget(this.$dataGrid, 'infaDataGrid');
	},
	
	_resetGridDiv: function(){
	  	if($.getWidget(this.$dataGrid, 'infaDataGrid')){
			this.$dataGrid.infaDataGrid('destroy');				
			this.$gridContainer.empty();
			this.gridId = this._getNewID();
			this.$dataGrid = $('<div></div>').appendTo(this.$gridContainer); 
			this.$dataGrid.addClass('dataPreviewDataGrid');
			this.$dataGrid.attr('id', this.gridId);
			this.dataGrid = null;
    	}
	},
	
	destroy: function(){
		this.element.empty();
		$.Widget.prototype.destroy.call(this);			
	}
	
});

}(jQuery));