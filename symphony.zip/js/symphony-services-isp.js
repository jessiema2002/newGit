$.infaNamespace('infaw.isp');
(function( $ ){
infaw.isp.I18nResources = {
  NAMESPACE : 'Domain',
  LOGOUT_MSG : 'You have been logged out. Close the browser window.',
  VERSION : 'Version 9.6.1',
  COPYRIGHT : 'Copyright © 1993-2015 Informatica LLC. All rights reserved.'
  
}}(jQuery));

/**
 * @author Madhu 
 * ISP Authentication
 */


infaw.common.LoginPageView.extend('infaw.isp.LoginPageView', {
	init: function(options) {
		this._super({
				logo: options.logo,
				logo2: options.logo2,
				namespaces : options.namespaces,
				bgImages : options.bgImages,
				version : options.version,
				modeURL : options.modeURL,
				year : options.year,
				patentMessage: options.patentMessage,
				patentUrl: options.patentUrl,
				errMsg: options.errMsg
		});
	},
	
	getFromFields: function() {
		var fields = this._super();
		if(this._namespaces && this._namespaces.length > 1) {
			fields.splice(2, 0, {
				id:'namespace', 
				label:$.getLocalizedText(infaw.isp.I18nResources, 'NAMESPACE'),
				wType:'infaListbox',
				wOptions: {
					allowNull: false,
					list: this._namespaces,
					value: $.cookie('namespace')
				}
			});
		}
		return fields;
	},
	
	getLoginData: function(){
		var loginData = this._super();
		if(this._namespaces!==null){
			if(!loginData.namespace){
				if(this._namespaces && this._namespaces.length > 0) {
					loginData.namespace = this._namespaces[0].label;
				} else {
					loginData.namespace = '';
				}
			}
			
			$.cookie('namespace', loginData.namespace);
		}
		
		return loginData;
	}
});

/**
 * ISP Kerberos NamespaceView
 */

		
		
		
infaw.common.LoginPageView.extend('infaw.isp.NamespaceView', {
		
	init: function(options) {
		this._super({
				logo : options.logo,
				logo2 : options.logo2,
				namespaces : options.namespaces,
				bgImages : options.bgImages,
				version : options.version,
				modeURL : options.modeURL,
				year : options.year,
				errMsg: options.errMsg
				
		});
		this._namespaces = (options) ? options.namespaces : undefined; 
	},
		
	// getVersion and getCopyright are temporary solution for not being able to get locale-specific copyright and version information
	getVersion: function(){
		var $i18nAlias = infaw.isp.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();
		return $i18nAlias.VERSION;
	},
	
	getCopyright: function(){
		var $i18nAlias = infaw.isp.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();
		return $i18nAlias.COPYRIGHT;
	},


	getFromFields: function() {
		var $i18nAlias = infaw.isp.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
			
		var fields = [];
		
		if(this._namespaces) {
			fields.push({
				id:'namespace', 
				label:$textUtils.getText($i18nAlias.NAMESPACE),
				wType:'infaListbox',
				wOptions: {
					allowNull: false,
					list: this._namespaces
				}
			});			
		}

		// change i18nAlieas to shell.common because LOGIN is present there, not in isp bundle.properties
		$i18nAlias = infaw.shell.common.I18nResources;
		
		fields.push({
			rowSpan: 2,
        	 id:'blogin',
        	 label:'',
        	 wType:'infaButton',
        	 wOptions:{
					label: $textUtils.getText($i18nAlias.LOGIN)
        	 }
        });
		
		return fields;		
		}
});
		

/**
 * Change Password Menu Item Command Handler
 * @author Madhu 
 */

$.Class('infaw.isp.ChangePasswrodCommandHandler', {	
	execute: function(commandId, $eMenu){		
		$.when(this.getChangePasswordURL()).then(function(url){
			if(url) {
				window.open(url);	
			}			
		});
	},
	
	isEnabled: function(commandId, $eMenu) {
		var isKerberosEnabled = $.cookie('isKerberosEnabled');
		if(isKerberosEnabled && isKerberosEnabled === 'true') {
			return false;
		}
		
		var $deferred = $.Deferred(), self = this;
		
		infaw.access.AccessManager.instance().isAllowed(commandId, 'allowed', -1).done(function (result) {
			$deferred.resolve(result.value);
		}).fail(function() {
			$deferred.reject();
		});
		return $deferred.promise();
	},
	
	
	getChangePasswordURL: function() {
		if(this._changePwdURL) {
			return this._changePwdURL;	
		} else {
			return $.getJSON($.url('/web.isp/changePasswordURL?' + infa.utils.Utils.instance().getTokenParam())).then(function(data){
				if(data) {
					return data.changePasswordURL;
				}
			});
		}		
	}
	
	
});
/**
 * @author aditi 
 * Kerberos Logout
 */

$.Class('infaw.isp.LogoutPageView', {
	init: function(options) {
		
		var self = this;
		this.options = options;
		
		this.processCopyRightInformation(options.version,options.year);
		
		this.processBackgroundImage(options.bgImages);
		//using the same as infaPageHeader.htm so that we get styling
		//we have to pass html here itself as $.url is not available on logout
		//and infaPageHeader uses that to get html tmpl
		var logoutPageHtml = '<div class="infaPageHeader"><div class="infaBlackTopBar"><div class="infaPHeaderLogo" data-id="Logo"></div></div><div class="clearer"></div></div>';
		this.$header = $('#LogoutPageHeader').infaPageHeader({
				html: logoutPageHtml
			});
		
		this.$header.find("[data-id='Logo']").html(self._getLogosHTML());
		
		var $i18nAlias = infaw.isp.I18nResources,
			$textUtils = infa.i18n.TextUtils.instance();
		$('.infaLogoutMsg').text($textUtils.getText($i18nAlias.LOGOUT_MSG));
		
		
	},
	
	processBackgroundImage: function(bgImages){
		var randomNum;
		var imageUrl;
		
		if(bgImages !== undefined && bgImages !== null && bgImages.length>0){
			randomNum = Math.floor((Math.random()*bgImages.length));
			imageUrl = bgImages[randomNum][randomNum.toString()];
		}
		else{
			randomNum = Math.ceil(Math.random()*4);
			imageUrl = this.options.defaultImagesUrl +randomNum+'.png';
		}
		
		$("#mainContainer").css({"background-image":"url("+imageUrl+")"});
	},
	
	processCopyRightInformation: function(copyRightVersion, copyRightYear){
		
		var divVersion = 'CopyRightVersion';
		var divYear = 'CopyRightYear';
/*		
		if(copyRightVersion !== undefined){
			$('#'+divVersion).text(copyRightVersion);  
			$('#'+divYear).text(copyRightYear);
			return;
		}
*/			
		var $i18nAlias = infaw.isp.I18nResources,
		$textUtils = infa.i18n.TextUtils.instance();
		$('#'+divVersion).text($textUtils.getText($i18nAlias.VERSION));  
		$('#'+divYear).text($textUtils.getText($i18nAlias.COPYRIGHT));
	},
	
	_getLogosHTML: function(){
    	var h=[];
		h.push('<img src="',this.options.logo,'"/>');
		if(this.options.logo2 && this.options.logo2 !== "" && this.options.logo2 !== undefined){
			h.push('<img src="',this.options.logo2,'"/>');
	    }    	
    	return h.join(''); 
    },    
    
	getFromFields: function() {
		return "";
	}
    
});